             <template>
              Tìm theo
             </template>:</span> 
            <div class="content__search__list check-box-parent"> 
             <div @click="changeRadioSearchWith('notifyNo,bidName')" :class="(quickSearchPayload.searchWith == 'notifyNo,bidName')?'content__search__title__option check-radio-group active':'content__search__title__option check-radio-group'"> 
              <label for="radio-tbmt"> <input id="radio-tbmt" type="radio" name="searchWith" v-model="quickSearchPayload.searchWith" value="notifyNo,bidName" class=""> <span></span> </label> 
              <label class="label" style="font-size: 13px">
               <template>
                Mã TBMT
               </template>/
               <template>
                Tên gói thầu
               </template></label> 
             </div> 
             <div @click="changeRadioSearchWith('planNo,name')" :class="(quickSearchPayload.searchWith == 'planNo,name')?'content__search__title__option check-radio-group active':'content__search__title__option check-radio-group'"> 
              <label for="radio-khlcnt"> <input id="radio-khlcnt" type="radio" name="searchWith" v-model="quickSearchPayload.searchWith" value="planNo,name" class=""> <span></span> </label> 
              <label class="label" style="font-size: 13px">KHLCNT</label> 
             </div> 
             <!--                    <div class="content__search__item check-box-group">--> 
             <!--                        <input type="checkbox" v-model="quickSearchPayload.matchFields"--> 
             <!--                               name="matchFields"--> 
             <!--                               value="investorName" class=""/>--> 
             <!--                        <label class="label" style="font-size: 13px">Chủ đầu tư</label>--> 
             <!--                    </div>--> 
             <div class="content__search__item check-box-group"> 
              <input type="checkbox" name="matchFields" v-model="quickSearchPayload.matchFields" value="procuringEntityName" class=""> 
              <label class="label" style="font-size: 13px">Chủ đầu tư</label> 
             </div> 
             <!--                        <div class="content__search__item check-box-group">--> 
             <!--                            <input type="checkbox" v-model="payload.query.matchFields" @change="actionSearch"--> 
             <!--                                   value="pNoStand" name="check-1" class=""/>--> 
             <!--                            <label class="label">Mã dự án</label>--> 
             <!--                        </div>--> 
            </div> 
            <div> 
             <a @click="downloadGuide()" class="download__guide d-flex justify-content-end"> <span style="text-decoration: underline">Hướng dẫn tìm kiếm</span> <span style="margin-left: 5px;">*</span> </a> 
            </div> 
            <!--                <div style="margin-left: 5px; color: #be8a4b;">*</div>--> 
           </div> 
           <div class="content__search__words"> 
            <span>
             <template>
              Từ khóa
             </template>:</span> 
            <div class="content__search__list check-radio-parent"> 
             <div @click="changeRadioSearchType('all-1')" :class=" (quickSearchPayload.type == 'all-1')?'content__search__item check-radio-group active':'content__search__item check-radio-group'"> 
              <label for="radio-3"> <input id="radio-3" type="radio" value="all-1" v-model="quickSearchPayload.type" name="check-2" class=""> <span></span> </label> 
              <label class="label" style="font-size: 13px">Khớp tất cả từ (Phân biệt dấu)</label> 
             </div> 
             <div @click="changeRadioSearchType('exact')" :class=" (quickSearchPayload.type == 'exact')?'content__search__item check-radio-group active':'content__search__item check-radio-group'"> 
              <label for="radio-4"> <input id="radio-4" type="radio" value="exact" v-model="quickSearchPayload.type" name="check-2" class=""> <span></span> </label> 
              <label class="label" style="font-size: 13px">Khớp chính xác cụm từ</label> 
             </div> 
            </div> 
           </div> 
          </div> 
          <div class="neps neps-right" style=""> 
           <img src="/o/egp-portal-contractor-selection-v2/images/icons/NEPS.png" class="" style=""> 
          </div> 
         </div> 
         <div id="egp-breadcrumb" class="content__wrapper p-0"> 
          <div class="content mt-0"> 
           <nav aria-label="breadcrumb"> 
            <ol class="breadcrumb mb-0 px-0"> 
             <li class="breadcrumb-item inactive" @click="breadcrumbRedirect()"> <a>Trang chủ</a> </li> 
             <li class="breadcrumb-item active"> <a>Thông tin lựa chọn nhà thầu</a> </li> 
            </ol> 
           </nav> 
          </div> 
         </div> 
         <div class="content__wrapper background--white"> 
          <div class="content" v-if="checkLogin &amp;&amp; listUmFilterInfo?.length > 0"> 
           <!--START Nhập từ bộ lọc của tôi--> 
           <div class="content__body__session" style="display: flex; margin-bottom: 16px; align-items: center;"> 
            <div class="content__body__session__title" style="margin-right: 5px;">
             <template>
              Chọn từ bộ lọc của tôi
             </template>:
            </div> 
            <div class="content__body__session__desc"> 
             <div style="display: flex;"> 
              <!--                        <button class="content__footer__btn cancel-choose-filter" @click="onCancelChoose()"  v-if="indexSelect != -1">Bỏ chọn</button>--> 
              <!--                        <button class="content__footer__btn cancel-choose-filter" @click="onCheck()">Check</button>--> 
              <ul class="nav isTag border--none"> 
               <li class="nav-item" v-for="(item, index) in listUmFilterInfo" style="padding: 0px 4px; margin: 4px 0px;"> <a class="tags-tab" @click="onChangeFilter(index)" :class="{ 'active': (indexSelect == index)}"> {{item?.umFilterInfoDTO?.filterName}} 
                 <a-tooltip v-if="indexSelect == index"> 
                  <template #title>
                   Bỏ chọn
                  </template> 
                  <img src="/o/egp-portal-contractor-selection-v2/images/cancel.png" alt="" style="margin-bottom: 2px;margin-left: 2px;" @click="onCancelChoose()"> 
                 </a-tooltip> </a> </li> 
              </ul> 
             </div> 
            </div> 
           </div> 
           <!--END Nhập từ bộ lọc của tôi--> 
          </div> 
          <div class="content"> 
           <template v-if="searchAdvancePayload"> 
            <p></p> 
            <div class="border rounded"> 
             <div class="content__wrapper search__wrap blurText" id="search__wrap"> 
              <div class="d-flex flex-wrap" id="search__box"> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Từ khóa
                 </template>:</span> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="searchAdvancePayload?.keywordDA">--> 
                <!--                                     <span class="text-12-500">--> 
                <!--                                         {{searchAdvancePayload?.keywordDA}}</span>--> 
                <!--                                </div>--> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.keyword"> 
                 <span class="text-12-500">{{searchAdvancePayload.keyword}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.bidName"> 
                 <span class="text-12-500">{{searchAdvancePayload.bidName}}</span> 
                </div> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="searchAdvancePayload?.keywordKH">--> 
                <!--                                     <span class="text-12-500"--> 
                <!--                                     >{{searchAdvancePayload?.keywordKH}}</span--> 
                <!--                                     >--> 
                <!--                                </div>--> 
                <div class="tags-default ml-2 row search__tags__flex" v-for="(item, index) in searchAdvancePayload?.listKeywordCdt" v-if="searchAdvancePayload?.listKeywordCdt"> 
                 <span class="text-12-500">{{item}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-for="(item, index) in searchAdvancePayload?.listKeywordMedicineOld" v-if="searchAdvancePayload?.listKeywordMedicineOld"> 
                 <span class="text-12-500">{{item}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-for="(item, index) in searchAdvancePayload?.listKeywordMedicineNew" v-if="searchAdvancePayload?.listKeywordMedicineNew"> 
                 <span class="text-12-500">{{item}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.listKeywordBmt" v-for="(item, index) in searchAdvancePayload?.listKeywordBmt"> 
                 <span class="text-12-500">{{item}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.keywordGood"> 
                 <span class="text-12-500">{{searchAdvancePayload?.keywordGood}}</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.keywordNttt"> 
                 <span class="text-12-500">{{searchAdvancePayload?.keywordNttt}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Tìm theo
                 </template>:</span> 
                <div class="ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{loadMatchType(searchAdvancePayload?.matchType)}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Loại thông báo
                 </template>: </span> 
                <div class="ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{loadSearchType()}}</span> 
                </div> 
               </div> 
               <!--                            <div class="search__box__tags d-flex flex-wrap">--> 
               <!--                                <span class="text-12-600">Tìm theo:</span>--> 
               <!--                                <div class="ml-2 row search__tags__flex">--> 
               <!--                                    <span class="text-12-500">{{loadMatchType(searchAdvancePayload?.matchType)}}</span>--> 
               <!--                                </div>--> 
               <!--                            </div>--> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Tìm trong
                 </template>:</span> 
                <!-- <template v-for="(i, index) in searchAdvancePayload?.matchFields">--> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordBmt &amp;&amp; searchAdvancePayload?.listKeywordBmt?.length > 0"> 
                 <span class="text-12-500">Tên chủ đầu tư</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordBmt &amp;&amp; searchAdvancePayload?.listKeywordBmt?.length > 0"> 
                 <span class="text-12-500">Mã chủ đầu tư</span> 
                </div> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="searchAdvancePayload.listKeywordCdt && searchAdvancePayload?.listKeywordBmt?.length > 0">--> 
                <!--                                    <span class="text-12-500">Tên chủ đầu tư</span>--> 
                <!--                                </div>--> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="searchAdvancePayload.listKeywordCdt && searchAdvancePayload?.listKeywordBmt?.length > 0">--> 
                <!--                                    <span class="text-12-500">Mã chủ đầu tư</span>--> 
                <!--                                </div>--> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordMedicineOld &amp;&amp; searchAdvancePayload?.listKeywordMedicineOld?.length > 0"> 
                 <span class="text-12-500">Tên hoạt chất</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordMedicineOld &amp;&amp; searchAdvancePayload?.listKeywordMedicineOld?.length > 0"> 
                 <span class="text-12-500">Tên thuốc</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordMedicineNew &amp;&amp; searchAdvancePayload?.listKeywordMedicineNew?.length > 0"> 
                 <span class="text-12-500">Tên dược liệu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordMedicineNew &amp;&amp; searchAdvancePayload?.listKeywordMedicineNew?.length > 0"> 
                 <span class="text-12-500">Tên vị thuốc cổ truyền</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.listKeywordMedicineNew &amp;&amp; searchAdvancePayload?.listKeywordMedicineNew?.length > 0"> 
                 <span class="text-12-500">Tên khoa học</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'tbmt'
                                     || searchAdvancePayload.notiType == 'tbmt-cgttrg'
                                     || searchAdvancePayload.notiType == 'bbmt'
                                     || searchAdvancePayload.notiType == 'kqlcnt'
                                     || (searchAdvancePayload.notiType == 'kqlcnt-medicine' &amp;&amp; searchAdvancePayload.keyword)
                                "> 
                 <span class="text-12-500">Mã TBMT</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'tbmqt'
                                     || searchAdvancePayload.notiType == 'kqmqt'
                                     || searchAdvancePayload.notiType == 'bbmhsqt'  "> 
                 <span class="text-12-500">Mã TBMQT</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'tbmst'
                                     || searchAdvancePayload.notiType == 'bbmst'
                                     || searchAdvancePayload.notiType == 'kqst'"> 
                 <span class="text-12-500">Mã TBMST</span> 
                </div> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="searchAdvancePayload.notiType == 'kqlcnt'">--> 
                <!--                                    <span class="text-12-500">Mã KQLCNT</span>--> 
                <!--                                </div>--> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType != 'khlcnt' &amp;&amp; searchAdvancePayload.notiType != 'es-ycbg'
                                     &amp;&amp; searchAdvancePayload.notiType != 'da' &amp;&amp; searchAdvancePayload.notiType != 'kqlcnt-medicine'"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'kqlcnt-medicine' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt' &amp;&amp; !searchAdvancePayload.bidName"> 
                 <span class="text-12-500">Mã kế hoạch</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt'&amp;&amp; !searchAdvancePayload.bidName"> 
                 <span class="text-12-500">Tên kế hoạch</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt'"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt'"> 
                 <span class="text-12-500">Tóm tắt công việc chính của gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt-tt' &amp;&amp; !searchAdvancePayload.bidName"> 
                 <span class="text-12-500">Mã kế hoạch tổng thể</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'khlcnt-tt'&amp;&amp; !searchAdvancePayload.bidName"> 
                 <span class="text-12-500">Tên kế hoạch tổng thể</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'ycbg' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Mã YCBG</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'ycbg' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Tên YCBG</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'es-bido-interest-notify' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Mã thông báo khảo sát quan tâm</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'es-ct-publish-frame' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Mã thỏa thuận khung</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'es-ct-contract' &amp;&amp; searchAdvancePayload.keyword"> 
                 <span class="text-12-500">Mã hợp đồng</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="!!searchAdvancePayload.bidName"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'da'"> 
                 <span class="text-12-500">Mã dự án</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.notiType == 'da'"> 
                 <span class="text-12-500">Tên dự án</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.keywordNttt"> 
                 <span class="text-12-500">Mã nhà thầu trúng thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.keywordNttt"> 
                 <span class="text-12-500">Tên nhà thầu trúng thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.keywordGood"> 
                 <span class="text-12-500">Tên hàng hóa</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload.keywordGood"> 
                 <span class="text-12-500">Mã hàng hóa</span> 
                </div> 
                <!--                                            </template>--> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.investField?.length > 0"> 
                <span class="text-12-600">
                 <template>
                  Lĩnh vực
                 </template>:</span> 
                <template v-for="(item,index) in searchAdvancePayload?.investField"> 
                 <div class="tags-default ml-2 row search__tags__flex"> 
                  <span class="text-12-500">{{getNameCatByCodeCat(item , catInvestFields)}}</span> 
                 </div> 
                </template> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.workType?.length > 0"> 
                <span class="text-12-600">
                 <template>
                  Loại công trình
                 </template>:</span> 
                <template v-for="(item,index) in searchAdvancePayload?.workType"> 
                 <div class="tags-default ml-2 row search__tags__flex"> 
                  <span class="text-12-500">{{getNameCatByCodeCat(item , workTypes)}}</span> 
                 </div> 
                </template> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.publicDateFrom || searchAdvancePayload?.publicDateTo"> 
                <span class="text-12-600">
                 <template>
                  Thời điểm đăng tải
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.publicDateFrom| formatDate}} - {{searchAdvancePayload?.publicDateTo| formatDate}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.bidCloseFrom || searchAdvancePayload?.bidCloseTo"> 
                <span class="text-12-600">
                 <template>
                  Thời điểm đóng thầu
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.bidCloseFrom| formatDate}} - {{searchAdvancePayload?.bidCloseTo| formatDate}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.bidPriceFrom || searchAdvancePayload?.bidPriceTo"> 
                <span class="text-12-600">
                 <template>
                  Giá gói thầu
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.bidPriceFrom| currency}} VND - {{searchAdvancePayload?.bidPriceTo| currency}} VND</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.investTotalFrom || searchAdvancePayload?.investTotalTo"> 
                <span class="text-12-600">
                 <template>
                  Tổng mức đầu tư/ Dự toán mua sắm
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.investTotalFrom| currency}} VND - {{searchAdvancePayload?.investTotalTo| currency}} VND</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.processApply"> 
                <span class="text-12-600">
                 <template>
                  Quy trình áp dụng
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{getNameCatByCodeCat(searchAdvancePayload?.processApply,processApplies)}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.locationQuan?.length > 0 || searchAdvancePayload?.locationTinh?.length > 0"> 
                <span class="text-12-600">Địa điểm</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{(searchAdvancePayload?.locationQuanName)?searchAdvancePayload?.locationQuanName+" - ":""}} {{searchAdvancePayload?.locationTinhName?.toString()}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.bidMode"> 
                <span class="text-12-600">Phương thức lựa chọn nhà thầu</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{getNameCatByCodeCat(searchAdvancePayload?.bidMode,dmPtlcnt)}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.bidForm"> 
                <span class="text-12-600">Hình thức lựa chọn nhà thầu</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{getNameCatByCodeCat(searchAdvancePayload?.bidForm,bidForms)}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.isInternet?.length > 0"> 
                <span class="text-12-600">Hình thức dự thầu</span> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.isInternet.includes('1')"> 
                 <span class="text-12-500">Qua mạng</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.isInternet.includes('0')"> 
                 <span class="text-12-500">Không qua mạng</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.isDomestic?.length > 0"> 
                <span class="text-12-600">Vùng</span> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.isDomestic.includes('1')"> 
                 <span class="text-12-500">Trong nước </span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.isDomestic.includes('0')"> 
                 <span class="text-12-500">Quốc tế</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numSavingRateFrom || searchAdvancePayload?.numSavingRateTo"> 
                <span class="text-12-600">
                 <template>
                  Tỷ lệ tiết kiệm
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numSavingRateFrom| currency}} % - {{searchAdvancePayload?.numSavingRateTo| currency}} %</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.typePetition?.length > 0"> 
                <span class="text-12-600">
                 <template>
                  Loại kiến nghị
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.typePetition.includes('LCNT_QM')"> 
                 <span class="text-12-500">Những vấn đề liên quan đến e-HSMT</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.typePetition.includes('KQDT')"> 
                 <span class="text-12-500">Những vấn đề liên quan đến quá trình tổ chức LCNT qua mạng</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="searchAdvancePayload?.typePetition.includes('E-HSMT')"> 
                 <span class="text-12-500">Kết quả lựa chọn nhà thầu</span> 
                </div> 
               </div> 
               <!--                            <div class="search__box__tags d-flex flex-wrap"--> 
               <!--                                 v-if="searchAdvancePayload?.numPetitionFrom || searchAdvancePayload?.numPetitionTo">--> 
               <!--                                <span class="text-12-600">Số lần kiến nghị:</span>--> 
               <!--                                <div class="tags-default ml-2 row search__tags__flex">--> 
               <!--                                    <span class="text-12-500">{{searchAdvancePayload?.numPetitionFrom| currency}}  - {{searchAdvancePayload?.numPetitionTo| currency}} </span>--> 
               <!--                                </div>--> 
               <!--                            </div>--> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numPetitionFromEHSMT || searchAdvancePayload?.numPetitionToEHSMT"> 
                <span class="text-12-600">
                 <template>
                  Số lần kiến nghị e-HSMT
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numPetitionFromEHSMT| currency}} - {{searchAdvancePayload?.numPetitionToEHSMT| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numPetitionFromLCNT || searchAdvancePayload?.numPetitionToLCNT"> 
                <span class="text-12-600">
                 <template>
                  Số lần kiến nghị LCNT qua mạng
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numPetitionFromLCNT| currency}} - {{searchAdvancePayload?.numPetitionToLCNT| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numPetitionFromKQLCNT || searchAdvancePayload?.numPetitionToKQLCNT"> 
                <span class="text-12-600">
                 <template>
                  Số lần kiến nghị kết quả
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numPetitionFromKQLCNT| currency}} - {{searchAdvancePayload?.numPetitionToKQLCNT| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numClarifyReqFrom || searchAdvancePayload?.numClarifyReqTo"> 
                <span class="text-12-600">
                 <template>
                  Số lần làm rõ
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numClarifyReqFrom| currency}} - {{searchAdvancePayload?.numClarifyReqTo| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numBidderTechFrom || searchAdvancePayload?.numBidderTechTo"> 
                <span class="text-12-600">
                 <template>
                  Số nhà thầu vượt kỹ thuật
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numBidderTechFrom| currency}} - {{searchAdvancePayload?.numBidderTechTo| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap" v-if="searchAdvancePayload?.numBidderJoinFrom || searchAdvancePayload?.numBidderJoinTo"> 
                <span class="text-12-600">
                 <template>
                  Số nhà thầu tham dự
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{searchAdvancePayload?.numBidderJoinFrom| currency}} - {{searchAdvancePayload?.numBidderJoinTo| currency}} </span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <div class="tags-default ml-2 row search__tags__flex--red" @click="deleteAllAdvancedSearch" style="cursor: pointer"> 
                 <span class="text-12-500">Xóa tất cả</span> 
                </div> 
               </div> 
              </div> 
              <div class="row search__box__button position-relative d-none" id="afterCollapse"> 
               <button class="change__search__button" onclick="handleAdd()" @click="renderSearchAdvance(false)"> <span>Sửa tiêu chí tìm kiếm</span> <img src="/o/egp-portal-contractor-selection-v2/images/icons/icon-edit-white.svg" class="font-weight-lighter" width="12" heght="12"> </button> 
               <button id="button__expand" class="expand__search__button button__expand"> 
                <template>
                 Mở rộng
                </template> 
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                 <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
                </svg> </button> 
               <button id="button__small" class="expand__search__button button__small"> 
                <template>
                 Thu nhỏ
                </template> 
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                 <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
                </svg> </button> 
              </div> 
             </div> 
            </div> 
            <div class="content__wrapper minusTop" id="beforeCollapse"> 
             <div class="row search__box__button position-relative"> 
              <button class="change__search__button" onclick="handleAdd()" @click="renderSearchAdvance(false)"> <span>Sửa tiêu chí tìm kiếm</span> <img src="/o/egp-portal-contractor-selection-v2/images/icons/icon-edit-white.svg" class="icon__small font-weight-lighter"> </button> 
              <button id="button__expand" class="expand__search__button button__expand"> 
               <template>
                Mở rộng
               </template> 
               <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
               </svg> </button> 
              <button id="button__small" class="expand__search__button button__small"> 
               <template>
                Thu nhỏ
               </template> 
               <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
               </svg> </button> 
             </div> 
            </div> 
           </template> 
           <template v-if="!searchAdvancePayload"> 
            <p></p> 
            <div class="border rounded"> 
             <div class="content__wrapper search__wrap blurText" id="search__wrap"> 
              <div class="d-flex flex-wrap" id="search__box"> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Từ khóa
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="textSearch"> 
                 <span class="text-12-500">{{textSearch}}</span> 
                </div> 
               </div> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Tìm theo
                 </template>:</span> 
                <div class="ml-2 row search__tags__flex"> 
                 <span class="text-12-500">{{loadMatchType(quickSearchPayload?.type)}}</span> 
                </div> 
               </div> 
               <!--                            <div class="search__box__tags d-flex flex-wrap">--> 
               <!--                                <span class="text-12-600">Phân loại: </span>--> 
               <!--                                <div class="ml-2 row search__tags__flex">--> 
               <!--                                    <span class="text-12-500">{{loadSearchType()}}</span>--> 
               <!--                                </div>--> 
               <!--                            </div>--> 
               <div class="search__box__tags d-flex flex-wrap"> 
                <span class="text-12-600">
                 <template>
                  Tìm trong
                 </template>:</span> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'planNo,name'"> 
                 <span class="text-12-500">Mã kế hoạch</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'planNo,name'"> 
                 <span class="text-12-500">Tên kế hoạch</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'planNo,name'"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'planNo,name'"> 
                 <span class="text-12-500">Tóm tắt công việc chính của gói thầu</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'notifyNo,bidName'"> 
                 <span class="text-12-500">Mã TBMT</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.searchWith == 'notifyNo,bidName'"> 
                 <span class="text-12-500">Tên gói thầu</span> 
                </div> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="quickSearchPayload.matchFields?.includes('investorName') ">--> 
                <!--                                    <span class="text-12-500">Tên chủ đầu tư</span>--> 
                <!--                                </div>--> 
                <!--                                <div class="tags-default ml-2 row search__tags__flex"--> 
                <!--                                     v-if="quickSearchPayload.matchFields?.includes('investorName')">--> 
                <!--                                    <span class="text-12-500">Mã chủ đầu tư</span>--> 
                <!--                                </div>--> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.matchFields?.includes('procuringEntityName')"> 
                 <span class="text-12-500">Mã chủ đầu tư</span> 
                </div> 
                <div class="tags-default ml-2 row search__tags__flex" v-if="quickSearchPayload.matchFields?.includes('procuringEntityName')"> 
                 <span class="text-12-500">Tên chủ đầu tư</span> 
                </div> 
               </div> 
               <!--                            <div class="search__box__tags d-flex flex-wrap">--> 
               <!--                                <div class="tags-default ml-2 row search__tags__flex&#45;&#45;red" @click="resetAdvancedSearch"--> 
               <!--                                     style="cursor: pointer">--> 
               <!--                                    <span class="text__size font-weight-bold">Xóa tất cả</span>--> 
               <!--                                </div>--> 
               <!--                            </div>--> 
              </div> 
              <div class="row search__box__button position-relative d-none" id="afterCollapse"> 
               <button class="change__search__button" @click="renderSearchAdvance(false)"> <span>Sửa tiêu chí tìm kiếm</span> <img src="/o/egp-portal-contractor-selection-v2/images/icons/icon-edit-white.svg" class="font-weight-lighter" width="12" heght="12"> </button> 
               <button id="button__expand" class="expand__search__button button__expand"> 
                <template>
                 Mở rộng
                </template> 
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                 <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
                </svg> </button> 
               <button id="button__small" class="expand__search__button button__small"> 
                <template>
                 Thu nhỏ
                </template> 
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                 <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
                </svg> </button> 
              </div> 
             </div> 
            </div> 
            <div class="content__wrapper minusTop" id="beforeCollapse"> 
             <div class="row search__box__button position-relative"> 
              <button class="change__search__button" @click="renderSearchAdvance(false)"> <span>Sửa tiêu chí tìm kiếm</span> <img src="/o/egp-portal-contractor-selection-v2/images/icons/icon-edit-white.svg" class="icon__small font-weight-lighter"> </button> 
              <button id="button__expand" class="expand__search__button button__expand"> 
               <template>
                Mở rộng
               </template> 
               <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
               </svg> </button> 
              <button id="button__small" class="expand__search__button button__small"> 
               <template>
                Thu nhỏ
               </template> 
               <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" fill="currentColor" class="bi bi-chevron-compact-down" viewbox="0 0 16 16"> 
                <path fill-rule="evenodd" d="M1.553 6.776a.5.5 0 0 1 .67-.223L8 9.44l5.776-2.888a.5.5 0 1 1 .448.894l-6 3a.5.5 0 0 1-.448 0l-6-3a.5.5 0 0 1-.223-.67z" /> 
               </svg> </button> 
             </div> 
            </div> 
           </template> 
           <template v-if="spinningSearch"> 
            <div style="text-align-last: center; margin-top: 8%; color: #0a314d"> 
             <div class="spinner-border" role="status"> 
              <span class="sr-only">Loading...</span> 
             </div> 
             <div>
              Vui lòng đợi trong giây lát ...
             </div> 
            </div> 
           </template> 
           <template v-if="!spinningSearch"> 
            <div class="row text-danger" v-if="searchAdvancePayload?.notiType == 'tbmt-cgttrg'"> 
             <template>
              Trường hợp cần thay đổi tiêu chí tìm kiếm, nhấn nút Sửa tiêu chí tìm kiếm để thực hiện điều chỉnh.
             </template> 
            </div> 
            <div class="row d-flex justify-content-between"> 
             <div> 
              <label class="text__size text__size__label" v-if="isHideTab">
               <template>
                Tìm thấy
               </template> {{(getQuantityClosedDate() + getQuantityNotCloseDate())| currency}} 
               <template>
                kết quả
               </template> </label> 
              <label class="text__size text__size__label" v-if="!isHideTab">
               <template>
                Tìm thấy
               </template> {{page.totalElements | currency }} 
               <template>
                kết quả
               </template> </label> 
             </div> 
             <div style="margin-top: 16px"> 
              <template>
               Hiển thị
              </template> 
              <select style="border-radius: 5px" v-model="quickSearchPayload.pageSize" @change="changePageSize"> <option value="10">10</option> <option value="20">20</option> <option value="50">50</option> </select> 
              <template>
               bản ghi/ Trang
              </template> 
             </div> 
            </div> 
            <div class="row d-flex justify-content-between" v-if=" !isHideTab &amp;&amp; (quickSearchPayload
                    || searchAdvancePayload.notiType == 'da'
                    || searchAdvancePayload.notiType == 'khlcnt-tt'
                    || searchAdvancePayload.notiType == 'khlcnt') &amp;&amp; searchAdvancePayload?.notiType != 'es-re-offer-price'"> 
             <div class="pagination"> 
              <el-pagination background layout="prev, pager, next" :total="page.totalElements" :page-size="page.pageSize" :current-page="page.currentPage + 1" @current-change="changePage" :page-count="page.totalPages"> 
              </el-pagination> 
             </div> 
            </div> 
            <div class="content__body__left"> 
             <div class="" v-if="isHideTab &amp;&amp; (quickSearchPayload
                    || searchAdvancePayload.notiType == 'tbmt'
                    || searchAdvancePayload.notiType == 'tbmt-cgttrg'
                    || searchAdvancePayload.notiType == 'bbmt'
                    || searchAdvancePayload.notiType == 'kqlcnt'
                    )"> 
              <div class="content__body__left__nav"> 
               <ul class="nav nav-tabs border--none"> 
                <li> <a :class="activeTab=='all'?'active':''" data-toggle="tab" @click="getListAllForTab()">
                  <template>
                   Tất cả
                  </template> ({{(getQuantityClosedDate() + getQuantityNotCloseDate())| currency}})</a> </li> 
                <li class=""> <a :class="activeTab=='open'?'active':''" data-toggle="tab" @click="getListNotYetClose()">
                  <template>
                   Chưa đóng thầu
                  </template>({{(getQuantityNotCloseDate())| currency}}) </a> </li> 
                <li> <a :class="activeTab=='closed'?'active':''" data-toggle="tab" @click="getListClose()">
                  <template>
                   Đã đóng thầu
                  </template> ({{getQuantityClosedDate()| currency}})</a> </li> 
                <div class="d-flex justify-content-around align-items-center"> 
                 <!--                                <h3 class="mb-0">Sắp xếp theo:</h3>--> 
                 <!--                                <select class="border-0">--> 
                 <!--                                    <option>Đăng tải mới nhất</option>--> 
                 <!--                                </select>--> 
                </div> 
               </ul> 
               <div class="pagination"> 
                <el-pagination background layout="prev, pager, next" :total="page.totalElements" :page-size="page.pageSize" :current-page="page.currentPage + 1" @current-change="changePage" :page-count="page.totalPages"> 
                </el-pagination> 
               </div> 
              </div> 
             </div> 
             <div class="" v-if="searchAdvancePayload?.notiType == 'es-re-offer-price'"> 
              <div class="content__body__left__nav"> 
               <ul class="nav nav-tabs border--none"> 
                <li> <a :class="activeReOffer == 'all'?'active':''" data-toggle="tab" @click="getListAllReOffer()">
                  <template>
                   Tất cả
                  </template></a> </li> 
                <li class=""> <a :class="activeReOffer == 'open'?'active':''" data-toggle="tab" @click="getListOpeningReOffer()">
                  <template>
                   Đang diễn ra
                  </template></a> </li> 
                <li> <a :class="activeReOffer == 'upcoming'?'active':''" data-toggle="tab" @click="getListUpcomingReOffer()">
                  <template>
                   Chưa diễn ra
                  </template></a> </li> 
                <li> <a :class="activeReOffer == 'closed'?'active':''" data-toggle="tab" @click="getListClosedReOffer()">
                  <template>
                   Đã có kết quả
                  </template></a> </li> 
                <div class="d-flex justify-content-around align-items-center"> 
                 <!--                                <h3 class="mb-0">Sắp xếp theo:</h3>--> 
                 <!--                                <select class="border-0">--> 
                 <!--                                    <option>Đăng tải mới nhất</option>--> 
                 <!--                                </select>--> 
                </div> 
               </ul> 
               <div class="pagination"> 
                <el-pagination background layout="prev, pager, next" :total="page.totalElements" :page-size="page.pageSize" :current-page="page.currentPage + 1" @current-change="changePage" :page-count="page.totalPages"> 
                </el-pagination> 
               </div> 
              </div> 
              <div class="content__body__left__nav border-0" v-if="activeReOffer != 'all'"> 
               <ul class="nav nav-tabs ml-4"> 
                <li> <a :class="isMultiLotReOffer === 0 ?'active':''" data-toggle="tab" @click="changeMultiLotType(0)"> 
                  <template>
                   Không lô
                  </template> </a> </li> 
                <li> <a :class="isMultiLotReOffer === 1 ?'active':''" data-toggle="tab" @click="changeMultiLotType(1)"> 
                  <template>
                   Có lô
                  </template> </a> </li> 
               </ul> 
              </div> 
             </div> 
             <div class="tab-content w-100"> 
              <!-- NOTICE OF INTEREST SURVEY --> 
              <div id="bid-closed" class="tab-pane active"> 
               <div v-if="isShowClosedStatus &amp;&amp; activeTab=='closed'" class="content__body__option"> 
                <span style="cursor: pointer" :class="(optionActive == 'all')?'active':''" @click="filterTab('all')">Tất cả</span> 
                <span style="cursor: pointer" :class="(optionActive == 'DXT')?'active':''" @click="filterTab('DXT')">
                 <template>
                  Đang xét thầu
                 </template> ({{(getQuantityStatusClosedDate('DXT') + getQuantityStatusClosedDXT())| currency}}) </span> 
                <span style="cursor: pointer" :class="(optionActive == 'CNTTT')?'active':''" @click="filterTab('CNTTT')">
                 <template>
                  Có nhà thầu trúng thầu
                 </template> ({{getQuantityStatusClosedDate('CNTTT')| currency}})</span> 
                <span style="cursor: pointer" :class="(optionActive == 'KCNTTT')?'active':''" @click="filterTab('KCNTTT')">
                 <template>
                  Không có nhà thầu trúng thầu
                 </template> ({{getQuantityStatusClosedDate('KCNTTT')| currency}})</span> 
                <span style="cursor: pointer" :class="(optionActive == 'DHT')?'active':''" @click="filterTab('DHT')">
                 <template>
                  Đã hủy thầu
                 </template>({{getQuantityStatusClosedDate('DHT')| currency}} )</span> 
                <span style="cursor: pointer" :class="(optionActive == '')?'active':''" @click="filterTab('')">
                 <template>
                  Chưa mở thầu
                 </template> ({{(getQuantityStatusCmtBlank() - getQuantityStatusClosedDXT())| currency}} )</span> 
                <span style="cursor: pointer" :class="(optionActive == 'VHH')?'active':''" @click="filterTab('VHH')">
                 <template>
                  Tuyên bố vô hiệu quyết định về KQLCNT
                 </template> ({{getQuantityStatusClosedDate('VHH')| currency}} )</span> 
                <span style="cursor: pointer" :class="(optionActive == 'KCN')?'active':''" @click="filterTab('KCN')">
                 <template>
                  Không công nhận KQLCNT
                 </template> ({{getQuantityStatusClosedDate('KCN')| currency}} )</span> 
                <span style="cursor: pointer" :class="(optionActive == 'DC')?'active':''" @click="filterTab('DC')">
                 <template>
                  Đình chỉ cuộc thầu
                 </template> ({{getQuantityStatusClosedDate('DC')| currency}} )</span> 
               </div> 
               <hr v-if="searchAdvancePayload?.notiType == 'es-bide-contractor-input-result-other'"> 
               <div v-if="searchAdvancePayload?.notiType == 'es-bide-contractor-input-result-other'" class="content__body__option"> 
                <span style="cursor: pointer" :class="(optionActive == 'all')?'active':''" @click="filterTab('all')">Tất cả</span> 
                <span style="cursor: pointer" :class="(optionActive == 'CNTTT')?'active':''" @click="filterTab('CNTTT')">
                 <template>
                  Có nhà thầu trúng thầu
                 </template> ({{getQuantityStatusClosedDate('CNTTT')| currency}})</span> 
                <span style="cursor: pointer" :class="(optionActive == 'KCNTTT')?'active':''" @click="filterTab('KCNTTT')">
                 <template>
                  Không có nhà thầu trúng thầu
                 </template> ({{getQuantityStatusClosedDate('KCNTTT')| currency}})</span> 
                <span style="cursor: pointer" :class="(optionActive == 'DHT')?'active':''" @click="filterTab('DHT')">
                 <template>
                  Đã hủy
                 </template>({{getQuantityStatusClosedDate('DHT')| currency}} )</span> 
               </div> 
               <template v-for="(item,index) in listResultSearch"> 
                <!--Thông báo mời thầu--> 
                <div class="content__body__left__item" v-if="item.type =='es-notify-contractor'" :class="{'text-viewed': checkViewed(item?.notifyNoStand)}"> 
                 <div class="content__body__left__item__infor" v-if="item.bidForm != 'CGTTRG'"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã TBMT
                    </template>: {{item?.notifyNo}}-{{item?.notifyVersion}} </p> 
                   <span :class="getClassStatus(item)">{{getNameStatus(item)}}</span> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-8 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNoStand)" @click="addToViewedList(item?.notifyNoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other format__text"> 
                      <template v-if="item.planType == 'DTPT'"> 
                       <h6 class="format__text" v-if="item?.procuringEntityName"> 
                        <template>
                         Bên mời thầu
                        </template>: <span>{{item?.procuringEntityName}}</span> </h6> 
                       <h6 class="format__text"> 
                        <template>
                         Chủ đầu tư
                        </template>: <span>{{item?.investorName}}</span> </h6> 
                      </template> 
                      <template v-if="item.planType != 'DTPT'"> 
                       <h6 class="format__text" v-if="isPublicAfter2024(item?.publicDate) &amp;&amp; item?.procuringEntityName"> 
                        <template>
                         Bên mời thầu
                        </template>: <span>{{item?.procuringEntityName}}</span> </h6> 
                       <h6 class="format__text"> 
                        <template v-if="!isPublicAfter2024(item?.publicDate)">
                         Chủ đầu tư
                        </template> 
                        <template v-if="isPublicAfter2024(item?.publicDate)">
                         Chủ đầu tư
                        </template> : <span>{{item?.investorName}}</span> </h6> 
                      </template> 
                      <h6 v-if="!checkSearchKqlcnt() &amp;&amp; !checkSearchKqst() &amp;&amp; !checkSearchKqmqt()"> 
                       <template v-if="!item?.caseKHKQ &amp;&amp; item?.notifyVersion == '00'"> 
                        <template>
                         Ngày đăng tải thông báo
                        </template>: 
                        <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}} </span> 
                       </template> 
                       <template v-if="item?.caseKHKQ"> 
                        <template>
                         Ngày đăng tải KQLCNT
                        </template>: 
                        <span>{{item?.publicDateKqlcnt | formatDate}} - {{item.publicDateKqlcnt | formatHour}}</span> 
                       </template> 
                       <template v-if="!item?.caseKHKQ &amp;&amp; item?.notifyVersion != '00'"> 
                        <template>
                         Thời gian sửa TBMT
                        </template>: 
                        <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}} </span> 
                       </template> </h6> 
                      <h6 v-if="checkSearchKqlcnt()"> 
                       <template>
                        Ngày đăng tải KQLCNT
                       </template>: <span>{{item?.publicDateKqlcnt | formatDate}} - {{item.publicDateKqlcnt | formatHour}}</span> </h6> 
                      <h6 v-if="checkSearchKqst()"> 
                       <template>
                        Ngày đăng tải KQST
                       </template>: <span>{{item?.publicDateKqst| formatDate}} - {{item.publicDateKqst | formatHour}}</span> </h6> 
                      <h6 v-if="checkSearchKqmqt()"> 
                       <template>
                        Ngày đăng tải KQMQT
                       </template>: <span>{{item?.publicDateKqst | formatDate}} - {{item.publicDateKqst | formatHour}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6 v-if="item?.investField">
                       <template>
                        Lĩnh vực
                       </template>: <span>{{ item?.investField?.[0] ? (getNameCatByCodeCat(item?.investField,catInvestFields)):(getNameCatByCodeCat(item?.bidField,catInvestFields))}}</span> </h6> 
                      <h6 class="format__text__title" v-if="item.locations"> 
                       <template>
                        Địa điểm
                       </template>: <span v-if="item.locations?.length > 0"> 
                        <template v-for="lc in  item.locations">
                          {{(lc?.districtName)?lc?.districtName+" - ":""}}{{lc?.provName}}; 
                        </template> </span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <template v-if="item?.publicDate &amp;&amp; item.caseKHKQ != 1"> 
                      <p>Thời điểm đóng thầu</p> 
                      <h5>{{item.bidCloseDate | formatHour}}</h5> 
                      <h5>{{item.bidCloseDate | formatDate}}</h5> 
                     </template> 
                     <p>Hình thức dự thầu</p> 
                     <h5> 
                      <template v-if="item.isInternet == 1">
                       Qua mạng
                      </template> 
                      <template v-if="item.isInternet != 1">
                       Không qua mạng
                      </template> </h5> 
                    </div> 
                   </div> 
                   <div class="col-lg-2 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right" v-if="item.statusForNotify != 'DHT' &amp;&amp; item.statusForNotify != 'DHTBMT'"> 
                     <!--                                                <p v-if="(item?.ventureName)?item?.ventureName:item?.contractorName">Nhà--> 
                     <!--                                                    thầu trúng thầu</p>--> 
                     <!--                                                <h5--> 
                     <!--                                                        class="content__body__right__item__infor__contract__right__text"--> 
                     <!--                                                        v-if="(item?.ventureName)?item?.ventureName:item?.contractorName"--> 
                     <!--                                                >--> 
                     <!--                                                    {{(item?.ventureName)?item?.ventureName:item?.contractorName}}--> 
                     <!--                                                </h5>--> 
                     <!--                                                <p v-if="item.bidWinningPrice">Giá trúng thầu (VNĐ)</p>--> 
                     <!--                                                <h5 v-if="item?.bidWinningPrice">{{item?.bidWinningPrice |--> 
                     <!--                                                    currency}}</h5>--> 
                     <p v-if="getTextCnttt(item)">Nhà thầu trúng thầu</p> 
                     <h5 class="content__body__right__item__infor__contract__right__text" v-if="getTextCnttt(item)"> {{getTextCnttt(item)}} </h5> 
                     <p v-if="getPriceCnttt(item)">Giá trúng thầu (VND)</p> 
                     <h5 v-if="getPriceCnttt(item)"> {{getPriceCnttt(item) | currency}} </h5> 
                     <p v-if="item?.decisionDate">Ngày phê duyệt KQLCNT</p> 
                     <h5 v-if="item?.decisionDate"> {{item?.decisionDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                 <div class="content__body__left__item__infor" v-if="item.bidForm == 'CGTTRG'"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã TBMT
                    </template>: {{item?.notifyNo}}-{{item?.notifyVersion}} </p> 
                   <span :class="getClassStatus(item)">{{getNameStatus(item)}}</span> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-8 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNoStand)" @click="addToViewedList(item?.notifyNoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other format__text"> 
                      <template> 
                       <h6 class="format__text" v-if="item?.procuringEntityName"> 
                        <template>
                         Bên mời thầu
                        </template>: <span>{{item?.procuringEntityName}}</span> </h6> 
                       <h6 class="format__text"> 
                        <template>
                         Chủ đầu tư
                        </template>: <span>{{item?.investorName}}</span> </h6> 
                      </template> 
                      <h6 v-if="!checkSearchKqlcnt()"> 
                       <template v-if="!item?.caseKHKQ &amp;&amp; item?.notifyVersion == '00'"> 
                        <template>
                         Ngày đăng tải thông báo
                        </template>: 
                        <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}} </span> 
                       </template> 
                       <template v-if="!item?.caseKHKQ &amp;&amp; item?.notifyVersion != '00'"> 
                        <template>
                         Thời gian sửa TBMT
                        </template>: 
                        <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}} </span> 
                       </template> </h6> 
                      <h6 v-if="checkSearchKqlcnt()"> 
                       <template>
                        Ngày đăng tải KQLCNT
                       </template>: <span>{{item?.publicDateKqlcnt | formatDate}} - {{item.publicDateKqlcnt | formatHour}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6 v-if="item?.investField">
                       <template>
                        Lĩnh vực
                       </template>: <span>{{ item?.investField?.[0] ? (getNameCatByCodeCat(item?.investField,catInvestFields)):(getNameCatByCodeCat(item?.bidField,catInvestFields))}}</span> </h6> 
                      <h6 class="format__text__title" v-if="item.locations"> 
                       <template>
                        Địa điểm
                       </template>: <span v-if="item.locations?.length > 0"> 
                        <template v-for="lc in  item.locations">
                          {{(lc?.districtName)?lc?.districtName+" - ":""}}{{lc?.provName}}; 
                        </template> </span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Thời điểm bắt đầu chào giá trực tuyến</p> 
                     <h5>{{item.bidOpenDate | formatHour}}</h5> 
                     <h5>{{item.bidOpenDate | formatDate}}</h5> 
                     <p>Thời điểm kết thúc chào giá trực tuyến</p> 
                     <h5>{{item.bidCloseDate | formatHour}}</h5> 
                     <h5>{{item.bidCloseDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                   <div class="col-lg-2 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right" v-if="item.statusForNotify != 'DHT' &amp;&amp; item.statusForNotify != 'DHTBMT'"> 
                     <p v-if="getTextCnttt(item)">Nhà thầu trúng thầu</p> 
                     <h5 class="content__body__right__item__infor__contract__right__text" v-if="getTextCnttt(item)"> {{getTextCnttt(item)}} </h5> 
                     <p v-if="getPriceCnttt(item)">Giá trúng thầu (VND)</p> 
                     <h5 v-if="getPriceCnttt(item)"> {{getPriceCnttt(item) | currency}} </h5> 
                     <p v-if="item?.decisionDate">Ngày phê duyệt KQLCNT</p> 
                     <h5 v-if="item?.decisionDate"> {{item?.decisionDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--END Thông báo mời thầu--> 
                <div class="content__body__left__item" v-if="item.type =='es-kqlcnt-old'" :class="{'text-viewed' : checkViewed(item?.resultNo + '-' + item?.resultVersion)}"> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã KQLCNT
                    </template>: {{item?.resultNo}}-{{item?.resultVersion}} </p> 
                   <span :class="getClassStatus(item)">{{getNameStatus(item)}}</span> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-8 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.resultNo + '-' + item?.resultVersion);" @click="addToViewedList(item?.resultNo + '-' + item?.resultVersion);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other format__text"> 
                      <h6 class="format__text" v-if="item?.procuringEntityName"> 
                       <template>
                        Bên mời thầu
                       </template>: <span>{{item?.procuringEntityName}}</span> </h6> 
                      <h6 v-if="item.planType != 'TX' &amp;&amp; item?.investorName" class="format__text"> 
                       <template>
                        Chủ đầu tư
                       </template>: <span>{{item?.investorName}}</span> </h6> 
                      <h6> 
                       <template v-if="item?.publicDateKqlcnt"> 
                        <template>
                         Ngày đăng tải KQLCNT
                        </template>: 
                        <span>{{item?.publicDateKqlcnt | formatDate}} - {{item.publicDateKqlcnt | formatHour}}</span> 
                       </template> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6 v-if="item?.investField">
                       <template>
                        Lĩnh vực
                       </template>: <span>{{ getNameCatByCodeCat(item?.bidField,catInvestFields)}}</span> </h6> 
                      <h6 class="format__text__title" v-if="item.locations"> 
                       <template>
                        Địa điểm
                       </template>: <span v-if="item.locations?.length > 0"> 
                        <template v-for="lc in  item.locations">
                          {{(lc?.districtName)?lc?.districtName+" - ":""}}{{lc?.provName}}; 
                        </template> </span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <template v-if="item?.publicDate"> 
                      <p>Thời điểm đóng thầu</p> 
                      <h5>{{item.bidCloseDate | formatHour}}</h5> 
                      <h5>{{item.bidCloseDate | formatDate}}</h5> 
                     </template> 
                     <p>Hình thức dự thầu</p> 
                     <h5> 
                      <template v-if="item.isInternet == 1">
                       Qua mạng
                      </template> 
                      <template v-if="item.isInternet != 1">
                       Không qua mạng
                      </template> </h5> 
                    </div> 
                   </div> 
                   <div class="col-lg-2 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right" v-if="item.statusForNotify != 'DHT' &amp;&amp; item.statusForNotify != 'DHTBMT'"> 
                     <!--                                                <p v-if="(item?.ventureName)?item?.ventureName:item?.contractorName">Nhà--> 
                     <!--                                                    thầu trúng thầu</p>--> 
                     <!--                                                <h5--> 
                     <!--                                                        class="content__body__right__item__infor__contract__right__text"--> 
                     <!--                                                        v-if="(item?.ventureName)?item?.ventureName:item?.contractorName"--> 
                     <!--                                                >--> 
                     <!--                                                    {{(item?.ventureName)?item?.ventureName:item?.contractorName}}--> 
                     <!--                                                </h5>--> 
                     <!--                                                <p v-if="item.bidWinningPrice">Giá trúng thầu (VNĐ)</p>--> 
                     <!--                                                <h5 v-if="item?.bidWinningPrice">{{item?.bidWinningPrice |--> 
                     <!--                                                    currency}}</h5>--> 
                     <p v-if="getTextCnttt(item)">Nhà thầu trúng thầu</p> 
                     <h5 class="content__body__right__item__infor__contract__right__text" v-if="getTextCnttt(item)"> {{getTextCnttt(item)}} </h5> 
                     <p v-if="getPriceCnttt(item)">Giá trúng thầu (VND)</p> 
                     <h5 v-if="getPriceCnttt(item)"> {{getPriceCnttt(item) | currency}} </h5> 
                     <p v-if="item?.decisionDate">Ngày phê duyệt KQLCNT</p> 
                     <h5 v-if="item?.decisionDate"> {{item?.decisionDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--END Thông báo mời thầu--> 
                <!--Thông báo mời sơ tuyển--> 
                <div class="content__body__left__item" v-if="item.type =='es-pre-notify-contractor'" :class="{'text-viewed' : checkViewed(item?.notifyNoStand)}"> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template v-if="item.investField == 'TV'">
                     Mã TBMQT
                    </template> 
                    <template v-if="item.investField != 'TV'">
                     Mã TBMST
                    </template> : {{item?.notifyNoStand}} </p> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                              v-if="item.statusForNotify == 'DHTBMT'"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                   <!--                                        <span--> 
                   <!--                                                class="content__body__left__item__infor__notice--gray"--> 
                   <!--                                                v-if="item.statusForNotify == 'KCNTTT'"--> 
                   <!--                                        >Không có nhà thầu trúng thầu</span--> 
                   <!--                                        >--> 
                   <!--                                        <span--> 
                   <!--                                                class="content__body__left__item__infor__notice--blue"--> 
                   <!--                                                v-if="item.statusForNotify == 'CNTTT'"--> 
                   <!--                                        >Có nhà thầu trúng thầu</span--> 
                   <!--                                        >--> 
                   <!--                                        <span--> 
                   <!--                                                class="content__body__left__item__infor__notice--red"--> 
                   <!--                                                v-if="item.statusForNotify == 'DHT'"--> 
                   <!--                                        >Đã huỷ thầu</span--> 
                   <!--                                        >--> 
                   <!--                                        <span--> 
                   <!--                                                class="content__body__left__item__infor__notice--orange"--> 
                   <!--                                                v-if="item.statusForNotify == 'DXT'"--> 
                   <!--                                        >Đang xét thầu</span--> 
                   <!--                                        >--> 
                   <!--                                        <span--> 
                   <!--                                                class="content__body__left__item__infor__notice--be"--> 
                   <!--                                                v-if="!item.statusForNotify"--> 
                   <!--                                        >Chưa mở thầu</span--> 
                   <!--                                        >--> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-8 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNoStand)" @click="addToViewedList(item?.notifyNoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6 class="format__text" v-if="item?.procuringEntityName"> 
                       <template>
                        Bên mời thầu
                       </template>: <span>{{item?.procuringEntityName}}</span> </h6> 
                      <h6 v-if="(item.planType != 'TX' || checkIsNewLaw2025(item)) &amp;&amp; item?.investorName" class="format__text"> 
                       <template>
                        Chủ đầu tư
                       </template>: <span>{{item?.investorName}}</span> </h6> 
                      <h6 v-if="!checkSearchKqlcnt() &amp;&amp; !checkSearchKqst() &amp;&amp; !checkSearchKqmqt()"> 
                       <template>
                        Ngày đăng tải thông báo
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                      <h6 v-if="checkSearchKqlcnt()"> 
                       <template>
                        Ngày đăng tải KQLCNT
                       </template>: <span>{{item?.publicDateKqlcnt | formatDate}} - {{item.publicDateKqlcnt | formatHour}}</span> </h6> 
                      <h6 v-if="checkSearchKqst()"> 
                       <template>
                        Ngày đăng tải KQST
                       </template>: <span>{{item?.publicDateKqst| formatDate}} - {{item.publicDateKqst | formatHour}}</span> </h6> 
                      <h6 v-if="checkSearchKqmqt()"> 
                       <template>
                        Ngày đăng tải KQMQT
                       </template>: <span>{{item?.publicDateKqst | formatDate}} - {{item.publicDateKqst | formatHour}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6>
                       <template>
                        Lĩnh vực
                       </template>: <span>{{getNameCatByCodeCat(item?.investField,catInvestFields)}}</span> </h6> 
                      <h6 class="format__text__title"> 
                       <template>
                        Địa điểm
                       </template>: <span v-if="item.locations?.length > 0"> 
                        <template v-for="lc in  item.locations">
                          {{(lc?.districtName)?lc?.districtName+" - ":""}}{{lc?.provName}}; 
                        </template> </span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Thời điểm đóng thầu</p> 
                     <h5>{{item.bidCloseDate | formatHour}}</h5> 
                     <h5>{{item.bidCloseDate | formatDate}}</h5> 
                     <p>Hình thức dự thầu</p> 
                     <h5> 
                      <template v-if="item.isInternet == 1">
                       Qua mạng
                      </template> 
                      <template v-if="item.isInternet != 1">
                       Không qua mạng
                      </template> </h5> 
                    </div> 
                   </div> 
                   <div class="col-lg-2 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right" v-if="item.statusForNotify != 'DHT' &amp;&amp; item.statusForNotify != 'DHTBMT'"> 
                     <!--                                                <p v-if="(item?.ventureName)?item?.ventureName:item?.contractorName">Nhà--> 
                     <!--                                                    thầu trúng thầu</p>--> 
                     <!--                                                <h5--> 
                     <!--                                                        class="content__body__right__item__infor__contract__right__text"--> 
                     <!--                                                        v-if="(item?.ventureName)?item?.ventureName:item?.contractorName"--> 
                     <!--                                                >--> 
                     <!--                                                    {{(item?.ventureName)?item?.ventureName:item?.contractorName}}--> 
                     <!--                                                </h5>--> 
                     <!--                                                <p v-if="item.bidWinningPrice">Giá trúng thầu (VNĐ)</p>--> 
                     <!--                                                <h5 v-if="item?.bidWinningPrice">{{item?.bidWinningPrice |--> 
                     <!--                                                    currency}}</h5>--> 
                     <p v-if="getTextCnttt(item)">Nhà thầu trúng thầu</p> 
                     <h5 class="content__body__right__item__infor__contract__right__text" v-if="getTextCnttt(item)"> {{getTextCnttt(item)}} </h5> 
                     <p v-if="getPriceCnttt(item)">Giá trúng thầu (VND)</p> 
                     <h5 v-if="getPriceCnttt(item)"> {{getPriceCnttt(item) | currency}} </h5> 
                     <p v-if="item?.decisionDate"> 
                      <template v-if="item.investField == 'TV'">
                       Ngày phê duyệt KQMQT
                      </template> 
                      <template v-if="item.investField != 'TV'">
                       Ngày phê duyệt KQST
                      </template> </p> 
                     <h5 v-if="item?.decisionDate"> {{item?.decisionDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--END Thông báo mời sơ tuyển--> 
                <!--Kế hoạch lựa chọn nhà thầu--> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.planNoStand)}" v-if="item.type =='es-plan-project-p' || item.type =='es-khlcnt-tt' "> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template v-if="item.type =='es-plan-project-p'">
                     Mã KHLCNT
                    </template> 
                    <template v-if="item.type =='es-khlcnt-tt'">
                     Mã kế hoạch tổng thể lựa chọn nhà thầu
                    </template> : {{item.planNoStand}} </p> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-10 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.planNoStand)" @click="addToViewedList(item?.planNoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{item.name}} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template v-if="item.planType == 'DTPT' || (item.planType != 'DTPT' &amp;&amp; isPublicAfter2024(item.decisionDate))">
                        Chủ đầu tư
                       </template> 
                       <template v-if="item.planType != 'DTPT' &amp;&amp; !isPublicAfter2024(item.decisionDate)">
                        Chủ đầu tư
                       </template> : <span>{{(item.investorName)?item.investorName:item.procuringEntityName}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6 v-if="item.type =='es-plan-project-p'">
                       <template>
                        Phân loại
                       </template>: <span>{{getNameCatByCodeCat(item.planType,planTypesVe)}}</span> </h6> 
                      <h6 v-if="!(item.planType == 'DTPT' || item.planType == 'DTMS') || ((item.planType == 'DTPT' || item.planType == 'DTMS') &amp;&amp; item.approvalStatus == '01')"> 
                       <template v-if="item.planType == 'DTPT' || item.planType == 'DTMS'">
                        Tổng mức đầu tư
                       </template> 
                       <template v-if="!(item.planType == 'DTPT' || item.planType == 'DTMS')">
                        Dự toán mua sắm
                       </template> : <span>{{item.investTotal | currency}} VND</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Thời điểm phê duyệt</p> 
                     <h5>{{item.decisionDate | formatDate}}</h5> 
                     <!--                                                <p>Hình thức dự thầu</p>--> 
                     <!--                                                <h5>{{item.isInternet == 1 ?'Qua mạng':'Không qua mạng' }}</h5>--> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--END Kế hoạch lựa chọn nhà thầu--> 
                <!--Dự án đầu tư và phát triển--> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.pnoStand)}" v-if="item.type =='es-bidp-project-p'"> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã dự án
                    </template>: {{item.pnoStand}} </p> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-10 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.pnoStand);" @click="addToViewedList(item?.pnoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{item.name}} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Tên chủ đầu tư
                       </template>: <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Tổng mức đầu tư
                       </template>: <span> {{item.investTotal | currency}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6>
                       <template>
                        Phân loại
                       </template>: <span>{{getNameCatByCodeCat(item.pgroup,dmGroupDa)}}</span> </h6> 
                      <h6 class="format__text__title" v-if="item.locations"> 
                       <template>
                        Địa điểm
                       </template>: <span v-if="item.locations?.length > 0"> 
                        <template v-for="(lc,index) in  item.locations">
                          {{(lc?.districtName)?lc?.districtName+" - ":""}}{{lc?.provName}} {{ (index == item?.locations?.length - 1) ? '' : ';' }} 
                        </template> </span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Thời điểm phê duyệt</p> 
                     <h5>{{item.decisionDate | formatDate}}</h5> 
                     <!--                                                <p>Hình thức dự thầu</p>--> 
                     <!--                                                <h5>{{item.isInternet == 1 ?'Qua mạng':'Không qua mạng' }}</h5>--> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--END: Dự án đầu tư và phát triển--> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.notifyNo + '-' + item?.notifyVersion)}" v-if="item.type =='es-ycbg' "> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã YCBG
                    </template> : {{item.notifyNo}}-{{item.notifyVersion}} </p> 
                   <span :class="getClassStatusYCBG(item)">{{getStatusYCBG(item)}}</span> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-10 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion)" @click="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{item.name}} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Chủ đầu tư
                       </template> : <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Ngày phê duyệt</p> 
                     <h5>{{item.decisionDate | formatDate}}</h5> 
                     <!--                                                <p>Hình thức dự thầu</p>--> 
                     <!--                                                <h5>{{item.isInternet == 1 ?'Qua mạng':'Không qua mạng' }}</h5>--> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.notifyNo + '-' + item?.notifyVersion)}" v-if="item.type =='es-bido-interest-notify' "> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã khảo sát
                    </template> : {{item.notifyNo}}-{{item.notifyVersion}} </p> 
                   <span :class="getClassStatusKSQT(item)">{{getStatusKSQT(item)}}</span> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-10 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion)" @click="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Chủ đầu tư
                       </template> : <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Thời gian kết thúc khảo sát</p> 
                     <h5>{{item.bidCloseDate | formatDate}}</h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.notifyNo + '-' + item?.notifyVersion)}" v-if="item.type =='es-ct-contract' || item.type =='es-ct-publish-frame'"> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center" @click="addToViewedList(item?.contractCode + '-' + item?.contractVersion);renderUrlDetailContractV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.contractCode)" style="cursor: pointer"> 
                   <p class="content__body__left__item__infor__code"> <span v-if="item.type == 'es-ct-publish-frame'">Mã thỏa thuận khung</span> <span v-if="item.type == 'es-ct-contract'"> 
                     <!--                                                    <template v-if="item.processApply == 'ORDER_CONTRACT'">Mã hợp đồng đặt hàng</template>--> 
                     <!--                                                    <template v-else-if="item.processApply == 'ORDER_DECIDE'">Mã quyết định đặt hàng</template>--> 
                     <!--                                                    <template v-else th:text="#{contractor.selection.contract.mhd}">Mã hợp đồng</template>--> 
                     <template>
                      Mã hợp đồng
                     </template> </span> : {{item.contractCode}}-{{item.contractVersion}} </p> 
                   <!--                                        <span class="content__body__left__item__infor__notice"--> 
                   <!--                                        >Đã hủy TBMT</span--> 
                   <!--                                        >--> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-10 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.contractCode + '-' + item?.contractVersion)" @click="addToViewedList(item?.contractCode + '-' + item?.contractVersion);renderUrlDetailContractV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.contractCode)" :href="renderUrlDetailContract(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.contractCode)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{item?.bidName?.[0]}} </h5> </a> 
                    <!--                                                <div class="row" v-if="item.processApply == 'ORDER_CONTRACT' || item.processApply == 'ORDER_DECIDE'">--> 
                    <!--                                                    <div class="col-md-12 content__body__left__item__infor__contract__other">--> 
                    <!--                                                        <h6>--> 
                    <!--                                                            <template >Cơ quan đặt hàng</template>: <span>{{item.investorName}}</span>--> 
                    <!--                                                        </h6>--> 
                    <!--                                                        <h6 v-if="item?.winningContractorName?.length">--> 
                    <!--                                                            <template v-if="item.processApply == 'ORDER_CONTRACT'">Nhà cung cấp</template>--> 
                    <!--                                                            <template v-if="item.processApply == 'ORDER_DECIDE'">Đơn vị sự nghiệp</template>--> 
                    <!--                                                            : <span>{{item?.winningContractorName?.join(', ')}}</span>--> 
                    <!--                                                        </h6>--> 
                    <!--                                                        <h6>--> 
                    <!--                                                            <template th:text="#{publicDate}">Ngày đăng tải</template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span>--> 
                    <!--                                                        </h6>--> 
                    <!--                                                    </div>--> 
                    <!--                                                </div>--> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Chủ đầu tư
                       </template> : <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Nhà thầu
                       </template>: <span>{{item?.winningContractorName?.length &gt; 1 ? 'Có nhiều hơn một nhà thầu trúng thầu' : item?.winningContractorName?.[0]}}</span> </h6> 
                     </div> 
                     <div class="col-md-4 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Lĩnh vực
                       </template> : <span>{{getNameCatByCodeCat(item?.investField,catInvestFields)}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <!--Thông báo mời chào giá trực tuyến--> 
                <!--                                <div class="content__body__left__item" v-if="item.type =='es-re-offer-price'"  :class="{'text-viewed': checkViewed(item?.pnoStand)}">--> 
                <!--                                    <div class="content__body__left__item__infor">--> 
                <!--                                        <div class="d-flex justify-content-between align-items-center">--> 
                <!--                                            <p class="content__body__left__item__infor__code">--> 
                <!--                                                <template>Mã E-TBMT</template>: {{item?.pnoStand}}--> 
                <!--                                            </p>--> 
                <!--                                            <template v-if="isShowSummitButton(item)">--> 
                <!--                                                <template v-if="item.submissionDetailByNT">--> 
                <!--                                                    <button type="button" v-if="item.submissionDetailByNT && userName === item?.submissionDetailByNT?.createdBy"--> 
                <!--                                                            class="btn btn-primary detail__children-2__button"--> 
                <!--                                                            style="background: #064d69 !important; font-weight: 700;"--> 
                <!--                                                            @click="openUrl(kongUrl + '/bidonlinefe/reoffer-onl-proposals/edit/'+item?.submissionDetailByNT?.id+'?step=2&reofferId='+item?.id)">--> 
                <!--                                                        <img th:src="@{/images/icons/mace.svg}" alt="icon"/>--> 
                <!--                                                        Chào giá--> 
                <!--                                                    </button>--> 
                <!--                                                </template>--> 
                <!--                                                <template v-if="!item.submissionDetailByNT && !item.expired && !userName?.includes(item?.investorCode) && !userName?.includes(item?.procuringEntityCode)">--> 
                <!--                                                    <button type="button"--> 
                <!--                                                            class="btn btn-primary detail__children-2__button"--> 
                <!--                                                            style="background: #064d69 !important; font-weight: 700;"--> 
                <!--                                                            @click="openUrl(kongUrl + '/bidonlinefe/reoffer-onl-proposals/edit/PO?step=2&reofferId='+item?.id)">--> 
                <!--                                                        <img th:src="@{/images/icons/mace.svg}" alt="icon"/>--> 
                <!--                                                        Chào giá--> 
                <!--                                                    </button>--> 
                <!--                                                </template>--> 
                <!--                                            </template>--> 
                <!--                                            <span v-if="!isShowSummitButton(item)" :class="getClassStatusReOfferOnline(item)">--> 
                <!--                                                {{getNameStatusReOfferOnline(item)}}--> 
                <!--                                            </span>--> 
                <!--                                        </div>--> 
                <!--                                        <div class="row">--> 
                <!--                                            <div--> 
                <!--                                                    class="col-md-9 content__body__left__item__infor__contract"--> 
                <!--                                            >--> 
                <!--                                                <a--> 
                <!--                                                        @click.right="addToViewedList(item?.pnoStand)"--> 
                <!--                                                        @click="addToViewedList(item?.pnoStand);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"--> 
                <!--                                                        :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)">--> 
                <!--                                                    <h5--> 
                <!--                                                            class="content__body__left__item__infor__contract__name format__text__title"--> 
                <!--                                                    >--> 
                <!--                                                        {{(item.bidName && item.bidName?.length > 0)? item.bidName[0]: ''  }}--> 
                <!--                                                    </h5>--> 
                <!--                                                </a>--> 
                <!--                                                <div class="row">--> 
                <!--                                                    <div--> 
                <!--                                                            class="col-md-8 content__body__left__item__infor__contract__other format__text"--> 
                <!--                                                    >--> 
                <!--                                                        <template>--> 
                <!--                                                            <h6 class="format__text">--> 
                <!--                                                                <template th:text="#{procuringEntity}">Bên mời thầu</template>:--> 
                <!--                                                                <span>{{item?.procuringEntityName}}</span>--> 
                <!--                                                            </h6>--> 
                <!--                                                            <h6 class="format__text">--> 
                <!--                                                                <template th:text="#{investor}">Chủ đầu tư</template>:--> 
                <!--                                                                <span>{{item?.investorName}}</span>--> 
                <!--                                                            </h6>--> 
                <!--                                                        </template>--> 
                <!--                                                        <h6>--> 
                <!--                                                            <template>--> 
                <!--                                                                <template>Thời gian đăng tải</template>:--> 
                <!--                                                                <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}--> 
                <!--                                                            </span>--> 
                <!--                                                            </template>--> 
                <!--                                                        </h6>--> 
                <!--                                                    </div>--> 
                <!--                                                    <div class="col-md-4 content__body__left__item__infor__contract__other">--> 
                <!--                                                        <template v-if="item.isMultiLot != 1">--> 
                <!--                                                            <h6 class="format__text" v-if="followChanges && isOpeningReOffer(item) || isClosedReOffer(item)">--> 
                <!--                                                                <template>Giá thấp nhất hiện tại</template>:--> 
                <!--                                                                <span>{{ item.minPrice | currency}} VND</span>--> 
                <!--                                                            </h6>--> 
                <!--                                                            <h6 class="format__text">--> 
                <!--                                                                <template>Giá trần</template>:--> 
                <!--                                                                <span>{{item?.priceInit | currency}} VND</span>--> 
                <!--                                                            </h6>--> 
                <!--                                                            <h6 class="format__text">--> 
                <!--                                                                <template>Bước giá</template>:--> 
                <!--                                                                <span>{{item?.priceStep | currency}} VND</span>--> 
                <!--                                                            </h6>--> 
                <!--                                                        </template>--> 
                <!--                                                    </div>--> 
                <!--                                                </div>--> 
                <!--                                            </div>--> 
                <!--                                            <div class="col-md-3 content__body__right__item__infor__contract" >--> 
                <!--                                                <div class="">--> 
                <!--                                                    <template v-if="isClosedReOffer(item)">--> 
                <!--                                                        <p>Thời điểm kết thúc chào giá trực tuyến</p>--> 
                <!--                                                        <h5>{{item.bidCloseDate | formatHour}}</h5>--> 
                <!--                                                        <h5>{{item.bidCloseDate | formatDate}}</h5>--> 
                <!--                                                    </template>--> 
                <!--                                                    <template v-if="isUpComingReOffer(item)">--> 
                <!--                                                        <p>Thời điểm bắt đầu chào giá trực tuyến</p>--> 
                <!--                                                        <h5>{{item.bidOpenDate | formatHour}}</h5>--> 
                <!--                                                        <h5>{{item.bidOpenDate | formatDate}}</h5>--> 
                <!--                                                    </template>--> 
                <!--                                                    <template v-if="isOpeningReOffer(item)">--> 
                <!--                                                        <p>Thời gian còn lại</p>--> 
                <!--                                                        <h5 class="text-danger">{{getDiffTimesReOffer(item, nowDate)}}</h5>--> 
                <!--                                                    </template>--> 
                <!--                                                    <p><template th:text="#{field}">Lĩnh vực</template></p>--> 
                <!--                                                    <h5>--> 
                <!--                                                        <span>{{ item?.investField?.[0]  ? (getNameCatByCodeCat(item?.investField,catInvestFields)):(getNameCatByCodeCat(item?.bidField,catInvestFields))}}</span>--> 
                <!--                                                    </h5>--> 
                <!--                                                </div>--> 
                <!--                                            </div>--> 
                <!--                                        </div>--> 
                <!--                                    </div>--> 
                <!--                                </div>--> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.notifyNo + '-' + item?.notifyVersion)}" v-if="item.type =='es-bide-contractor-input-result-other' "> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                   <p class="content__body__left__item__infor__code"> 
                    <template>
                     Mã TBMT
                    </template> : {{item.notifyNo}} </p> 
                   <span :class="getClassStatus(item)">{{getStatusKQ(item)}}</span> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-7 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion)" @click="addToViewedList(item?.notifyNo + '-' + item?.notifyVersion);renderUrlDetailV2(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)" :href="renderUrlDetail(item.type,item.stepCode, item.id, item.notifyId, item.inputResultId, item.bidOpenId, item.techReqId, item.bidPreNotifyResultId, item.bidPreOpenId,item.processApply,item.bidMode,item.notifyNo,item.planNo,item.pno, item.stepCode,item.isInternet,item.caseKHKQ,item.bidForm)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-8 content__body__left__item__infor__contract__other"> 
                      <h6> 
                       <template>
                        Chủ đầu tư
                       </template> : <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                      <h6> 
                       <template>
                        Lĩnh vực
                       </template>: <span>{{getNameCatByCodeCat(item?.bidField,catInvestFields)}}</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Ngày phê duyệt</p> 
                     <h5>{{item.decisionDate | formatDate}}</h5> 
                     <p>Hình thức dự thầu</p> 
                     <h5> 
                      <template v-if="item.isInternet == 1">
                       Qua mạng
                      </template> 
                      <template v-if="item.isInternet != 1">
                       Không qua mạng
                      </template> </h5> 
                    </div> 
                   </div> 
                   <div class="col-md-3 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right" v-if="item.statusForNotify != 'DHT'"> 
                     <p v-if="item?.winningContractorName?.length > 0">Nhà thầu trúng thầu</p> 
                     <h5 class="content__body__right__item__infor__contract__right__text" v-if="item?.winningContractorName?.length > 0"> {{getNttt(item)}} </h5> 
                     <p v-if="getPriceCnttt(item)">Giá trúng thầu (VND)</p> 
                     <h5 v-if="getPriceCnttt(item)"> {{getPriceCnttt(item) | currency}} </h5> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
                <div class="content__body__left__item" :class="{'text-viewed' : checkViewed(item?.orderNo?.[0])}" v-if="item.type =='es-shopping-result' "> 
                 <div class="content__body__left__item__infor"> 
                  <div class="d-flex justify-content-between align-items-center"> 
                  </div> 
                  <div class="row"> 
                   <div class="col-md-7 content__body__left__item__infor__contract"> 
                    <a @click.right="addToViewedList(item?.orderNo?.[0])" @click="addToViewedList(item?.orderNo?.[0]);renderUrlDetailShoppingResult(item)" :href="renderUrlDetailShoppingResult(item)"> <h5 class="content__body__left__item__infor__contract__name format__text__title"> {{(item.bidName &amp;&amp; item.bidName?.length &gt; 0)? item.bidName[0]: '' }} </h5> </a> 
                    <div class="row"> 
                     <div class="col-md-9 content__body__left__item__infor__contract__other"> 
                      <!--                                                        <h6>--> 
                      <!--                                                            <template th:text="#{procuringEntity}">Bên mời thầu</template>--> 
                      <!--                                                            : <span>{{item.procuringEntityName}}</span>--> 
                      <!--                                                        </h6>--> 
                      <h6> 
                       <template>
                        Chủ đầu tư
                       </template> : <span>{{item.investorName}}</span> </h6> 
                      <h6> 
                       <template>
                        Ngày đăng tải
                       </template>: <span>{{item?.publicDate | formatDate}} - {{item.publicDate | formatHour}}</span> </h6> 
                     </div> 
                    </div> 
                   </div> 
                   <div class="col-md-3 content__body__right__item__infor__contract"> 
                    <div class=""> 
                     <p>Số hiệu đơn hàng</p> 
                     <h5>{{item?.orderNo?.[0]}}</h5> 
                     <p>Giá trị đơn hàng</p> 
                     <h5>{{item.bidWinningPrice | currency}}</h5> 
                    </div> 
                   </div> 
                   <div class="col-md-2 content__body__right__item__infor__contract"> 
                    <div class="p-0 content__body__right__item__infor__contract__right"> 
                     <span class="content__body__left__item__infor__notice--blue"> 
                      <template>
                       {{item.status === '02' ? 'Đã hủy' : 'Đã đăng tải'}} 
                      </template> </span> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </template> 
              </div> 
              <!--                    <div id="tender-notice" class="tab-pane"></div>--> 
              <!--                    <div id="KQLCNĐT" class="tab-pane"></div>--> 
             </div> 
            </div> 
           </template> 
          </div> 
          <div class="content" v-if="!spinningSearch"> 
           <div class="pagination"> 
            <el-pagination background layout="prev, pager, next" :total="page.totalElements" :page-size="page.pageSize" :current-page="page.currentPage + 1" @current-change="changePage" :page-count="page.totalPages"> 
            </el-pagination> 
           </div> 
          </div> 
         </div> 
        </div> 
<script>
new Vue({
  el: "#search-home",
  data() {
    return {
      spinningSearch: true,
      isPopupOpen: false,
      visible: false,
      elasticSearch: "\/o\/egp-portal-contractor-selection-v2\/services\/smart\/search",
      renderDetailUrl:
        "https:\/\/muasamcong.mpi.gov.vn\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=detail",
      renderDetailV2Url:
        "https:\/\/muasamcong.mpi.gov.vn\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=detail-v2",
      renderSearchAdvanceUrl:
        "https:\/\/muasamcong.mpi.gov.vn\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=search",
      getCategory: "\/o\/egp-portal-contractor-selection-v2\/services\/get\/category",
      siteURL: "https:\/\/muasamcong.mpi.gov.vn\/web\/guest",
      indexSelectParam: "null",
      IsEnglish: false,
      currentUrl:
        "\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=index\u0026indexSelect=null",
      loading: false,
      viewedList: [],
      getViewedListUrl:
        "\/o\/egp-portal-contractor-selection-v2\/services\/get-viewed-list",
      addViewedListUrl:
        "\/o\/egp-portal-contractor-selection-v2\/services\/add-to-viewed-list",
      listResultSearch: [],
      page: {},
      textSearch: "",
      searchWithValue: "notifyNo",
      payload: {},
      searchAdvancePayload: null,
      quickSearchPayload: {
        keyword: "",
        type: "all-1",
        searchWith: "notifyNo,bidName",
        matchFields: [],
        isBidCloseDate: null,
        pageSize: 10,
      },
      currentPage: 0,
      advancedSearchPayload: {},
      isHideTab: true,
      isShowClosedStatus: false,
      aggOpen: null,
      aggClose: null,
      optionActive: "all",
      payloadSearch: null,
      activeTab: "all",

      countTime: "2026-01-03T08:49:05.299",
      kongUrl: "https:\/\/muasamcong.mpi.gov.vn\/c\/portal\/login?redirect=\/egp",
      urlSubmitReOffer:
        "\/o\/egp-portal-contractor-selection-v2\/services\/submission-online-reoffer\/detail-dtos",
      nowDate: null,
      userName: "",
      activeReOffer: "all",
      isMultiLotReOffer: 0,
      followChanges: 1,
      aggOpenReOffer: null,
      stompClient: null,
      poOnlineUrl: "https:\/\/poonline.muasamcong.gov.vn",

      // Cat
      planTypesVe: [],
      planAppVeStatus: [],
      provinceAreas: [],
      districtAreas: [],
      catInvestFields: [],
      bidForms: [],
      contractTypes: [],
      processApplies: [],
      dmTrangThais: [],
      reasonCancelBidCPTPP: [],
      /*bidInvestForm: [],*/
      dmQt: [],
      dmPtlcnt: [],
      dmSpendingCat: [],
      dmBidStatusCat: [],
      notiStatusCat: [],
      dmGroupDa: [],
      dmCqms: [],
      dmCqmsLv1: [],
      reasonCancelBidVK: [],
      htqlDa: [],
      dmHtdt: [],
      bidPlanStatus: [],
      dmLhdLcnt: [],
      bidoStatus: [],
      // End-Cat
      urlSearchUmFilterInfo:
        "\/o\/egp-portal-contractor-selection-v2\/services\/um\/um-filter-info\/get-um-filter-info-by-org-code",
      listUmFilterInfo: [],
      indexSelect: -1,
      checkLogin: false,
      roleLogin: null,
      DATE_LAW_2025: "2025-07-01T00:00:00",
      getAreaProvince: "\/o\/egp-portal-contractor-selection-v2\/services\/get\/area",
      getAreaAPI: "\/o\/egp-portal-contractor-selection-v2\/services\/get\/area-api",
      getCategory: "\/o\/egp-portal-contractor-selection-v2\/services\/get\/category",
      siteKey: "6LfXhdcpAAAAAIb2GV9eRkJcf8clrHAOVOIseJdT",
    };
  },
  filters: {
    formatDate: function (date) {
      return date ? moment(date).format("DD/MM/YYYY") : "";
    },

    formatMonth: function (date) {
      return date ? moment(date).format("MM/YYYY") : "";
    },

    formatHour: function (date) {
      return date ? moment(date).format("HH:mm") : "";
    },
    currency(value) {
      if (value) {
        return new Number(value).toLocaleString("vi-VN");
      } else return value;
    },
  },

  methods: {
    closePopUp() {
      this.visible = false;
    },

    downloadGuide() {
      window.open(
        "https://muasamcong.mpi.gov.vn/api/unau/edocproxy/file/share/74c801ce8b4b31515de5deff355ada12e1d416d7940c1eeb70386c3c82e400c7",
        "_self"
      );
    },
    // resetPagingLocalStorage(){
    //     this.quickSearchPayload.isBidCloseDate = null;
    //
    //     this.currentPage = 0;
    //     localStorage.setItem("currentPage", this.currentPage);
    //
    //     this.activeTab = "all";
    //     localStorage.setItem("activeTab",  this.activeTab);
    //
    //     this.optionActive = "all";
    //     localStorage.setItem("optionActive", this.optionActive);
    //
    //
    // },

    getNameStatus(item) {
      if (item.statusForNotify == "DHTBMT")
        return this.isEnglish ? "Invitation to bid is cancelled" : "Đã hủy TBMT";
      if (item.statusForNotify == "KCNTTT")
        return this.isEnglish
          ? "There is no successful bidder"
          : "Không có nhà thầu trúng thầu";
      if (item.statusForNotify == "CNTTT")
        return this.isEnglish ? "There is successful bidder" : "Có nhà thầu trúng thầu";
      if (item.statusForNotify == "DHT")
        return this.isEnglish ? "Bid is cancelled" : "Đã huỷ thầu";
      if (item.statusForNotify == "DHKQLCNT")
        return this.isEnglish ? "Result canceled" : "Đã huỷ KQLCNT";
      if (item.statusForNotify == "DXT")
        return this.isEnglish ? "Bid evaluation is in progress" : "Đang xét thầu";
      if (item.statusForNotify == "VHH")
        return this.isEnglish
          ? "Declare void against contractor selection result"
          : "Tuyên bố vô hiệu quyết định về KQLCNT";
      if (item.statusForNotify == "KCN")
        return this.isEnglish
          ? "Refuse to recognize contractor selection result"
          : "Không công nhận KQLCNT";
      if (item.statusForNotify == "DC")
        return this.isEnglish ? "Suspend bidding process" : "Đình chỉ cuộc thầu";

      if (!item.statusForNotify) {
        if (
          item.bidCloseDate &&
          new Date(item.bidCloseDate).getTime() > new Date().getTime()
        )
          return this.isEnglish ? "Bid is not closed yet" : "Chưa đóng thầu";
        if (
          item.bidCloseDate &&
          new Date(item.bidCloseDate).getTime() <= new Date().getTime()
        ) {
          if (item.isInternet == 0) {
            return this.isEnglish ? "Bid evaluation is in progress" : "Đang xét thầu";
          } else {
            return this.isEnglish ? "Bid is not opened yet" : "Chưa mở thầu";
          }
        }
      }
    },
    getNameStatusReOfferOnline(item) {
      if (item.status == "01") return "Đã đăng tải";
      if (item.status == "03") return "Đã hủy";
    },
    getClassStatusReOfferOnline(item) {
      if (item.status == "01") return "content__body__left__item__infor__notice--blue";
      if (item.status == "03") return "content__body__left__item__infor__notice--red";
    },
    // getPlaceHolderQuickSearch(){
    //     if (this.quickSearchPayload.searchWith == 'planNo,name') return this.isEnglish ? "Enter Bidder selection plan No./Name, Bidding package name" : "Nhập Mã KHLCNT/ Tên KHLCNT/ Tên gói thầu/ Tóm tắt công việc chính ...";
    //     return this.isEnglish ? 'Enter a keyword (for example: IB000202 or Equipment Shopping)' : 'Nhập từ khoá (ví dụ: IB000202 hoặc Mua sắm thiết bị)' ;
    // },

    getPlaceHolderQuickSearch() {
      if (
        this.quickSearchPayload.searchWith == "planNo,name" &&
        this.quickSearchPayload.matchFields == "procuringEntityName"
      )
        return this.isEnglish
          ? "Enter Bidder selection plan No./Name, Bidding package name"
          : "Nhập Mã KHLCNT/ Tên KHLCNT/ Tên gói thầu/ Tóm tắt công việc chính ... hoặc cơ quan A";
      if (this.quickSearchPayload.searchWith == "planNo,name")
        return this.isEnglish
          ? "Enter Bidder selection plan No./Name, Bidding package name"
          : "Nhập Mã KHLCNT/ Tên KHLCNT/ Tên gói thầu/ Tóm tắt công việc chính ...";
      if (
        this.quickSearchPayload.searchWith == "notifyNo,bidName" &&
        this.quickSearchPayload.matchFields == "procuringEntityName"
      )
        return this.isEnglish
          ? "Enter Bidder selection plan No./Name, Bidding package name"
          : "Nhập từ khoá (ví dụ: IB000202 hoặc Mua sắm thiết bị) hoặc cơ quan A";
      return this.isEnglish
        ? "Enter a keyword (for example: IB000202 or Equipment Shopping)"
        : "Nhập từ khoá (ví dụ: IB000202 hoặc Mua sắm thiết bị)";
    },

    getClassStatus(item) {
      if (item.statusForNotify == "DHTBMT")
        return "content__body__left__item__infor__notice";
      if (item.statusForNotify == "KCNTTT")
        return "content__body__left__item__infor__notice--gray";
      if (item.statusForNotify == "CNTTT")
        return "content__body__left__item__infor__notice--blue";
      if (item.statusForNotify == "DHT")
        return "content__body__left__item__infor__notice--red";
      if (item.statusForNotify == "DHKQLCNT")
        return "content__body__left__item__infor__notice";
      if (item.statusForNotify == "DXT")
        return "content__body__left__item__infor__notice--orange";
      if (item.statusForNotify == "VHH")
        return "content__body__left__item__infor__notice--beige";
      if (item.statusForNotify == "KCN")
        return "content__body__left__item__infor__notice--orange--red";
      if (item.statusForNotify == "DC")
        return "content__body__left__item__infor__notice--brown";
      if (!item.statusForNotify) {
        if (
          item.bidCloseDate &&
          new Date(item.bidCloseDate).getTime() <= new Date().getTime() &&
          item.isInternet == 0
        ) {
          return "content__body__left__item__infor__notice--orange";
        } else {
          return "content__body__left__item__infor__notice--be";
        }
      }
    },
    getStatusYCBG(item) {
      if (item?.status == "03") {
        return this.isEnglish
          ? "Request for quotation is cancelled"
          : "Đã hủy yêu cầu báo giá";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() < new Date().getTime()
      ) {
        return this.isEnglish
          ? "Request for quotation is over validity period"
          : "Đã hết hạn nhận báo giá";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() >= new Date().getTime()
      ) {
        return this.isEnglish
          ? "Request for quotation is still within validity period"
          : "Chưa hết hạn nhận báo giá";
      }
      return "";
    },
    getClassStatusYCBG(item) {
      if (item?.status == "03") {
        return "content__body__left__item__infor__notice--red";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() < new Date().getTime()
      ) {
        return "content__body__left__item__infor__notice--orange";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() >= new Date().getTime()
      ) {
        return "content__body__left__item__infor__notice--blue";
      }
      return "";
    },
    getStatusKSQT(item) {
      if (item?.status == "03") {
        return this.isEnglish ? "Cancelled" : "Đã hủy";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() < new Date().getTime()
      ) {
        return this.isEnglish ? "Survey Submission Closed" : "Hết hạn nhận khảo sát";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() >= new Date().getTime()
      ) {
        return this.isEnglish ? "Survey Submission Open" : "Chưa hết hạn nhận khảo sát";
      }
      return "";
    },
    getClassStatusKSQT(item) {
      if (item?.status == "03") {
        return "content__body__left__item__infor__notice--red";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() < new Date().getTime()
      ) {
        return "content__body__left__item__infor__notice--blue";
      }
      if (
        item?.bidCloseDate &&
        new Date(item?.bidCloseDate).getTime() >= new Date().getTime()
      ) {
        return "content__body__left__item__infor__notice--blue";
      }
      return "";
    },
    getStatusKQ(item) {
      if (item.statusForNotify == "KCNTTT")
        return this.isEnglish
          ? "There is no successful bidder"
          : "Không có nhà thầu trúng thầu";
      if (item.statusForNotify == "CNTTT")
        return this.isEnglish ? "There is successful bidder" : "Có nhà thầu trúng thầu";
      if (item.statusForNotify == "DHT") return this.isEnglish ? "Canceled" : "Đã huỷ";
      return "";
    },
    getNttt(item) {
      return item?.winningContractorName?.toString() || "";
    },

    checkSearchKqlcnt() {
      return this.searchAdvancePayload && this.searchAdvancePayload.notiType == "kqlcnt";
    },
    checkSearchKqst() {
      return this.searchAdvancePayload && this.searchAdvancePayload.notiType == "kqst";
    },
    checkSearchKqmqt() {
      return this.searchAdvancePayload && this.searchAdvancePayload.notiType == "kqmqt";
    },
    isPublicAfter2024(publicDate) {
      if (!publicDate) return false;
      return new Date(publicDate).getTime() > new Date("2024-01-01T00:00:00");
    },
    checkIsNewLaw2025(item) {
      if (item.processApply != "LDT") return false;
      if (!item?.originalPublicDate) return false;
      return new Date(item?.originalPublicDate).getTime() > new Date(this.DATE_LAW_2025);
    },

    getTextCnttt(item) {
      if (item.contractorName) {
        if (item.contractorName.filter((it) => it != null).length > 1) {
          return this.isEnglish
            ? "(There are more than one successful bidders)"
            : "(Có nhiều hơn một nhà thầu trúng thầu)";
        } else if (item.contractorName.filter((it) => it != null).length == 1) {
          return item.contractorName.filter((it) => it != null)[0];
        } else {
          return null;
        }
      }
    },

    getPriceCnttt(item) {
      if (item.bidWinningPrice) {
        if (item.bidWinningPrice.length == 1) {
          return item.bidWinningPrice[0];
        } else {
          return item.bidWinningPrice?.reduce(function (total, current) {
            return total + current;
          }, 0);
        }
      }
    },

    breadcrumbRedirect(path) {
      let url = this.siteURL;
      if (path) url = `${url}/${path}`;
      window.location = url;
    },

    formatDate(value) {
      if (value) return value.split("/").reverse().join("-");
    },

    push7HoursToDate(date) {
      return new Date(date.getTime() + 7 * 60 * 60 * 1000);
    },

    convertDateTo(toDate) {
      return this.push7HoursToDate(new Date(new Date(toDate).setHours(23, 59, 59, 59)));
    },

    convertDateFrom(fromDate) {
      return this.push7HoursToDate(new Date(new Date(fromDate).setHours(0, 0, 0, 0)));
    },

    deleteAllAdvancedSearch() {
      localStorage.setItem("searchAdvancePayload", null);
      this.searchAdvancePayload = null;
      this.activeTab = "all";
      this.quickSearchPayload = {
        keyword: "",
        type: "all-1",
        searchWith: "notifyNo,bidName",
        matchFields: [],
        isBidCloseDate: null,
        pageSize: this.quickSearchPayload.pageSize,
      };
      this.indexSelect = -1;
      // localStorage.setItem('indexSelect', this.indexSelect);

      let payload = this.loadDetailQuickAndAdvance();
      // this.axiosSearchAggOpen(payload);
    },

    resetAdvancedSearch() {
      this.indexSelect = -1;
      // localStorage.setItem('indexSelect', this.indexSelect);
      localStorage.setItem("searchAdvancePayload", null);
      localStorage.setItem("pageSizeResult", this.quickSearchPayload.pageSize);
      this.searchAdvancePayload = null;
      this.quickSearchPayload.isBidCloseDate = null;
      this.currentPage = 0;

      this.activeTab = "all";

      let payload = this.loadDetailQuickAndAdvance();
      // this.axiosSearchAggOpen(payload);
      // this.axiosSearchAggClose(payload)
    },

    changePageSize() {
      if (JSON.parse(localStorage.getItem("searchAdvancePayload"))) {
        this.searchAdvancePayload = JSON.parse(
          localStorage.getItem("searchAdvancePayload")
        );
        this.searchAdvancePayload.pageSize = this.quickSearchPayload.pageSize;
        localStorage.setItem(
          "searchAdvancePayload",
          JSON.stringify(this.searchAdvancePayload)
        );
      }
      localStorage.setItem("pageSizeResult", this.quickSearchPayload.pageSize);
      let payload = this.loadDetailQuickAndAdvance();
      /*this.axiosSearchAggOpen(payload);
                this.axiosSearchAggClose(payload)*/
    },

    changeRootType(type) {
      if (type == "lcndt") {
        window.location = this.siteURL + "/investor-selection";
      } else {
        window.location = this.siteURL + "/contractor-selection?render=index";
      }
    },

    filterTab(type) {
      this.optionActive = type;

      localStorage.setItem("optionActive", this.optionActive);

      this.currentPage = 0;

      let payload = {};

      if (JSON.parse(localStorage.getItem("searchAdvancePayload"))) {
        this.searchAdvancePayload = JSON.parse(
          localStorage.getItem("searchAdvancePayload")
        );
        payload = this.convertAdvanceSearchToPayload(this.searchAdvancePayload);
      } else {
        payload = this.convertQuickSearchPayloadToPayload(this.quickSearchPayload);
      }

      if (type == "all") {
        payload.query[0].filters = payload.query[0].filters.filter(
          (it) => it.fieldName != "statusForNotify"
        );
      } else {
        payload.query[0].filters = payload.query[0].filters.filter(
          (it) => it.fieldName != "statusForNotify"
        );

        payload.query[0].filters.push({
          fieldName: "statusForNotify",
          searchType: "in",
          fieldValues: [type],
        });
      }

      this.axiosSearch(payload);
    },

    getQuantityStatusClosedDate(key) {
      let count = 0;
      let aggClose = this.aggClose?.filter(
        (it) => it.aggregationName == "facet_status_notify"
      );
      if (aggClose?.length > 0) {
        let closed = aggClose[0]?.bucketTerms?.filter((it) => it.key == key);
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityClosedDate() {
      let count = 0;
      let aggOpen = this.aggOpen?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "closed");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityNotCloseDate() {
      let count = 0;
      let aggOpen = this.aggOpen?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "open");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityStatusClosedDXT() {
      let count = 0;
      let aggClose = this.aggClose?.filter((it) => it.name == "status_dxt_blanks");
      if (aggClose?.length > 0) {
        let closed = aggClose[0]?.buckets?.filter((it) => it.key == "0");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityStatusCmtBlank() {
      let count = 0;
      let aggClose = this.aggClose?.filter((it) => it.name == "status_cmt_blank");
      if (aggClose?.length > 0) {
        let closed = aggClose[0]?.buckets?.filter((it) => it.key == "0");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityClosedDate() {
      let count = 0;
      let aggOpen = this.aggOpen?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "closed");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityNotCloseDate() {
      let count = 0;
      let aggOpen = this.aggOpen?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "open");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    loadMatchType(type) {
      if (type == "any-1")
        return this.isEnglish
          ? "Match all or match phrase (Distinct accents)"
          : "Khớp từ hoặc một số từ (Phân biệt dấu)";
      if (type == "any-0")
        return this.isEnglish
          ? "Match all or match phrase (Irrespective of accents)"
          : "Khớp từ hoặc một số từ (Không phân biệt dấu)";
      if (type == "all-1")
        return this.isEnglish
          ? "Match all (Distinct accents)"
          : "Khớp tất cả từ (Phân biệt dấu)";
      if (type == "all-0")
        return this.isEnglish
          ? "Match all (Irrespective of accents)"
          : "Khớp tất cả từ (Không phân biệt dấu)";
      if (type == "exact")
        return this.isEnglish ? "Match phrase" : "Khớp chính xác cụm từ";
    },

    loadSearchType() {
      if (this.searchAdvancePayload?.notiType == "da")
        return this.isEnglish ? "Project" : "Dự án";
      if (
        this.searchAdvancePayload?.notiType == "khlcnt" ||
        this.quickSearchPayload?.notiType == "khlcnt"
      ) {
        if (this.searchAdvancePayload?.haveBidNotNotify == true)
          return this.isEnglish
            ? "Bidder selection plan (Only search for bidding plans with bidding packages that have not yet posted ITB)"
            : "Kế hoạch lựa chọn nhà thầu (Chỉ tìm kiếm các KHLCNT có gói thầu chưa đăng tải TBMT)";
        return this.isEnglish ? "Bidder selection plan" : "Kế hoạch lựa chọn nhà thầu";
      }
      if (this.searchAdvancePayload?.notiType == "khlcnt-tt") {
        return "Kế hoạch tổng thể lựa chọn nhà thầu";
      }
      if (this.searchAdvancePayload?.notiType == "tbmt-cgttrg")
        return this.isEnglish
          ? "Invitation to Bid (shortened process)"
          : "Thông báo mời thầu (theo quy trình rút gọn)";
      if (
        this.searchAdvancePayload?.notiType == "tbmt" ||
        this.quickSearchPayload?.notiType == "tbmt"
      ) {
        if (this.searchAdvancePayload?.hasNotBeenClose == true)
          return this.isEnglish
            ? "ITB No. (Search only for tender notices that have not yet closed)"
            : "Thông báo mời thầu (Chỉ tìm kiếm các thông báo mời thầu chưa đóng thầu)";
        return this.isEnglish ? "ITB No." : "Thông báo mời thầu";
      }
      if (this.searchAdvancePayload?.notiType == "tbmst")
        return this.isEnglish
          ? "Invitation for pre-qualification"
          : "Thông báo mời sơ tuyển";
      if (this.searchAdvancePayload?.notiType == "tbmqt")
        return this.isEnglish
          ? "Request for expression of interest"
          : "Thông báo mời quan tâm";
      if (this.searchAdvancePayload?.notiType == "bbmt")
        return this.isEnglish ? "Bid opening minutes" : "Biên bản mở thầu";
      if (this.searchAdvancePayload?.notiType == "bbmst")
        return this.isEnglish
          ? "Results of prequalification opening"
          : "Biên bản mở sơ tuyển";
      if (this.searchAdvancePayload?.notiType == "bbmhsqt")
        return this.isEnglish
          ? "Results of consultant prequalification opening"
          : "Biên bản mở hồ sơ quan tâm";
      if (this.searchAdvancePayload?.notiType == "kqst")
        return this.isEnglish
          ? "Results of prequalification opening"
          : "Kết quả sơ tuyển";
      if (this.searchAdvancePayload?.notiType == "kqmqt")
        return this.isEnglish
          ? "Results of consultant prequalification opening"
          : "Kết quả mời quan tâm";
      if (this.searchAdvancePayload?.notiType == "kqlcnt")
        return this.isEnglish
          ? "Result of bidder selection"
          : "Kết quả lựa chọn nhà thầu";
      if (this.searchAdvancePayload?.notiType == "es-ycbg")
        return this.isEnglish ? "Request for quotation (RFQ)" : "Yêu cầu báo giá";
      if (this.searchAdvancePayload?.notiType == "es-bido-interest-notify")
        return this.isEnglish
          ? "Survey of Domestic Contractors’ Expression of Interest"
          : "Khảo sát quan tâm của nhà thầu trong nước";
      if (this.searchAdvancePayload?.notiType == "es-bide-contractor-input-result-other")
        return this.isEnglish
          ? "Kết quả lựa chọn nhà thầu (không liên kết với KHLCNT)"
          : "Kết quả lựa chọn nhà thầu (không liên kết với KHLCNT)";
      if (this.searchAdvancePayload?.notiType == "es-ct-publish-frame")
        return this.isEnglish ? "Thỏa thuận khung" : "Thỏa thuận khung";
      if (this.searchAdvancePayload?.notiType == "es-ct-contract")
        return this.isEnglish ? "Hợp đồng" : "Hợp đồng";
    },

    changeRadioSearchType(value) {
      this.quickSearchPayload.type = value;
    },

    changeRadioSearchWith(value) {
      this.quickSearchPayload.searchWith = value;
    },

    convertMatchField(quickSearchPayload) {
      let arr = [];
      if (quickSearchPayload.searchWith) {
        let arrSplit = quickSearchPayload.searchWith.split("\,");
        arr.push(...arrSplit);
      }
      if (quickSearchPayload.matchFields) {
        console.log("quickSearchPayload : ", this.quickSearchPayload);
        // arr.push(quickSearchPayload.matchFields);
        if (quickSearchPayload.matchFields?.includes("procuringEntityName")) {
          arr = arr.filter((it) => it != "investorName" && it != "investorCode");
          if (this.quickSearchPayload?.searchWith == "notifyNo,bidName") {
            arr.push("investorName");
            arr.push("investorCode");
          } else {
            arr.push("investorName");
            arr.push("investorCode");
            arr.push("procuringEntityName");
            arr.push("procuringEntityCode");
          }
        }
      }
      return arr;
    },

    convertQuickSearchPayloadToPayload(quickSearchPayload) {
      console.log("convertQuickSearchPayloadToPayload", quickSearchPayload);
      let matchFields = this.convertMatchField(quickSearchPayload);
      let filters = this.convertFilters(matchFields);
      let keyword = quickSearchPayload.keyword;
      let matchType = quickSearchPayload.type;
      let pageSize = quickSearchPayload.pageSize;

      let payload = {
        pageSize: pageSize,
        pageNumber: this.currentPage ? this.currentPage : 0,
        query: [
          {
            index: "es-contractor-selection",
            keyWord: keyword,
            matchType: matchType,
            matchFields: matchFields,
            filters: filters,
          },
        ],
      };

      return payload;
    },

    changeRadioSearchType(value) {
      this.quickSearchPayload.type = value;
    },

    changeRadioSearchWith(value) {
      this.quickSearchPayload.searchWith = value;
    },

    convertFilters(matchFields) {
      let isBidCloseDate = null;

      if (this.activeTab == "closed") isBidCloseDate = true;
      if (this.activeTab == "open") isBidCloseDate = false;

      let filters = [];
      if (matchFields?.includes("notifyNo")) {
        filters.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });

        filters.push({
          fieldName: "caseKHKQ",
          searchType: "not_in",
          fieldValues: ["1"],
        });

        if (isBidCloseDate == false) {
          filters.push({
            fieldName: "bidCloseDate",
            searchType: "range",
            from: this.push7HoursToDate(new Date()).toISOString(),
            to: null,
          });
        } else if (isBidCloseDate == true) {
          filters.push({
            fieldName: "bidCloseDate",
            searchType: "range",
            from: null,
            to: this.push7HoursToDate(new Date()).toISOString(),
          });
        }
      } else {
        filters.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-plan-project-p"],
        });
      }

      if (this.activeTab == "closed") {
        if (this.optionActive == "all") {
          filters = filters.filter((it) => it.fieldName != "statusForNotify");
        } else {
          filters = filters.filter((it) => it.fieldName != "statusForNotify");

          filters.push({
            fieldName: "statusForNotify",
            searchType: "in",
            fieldValues: [this.optionActive],
          });
        }
      }

      return filters;
    },

    convertQuickSearchPayloadToPayload(quickSearchPayload) {
      let matchFields = this.convertMatchField(quickSearchPayload);
      let filters = this.convertFilters(matchFields);
      let keyword = quickSearchPayload.keyword;
      let matchType = quickSearchPayload.type;
      let pageSize = quickSearchPayload.pageSize;

      let payload = {
        pageSize: pageSize,
        pageNumber: this.currentPage ? this.currentPage : 0,
        query: [
          {
            index: "es-contractor-selection",
            keyWord: keyword,
            matchType: matchType,
            matchFields: matchFields,
            filters: filters,
          },
        ],
      };

      return payload;
    },

    actionSearchQuick(payload) {
      localStorage.setItem("quickSearchPayload", JSON.stringify(this.quickSearchPayload));
      localStorage.setItem("searchAdvancePayload", null);
      this.searchAdvancePayload = null;

      this.axiosSearch(payload);
      // this.axiosSearchAggOpen(payload)
    },

    convertFilterAdvanceSearch(advancedSearchPayload) {
      let filterAdvanced = [];
      // let isBidCloseDate = this.quickSearchPayload.isBidCloseDate;
      let isBidCloseDate = null;

      if (this.activeTab == "closed") isBidCloseDate = true;

      if (this.activeTab == "open") isBidCloseDate = false;

      if (advancedSearchPayload.bidCloseFrom || advancedSearchPayload.bidCloseTo) {
        filterAdvanced.push({
          fieldName: "bidCloseDate",
          searchType: "range",
          from: advancedSearchPayload.bidCloseFrom
            ? this.convertDateFrom(advancedSearchPayload.bidCloseFrom)
            : null,
          to: advancedSearchPayload.bidCloseTo
            ? this.convertDateTo(advancedSearchPayload.bidCloseTo)
            : null,
        });
      }

      if (advancedSearchPayload.publicDateFrom || advancedSearchPayload.publicDateTo) {
        if (advancedSearchPayload.notiType == "kqlcnt") {
          filterAdvanced.push({
            fieldName: "publicDateKqlcnt",
            searchType: "range",
            from: advancedSearchPayload.publicDateFrom
              ? this.convertDateFrom(advancedSearchPayload.publicDateFrom)
              : null,
            to: advancedSearchPayload.publicDateTo
              ? this.convertDateTo(advancedSearchPayload.publicDateTo)
              : null,
          });
        } else {
          filterAdvanced.push({
            fieldName: "publicDate",
            searchType: "range",
            from: advancedSearchPayload.publicDateFrom
              ? this.convertDateFrom(advancedSearchPayload.publicDateFrom)
              : null,
            to: advancedSearchPayload.publicDateTo
              ? this.convertDateTo(advancedSearchPayload.publicDateTo)
              : null,
          });
        }
      }

      if (advancedSearchPayload.approveDateFrom || advancedSearchPayload.approveDateTo) {
        if (advancedSearchPayload.notiType == "es-bide-contractor-input-result-other") {
          filterAdvanced.push({
            fieldName: "approvalDate",
            searchType: "range",
            from: advancedSearchPayload.approveDateFrom
              ? this.convertDateFrom(advancedSearchPayload.approveDateFrom)
              : null,
            to: advancedSearchPayload.approveDateTo
              ? this.convertDateTo(advancedSearchPayload.approveDateTo)
              : null,
          });
        } else if (!filterAdvanced?.some((it) => it.fieldName == "bidCloseDate")) {
          filterAdvanced.push({
            fieldName: "bidCloseDate",
            searchType: "range",
            from: advancedSearchPayload.approveDateFrom
              ? this.convertDateFrom(advancedSearchPayload.approveDateFrom)
              : null,
            to: advancedSearchPayload.approveDateTo
              ? this.convertDateTo(advancedSearchPayload.approveDateTo)
              : null,
          });
        }
      }

      if (
        advancedSearchPayload.contractSignDateFrom ||
        advancedSearchPayload.contractSignDateTo
      ) {
        filterAdvanced.push({
          fieldName: "contractSignDate",
          searchType: "range",
          from: advancedSearchPayload.contractSignDateFrom
            ? this.convertDateFrom(advancedSearchPayload.contractSignDateFrom)
            : null,
          to: advancedSearchPayload.contractSignDateTo
            ? this.convertDateTo(advancedSearchPayload.contractSignDateTo)
            : null,
        });
      }

      if (
        advancedSearchPayload.contractPriceFrom ||
        advancedSearchPayload.contractPriceTo
      ) {
        filterAdvanced.push({
          fieldName: "ctPriceAfter",
          searchType: "range",
          from: advancedSearchPayload.contractPriceFrom
            ? advancedSearchPayload.contractPriceFrom
            : null,
          to: advancedSearchPayload.contractPriceTo
            ? advancedSearchPayload.contractPriceTo
            : null,
        });
      }

      if (advancedSearchPayload.bidPriceFrom || advancedSearchPayload.bidPriceTo) {
        filterAdvanced.push({
          fieldName: "bidPrice",
          searchType: "range",
          from: advancedSearchPayload.bidPriceFrom
            ? advancedSearchPayload.bidPriceFrom
            : null,
          to: advancedSearchPayload.bidPriceTo ? advancedSearchPayload.bidPriceTo : null,
        });
      }

      if (advancedSearchPayload.investTotalFrom || advancedSearchPayload.investTotalTo) {
        filterAdvanced.push({
          fieldName: "investTotal",
          searchType: "range",
          from: advancedSearchPayload.investTotalFrom
            ? advancedSearchPayload.investTotalFrom
            : null,
          to: advancedSearchPayload.investTotalTo
            ? advancedSearchPayload.investTotalTo
            : null,
        });
      }

      if (
        advancedSearchPayload.investField &&
        advancedSearchPayload.investField?.length > 0
      ) {
        filterAdvanced.push({
          fieldName: "investField",
          searchType: "in",
          fieldValues: advancedSearchPayload.investField,
        });
      }

      if (advancedSearchPayload?.isDomestic?.length > 0) {
        filterAdvanced.push({
          fieldName: "isDomestic",
          searchType: "in",
          fieldValues: advancedSearchPayload.isDomestic.map((it) => Number(it)),
        });
      }

      if (advancedSearchPayload.notiType == "khlcnt") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-plan-project-p"],
        });
      }

      if (advancedSearchPayload.notiType == "es-shopping-result") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-shopping-result"],
        });

        if (advancedSearchPayload.orderPriceFrom || advancedSearchPayload.orderPriceTo) {
          filterAdvanced.push({
            fieldName: "bidWinningPrice",
            searchType: "range",
            from: advancedSearchPayload.orderPriceFrom
              ? advancedSearchPayload.orderPriceFrom
              : null,
            to: advancedSearchPayload.orderPriceTo
              ? advancedSearchPayload.orderPriceTo
              : null,
          });
        }

        if (advancedSearchPayload.orderNo) {
          filterAdvanced.push({
            fieldName: "orderNo",
            searchType: "in",
            fieldValues: [advancedSearchPayload.orderNo],
          });
        }
      }

      if (advancedSearchPayload.notiType == "es-ycbg") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-ycbg"],
        });
      }

      if (advancedSearchPayload.notiType == "es-bido-interest-notify") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-bido-interest-notify"],
        });
      }

      if (
        advancedSearchPayload.notiType == "es-ct-contract" ||
        advancedSearchPayload.notiType == "es-ct-publish-frame"
      ) {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: [advancedSearchPayload.notiType],
        });
      }

      // if (advancedSearchPayload.notiType == 'es-re-offer-price') {
      //     filterAdvanced.push({
      //         fieldName: "type",
      //         searchType: "in",
      //         fieldValues: [ "es-re-offer-price"]
      //     });
      //
      //     filterAdvanced.push({
      //         fieldName: "bidForm",
      //         searchType: "in",
      //         fieldValues: ["CGTTRG"]
      //     });
      //
      //     if (this.activeReOffer == 'upcoming' ) {
      //         filterAdvanced.push({
      //             "fieldName": "bidOpenDate",
      //             "searchType": "range",
      //             "from": this.push7HoursToDate(new Date()).toISOString(),
      //             "to": null
      //         });
      //         filterAdvanced.push({
      //             "fieldName": "status",
      //             searchType: "not_in",
      //             fieldValues: ["03"]
      //         });
      //     }
      //     else if (this.activeReOffer == 'open') {
      //         filterAdvanced.push({
      //             "fieldName": "bidOpenDate",
      //             "searchType": "range",
      //             "from": null,
      //             "to": this.push7HoursToDate(new Date()).toISOString(),
      //         });
      //         filterAdvanced.push({
      //             fieldName: "status",
      //             searchType: "not_in",
      //             fieldValues: ["03"]
      //         });
      //
      //         filterAdvanced.push({
      //             "fieldName": "bidCloseDate",
      //             "searchType": "range",
      //             "from": this.push7HoursToDate(new Date()).toISOString(),
      //             "to": null
      //         });
      //     } else if (this.activeReOffer == 'closed') {
      //         filterAdvanced.push({
      //             "fieldName": "bidCloseDate",
      //             "searchType": "range",
      //             "from": null,
      //             "to": this.push7HoursToDate(new Date()).toISOString(),
      //         });
      //         filterAdvanced.push({
      //             fieldName: "status",
      //             searchType: "not_in",
      //             fieldValues: ["03"]
      //         });
      //     }
      //     if(this.activeReOffer != 'all'){
      //         filterAdvanced.push(
      //             {
      //                 fieldName: "isMultiLot",
      //                 searchType: "in",
      //                 fieldValues: [this.isMultiLotReOffer]
      //             }
      //         )
      //     }
      // }

      if (advancedSearchPayload.notiType == "es-bide-contractor-input-result-other") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-bide-contractor-input-result-other"],
        });
      }

      if (advancedSearchPayload.notiType == "khlcnt-tt") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-khlcnt-tt"],
        });
      }

      if (advancedSearchPayload.notiType == "da") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-bidp-project-p"],
        });
      }

      // if (advancedSearchPayload.keywordDA) {
      //
      //     if (advancedSearchPayload.keywordKH) {
      //         filterAdvanced.push({
      //             fieldName: "type",
      //             searchType: "in",
      //             fieldValues: ["es-bidp-project-p", "es-plan-project-p"]
      //         });
      //     } else {
      //         filterAdvanced.push({
      //             fieldName: "type",
      //             searchType: "in",
      //             fieldValues: ["es-bidp-project-p"]
      //         });
      //     }
      //
      // }

      // if (advancedSearchPayload.notiType) {
      if (isBidCloseDate == false) {
        filterAdvanced.push({
          fieldName: "bidCloseDate",
          searchType: "range",
          from: this.push7HoursToDate(new Date()).toISOString(),
          to: null,
        });
      } else if (isBidCloseDate == true) {
        filterAdvanced.push({
          fieldName: "bidCloseDate",
          searchType: "range",
          from: null,
          to: this.push7HoursToDate(new Date()).toISOString(),
        });
      }

      if (
        advancedSearchPayload.notiType == "tbmt" ||
        advancedSearchPayload.notiType == "tbmt-cgttrg"
      ) {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });
        filterAdvanced.push({
          fieldName: "caseKHKQ",
          searchType: "not_in",
          fieldValues: ["1"],
        });
      } else if (advancedSearchPayload.notiType == "tbmst") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );

        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "investField",
          searchType: "not_in",
          fieldValues: ["TV"],
        });
      } else if (advancedSearchPayload.notiType == "tbmqt") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );

        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        let qr = filterAdvanced.filter((it) => it.fieldName == "investField");
        if (qr?.length > 0) {
          qr[0].fieldValues.push("TV");
        } else {
          filterAdvanced = filterAdvanced.filter((it) => it.fieldName != "investField");
          filterAdvanced.push({
            fieldName: "investField",
            searchType: "in",
            fieldValues: ["TV"],
          });
        }
      } else if (advancedSearchPayload.notiType == "kqlcnt") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["notify-contractor-step-4-kqlcnt"],
        });
      } else if (advancedSearchPayload.notiType == "kqlcnt-medicine") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["notify-contractor-step-4-kqlcnt"],
        });
      } else if (advancedSearchPayload.notiType == "kqst") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "investField",
          searchType: "not_in",
          fieldValues: ["TV"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["pre-notify-contractor-step-3-kqst"],
        });
      } else if (advancedSearchPayload.notiType == "kqmqt") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["pre-notify-contractor-step-3-kqst"],
        });

        let qr = filterAdvanced.filter((it) => it.fieldName == "investField");
        if (qr?.length > 0) {
          qr[0].fieldValues.push("TV");
        } else {
          filterAdvanced = filterAdvanced.filter((it) => it.fieldName != "investField");
          filterAdvanced.push({
            fieldName: "investField",
            searchType: "in",
            fieldValues: ["TV"],
          });
        }
      } else if (advancedSearchPayload.notiType == "bbmt") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: [
            "notify-contractor-step-2-kqmt",
            "notify-contractor-step-3-dsntdkt",
            "notify-contractor-step-4-kqlcnt",
          ],
        });

        filterAdvanced.push({
          fieldName: "publicDateKqmt",
          searchType: "not_null",
          fieldValues: [""],
        });

        // filterAdvanced.push({
        //     fieldName: "caseKHKQ",
        //     searchType: "not_in",
        //     fieldValues: [1]
        // });
      } else if (advancedSearchPayload.notiType == "bbmhsqt") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["pre-notify-contractor-step-2-kqmst"],
        });

        let qr = filterAdvanced.filter((it) => it.fieldName == "investField");
        if (qr?.length > 0) {
          qr[0].fieldValues.push("TV");
        } else {
          filterAdvanced = filterAdvanced.filter((it) => it.fieldName != "investField");
          filterAdvanced.push({
            fieldName: "investField",
            searchType: "in",
            fieldValues: ["TV"],
          });
        }
      } else if (advancedSearchPayload.notiType == "bbmst") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "investField",
          searchType: "not_in",
          fieldValues: ["TV"],
        });

        filterAdvanced.push({
          fieldName: "stepCode",
          searchType: "in",
          fieldValues: ["pre-notify-contractor-step-2-kqmst"],
        });
      } else if (advancedSearchPayload.notiType == "es-kqlcnt-old") {
        filterAdvanced = filterAdvanced.filter((it) => it.fieldName != "type");

        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-kqlcnt-old"],
        });
      } else if (advancedSearchPayload.notiType == "tbmt-medicine") {
        filterAdvanced = filterAdvanced.filter(
          (it) => it.fieldName != "type" && it.fieldName != "stepCode"
        );
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });
        filterAdvanced.push({
          fieldName: "isMedicine",
          searchType: "in",
          fieldValues: [1],
        });
        filterAdvanced.push({
          fieldName: "caseKHKQ",
          searchType: "not_in",
          fieldValues: ["1"],
        });
        if (advancedSearchPayload.listKeywordMedicineNew?.length > 0) {
          filterAdvanced.push({
            fieldName: "medicines",
            searchType: "in",
            fieldValues: [4, 5],
          });
        } else if (advancedSearchPayload.listKeywordMedicineOld?.length > 0) {
          filterAdvanced.push({
            fieldName: "medicines",
            searchType: "in",
            fieldValues: [0, 1, 2, 3, 6, 7],
          });
        }
      }
      // else {
      //     filterAdvanced.push({
      //         fieldName: "type",
      //         searchType: "in",
      //         fieldValues: ["es-bidp-project-p", "es-plan-project-p"]
      //     });
      //
      // }

      // }

      if (advancedSearchPayload.notiType == "khlcnt-tt") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-khlcnt-tt"],
        });
      }

      if (advancedSearchPayload.notiType == "khlcnt") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-plan-project-p"],
        });
      }

      if (advancedSearchPayload.notiType == "da") {
        filterAdvanced.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-bidp-project-p"],
        });
      }

      // if (advancedSearchPayload.keywordGood) {
      //
      //     filterAdvanced.push({
      //         fieldName: "type",
      //         searchType: "in",
      //         fieldValues: ["es-notify-contractor"]
      //     });
      // }

      if (advancedSearchPayload.bidForm) {
        filterAdvanced.push({
          fieldName: "bidForm",
          searchType: "in",
          fieldValues: [advancedSearchPayload.bidForm],
        });
      }

      if (
        advancedSearchPayload.isDomestic &&
        advancedSearchPayload.isDomestic.length > 0
      ) {
        filterAdvanced.push({
          fieldName: "isDomestic",
          searchType: "in",
          fieldValues: advancedSearchPayload.isDomestic.map((it) => Number(it)),
        });
      }

      if (advancedSearchPayload.bidMode) {
        filterAdvanced.push({
          fieldName: "bidMode",
          searchType: "in",
          fieldValues: [advancedSearchPayload.bidMode],
        });
      }

      if (advancedSearchPayload.processApply) {
        filterAdvanced.push({
          fieldName: "processApply",
          searchType: "in",
          fieldValues: [advancedSearchPayload.processApply],
        });
      }

      if (
        advancedSearchPayload.isInternet &&
        advancedSearchPayload.isInternet.length > 0
      ) {
        filterAdvanced.push({
          fieldName: "isInternet",
          searchType: "in",
          fieldValues: advancedSearchPayload.isInternet.map((it) => Number(it)),
        });
      }

      if (advancedSearchPayload.workType && advancedSearchPayload.workType.length > 0) {
        filterAdvanced.push({
          fieldName: "workType",
          searchType: "in",
          fieldValues: advancedSearchPayload.workType,
        });
      }

      if (
        advancedSearchPayload.locationTinh &&
        advancedSearchPayload.locationTinh.length > 0
      ) {
        const selectedNames = this.listProvince
          ?.filter((lc) => advancedSearchPayload.locationTinh?.includes(lc.code))
          ?.map((lc) => lc.name);
        const locationProvCodeConvert = this.listProvince
          ?.filter((it) => selectedNames?.includes(it.name))
          ?.map((it) => it.code);
        filterAdvanced.push({
          fieldName: "locations.provCode",
          searchType: "in",
          fieldValues: locationProvCodeConvert,
        });
      }

      if (
        advancedSearchPayload.locationQuan &&
        advancedSearchPayload.locationQuan.length > 0
      ) {
        filterAdvanced.push({
          fieldName: "locations.districtCode",
          searchType: "in",
          fieldValues: advancedSearchPayload.locationQuan,
        });
      }

      if (advancedSearchPayload.haveBidNotNotify == true) {
        filterAdvanced.push({
          fieldName: "haveBidNotNotify",
          searchType: "in",
          fieldValues: ["1"],
        });
      }

      console.log(
        "advancedSearchPayload.hasNotBeenClose  : ",
        advancedSearchPayload.hasNotBeenClose
      );
      if (advancedSearchPayload.hasNotBeenClose == true) {
        console.log(
          "this.push7HoursToDate(new Date()).toISOString, : ",
          this.push7HoursToDate(new Date()).toISOString()
        );

        filterAdvanced.push({
          fieldName: "bidCloseDate",
          searchType: "range",
          from: this.push7HoursToDate(new Date()).toISOString(),
          to: null,
        });
      }

      if (
        advancedSearchPayload.numSavingRateFrom ||
        advancedSearchPayload.numSavingRateTo
      ) {
        filterAdvanced.push({
          fieldName: "numSavingRate",
          searchType: "range",
          from: advancedSearchPayload.numSavingRateFrom
            ? advancedSearchPayload.numSavingRateFrom / 100
            : null,
          to: advancedSearchPayload.numSavingRateTo
            ? advancedSearchPayload.numSavingRateTo / 100
            : null,
        });
      }
      // if (advancedSearchPayload.numPetitionFrom || advancedSearchPayload.numPetitionTo) {
      //     filterAdvanced.push({
      //         fieldName: "numPetition",
      //         searchType: "range",
      //         from: (advancedSearchPayload.numPetitionFrom) ? advancedSearchPayload.numPetitionFrom : null,
      //         to: (advancedSearchPayload.numPetitionTo) ? advancedSearchPayload.numPetitionTo : null,
      //     })
      // }
      // if(advancedSearchPayload?.typePetition?.length == 0){
      //     if (advancedSearchPayload.numPetitionFrom || advancedSearchPayload.numPetitionTo) {
      //         filterAdvanced.push({
      //             fieldName: "numPetition",
      //             searchType: "range",
      //             from: (advancedSearchPayload.numPetitionFrom) ? advancedSearchPayload.numPetitionFrom : null,
      //             to: (advancedSearchPayload.numPetitionTo) ? advancedSearchPayload.numPetitionTo : null,
      //         })
      //     }
      // } else {
      //     if(advancedSearchPayload?.typePetition?.length > 0){
      //         if(advancedSearchPayload?.typePetition.includes('LCNT_QM')){
      //             filterAdvanced.push({
      //                 fieldName: "numPetitionLcnt",
      //                 searchType: "range",
      //                 from: (advancedSearchPayload.numPetitionFrom) ? advancedSearchPayload.numPetitionFrom : 1,
      //                 to: (advancedSearchPayload.numPetitionTo) ? advancedSearchPayload.numPetitionTo : null,
      //             })
      //         }
      //         if(advancedSearchPayload?.typePetition.includes('KQDT')){
      //             filterAdvanced.push({
      //                 fieldName: "numPetitionKqlcnt",
      //                 searchType: "range",
      //                 from: (advancedSearchPayload.numPetitionFrom) ? advancedSearchPayload.numPetitionFrom : 1,
      //                 to: (advancedSearchPayload.numPetitionTo) ? advancedSearchPayload.numPetitionTo : null,
      //             })
      //         }
      //         if(advancedSearchPayload?.typePetition.includes('E-HSMT')){
      //             filterAdvanced.push({
      //                 fieldName: "numPetitionHsmt",
      //                 searchType: "range",
      //                 from: (advancedSearchPayload.numPetitionFrom) ? advancedSearchPayload.numPetitionFrom : 1,
      //                 to: (advancedSearchPayload.numPetitionTo) ? advancedSearchPayload.numPetitionTo : null,
      //             })
      //         }
      //     }
      // }
      if (
        advancedSearchPayload.numPetitionFromEHSMT ||
        advancedSearchPayload.numPetitionToEHSMT
      ) {
        if (
          advancedSearchPayload.numPetitionToEHSMT != null &&
          !advancedSearchPayload.numPetitionFromEHSMT
        )
          advancedSearchPayload.numPetitionFromEHSMT = 0;
        filterAdvanced.push({
          fieldName: "numPetitionHsmt",
          searchType: "range",
          from: advancedSearchPayload.numPetitionFromEHSMT
            ? advancedSearchPayload.numPetitionFromEHSMT
            : null,
          to: advancedSearchPayload.numPetitionToEHSMT
            ? advancedSearchPayload.numPetitionToEHSMT
            : null,
        });
      }
      if (
        advancedSearchPayload.numPetitionFromLCNT ||
        advancedSearchPayload.numPetitionToLCNT
      ) {
        if (
          advancedSearchPayload.numPetitionToLCNT != null &&
          !advancedSearchPayload.numPetitionFromLCNT
        )
          advancedSearchPayload.numPetitionFromLCNT = 0;

        filterAdvanced.push({
          fieldName: "numPetitionLcnt",
          searchType: "range",
          from: advancedSearchPayload.numPetitionFromLCNT
            ? advancedSearchPayload.numPetitionFromLCNT
            : null,
          to: advancedSearchPayload.numPetitionToLCNT
            ? advancedSearchPayload.numPetitionToLCNT
            : null,
        });
      }
      if (
        advancedSearchPayload.numPetitionFromKQLCNT ||
        advancedSearchPayload.numPetitionToKQLCNT
      ) {
        if (
          advancedSearchPayload.numPetitionToKQLCNT != null &&
          !advancedSearchPayload.numPetitionFromKQLCNT
        )
          advancedSearchPayload.numPetitionFromKQLCNT = 0;

        filterAdvanced.push({
          fieldName: "numPetitionKqlcnt",
          searchType: "range",
          from: advancedSearchPayload.numPetitionFromKQLCNT
            ? advancedSearchPayload.numPetitionFromKQLCNT
            : null,
          to: advancedSearchPayload.numPetitionToKQLCNT
            ? advancedSearchPayload.numPetitionToKQLCNT
            : null,
        });
      }
      if (
        advancedSearchPayload.numPentitionKqlcntNotResFrom ||
        advancedSearchPayload.numPentitionKqlcntNotResTo
      ) {
        if (
          advancedSearchPayload.numPentitionKqlcntNotResTo != null &&
          !advancedSearchPayload.numPentitionKqlcntNotResFrom
        )
          advancedSearchPayload.numPentitionKqlcntNotResFrom = 0;

        filterAdvanced.push({
          fieldName: "numPentitionKqlcntNotRes",
          searchType: "range",
          from: advancedSearchPayload.numPentitionKqlcntNotResFrom
            ? advancedSearchPayload.numPentitionKqlcntNotResFrom
            : null,
          to: advancedSearchPayload.numPentitionKqlcntNotResTo
            ? advancedSearchPayload.numPentitionKqlcntNotResTo
            : null,
        });
      }
      if (
        advancedSearchPayload.numPentitionHsmtNotResFrom ||
        advancedSearchPayload.numPentitionKqlcntNotResTo
      ) {
        if (
          advancedSearchPayload.numPentitionHsmtNotResTo != null &&
          !advancedSearchPayload.numPentitionHsmtNotResFrom
        )
          advancedSearchPayload.numPentitionHsmtNotResFrom = 0;

        filterAdvanced.push({
          fieldName: "numPentitionHsmtNotRes",
          searchType: "range",
          from: advancedSearchPayload.numPentitionHsmtNotResFrom
            ? advancedSearchPayload.numPentitionHsmtNotResFrom
            : null,
          to: advancedSearchPayload.numPentitionHsmtNotResTo
            ? advancedSearchPayload.numPentitionHsmtNotResTo
            : null,
        });
      }
      if (
        advancedSearchPayload.numClarifyNotResFrom ||
        advancedSearchPayload.numClarifyNotResTo
      ) {
        if (
          advancedSearchPayload.numClarifyNotResTo != null &&
          !advancedSearchPayload.numClarifyNotResFrom
        )
          advancedSearchPayload.numClarifyNotResFrom = 0;

        filterAdvanced.push({
          fieldName: "numClarifyNotRes",
          searchType: "range",
          from: advancedSearchPayload.numClarifyNotResFrom
            ? advancedSearchPayload.numClarifyNotResFrom
            : null,
          to: advancedSearchPayload.numClarifyNotResTo
            ? advancedSearchPayload.numClarifyNotResTo
            : null,
        });
      }
      if (
        advancedSearchPayload.numClarifyReqFrom ||
        advancedSearchPayload.numClarifyReqTo
      ) {
        if (
          advancedSearchPayload.numClarifyReqTo != null &&
          !advancedSearchPayload.numClarifyReqFrom
        )
          advancedSearchPayload.numClarifyReqFrom = 0;

        filterAdvanced.push({
          fieldName: "numClarifyReq",
          searchType: "range",
          from: advancedSearchPayload.numClarifyReqFrom
            ? advancedSearchPayload.numClarifyReqFrom
            : null,
          to: advancedSearchPayload.numClarifyReqTo
            ? advancedSearchPayload.numClarifyReqTo
            : null,
        });
      }
      if (
        advancedSearchPayload.numBidderTechFrom ||
        advancedSearchPayload.numBidderTechTo
      ) {
        if (
          advancedSearchPayload.numBidderTechTo != null &&
          !advancedSearchPayload.numBidderTechFrom
        )
          advancedSearchPayload.numBidderTechFrom = 0;

        filterAdvanced.push({
          fieldName: "numBidderTech",
          searchType: "range",
          from: advancedSearchPayload.numBidderTechFrom
            ? advancedSearchPayload.numBidderTechFrom
            : null,
          to: advancedSearchPayload.numBidderTechTo
            ? advancedSearchPayload.numBidderTechTo
            : null,
        });
      }
      if (
        advancedSearchPayload.numBidderJoinFrom ||
        advancedSearchPayload.numBidderJoinTo
      ) {
        if (
          advancedSearchPayload.numBidderJoinTo != null &&
          !advancedSearchPayload.numBidderJoinFrom
        )
          advancedSearchPayload.numBidderJoinFrom = 0;

        filterAdvanced.push({
          fieldName: "numBidderJoin",
          searchType: "range",
          from: advancedSearchPayload.numBidderJoinFrom
            ? advancedSearchPayload.numBidderJoinFrom
            : null,
          to: advancedSearchPayload.numBidderJoinTo
            ? advancedSearchPayload.numBidderJoinTo
            : null,
        });
      }
      if (this.activeTab == "closed") {
        if (this.optionActive == "all") {
          filterAdvanced = filterAdvanced.filter(
            (it) => it.fieldName != "statusForNotify"
          );
        } else {
          filterAdvanced = filterAdvanced.filter(
            (it) => it.fieldName != "statusForNotify"
          );

          filterAdvanced.push({
            fieldName: "statusForNotify",
            searchType: "in",
            fieldValues: [this.optionActive],
          });
        }
      }

      return filterAdvanced;
    },

    checkIsEn() {
      if (this.currentUrl.includes("en/")) return true;
      return false;
    },

    convertKeywordSearch(str) {
      if (str) {
        if (str.substr(str.length - 3).includes("-")) {
          return str.slice(0, -3).toUpperCase();
        }
      }

      return str;
    },

    convertAdvanceSearchToPayload(advancedSearchPayload) {
      let queries = this.convertQueriesForAdvanceSearch(advancedSearchPayload);
      this.quickSearchPayload.pageSize = advancedSearchPayload.pageSize;
      let payload = {
        pageSize: advancedSearchPayload.pageSize,
        pageNumber: this.currentPage ? this.currentPage : 0,
        query: queries,
      };
      return payload;
    },

    convertQueriesForAdvanceSearch(advancedSearchPayload) {
      let queries = [];

      let filters = this.convertFilterAdvanceSearch(advancedSearchPayload);

      if (
        advancedSearchPayload.notiType == "kqlcnt-medicine" &&
        advancedSearchPayload.listKeywordMedicineOld &&
        advancedSearchPayload.listKeywordMedicineOld?.length > 0
      ) {
        let listKeywordMedicineOld = advancedSearchPayload.listKeywordMedicineOld.join(
          " AND "
        );
        queries.push({
          index: "es-contractor-selection",
          keyWord: listKeywordMedicineOld,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["pvccMedicineOld"],
          filters: filters,
        });
      }

      if (
        advancedSearchPayload.notiType == "kqlcnt-medicine" &&
        advancedSearchPayload.listKeywordMedicineNew &&
        advancedSearchPayload.listKeywordMedicineNew?.length > 0
      ) {
        let listKeywordMedicineNew = advancedSearchPayload.listKeywordMedicineNew.join(
          " AND "
        );
        queries.push({
          index: "es-contractor-selection",
          keyWord: listKeywordMedicineNew,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["pvccMedicineNew"],
          filters: filters,
        });
      }

      if (
        advancedSearchPayload.notiType == "tbmt-medicine" &&
        advancedSearchPayload.listKeywordMedicineOld &&
        advancedSearchPayload.listKeywordMedicineOld?.length > 0
      ) {
        let listKeywordMedicineOld = advancedSearchPayload.listKeywordMedicineOld.join(
          " AND "
        );
        queries.push({
          index: "es-contractor-selection",
          keyWord: listKeywordMedicineOld,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["goods"],
          filters: filters,
        });
      }

      if (
        advancedSearchPayload.notiType == "tbmt-medicine" &&
        advancedSearchPayload.listKeywordMedicineNew &&
        advancedSearchPayload.listKeywordMedicineNew?.length > 0
      ) {
        let listKeywordMedicineNew = advancedSearchPayload.listKeywordMedicineNew.join(
          " AND "
        );
        queries.push({
          index: "es-contractor-selection",
          keyWord: listKeywordMedicineNew,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["goods"],
          filters: filters,
        });
      }

      if (
        advancedSearchPayload.listKeywordCdt &&
        advancedSearchPayload.listKeywordCdt?.length > 0
      ) {
        let listKeywordCDT = advancedSearchPayload.listKeywordCdt.join(" AND ");
        queries.push({
          index: "es-contractor-selection",
          keyWord: listKeywordCDT,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["procuringEntityName", "procuringEntityCode"],
          filters: filters,
        });
      }
      if (
        advancedSearchPayload.listKeywordBmt &&
        advancedSearchPayload.listKeywordBmt?.length > 0
      ) {
        let listKeywordBMT = advancedSearchPayload.listKeywordBmt.join(" AND ");

        console.log("advancedSearchPayload.notiType  : ", advancedSearchPayload.notiType);
        if (advancedSearchPayload.notiType == "khlcnt") {
          queries.push({
            index: "es-contractor-selection",
            keyWord: listKeywordBMT,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: [
              "investorName",
              "investorCode",
              "procuringEntityName",
              "procuringEntityCode",
            ],
            filters: filters,
          });
        } else {
          queries.push({
            index: "es-contractor-selection",
            keyWord: listKeywordBMT,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["investorName", "investorCode"],
            filters: filters,
          });
        }
      }
      if (advancedSearchPayload.notiType == "da") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["pNo", "name"],
            filters: filters,
          });
        }
      }

      if (advancedSearchPayload.notiType == "es-kqlcnt-old") {
        console.log("222222");
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["resultNo", "planNo", "bidName", "preNotifyNo", "notifyNo"],
            filters: filters,
          });
        }
      }

      if (advancedSearchPayload.notiType == "es-shopping-result") {
        if (advancedSearchPayload.keyword) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["bidNo", "bidName"],
            filters: filters,
          });
        }

        if (advancedSearchPayload.planNoShopping) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.planNoShopping,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["planNo"],
            filters: filters,
          });
        }

        if (advancedSearchPayload.projectNameShopping) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.projectNameShopping,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["pName"],
            filters: filters,
          });
        }
      }

      if (
        advancedSearchPayload.notiType == "tbmt" ||
        advancedSearchPayload.notiType == "tbmt-cgttrg" ||
        advancedSearchPayload.notiType == "tbmqt" ||
        advancedSearchPayload.notiType == "tbmst" ||
        advancedSearchPayload.notiType == "kqlcnt"
      ) {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["notifyNo", "bidName"],
            filters: filters,
          });
        }
      }

      if (advancedSearchPayload.notiType == "khlcnt") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["planNo", "name"],
            filters: filters,
          });
        }
        // }else if(advancedSearchPayload.bidName || advancedSearchPayload.keyWordNotMatchSub){
        //     queries.push({
        //         index: "es-contractor-selection",
        //         keyWord: advancedSearchPayload.bidName,
        //         keyWordNotMatch: advancedSearchPayload.keyWordNotMatchSub,
        //         matchType: advancedSearchPayload.matchType,
        //         matchFields: ['bidName'],
        //         filters: filters
        //     });
        // }
      }

      if (advancedSearchPayload.notiType == "khlcnt-tt") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["planNo", "name"],
            filters: filters,
          });
        }
      }

      if (advancedSearchPayload.notiType == "es-ycbg") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["notifyNo", "name"],
            filters: filters,
          });
        }
        // }else if(advancedSearchPayload.bidName || advancedSearchPayload.keyWordNotMatchSub){
        //     queries.push({
        //         index: "es-contractor-selection",
        //         keyWord: advancedSearchPayload.bidName,
        //         keyWordNotMatch: advancedSearchPayload.keyWordNotMatchSub,
        //         matchType: advancedSearchPayload.matchType,
        //         matchFields: ['notifyNo','bidName'],
        //         filters: filters
        //     });
        // }
      }

      if (advancedSearchPayload.notiType == "es-bido-interest-notify") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["notifyNo", "name"],
            filters: filters,
          });
        }
      }

      if (
        advancedSearchPayload.notiType == "es-ct-contract" ||
        advancedSearchPayload.notiType == "es-ct-publish-frame"
      ) {
        if (advancedSearchPayload.keyword) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["contractCode", "bidName"],
            filters: filters,
          });
        }
      }

      if (advancedSearchPayload.notiType == "es-re-offer-price") {
        queries.push({
          index: "es-contractor-selection",
          keyWord: advancedSearchPayload.keyword,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["pNo", "bidName"],
          filters: filters,
        });
      }

      if (advancedSearchPayload.notiType == "es-bide-contractor-input-result-other") {
        if (advancedSearchPayload.keyword || advancedSearchPayload.keyWordNotMatch) {
          queries.push({
            index: "es-contractor-selection",
            keyWord: advancedSearchPayload.keyword,
            keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
            matchType: advancedSearchPayload.matchType,
            matchFields: ["notifyNo", "bidName"],
            filters: filters,
          });
        }
      }

      if (
        advancedSearchPayload.notiType == "kqlcnt" ||
        advancedSearchPayload.notiType == "tbmt" ||
        advancedSearchPayload.notiType == "tbmt-cgttrg" ||
        advancedSearchPayload.notiType == "es-kqlcnt-old" ||
        advancedSearchPayload.notiType == "es-shopping-result"
      ) {
        if (
          advancedSearchPayload.keywordGood ||
          advancedSearchPayload.keyWordNotMatchSub
        ) {
          if (advancedSearchPayload.notiType == "kqlcnt") {
            queries.push({
              index: "es-contractor-selection",
              keyWord: advancedSearchPayload.keywordGood,
              keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
              matchType: advancedSearchPayload.matchType,
              matchFields: ["pvccNewKqlcnt"],
              filters: filters,
            });
          } else {
            queries.push({
              index: "es-contractor-selection",
              keyWord: advancedSearchPayload.keywordGood,
              keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
              matchType: advancedSearchPayload.matchType,
              matchFields: ["goods"],
              filters: filters,
            });
          }
        }
      }
      if (advancedSearchPayload.keywordNttt) {
        queries.push({
          index: "es-contractor-selection",
          keyWord: advancedSearchPayload.keywordNttt,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["contractorName", "winningCode", "winningContractorName"],
          filters: filters,
        });
      }
      if (advancedSearchPayload.keywordGoodsBG) {
        queries.push({
          index: "es-contractor-selection",
          keyWord: advancedSearchPayload.keywordGoodsBG,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["goods"],
          filters: filters,
        });
      }

      if (queries?.length == 0) {
        queries.push({
          index: "es-contractor-selection",
          keyWord: advancedSearchPayload.keyword,
          keyWordNotMatch: advancedSearchPayload.keyWordNotMatch,
          matchType: advancedSearchPayload.matchType,
          matchFields: ["notifyNo", "bidName"],
          // filters: this.getFilterByNotifyType(advancedSearchPayload.notiType)
          filters: filters,
        });
      }

      return queries;
    },

    getFilterByNotifyType(notifyType) {
      let filters = [];
      if (notifyType == "tbmt") {
        filters.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-notify-contractor"],
        });

        filterAdvanced.push({
          fieldName: "caseKHKQ",
          searchType: "not_in",
          fieldValues: ["1"],
        });
      } else if (notifyType == "tbmst") {
        filters.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });

        filters.push({
          fieldName: "investField",
          searchType: "not_in",
          fieldValues: ["TV"],
        });
      } else if (notifyType == "tbmqt") {
        filters.push({
          fieldName: "type",
          searchType: "in",
          fieldValues: ["es-pre-notify-contractor"],
        });
        filters.push({
          fieldName: "investField",
          searchType: "in",
          fieldValues: ["TV"],
        });
      }

      return filters;
    },

    actionSearchAdvance(payload) {
      localStorage.setItem("quickSearchPayload", null);
      (this.quickSearchPayload = {
        keyword: "",
        type: "all-1",
        searchWith: "notifyNo,bidName",
        matchFields: [],
        isBidCloseDate: null,
        pageSize: payload.pageSize,
      }),
        this.axiosSearch(payload);

      // this.axiosSearchAggOpen(payload)
    },
    stringNullOrEmpty(strInput) {
      return strInput === undefined || strInput === null || strInput === "";
    },

    formatPayloadSearchWidthNotify(payload) {
      payload.query = payload.query.map((qr) => {
        qr.keyWord = this.convertKeywordSearch(qr.keyWord);
        return qr;
      });

      // Add GeneralTask and bidName query to request Plan
      if (
        this.checkIsKHLCNT(payload) &&
        payload.query.find((it) => it?.matchFields?.includes("planNo"))
      ) {
        const payloadTask = _.cloneDeep(payload);
        payloadTask.query
          .filter((qr) => qr.matchFields?.includes("planNo"))
          .map((qr) => (qr.matchFields = ["generalTasks"]));
        if (
          this.stringNullOrEmpty(payloadTask?.query?.[0]?.keyWord) &&
          !this.stringNullOrEmpty(payloadTask?.query?.[0]?.keyWordNotMatch)
        ) {
          const queryNotMatch = _.cloneDeep(payloadTask.query?.[0]);
          queryNotMatch.matchFields = ["name"];
          payloadTask.query.push(queryNotMatch);
        }
        const payloadBidName = _.cloneDeep(payload);
        payloadBidName.query
          .filter((qr) => qr.matchFields?.includes("planNo"))
          .map((qr) => (qr.matchFields = ["bidName"]));
        if (
          this.stringNullOrEmpty(payloadTask?.query?.[0]?.keyWord) &&
          !this.stringNullOrEmpty(payloadTask?.query?.[0]?.keyWordNotMatch)
        ) {
          const queryNotMatch = _.cloneDeep(payloadTask.query?.[0]);
          queryNotMatch.matchFields = ["name"];
          payloadBidName.query.push(queryNotMatch);
        }
        return [payload, payloadTask, payloadBidName];
      } else {
        return [payload];
      }

      return [payload];
    },

    axiosSearch(payload) {
      // this.payload.query.filters = [];

      grecaptcha.ready((res) => {
        grecaptcha.execute(this.siteKey, { action: "submit" }).then((token) => {
          this.spinningSearch = true;
          this.payloadSearch = payload;

          // console.log("payload : ", this.formatPayloadSearchWidthNotify(payload))
          axios
            .post(
              this.elasticSearch + "?token=" + token,
              this.formatPayloadSearchWidthNotify(payload)
            )
            .then((response) => {
              if (typeof response.data == "number") {
                this.popupSpinning();
              } else {
                this.listResultSearch = response.data.page.content;
                this.page = response.data.page;

                this.textSearch = payload.query[0].keyWord;

                if (this.activeTab == "all") {
                  this.aggOpen = response.data.agg;
                  this.aggClose = response.data.agg;
                }
                // if(this.activeReOffer == 'all'){
                //     this.aggOpenReOffer = response.data.agg;
                // }
                // if(Liferay.ThemeDisplay.isSignedIn() && this.checkIsReOfferPrice(payload)){
                //     this.addSubmitNt(this.listResultSearch);
                // }
                // if(this.checkIsReOfferPrice(payload)){
                //     this.loadMinPrice(this.listResultSearch);
                // }

                this.isHideTab = this.checkIsTbmt(payload);
                this.isShowClosedStatus = this.IsSearchNotify(payload);
              }
              this.spinningSearch = false;
            });
        });
      });
    },

    showConfirm() {
      this.$warning({
        title: "Cảnh báo",
        content: "Vui lòng chờ đợi trong giây lát ...",
      });
    },

    // axiosSearchAggOpen(payload) {
    //     // this.payload.query.filters = [];
    //     axios.post(
    //         this.elasticSearch, [payload]
    //     ).then(response => {
    //             this.aggOpen = response.data.agg;
    //
    //         }
    //     );
    //
    // },
    //
    // axiosSearchAggClose(payload) {
    //     axios.post(
    //         this.elasticSearch, [payload]
    //     ).then(response => {
    //             this.aggClose = response.data.agg;
    //
    //         }
    //     );
    // },

    checkIsTbmt(payload) {
      if (payload) {
        if (payload?.query) {
          let size = payload?.query[0]?.filters?.filter(
            (it) =>
              it.fieldName == "type" &&
              (it.fieldValues.includes("es-notify-contractor") ||
                it.fieldValues.includes("es-pre-notify-contractor"))
          )?.length;
          return size > 0;
        }
      }
      return false;
    },
    IsSearchNotify(payload) {
      if (payload) {
        if (payload?.query) {
          let size = payload?.query[0]?.filters?.filter(
            (it) =>
              it.fieldName == "type" && it.fieldValues.includes("es-notify-contractor")
          )?.length;
          return size > 0;
        }
      }
      return false;
    },

    checkIsKHLCNT(payload) {
      if (payload) {
        if (payload?.query) {
          let size = payload?.query[0]?.filters?.filter(
            (it) => it.fieldName == "type" && it.fieldValues.includes("es-plan-project-p")
          )?.length;
          return size > 0;
        }
      }
      return false;
    },

    checkIsReOfferPrice(payload) {
      if (payload) {
        if (payload?.query) {
          let size = payload?.query[0]?.filters?.filter(
            (it) => it.fieldName == "type" && it.fieldValues.includes("es-re-offer-price")
          )?.length;
          return size > 0;
        }
      }
      return false;
    },

    addSubmitNt(listResult) {
      const listId = listResult?.map((it) => it.id);
      axios.post(this.urlSubmitReOffer, { reofferIds: listId }).then((res) => {
        console.log("response submit", res);
        listResult?.forEach((reOffer) => {
          reOffer.submissionDetailByNT = res.data?.find(
            (submit) => submit.reofferId == reOffer.id
          );
        });
      });
    },

    reLoadChange() {
      this.followChanges++;
    },
    loadMinPrice(listResult) {
      const roomIds = listResult
        ?.filter(
          (it) =>
            it.isMultiLot == 0 && (this.isOpeningReOffer(it) || this.isClosedReOffer(it))
        )
        .map((it) => it.id);
      const self = this;
      if (roomIds?.length > 0) {
        if (this.stompClient?.connected) {
          this.stompClient.disconnect();
          console.log("Disconnected from STOMP server.");
        } else {
          console.log("Client is not connected.");
        }
        const roomId = roomIds[0];
        socket = new SockJS(`${this.poOnlineUrl}/po-online-service/ws-bid-online`);
        this.stompClient = Stomp.over(socket);
        const headers = { Room: roomId };
        this.stompClient.connect(headers, async function (frame) {
          let url = socket._transport.url;
          var res = url.split("/");
          sessionId = res[6];
          const bidOnlineRoomResponse = await fetch(
            `${self.poOnlineUrl}/po-online-service/api/bidonline/get/all`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ roomIds }),
            }
          );
          if (bidOnlineRoomResponse.status === 200) {
            const json = await bidOnlineRoomResponse.json();
            if (json && json?.responseCode === "200") {
              listResult.forEach((reOffer) => {
                const value = json?.body?.find((it) => it && it.roomId == reOffer.id);
                if (value) {
                  const listPrice =
                    value?.body[
                      Object.keys(value?.body)?.find((key) => key?.startsWith("BP"))
                    ];
                  reOffer.minPrice = listPrice?.[0]?.reofferPrice;
                } else {
                  reOffer.minPrice = reOffer.priceInit;
                }
              });
            } else {
              // Xử lý trường hợp dữ liệu trống rỗng tại đây
            }
            self.reLoadChange();
          } else {
            // Xử lý trường hợp lỗi khi gọi API
          }

          await self.stompClient.subscribe(
            `/user/${sessionId}/queue/bidonline`,
            function (message) {
              // Gọi hàm xử lý tin nhắn và truyền dữ liệu bạn cần
              const messageX = JSON.parse(message.body);
              Object.keys(messageX)?.forEach((key) => {
                const reOffer = listResult?.find((it) => it.id == key);
                if (reOffer) {
                  const value = messageX[key]?.body;
                  if (value) {
                    const listPrice =
                      value?.[Object.keys(value)?.find((k) => k?.startsWith("BP"))];
                    reOffer.minPrice = listPrice?.[0]?.reofferPrice;
                  }
                }
              });
              self.reLoadChange();
            }
          );
        });
      }
    },

    isShowSummitButton(item) {
      return this.isOpeningReOffer(item) && this.roleLogin == "NT";
    },
    loadUserInfo() {
      if (Liferay.ThemeDisplay.isSignedIn()) {
        Liferay.Util.fetch("/o/egp-portal-personal-page/services/get-org-info", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        })
          .then((data) => data.json())
          .then((res) => {
            this.userName = res.userInfo?.userName;
          });
      }
    },

    openUrl(url) {
      window.open(url, "_blank");
    },

    getListAllReOffer() {
      this.currentPage = 0;
      this.activeReOffer = "all";
      localStorage.setItem("activeReOffer", this.activeReOffer);
      this.loadDetailQuickAndAdvance();
    },

    getListOpeningReOffer() {
      this.currentPage = 0;
      this.isMultiLotReOffer = 0;
      this.activeReOffer = "open";
      localStorage.setItem("activeReOffer", this.activeReOffer);
      this.loadDetailQuickAndAdvance();
    },

    getListUpcomingReOffer() {
      this.currentPage = 0;
      this.isMultiLotReOffer = 0;
      this.activeReOffer = "upcoming";
      localStorage.setItem("activeReOffer", this.activeReOffer);
      this.loadDetailQuickAndAdvance();
    },

    getListClosedReOffer() {
      this.currentPage = 0;
      this.isMultiLotReOffer = 0;
      this.activeReOffer = "closed";
      localStorage.setItem("activeReOffer", this.activeReOffer);
      this.loadDetailQuickAndAdvance();
    },

    changeMultiLotType(isMultiLot) {
      this.currentPage = 0;
      this.isMultiLotReOffer = isMultiLot;
      this.loadDetailQuickAndAdvance();
    },

    getQuantityClosedReOffer() {
      let count = 0;
      let aggOpen = this.aggOpenReOffer?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "closed");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },

    getQuantityNotCloseReOffer() {
      let count = 0;
      let aggOpen = this.aggOpenReOffer?.filter(
        (it) => it.aggregationName == "facet_is_closed_date"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "open");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },
    getTotalReOffer() {
      return this.getQuantityClosedReOffer() + this.getQuantityNotCloseReOffer();
    },
    getQuantityUpComing() {
      let count = 0;
      let aggOpen = this.aggOpenReOffer?.filter(
        (it) => it.aggregationName == "coming_reOffer"
      );
      if (aggOpen?.length > 0) {
        let closed = aggOpen[0]?.bucketRanges?.filter((it) => it.key == "upcoming");
        if (closed?.length > 0) {
          count = closed[0]?.docCount;
        }
      }
      return count;
    },
    getQuantityOpenReOffer() {
      return this.getQuantityNotCloseReOffer() - this.getQuantityUpComing();
    },

    isClosedReOffer(item) {
      return (
        item.status != "03" &&
        new Date(item.bidCloseDate).getTime() < new Date().getTime()
      );
    },

    isOpeningReOffer(item) {
      return (
        item.status != "03" &&
        new Date(item.bidOpenDate).getTime() <= new Date().getTime() &&
        new Date(item.bidCloseDate).getTime() >= new Date().getTime()
      );
    },

    isUpComingReOffer(item) {
      return (
        item.status != "03" && new Date(item.bidOpenDate).getTime() > new Date().getTime()
      );
    },

    getDiffTimesReOffer(item, nowDate) {
      let results = 0 + " ngày " + 0 + " giờ " + 0 + " phút " + 0 + " giây";

      let closeDate = new Date(item.bidCloseDate);

      /* get total seconds between the times */

      if (nowDate < closeDate) {
        let delta = Math.abs(nowDate.getTime() - closeDate.getTime()) / 1000;
        /* calculate  days */
        const days = Math.floor(delta / 86400);
        delta -= days * 86400;
        /* calculate hours */
        const hours = Math.floor(delta / 3600) % 24;
        delta -= hours * 3600;
        /* calculate minutes */
        const minutes = Math.floor(delta / 60) % 60;
        delta -= minutes * 60;
        const seconds = Math.floor(delta);
        results =
          days + " ngày " + hours + " giờ " + minutes + " phút " + seconds + " giây";
      } else {
        results = "0 ngày 0 giờ 0 phút 0 giây";
        item.expired = true;
      }

      return results;
    },

    getListAllForTab() {
      this.quickSearchPayload.isBidCloseDate = null;
      this.currentPage = 0;
      this.activeTab = "all";
      localStorage.setItem("activeTab", this.activeTab);

      this.loadDetailQuickAndAdvance();
    },

    getListNotYetClose() {
      this.quickSearchPayload.isBidCloseDate = false;
      this.currentPage = 0;
      this.activeTab = "open";
      localStorage.setItem("activeTab", this.activeTab);
      this.loadDetailQuickAndAdvance();
    },

    getListClose() {
      this.quickSearchPayload.isBidCloseDate = true;
      this.currentPage = 0;
      this.optionActive = "all";
      this.activeTab = "closed";
      localStorage.setItem("activeTab", this.activeTab);
      let payload = this.loadDetailQuickAndAdvance();
      // this.axiosSearchAggClose(payload);
    },

    loadSearchWith(type) {
      if (type == "notifyNo") return "Số TBMT";
      if (type == "bidName") return "Tên gói thầu";
      if (type == "pNo") return "Mã dự án";
      if (type == "planNo") return "Mã kế hoạch";
      if (type == "name") return "Tên kế hoạch";
      if (type == "investorName") return "Tên chủ đầu tư";
      if (type == "procuringEntityName") return "Tên bên mời thầu";
      return type;
    },

    loadMatchTypeForName(type) {
      if (type == "any-1") return "Khớp từ hoặc một số từ (Phân biệt dấu)";
      if (type == "any-0") return "Khớp từ hoặc một số từ (Không phân biệt dấu)";
      if (type == "all-1") return "Khớp tất cả từ (Phân biệt dấu)";
      if (type == "all-0") return "Khớp tất cả từ (Không phân biệt dấu)";
      if (type == "exact") return "Khớp chính xác cụm từ";
    },

    changePage(page) {
      this.currentPage = page - 1;
      if (this.payloadSearch) {
        this.payloadSearch.pageNumber = this.currentPage;
        this.axiosSearch(this.payloadSearch);
      } else {
        this.loadDetailQuickAndAdvance();
      }
      localStorage.setItem("currentPage", this.currentPage);
      window.scrollTo({ top: 0, behavior: "smooth" });
    },

    renderQuickSearchAdvance() {
      // localStorage.setItem("searchAdvancePayload", null);
      localStorage.setItem("quickSearchPayload", JSON.stringify(this.quickSearchPayload));
      let url = this.renderSearchAdvanceUrl;
      window.location = url;
    },

    renderSearchAdvance(deleteAdvanced) {
      if (deleteAdvanced) {
        localStorage.setItem("searchAdvancePayload", null);
        localStorage.setItem("quickSearchPayload", null);
      } else {
        localStorage.setItem(
          "quickSearchPayload",
          JSON.stringify(this.quickSearchPayload)
        );
      }
      this.currentPage = 0;
      localStorage.setItem("currentPage", 0);
      localStorage.setItem("activeTab", "all");
      localStorage.setItem("optionActive", "all");

      // localStorage.setItem('indexSelect', this.indexSelect)

      let url = this.renderSearchAdvanceUrl;
      if (deleteAdvanced == false) {
        window.location = url + "&indexSelect=" + this.indexSelect;
      } else {
        window.location = url;
      }
    },

    renderUrlDetail(
      type,
      stepCode,
      id,
      notifyId,
      inputResultId,
      bidOpenId,
      techReqId,
      bidPreNotifyResultId,
      bidPreOpenId,
      processApply,
      bidMode,
      notifyNo,
      planNo,
      pno,
      step,
      isInternet,
      caseKHKQ,
      bidForm
    ) {
      let dataType = "";
      if (this.searchAdvancePayload?.notiType)
        dataType = this.searchAdvancePayload?.notiType;
      else {
        dataType = "tbmt";
      }
      let url = this.renderDetailV2Url;
      url = `${url}&type=${type}&stepCode=${stepCode}&id=${id}&notifyId=${notifyId}&inputResultId=${inputResultId}&bidOpenId=${bidOpenId}&techReqId=${techReqId}&bidPreNotifyResultId=${bidPreNotifyResultId}&bidPreOpenId=${bidPreOpenId}&processApply=${processApply}&bidMode=${bidMode}&notifyNo=${notifyNo}&planNo=${planNo}&pno=${pno}&step=${dataType}&isInternet=${isInternet}&caseKHKQ=${caseKHKQ}&bidForm=${bidForm}`;

      return url;
    },
    renderUrlDetailV2(
      type,
      stepCode,
      id,
      notifyId,
      inputResultId,
      bidOpenId,
      techReqId,
      bidPreNotifyResultId,
      bidPreOpenId,
      processApply,
      bidMode,
      notifyNo,
      planNo,
      pno,
      step,
      isInternet,
      caseKHKQ,
      bidForm
    ) {
      let dataType = "";
      if (this.searchAdvancePayload?.notiType)
        dataType = this.searchAdvancePayload?.notiType;
      else {
        dataType = "tbmt";
      }
      let url = this.renderDetailV2Url;
      url = `${url}&type=${type}&stepCode=${stepCode}&id=${id}&notifyId=${notifyId}&inputResultId=${inputResultId}&bidOpenId=${bidOpenId}&techReqId=${techReqId}&bidPreNotifyResultId=${bidPreNotifyResultId}&bidPreOpenId=${bidPreOpenId}&processApply=${processApply}&bidMode=${bidMode}&notifyNo=${notifyNo}&planNo=${planNo}&pno=${pno}&step=${dataType}&isInternet=${isInternet}&caseKHKQ=${caseKHKQ}&bidForm=${bidForm}`;

      window.open(url, "_self");
    },
    renderUrlDetailShoppingResult(item) {
      let url = this.renderDetailV2Url;
      url = `${url}&id=${item.id}&type=${item?.type}&bidNo=${item.bidNo}&orderNo=${item.orderNo?.[0]}`;
      return url;
    },
    renderUrlDetailContract(
      type,
      stepCode,
      id,
      notifyId,
      inputResultId,
      bidOpenId,
      techReqId,
      bidPreNotifyResultId,
      bidPreOpenId,
      processApply,
      bidMode,
      notifyNo,
      planNo,
      pno,
      step,
      isInternet,
      caseKHKQ,
      contractCode
    ) {
      let url = this.renderDetailV2Url;
      url = `${url}&type=${type}&stepCode=${stepCode}&id=${id}&notifyId=${notifyId}&inputResultId=${inputResultId}&bidOpenId=${bidOpenId}&techReqId=${techReqId}&bidPreNotifyResultId=${bidPreNotifyResultId}&bidPreOpenId=${bidPreOpenId}&processApply=${processApply}&bidMode=${bidMode}&notifyNo=${notifyNo}&planNo=${planNo}&pno=${pno}&isInternet=${isInternet}&caseKHKQ=${caseKHKQ}&contractCode=${contractCode}`;
      return url;
    },
    renderUrlDetailContractV2(
      type,
      stepCode,
      id,
      notifyId,
      inputResultId,
      bidOpenId,
      techReqId,
      bidPreNotifyResultId,
      bidPreOpenId,
      processApply,
      bidMode,
      notifyNo,
      planNo,
      pno,
      step,
      isInternet,
      caseKHKQ,
      contractCode
    ) {
      let url = this.renderDetailV2Url;
      url = `${url}&type=${type}&stepCode=${stepCode}&id=${id}&notifyId=${notifyId}&inputResultId=${inputResultId}&bidOpenId=${bidOpenId}&techReqId=${techReqId}&bidPreNotifyResultId=${bidPreNotifyResultId}&bidPreOpenId=${bidPreOpenId}&processApply=${processApply}&bidMode=${bidMode}&notifyNo=${notifyNo}&planNo=${planNo}&pno=${pno}&isInternet=${isInternet}&caseKHKQ=${caseKHKQ}&contractCode=${contractCode}`;

      window.open(url, "_self");
    },

    loadCatList() {
      let isLoadCat = localStorage.getItem("isLoadCatIndexLCNT");
      // if (isLoadCat == null || JSON.parse(isLoadCat) != '1') {
      if (isLoadCat == null || JSON.parse(isLoadCat) != "2") {
        axios
          .post(this.getCategory, {
            categoryTypeCodeLst: [
              "DM_TTPDDA",
              "DM_KHLCNT",
              "DM_LVLCNT",
              "DM_HTLCNT" /* hinh thuc LCNT */,
              "BID_INVEST_FORM",
              "BID_CONTRACT_TYPE",
              "DM_QT" /* quy trinh */,
              "DM_PTLCNT" /* phuong thuc LCNT */,
              "FORM_OF_SPENDING",
              "BIDO_BID_STATUS" /* Trang thai goi thau */,
              "BID_NOTIFY_STATUS",
              "DM_GROUP_DA",
              "DM_HTQLDA",
              "DM_HTDT",
              "BID_PLAN_STATUS",
              "DM_LHDLCNT",
              "DM_QT",
              "BIDO_BID_STATUS",
              "DM_TRANG_THAI",
              "DM_CQMS",
              "DM_CQMS_LV1",
              "DM_LYDO_HT_CPTPP",
              "DM_LYDO_HT_VK",
              "DM_LYDO_HT",
              "CAT_COUNTRY_LIST",
              "DM_LOAI_CT_TB",
            ],
          })
          .then((res) => {
            if (res != undefined && res.status === 200) {
              this.dmCqms = res.data.categories.DM_CQMS;
              this.dmCqmsLv1 = res.data.categories.DM_CQMS_LV1;
              this.dmGroupDa = res.data.categories.DM_GROUP_DA;
              this.bidoStatus = res.data.categories.BIDO_BID_STATUS;
              this.htqlDa = res.data.categories.DM_HTQLDA;
              this.dmHtdt = res.data.categories.DM_HTDT;
              this.planTypesVe = res.data.categories.DM_KHLCNT;
              this.planAppVeStatus = res.data.categories.DM_TTPDDA;
              this.catInvestFields = res.data.categories.DM_LVLCNT;
              this.bidForms = res.data.categories.DM_HTLCNT;
              this.dmQt = res.data.categories.DM_QT;
              this.dmPtlcnt = res.data.categories.DM_PTLCNT;
              this.dmSpendingCat = res.data.categories.FORM_OF_SPENDING;
              this.dmBidStatusCat = res.data.categories.BIDO_BID_STATUS;
              this.notiStatusCat = res.data.categories.BID_NOTIFY_STATUS;
              this.bidPlanStatus = res.data.categories.BID_PLAN_STATUS;
              this.dmLhdLcnt = res.data.categories.DM_LHDLCNT;
              this.contractTypes = res.data.categories.BID_CONTRACT_TYPE;
              this.processApplies = res.data.categories.DM_QT;
              this.dmTrangThais = res.data.categories.DM_TRANG_THAI;
              this.reasonCancelBidCPTPP = res.data.categories.DM_LYDO_HT_CPTPP;
              this.reasonCancelBidVK = res.data.categories.DM_LYDO_HT_VK;
              this.reasonCancelBid = res.data.categories.DM_LYDO_HT;
              this.catCountryList = res.data.categories.CAT_COUNTRY_LIST;
              this.workTypes = res.data.categories.DM_LOAI_CT_TB;

              localStorage.setItem("dmCqms", JSON.stringify(this.dmCqms));
              localStorage.setItem("dmCqmsLv1", JSON.stringify(this.dmCqmsLv1));
              localStorage.setItem("dmGroupDa", JSON.stringify(this.dmGroupDa));
              localStorage.setItem("bidoStatus", JSON.stringify(this.bidoStatus));
              localStorage.setItem("htqlDa", JSON.stringify(this.htqlDa));
              localStorage.setItem("dmHtdt", JSON.stringify(this.dmHtdt));
              localStorage.setItem("planTypesVe", JSON.stringify(this.planTypesVe));
              localStorage.setItem(
                "planAppVeStatus",
                JSON.stringify(this.planAppVeStatus)
              );
              localStorage.setItem(
                "catInvestFields",
                JSON.stringify(this.catInvestFields)
              );
              localStorage.setItem("bidForms", JSON.stringify(this.bidForms));
              localStorage.setItem("dmQt", JSON.stringify(this.dmQt));
              localStorage.setItem("dmPtlcnt", JSON.stringify(this.dmPtlcnt));
              localStorage.setItem("dmSpendingCat", JSON.stringify(this.dmSpendingCat));
              localStorage.setItem("dmBidStatusCat", JSON.stringify(this.dmBidStatusCat));
              localStorage.setItem("notiStatusCat", JSON.stringify(this.notiStatusCat));
              localStorage.setItem("bidPlanStatus", JSON.stringify(this.bidPlanStatus));
              localStorage.setItem("dmLhdLcnt", JSON.stringify(this.dmLhdLcnt));
              localStorage.setItem("contractTypes", JSON.stringify(this.contractTypes));
              localStorage.setItem("processApplies", JSON.stringify(this.processApplies));
              localStorage.setItem("dmTrangThais", JSON.stringify(this.dmTrangThais));
              localStorage.setItem(
                "reasonCancelBidCPTPP",
                JSON.stringify(this.reasonCancelBidCPTPP)
              );
              localStorage.setItem(
                "reasonCancelBidVK",
                JSON.stringify(this.reasonCancelBidVK)
              );
              localStorage.setItem(
                "reasonCancelBid",
                JSON.stringify(this.reasonCancelBid)
              );
              localStorage.setItem("catCountryList", JSON.stringify(this.catCountryList));
              localStorage.setItem("workTypes", JSON.stringify(this.workTypes));

              localStorage.setItem("isLoadCatIndexLCNT", "1");
            }
          });
      } else {
        this.dmCqms = JSON.parse(localStorage.getItem("dmCqms"));
        this.dmCqmsLv1 = JSON.parse(localStorage.getItem("dmCqmsLv1"));
        this.dmGroupDa = JSON.parse(localStorage.getItem("dmGroupDa"));
        this.bidoStatus = JSON.parse(localStorage.getItem("bidoStatus"));
        this.htqlDa = JSON.parse(localStorage.getItem("htqlDa"));
        this.dmHtdt = JSON.parse(localStorage.getItem("dmHtdt"));
        this.planTypesVe = JSON.parse(localStorage.getItem("planTypesVe"));
        this.planAppVeStatus = JSON.parse(localStorage.getItem("planAppVeStatus"));
        this.catInvestFields = JSON.parse(localStorage.getItem("catInvestFields"));
        this.bidForms = JSON.parse(localStorage.getItem("bidForms"));
        this.dmQt = JSON.parse(localStorage.getItem("dmQt"));
        this.dmPtlcnt = JSON.parse(localStorage.getItem("dmPtlcnt"));
        this.dmSpendingCat = JSON.parse(localStorage.getItem("dmSpendingCat"));
        this.dmBidStatusCat = JSON.parse(localStorage.getItem("dmBidStatusCat"));
        this.notiStatusCat = JSON.parse(localStorage.getItem("notiStatusCat"));
        this.bidPlanStatus = JSON.parse(localStorage.getItem("bidPlanStatus"));
        this.dmLhdLcnt = JSON.parse(localStorage.getItem("dmLhdLcnt"));
        this.contractTypes = JSON.parse(localStorage.getItem("contractTypes"));
        this.processApplies = JSON.parse(localStorage.getItem("processApplies"));
        this.dmTrangThais = JSON.parse(localStorage.getItem("dmTrangThais"));
        this.reasonCancelBidCPTPP = JSON.parse(
          localStorage.getItem("reasonCancelBidCPTPP")
        );
        this.reasonCancelBidVK = JSON.parse(
          localStorage.getItem("reasonCancelBidVK") || "[]"
        );
        this.reasonCancelBid = JSON.parse(localStorage.getItem("reasonCancelBid"));
        this.catCountryList = JSON.parse(localStorage.getItem("catCountryList"));
        this.workTypes = JSON.parse(localStorage.getItem("workTypes"));
      }
    },

    getNameCatByCodeCat(code, listCat) {
      if (!listCat) return code;
      const temp = listCat.filter((el) => el.code == code).pop();
      return temp ? (this.isEnglish ? temp.nameEn : temp.name) : code;
    },

    loadDetailQuickAndAdvance() {
      let payload = null;
      if (JSON.parse(localStorage.getItem("searchAdvancePayload"))) {
        this.searchAdvancePayload = JSON.parse(
          localStorage.getItem("searchAdvancePayload")
        );
        payload = this.convertAdvanceSearchToPayload(this.searchAdvancePayload);
        this.actionSearchAdvance(payload);
      } else {
        payload = this.convertQuickSearchPayloadToPayload(this.quickSearchPayload);
        this.actionSearchQuick(payload);
      }
      return payload;
    },
    loadListUmFilterInfo() {
      axios
        .post(this.urlSearchUmFilterInfo, {
          orgCode: JSON.parse(localStorage.getItem("userDTO"))?.orgCode,
          type: ["LCNT"],
          role: this.roleLogin,
          filterType: "BLTC",
        })
        .then((res) => {
          this.listUmFilterInfo = res?.data?.getUmFilterInfoByOrgCodeDTOList;
        });
    },
    onChangeFilter(index) {
      if (index != this.indexSelect) {
        this.activeTab = "all";

        this.indexSelect = index;
        this.onViewData();
        this.loadAreaDistrict();
        this.searchAdvancePayload.locationQuanName = this.getNameCatByCodeCat(
          this.searchAdvancePayload.locationQuan,
          this.listDistrict
        );
        let payload = this.convertAdvanceSearchToPayload(this.searchAdvancePayload);
        // this.axiosSearchAggOpen(payload);
        this.actionSearchAdvance(payload);
      }
    },
    onCancelChoose(index) {
      if (this.indexSelect != -1) {
        setTimeout(() => {
          this.indexSelect = -1;
          // localStorage.setItem('indexSelect', this.indexSelect);
          this.deleteAllAdvancedSearch();
        }, 100);
      }
    },
    onViewData() {
      this.searchAdvancePayload = {};
      this.listUmFilterInfo[this.indexSelect]?.umMapKeyFilterDTOList.forEach((e) => {
        switch (e?.code) {
          case "TK":
            this.searchAdvancePayload.matchType = e?.valueName;
            break;
          case "LTB":
            this.searchAdvancePayload.notiType = e?.valueName;
            break;
          case "TKLTB":
            this.searchAdvancePayload.keyword = e?.valueName;
            break;
          case "TGDTT":
            this.searchAdvancePayload.publicDateFrom = e?.valueName;
            break;
          case "TGDTD":
            this.searchAdvancePayload.publicDateTo = e?.valueName;
            break;
          case "TDDTT":
            this.searchAdvancePayload.bidCloseFrom = e?.valueName;
            break;
          case "TDDTD":
            this.searchAdvancePayload.bidCloseTo = e?.valueName;
            break;
          case "KHLCNT":
            this.searchAdvancePayload.keyword = e?.valueName;
            break;
          case "CDT":
            this.searchAdvancePayload.listKeywordCdt = e?.valueName?.split(",");
            break;
          case "BMT":
            this.searchAdvancePayload.listKeywordBmt = e?.valueName?.split(",");
            break;
          case "LV":
            this.searchAdvancePayload.investField = e?.valueName?.split(",");
            break;
          case "DDTHTTP":
            console.log(
              "this.searchAdvancePayload.locationTinh : ",
              this.searchAdvancePayload.locationTinh
            );
            this.searchAdvancePayload.locationTinh = e?.valueName?.split(",");
            this.searchAdvancePayload.locationTinhName = this.searchAdvancePayload.locationTinh?.map(
              (it) => {
                if (it == "825") return "Ngoài lãnh thổ Việt Nam";
                else return this.getNameCatByCodeCat(it, this.listProvince);
              }
            );
            console.log(
              "this.searchAdvancePayload.locationTinh : ",
              this.searchAdvancePayload.locationTinhName
            );
            break;
          case "DDTHQH":
            this.searchAdvancePayload.locationQuan = e?.valueName?.split(",");
            this.searchAdvancePayload.locationQuanName = this.searchAdvancePayload.locationQuan?.map(
              (it) => this.getNameCatByCodeCat(it, this.listDistrict)
            );
            break;
          case "DA":
            this.searchAdvancePayload.keyword = e?.valueName;
            break;
          case "GGTT":
            this.searchAdvancePayload.bidPriceFrom = e?.valueName;
            break;
          case "TMDTT":
            this.searchAdvancePayload.investTotalFrom = e?.valueName;
            break;
          case "TMDTD":
            this.searchAdvancePayload.investTotalTo = e?.valueName;
            break;
          case "GGTD":
            this.searchAdvancePayload.bidPriceTo = e?.valueName;
            break;
          case "QTAD":
            this.searchAdvancePayload.processApply = e?.valueName;
            break;
          case "NTTT":
            this.searchAdvancePayload.keywordNttt = e?.valueName;
            break;
          case "LHH_CT_DV":
            this.searchAdvancePayload.keywordNttt = e?.keywordGood;
            break;
          case "HTLCNT":
            this.searchAdvancePayload.bidForm = e?.valueName;
            break;
          case "TNQT":
            this.searchAdvancePayload.isDomestic = e?.valueName?.split(",");
            break;
          case "PTLCNT":
            this.searchAdvancePayload.bidMode = e?.valueName;
            break;
          case "HTDT":
            this.searchAdvancePayload.isInternet = e?.valueName?.split(",");
            break;
          case "SNTTDT":
            this.searchAdvancePayload.numBidderJoinFrom = e?.valueName;
            break;
          case "SNTTDD":
            this.searchAdvancePayload.numBidderJoinTo = e?.valueName;
            break;
          case "SNTDKTT":
            this.searchAdvancePayload.numBidderTechFrom = e?.valueName;
            break;
          case "SNTDKTD":
            this.searchAdvancePayload.numBidderTechTo = e?.valueName;
            break;
          case "SLLR_HSMTT":
            this.searchAdvancePayload.numClarifyReqFrom = e?.valueName;
            break;
          case "SLLR_HSMTD":
            this.searchAdvancePayload.numClarifyReqTo = e?.valueName;
            break;
          case "SLKNT":
            this.searchAdvancePayload.numPetitionFrom = e?.valueName;
            break;
          case "SLKND":
            this.searchAdvancePayload.numPetitionTo = e?.valueName;
            break;
          case "TLTKT":
            this.searchAdvancePayload.numSavingRateFrom = e?.valueName;
            break;
          case "TLTKD":
            this.searchAdvancePayload.numSavingRateTo = e?.valueName;
            break;
          case "keywordNotMatch":
            this.searchAdvancePayload.keyWordNotMatch = e?.valueName;
            break;
          case "keywordNotMatchHH":
            this.searchAdvancePayload.keyWordNotMatchSub = e?.valueName;
            break;
        }
      });
      localStorage.setItem(
        "searchAdvancePayload",
        JSON.stringify(this.searchAdvancePayload)
      );
    },
    loadLogin() {
      Liferay.Util.fetch("/o/egp-portal-personal-page/services/menus", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          langKey: "VI",
          keyModule: "PO",
          rootRole: null,
        }),
      })
        .then((data) => data.json())
        .then((res) => {
          this.checkLogin = true;
          this.roleLogin = res?.selectedrootRole;
          this.loadListUmFilterInfo();
        })
        .catch((err) => {
          console.error("error in load root roles {} ", err);
        });
    },

    async createdSearch() {
      // Call API to load provinces first for mapping with merged provinces in Province Search.
      await this.loadAreaProvince();
      this.loadDetailQuickAndAdvance();
    },
    async loadAreaProvince() {
      return await axios
        .post(this.getAreaProvince, {
          areaType: "1",
          parentCode: "VN",
        })
        .then((res) => {
          if (res != undefined && res.status === 200) {
            this.listProvince = res.data.areas;
          }
          console.log("AAAAAAA");
        });
    },

    loadAreaDistrict() {
      if (this.searchAdvancePayload.locationTinh) {
        axios
          .post(this.getAreaAPI, {
            areaType: "2",
            parentCode: this.searchAdvancePayload.locationTinh,
          })
          .then((res) => {
            if (res != undefined && res.status === 200) {
              this.listDistrict = res.data.areas;
            }
          });
      }
    },
    checkViewed(stand) {
      if (this.viewedList.includes(stand)) {
        return true;
      }
      return false;
    },
    addToViewedList(standNo) {
      if (!this.checkViewed(standNo)) {
        if (this.checkLogin) {
          axios.post(this.addViewedListUrl, { standNo });
        } else {
          this.viewedList.push(standNo);
          sessionStorage.setItem("viewedList", this.viewedList.toString());
        }
      }
    },
    onCheck() {},

    popupSpinning() {
      let p = this.$loading({
        fullscreen: true,
        text: this.isEnglish
          ? "Please try again in a moment..."
          : "Vui lòng thử lại trong giây lát ...",
      });
      setTimeout(() => {
        p.close();
      }, 5000);
    },
  },
  created() {
    if (localStorage.getItem("currentPage")) {
      this.currentPage = localStorage.getItem("currentPage");
    }
    this.isEnglish = this.checkIsEn();
    // if (localStorage.getItem('activeTab')) {
    //     this.activeTab = localStorage.getItem('activeTab');
    // }
    // if (localStorage.getItem('optionActive')) {
    //     this.optionActive = localStorage.getItem('optionActive');
    // }

    // this.loadAreaProvince();
    if (JSON.parse(localStorage.getItem("quickSearchPayload"))) {
      this.quickSearchPayload = JSON.parse(localStorage.getItem("quickSearchPayload"));
      localStorage.setItem("pageSizeResult", this.quickSearchPayload.pageSize);
    } else if (
      localStorage.getItem("pageSizeResult") &&
      localStorage.getItem("pageSizeResult") != undefined &&
      localStorage.getItem("pageSizeResult") != "undefined"
    ) {
      this.quickSearchPayload.pageSize = JSON.parse(
        localStorage.getItem("pageSizeResult")
      );
    }
    this.loadCatList();
    this.createdSearch();
    // let payload = this.loadDetailQuickAndAdvance();
    // this.axiosSearchAggOpen(payload);
    // this.indexSelect = localStorage.getItem('indexSelect');
    this.indexSelect = this.indexSelectParam;
    this.loadLogin();
    if (JSON.parse(localStorage.getItem("userDTO"))?.orgCode) {
      axios.post(this.getViewedListUrl, {}).then((res) => {
        if (res.data?.viewedList) {
          this.viewedList = res.data.viewedList;
        } else {
          this.viewedList = [];
        }
      });
    } else {
      this.viewedList = sessionStorage.getItem("viewedList")?.split(",") || [];
    }

    // if(this.searchAdvancePayload?.notiType == 'es-re-offer-price'){
    //     this.loadUserInfo();
    //     this.nowDate = new Date(this.countTime);
    //     setInterval(() => {
    //         this.nowDate = new Date(new Date(this.nowDate).getTime() + 1000)
    //     },1000)
    // }
  },
  mounted() {},
});
</script>
