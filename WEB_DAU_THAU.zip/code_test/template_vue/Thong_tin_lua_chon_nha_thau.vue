<!--Dự án đầu tư phát triển--> 
        <div class="view-detail"> 
         <div id="egp-breadcrumb" class="content__wrapper p-0"> 
          <div class="content mt-0"> 
           <nav aria-label="breadcrumb"> 
            <ol class="breadcrumb mb-0 px-0"> 
             <li class="breadcrumb-item inactive"> <a @click="breadcrumbRedirect('home')">Trang chủ</a> </li> 
             <li class="breadcrumb-item inactive"> <a @click="breadcrumbRedirect('contractor-selection?render=index')">Thông tin lựa chọn nhà thầu</a> </li> 
             <li class="breadcrumb-item active"> <a>{{cutStringWith50(detailRes?.name)}}</a> </li> 
            </ol> 
           </nav> 
          </div> 
         </div> 
         <main class="content-wrapper" id="development-investment-project"> 
          <div class="content"> 
           <!--            <a href="/contractor-selection?render=index">--> 
           <!--            <button type="button" class="btn btn-primary button-back" @click="backPreviousPage()">--> 
           <!--                <img--> 
           <!--                        class="content__button__icon"--> 
           <!--                        th:src="@{/images/icons/ic_left_arrow.svg}"--> 
           <!--                        alt=""--> 
           <!--                />--> 
           <!--                Quay lại kết quả tìm kiếm--> 
           <!--            </button>--> 
           <!--            </a>--> 
           <button type="button" class="btn btn-primary button-back" @click="backPreviousPage()"> <img class="content__button__icon" src="/o/egp-portal-contractor-selection-v2/images/icons/ic_left_arrow.svg" alt=""> <span>Quay trở lại</span> </button> 
           <div class="d-flex flex-row align-items-start content-body"> 
            <div class="d-flex flex-column align-items-start content-body__left"> 
             <div class="d-flex justify-content-between w-100"> 
              <div class="d-flex flex-column align-items-start"> 
               <h5>{{detailRes?.name}} </h5> 
              </div> 
              <div :style="showHintFlow()" class="pr-0 col-2"> 
               <button style="height: 35px" class="btn btn-back" v-if="!checkMail &amp;&amp; selectedrootRole=='NT'" @click="showModal('SUB_PROJECT_DTPT')">Theo dõi</button> 
               <button style="height: 35px" class="btn btn-back" v-if="checkMail" disabled>Đã theo dõi</button> 
              </div> 
             </div> 
             <div class="tab-content" v-if="detailRes"> 
              <div class="tab-pane fade active show"> 
               <div class="card border--none"> 
                <div class="card-header">
                 Thông tin chung
                </div> 
                <div class="card-body d-flex flex-column align-items-start infomation" v-if="detailRes?.typeProject != 'DTMS'"> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Số dự án
                  </div> 
                  <div>
                   {{detailRes.pno}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Phiên bản thay đổi
                  </div> 
                  <div class="text-blue-4D7AE6"> 
                   <select class="form-select" style="border: none; cursor: pointer" v-model="id" @change="loadDetailDadtpt()"> <option v-for="v of versionList" :value="v.id">{{v.pversion}}</option> </select> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Trạng thái đăng tải
                  </div> 
                  <div>
                   {{getNameCatByCodeCat(detailRes?.status,dmTrangThais)}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Tên dự án
                  </div> 
                  <div>
                    {{detailRes?.name}} 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Mục tiêu đầu tư
                  </div> 
                  <div>
                    {{detailRes.investTarget}} 
                  </div> 
                 </div> 
                 <!--                                    <div--> 
                 <!--                                            class="d-flex flex-row align-items-start infomation__content"--> 
                 <!--                                    >--> 
                 <!--                                        <div class="infomation__content__title">--> 
                 <!--                                            Quy mô đầu tư--> 
                 <!--                                        </div>--> 
                 <!--                                        <div>{{detailRes.investScale}}</div>--> 
                 <!--                                    </div>--> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Chủ đầu tư
                  </div> 
                  <div>
                   {{detailRes.investorName}} 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Người có thẩm quyền
                  </div> 
                  <div>
                   {{getCompetentPersons(detailRes.competentPersons)}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Thời gian thực hiện dự án
                  </div> 
                  <div>
                   {{detailRes.pperiod}} 
                   <span v-if="detailRes.pperiodUnit == '1'">Năm</span> 
                   <span v-if="detailRes.pperiodUnit == '2'">Tháng</span> 
                   <span v-if="detailRes.pperiodUnit == '3'">Ngày</span> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Nhóm dự án
                  </div> 
                  <div>
                   {{getNameCatByCodeCat(detailRes.pgroup,dmGroupDa)}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Hình thức quản lý dự án
                  </div> 
                  <div>
                   {{getNameCatByCodeCat(detailRes.pform,htqlDa)}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Có sử dụng vốn ODA
                  </div> 
                  <div> 
                   <template v-if="detailRes.isOda">
                    Có
                   </template> 
                   <template v-if="!detailRes.isOda">
                    Không
                   </template> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Địa điểm thực hiện
                  </div> 
                  <div> 
                   <p v-for="v of parseJsonToObject(detailRes.plocation)"> {{v.districtName ? (v.districtName + ',') : ''}} {{v.provName}} 
                    <!--                                   {{v.districtName}}, {{v.provName}}--> </p>
                  </div> 
                 </div> 
                </div> 
                <div class="card-body d-flex flex-column align-items-start infomation" v-if="detailRes?.typeProject == 'DTMS'"> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Số dự án
                  </div> 
                  <div>
                   {{detailRes.pno}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Phiên bản thay đổi
                  </div> 
                  <div class="text-blue-4D7AE6"> 
                   <select class="form-select" style="border: none; cursor: pointer" v-model="id" @change="loadDetailDadtpt()"> <option v-for="v of versionList" :value="v.id">{{v.pversion}}</option> </select> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Trạng thái đăng tải
                  </div> 
                  <div>
                   {{getNameCatByCodeCat(detailRes?.status,dmTrangThais)}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Tên dự án
                  </div> 
                  <div>
                    {{detailRes?.name}} 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                    Nguồn vốn 
                  </div> 
                  <div>
                   {{detailRes?.investmentFunds}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Chủ đầu tư
                  </div> 
                  <div>
                   {{detailRes.investorName}} 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Thời gian thực hiện dự án
                  </div> 
                  <div>
                   {{detailRes.pperiod}} 
                   <span v-if="detailRes.pperiodUnit == '1'">Năm</span> 
                   <span v-if="detailRes.pperiodUnit == '2'">Tháng</span> 
                   <span v-if="detailRes.pperiodUnit == '3'">Ngày</span> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Quy mô dự án
                  </div> 
                  <div>
                   {{detailRes.investScale}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Địa điểm thực hiện
                  </div> 
                  <div> 
                   <p v-for="v of parseJsonToObject(detailRes.plocation)"> {{v.districtName ? (v.districtName + ',') : ''}} {{v.provName}} </p> 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Các thông tin khác (nếu có)
                  </div> 
                  <div>
                   {{detailRes.otherInfo}}
                  </div> 
                 </div> 
                </div> 
               </div> 
               <div class="card border--none"> 
                <div class="card-header">
                 Thông tin tổng mức đầu tư
                </div> 
                <div class="card-body d-flex flex-column align-items-start infomation"> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Tổng mức đầu tư
                  </div> 
                  <div> 
                   <div class="mb-2 d-flex" v-for="(pr, index) in detailRes?.projectDTO?.investDetail"> 
                    <div style="min-width: 300px">
                     {{pr.invest | currency}} {{pr.moneyType}}
                    </div> 
                    <div v-if="pr?.exchangeRate &amp;&amp; pr?.moneyType != 'VND'"> 
                     <template>
                      Tỷ giá
                     </template> {{pr.moneyType}}/ VND : {{pr.exchangeRate | currency}} 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                 <div v-if="detailRes.isOda" class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Nguồn vốn đối ứng
                  </div> 
                  <div v-if="detailRes.investTotal">
                    {{detailRes?.projectDTO?.reciprocalCapital | currency}} {{detailRes?.projectDTO?.reciprocalCapitalUnit}} 
                  </div> 
                 </div> 
                 <div v-if="detailRes.isOda" class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Tổng mức đầu tư quy đổi về VND
                  </div> 
                  <div v-if="detailRes.investTotal">
                    {{detailRes?.projectDTO?.investTotalEx | currency}} {{detailRes?.projectDTO?.investTotalUnit}} 
                  </div> 
                 </div> 
                 <div v-if="detailRes.isOda" class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Thời điểm quy đổi
                  </div> 
                  <div>
                    {{detailRes?.projectDTO?.exChangeDate | formatDateAndH}} 
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Số tiền bằng chữ
                  </div> 
                  <div v-if="detailRes.investTotal &amp;&amp; detailRes.investTotal > 0">
                    {{numToVND().doc(detailRes.investTotal)}} 
                  </div> 
                 </div> 
                </div> 
               </div> 
               <div class="card border--none"> 
                <div class="card-header">
                 Thông tin quyết định phê duyệt
                </div> 
                <div class="card-body d-flex flex-column align-items-start infomation"> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Số quyết định phê duyệt dự án
                  </div> 
                  <div>
                   {{detailRes.decisionNo}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Ngày phê duyệt dự án
                  </div> 
                  <div>
                   {{detailRes.decisionDate | formatDate}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Cơ quan ban hành quyết định
                  </div> 
                  <div>
                   {{detailRes.decisionAgency}}
                  </div> 
                 </div> 
                 <div class="d-flex flex-row align-items-start infomation__content"> 
                  <div class="infomation__content__title">
                   Quyết định phê duyệt
                  </div> 
                  <div> 
                   <tags class="tags-fileAttach" style="cursor: pointer" @click="downloadFile(detailRes.decisionFileId, detailRes.decisionFileName)" v-if="detailRes.decisionFileName">
                     {{detailRes.decisionFileName}} 
                    <img src="/o/egp-portal-contractor-selection-v2/images/icons/download_Outline.svg" alt="icon-download"> 
                   </tags> 
                  </div> 
                 </div> 
                </div> 
               </div> 
               <div class="card border--none card-expand" v-if="detailRes?.linkedPublishPlan?.length > 0"> 
                <div class="card-header">
                 Danh sách KHLCNT liên kết với dự án
                </div> 
                <div class="card-body item-table" style="padding: 0 !important;"> 
                 <table class="table table-expand table-Stt"> 
                  <thead class="thead"> 
                   <tr> 
                    <th class="table-active-st" scope="col" style="background: #ececec;width:8%">STT</th> 
                    <th style="background: #ececec;width: 15%" class="table-active" scope="col">Số hiệu KHLCNT</th> 
                    <th class="table-active" scope="col">Tên KHLCNT</th> 
                    <th class="table-active" scope="col" style="width: 25%">Tổng giá gói thầu</th> 
                    <th class="table-active" scope="col">Phân loại KHLCNT</th> 
                   </tr> 
                  </thead> 
                  <tbody> 
                   <tr v-if="detailRes.linkedPublishPlan &amp;&amp; detailRes.linkedPublishPlan.length > 0" v-for="(bp,index) in detailRes.linkedPublishPlan"> 
                    <td class="lf-th-content">{{index+1}}</td> 
                    <td class="lf-th-content">{{bp.planNo}}</td> 
                    <td class="lf-th-content">{{bp.name}}</td> 
                    <td class="lf-th-content"> <span v-if="bp.investTotal">{{bp.totalBidPrice | currency}} {{bp?.investTotalUnit}}</span> </td> 
                    <td class="lf-th-content"> 
                     <template v-if="bp.isOldPlan == '1'">
                      KHLCNT đã thực hiện xong trên hệ thống EGP cũ
                     </template> 
                     <template v-if="bp.isOldPlan != '1'">
                      KHLCNT thực hiện trên hệ thống EGP mới
                     </template> </td> 
                   </tr> 
                   <tr v-if="detailRes.linkedPublishPlan &amp;&amp; detailRes.linkedPublishPlan.length > 0"> 
                    <td colspan="3" class="lf-th-content" style="text-align: center">Tổng tiền</td> 
                    <td class="lf-th-content" colspan="2">{{totalTableDa() | currency}} {{detailRes.linkedPublishPlan[0]?.investTotalUnit}} </td> 
                   </tr> 
                  </tbody> 
                 </table> 
                </div> 
               </div> 
               <div class="card border--none card-expand" v-if="detailRes?.linkedPlanOverall?.length > 0"> 
                <div class="card-header">
                 Danh sách kế hoạch tổng thể lựa chọn nhà thầu liên kết với dự án
                </div> 
                <div class="card-body item-table" style="padding: 0 !important;"> 
                 <table class="table table-expand table-Stt"> 
                  <thead class="thead"> 
                   <tr> 
                    <th class="table-active-st" scope="col" style="background: #ececec;width:8%">STT</th> 
                    <th style="background: #ececec" class="table-active" scope="col">Mã kế hoạch tổng thể lựa chọn nhà thầu</th> 
                    <th class="table-active" scope="col">Tên kế hoạch tổng thể lựa chọn nhà thầu</th> 
                   </tr> 
                  </thead> 
                  <tbody> 
                   <tr v-for="(bp,index) in detailRes?.linkedPlanOverall"> 
                    <td class="lf-th-content">{{index+1}}</td> 
                    <td class="lf-th-content">{{bp.planNo}}</td> 
                    <td class="lf-th-content">{{bp.name}}</td> 
                   </tr> 
                  </tbody> 
                 </table> 
                </div> 
               </div> 
              </div> 
             </div> 
            </div> 
            <div class="content-body__right"> 
             <div class="detail__children-2"> 
              <div class="detail__children-2__view detail__children-2__view-grey"> 
               <p class="detail__children-2__text-14 detail__children-2__text-center">Thời gian đăng tải</p> 
               <p class="detail__children-2__text-16 detail__children-2__text-orange detail__children-2__text-center"> {{detailRes?.publicDate | formatHour}} </p> 
               <p class="detail__children-2__text-20 detail__children-2__text-primary detail__children-2__text-center"> {{detailRes?.publicDate | formatDate}} </p> 
               <!--                            <button--> 
               <!--                                    type="button"--> 
               <!--                                    class="btn btn-primary detail__children-2__button"--> 
               <!--                            >--> 
               <!--                                Nộp hồ sơ--> 
               <!--                            </button>--> 
               <!--                            <p--> 
               <!--                                    class="text-14-400 text-orange-E14337 m-t-16 detail__children-2__text-center"--> 
               <!--                            >--> 
               <!--                                Còn 12 ngày 09 giờ 35 phút--> 
               <!--                            </p>--> 
              </div> 
              <div class="detail__children-2__view detail__children-2__view-grey"> 
               <p class="detail__children-2__text-14">Chủ đầu tư</p> 
               <p class="detail__children-2__text-16"> {{detailRes?.investorName}} </p> 
               <p class="detail__children-2__text-14">Địa điểm</p> 
               <p class="detail__children-2__text-16" v-if="detailRes?.plocation" v-for="v of parseJsonToObject(detailRes?.plocation)"> {{v.districtName ? (v.districtName + ',') : ''}} {{v.provName}} </p> 
               <p class="detail__children-2__text-14">Tổng vốn đầu tư</p> 
               <p class="detail__children-2__text-16" v-if="detailRes?.investTotal"> {{detailRes?.investTotal | currency}} {{detailRes?.investTotalUnit}} </p> 
              </div> 
              <div class="detail__children-2__view detail__children-2__view-primary"> 
               <p class="detail__children-2__text-16-b detail__children-2__text-primary">Quyết định phê duyệt</p> 
               <div class="detail__children-2__view__item d-flex justify-content-between" @click="downloadFile(detailRes?.decisionFileId, detailRes?.decisionFileName)" style="cursor: pointer"> 
                <div class="d-flex" style="align-items: self-start;"> 
                 <img class="content__button__icon" src="/o/egp-portal-contractor-selection-v2/images/icons/ic_pdf_file.svg" alt=""> 
                 <p class="detail__children-2__text-14 detail__children-2__text-blue align-self-end" style="word-break: break-all;"> {{detailRes?.decisionFileName}} </p> 
                </div> 
                <img @click="downloadFile(detailRes?.decisionFileId, detailRes?.decisionFileName)" style="cursor: pointer" class="content__button__icon" src="/o/egp-portal-contractor-selection-v2/images/icons/download_Outline.svg" alt=""> 
               </div> 
              </div> 
             </div> 
            </div> 
           </div> 
           <!--            <a href="/contractor-selection?render=index">--> 
           <!--            <button type="button" class="btn btn-primary button-back" @click="backPreviousPage()">--> 
           <!--                <img--> 
           <!--                        class="content__button__icon"--> 
           <!--                        th:src="@{/images/icons/ic_left_arrow.svg}"--> 
           <!--                        alt=""--> 
           <!--                />--> 
           <!--                Quay lại kết quả tìm kiếm--> 
           <!--            </button>--> 
           <!--            </a>--> 
           <button type="button" class="btn btn-primary button-back" @click="backPreviousPage()"> <img class="content__button__icon" src="/o/egp-portal-contractor-selection-v2/images/icons/ic_left_arrow.svg" alt=""> 
            <template>
             Quay trở lại
            </template> </button> 
          </div> 
         </main> 
        </div> 
        <!--END: Dự án đầu tư phát triển--> 
        <script>
    new Vue({
        el: '#view-detail-3',
        data() {
            return {
                elasticSearch: "\/o\/egp-portal-contractor-selection-v2\/services\/smart\/search",
                siteURL: "https:\/\/muasamcong.mpi.gov.vn\/web\/guest",
                kongUrl: "https:\/\/muasamcong.mpi.gov.vn\/c\/portal\/login?redirect=\/egp",
                currentUrl: "\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=detail-v2\u0026type=es-bidp-project-p\u0026stepCode=project-step-1\u0026id=82817483-86c3-4200-adf4-1b355dbf8527\u0026notifyId=undefined\u0026inputResultId=undefined\u0026bidOpenId=undefined\u0026techReqId=undefined\u0026bidPreNotifyResultId=undefined\u0026bidPreOpenId=undefined\u0026processApply=undefined\u0026bidMode=undefined\u0026notifyNo=undefined\u0026planNo=undefined\u0026pno=PR2600000073\u0026step=da\u0026isInternet=undefined\u0026caseKHKQ=undefined\u0026bidForm=undefined",
                rootUrl: "https:\/\/muasamcong.mpi.gov.vn",
                kongUrl: "https:\/\/muasamcong.mpi.gov.vn\/c\/portal\/login?redirect=\/egp",
                detailUrl: "https:\/\/muasamcong.mpi.gov.vn\/web\/guest\/contractor-selection?p_p_id=egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render=detail",
                urlDetailTbmtAdbWb: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-notify-contractor-out-adb-wb\/get-by-id",
                urlDetailKqmtAdbWb: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/kqmt\/bid-notify-contractor-out-adb-wb\/get-by-id",
                urlDetailTbmtVk:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-notify-contractor-out\/get-by-id",
                urlListVerTbmtVk:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/bid-no-contractor-out\/get-version-list",
                urlDetailTbmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bido-notify-contractor-view\/get-by-id",
                urlListVerTbmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bido-notify-contractor-view\/get-version-list",
                urlDetailKqmtVk:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/kqmt\/bid-notify-contractor-out\/get-by-id",
                urlDetailKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/get-by-id",
                urlNotifyKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/exposeldtkqmt\/bid-notification-p\/notify",
                urlRoundMngKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/roundmng",
                urlSubmissionKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/submission",
                urlBidOpenKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/bid-open",
                urlLotOpenSubmissionKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/lot-open",
                urlLotOpenDetailKqmtLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/lotOpenDetail",
                urlDetailKqmtLdtTC:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmt\/bid-notification-p\/get-by-id-v2",
                urlDetailKqlcntLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/contractor-input-result\/get",
                urlDetailKqlcntLdtByBidId:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/contractor-input-result\/get-by-bid-id",
                urlDetailKqlcntVk:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/kqlcnt\/bid-notify-contractor-out\/get-by-id",
                urlDetailDsntdktVk:"\/o\/egp-portal-contractor-selection-v2\/services\/lcnt\/bid-po-bido-notify-contractor-view2\/get-by-id-v2",
                urlDetailDsntdktLdt:"\/o\/egp-portal-contractor-selection-v2\/services\/ldtdsnt\/tech-req-approval\/get-by-id",
                urlDetailDadtpt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bidp-project-view\/get-by-id",
                urlListVerDadtpt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bidp-project-view\/get-version-list",
                urlDetailKhlcnt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bidp-plan-project-view\/get-by-id",
                urlListVerKhlcnt:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bidp-plan-project-view\/get-version-list",
                urlDetailBidKhlcnt:"\/o\/egp-portal-contractor-selection-v2\/services\/lcnt\/bid-po-bidp-plan-project-view\/get-bidp-plan-detail-by-id",
                urlDetailDsndthc:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bido-contractor-shortlist-view\/get-by-id",
                urlListVerDsndthc:"\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bid-po-bido-contractor-shortlist-view\/get-version-list",
                urlReoffer: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/lcnt\/bido-notify-reoffer\/get-detail",

                urlDetailTbst: "\/o\/egp-portal-contractor-selection-v2\/services\/ebid\/pre-notify-contractor-view\/detail",
                urlListVerTbst: "\/o\/egp-portal-contractor-selection-v2\/services\/ebid\/pre-notify-contractor-view\/version",
                urlDetailKqmst: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/ldtkqmst\/bido-qualification\/get-pre-notification-p",
                urlDetailKqst: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/pre-notify-contractor-result\/get",
                urlListVerKqst: "\/o\/egp-portal-contractor-selection-v2\/services\/expose\/pre-notify-contractor-result\/get-version",

                urlEdocAdbTemp: "https:\/\/muasamcong.mpi.gov.vn\/egp\/edocpreviewfe\/adb-wb-template",
                urlContractorFe: "https:\/\/muasamcong.mpi.gov.vn\/egp\/contractorfe\/viewer",
                urlADBWBFe: "https:\/\/muasamcong.mpi.gov.vn\/egp\/adbwbfe\/viewer",

                detailBidaInvChapterConfs: "\/o\/egp-portal-contractor-selection-v2\/services\/ebidinv\/bida-inv-chapter-confs",
                detailOpenGoodsGet: "\/o\/egp-portal-contractor-selection-v2\/services\/ebidbid\/open-goods\/get",


                getCategory:"\/o\/egp-portal-contractor-selection-v2\/services\/get\/category",

                // Category
                planTypesVe: [],
                planAppVeStatus: [],
                provinceAreas: [],
                districtAreas: [],
                catInvestFields: [],
                bidForms: [],
                contractTypes: [],
                processApplies: [],
                dmTrangThais: [],
                reasonCancelBidCPTPP: [],
                /*bidInvestForm: [],*/
                dmQt: [],
                dmPtlcnt: [],
                dmSpendingCat: [],
                dmBidStatusCat: [],
                notiStatusCat: [],
                dmGroupDa: [],
                dmCqms: [],
                dmCqmsLv1: [],
                reasonCancelBidCPTPP: [],
                htqlDa: [],
                dmHtdt: [],
                bidPlanStatus: [],
                dmLhdLcnt: [],
                bidoStatus: [],
                workTypeList: [],
                // End-Cat

                //bidStatusTabKQMT
                bidStatus: '',
                tagCancel: 1,
                cancelBid: {},

                id: "82817483-86c3-4200-adf4-1b355dbf8527",
                type: "es-bidp-project-p",
                stepCode: "project-step-1",
                notifyId: "undefined",
                inputResultId: "undefined",
                bidOpenId: "undefined",
                techReqId: "undefined",
                bidPreNotifyResultId: "undefined",
                bidPreOpenId: "undefined",
                processApply: "undefined",
                bidMode: "undefined",
                notifyNo: "undefined",
                planNo: "undefined",
                pno: "PR2600000073",
                step: "da",
                countTime: "2026-01-03T09:30:42.173",
                siteKey: "6LfXhdcpAAAAAIb2GV9eRkJcf8clrHAOVOIseJdT",

                loading: false,
                isLoadingKT: false,
                isLoadingTC: false,

                isVnLanguage: true,
                isEnglish: true,
                register: 'Đăng ký',
                // TBMT
                selectedTab: 'tbmt',
                isShowClarify: false,
                detailTbmt: null,
                tbmt: null,
                bidoNotifyView: null,
                chapterTrees: [],
                chapterTreesCHCTRG: [],
                dtlTdNs: {
                    bidaInvChapterConfList: [],
                    bidoInvReqApprovalAndDetailView: null,
                    bidoNotifyContractorM: {
                        bidCloseDate: new Date()
                    },
                    bidoPreBidConferenceList: [],
                    biduClarifyReqInvAndContentViewList: [],
                    bidoNotifyContractorP: {
                        bidCloseDate: new Date()
                    }
                },
                bidoPreNotifyContractorResult: {}, //Kết quả sơ tuyển
                contractorGroup: [], //danh sách nhà thầu pass ST
                haveSeeHSMT: true, //Có được xem HSMT không?
                orgCodeOfUserLogin: '',
                downloadFilePublic: true, //Dùng api download public
                attachedFiles: [],
                //END: TBMT
                // hh ADB
                goodsListAdb: null,
                serviceListAdb: null,

                // ptv tv LDT
                listServiceTG: [],
                listServiceDCCD: [],
                listServiceTG_1 : [],
                listServiceDCCD_1: [],
                currentPageTG: 1,
                currentPageDCCD: 1,
                currentPageTG_1: 1,
                currentPageDCCD_1: 1,
                pageSizeTvPtv: 20,

                /*KQMT*/
                // dtlRoundMngRes: null,
                dtlRoundMngRes: {
                    bidNoContractorResponse:{},
                    bidoBidroundMngViewDTO:{},
                    bidSubmissionByContractorViewResponse:{}
                },
                dtlRoundMngResTC: {
                    bidNoContractorResponse:{},
                    bidoBidroundMngViewDTO:{},
                    bidSubmissionByContractorViewResponse:{}
                },
                ptvFormCode:'',
                //ĐXKT
                viewInforNTofDXKT: 0,
                viewInforNTofDXTC: 0,
                viewInforNT: 0,
                viewInforNTofDSNTDKT: 0,
                viewInforNTofDSNTKDKT: 0,
                bidoLotOpenGroupsOfDXKT: [],
                bidoLotOpenGroupsOfDXTC: [],
                /*END: KQMT*/


                /*DSNTDKT*/
                dtlListContractor: [],
                dtlWinningContractor: [],
                dtlFalseContractor: [],
                dtlWinningContractorMedicine: [],
                dtlFalseContractorMedicine: [],
                winningContractorMultiLot: [],
                totalCtWinning: null,
                falseContractorMultiLot: [],
                winningContractorMultiLotGroupNT: [],
                falseContractorMultiLotGroupNT: [],
                winningContractorMultiLotGroupLo: [],
                falseContractorMultiLotGroupLo: [],
                dtlBidoBidNotifyRes: null,
                detailDsntdkt: null,
                listContractor: [],
                MAP_EVAL_TYPE : {
                    '1': 'Nhà thầu không đạt tại bước Đánh giá Tính hợp lệ',
                    '2': 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm',
                    '3': 'Nhà thầu không đạt tại bước Đánh giá Kỹ thuật',
                    '5': 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm (Nhân sự chủ chốt)',
                    '6': 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm (Thiết bị thi công)',
                    '5,6' : 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm (Nhân sự chủ chốt và thiết bị thi công)',
                    '2,5,6' : 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm, Nhân sự chủ chốt, thiết bị thi công',
                    '2,5': 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm, Nhân sự chủ chốt',
                    '2,6' : 'Nhà thầu không đạt tại bước Đánh giá Năng lực kinh nghiệm, thiết bị thi công'
                },
                /*END : DSNTDKT*/


                detailDsntdkt: null,

                /*CLG*/
                dtlReoffer: null,

                /*KQLCNT*/
                dtlKqlcnt: null,
                openGoodsList: null,
                selectedValue: 0,
                listInternetMedicineNoCt: [],
                listNotPassKT: [],

                dtlKqlcntRes: {
                    publicDate: new Date(),
                    openDate: new Date()
                },
                currentPageGoodlist: 1,
                currentPageGoodlistV2: 1,
                pageSizeGood: 30,
                MAP_FORM_CODE_HH_KQ : {
                    ['BD.MT.02.1088']: 'BD.MT.02.1251', // Mẫu cho chào hàng cạnh tranh rút gọn
                    ['BD.CG.02.0192']: 'BD.MT.02.1252', // 12.1
                    ['BD.CG.02.0197']: 'BD.MT.02.1253', // 13 dịch vụ liên quan
                    ['BD.DT.02.1150']: 'BD.MT.02.1254', // 13 dịch vụ liên quan
                    ['BD.DT.02.1008']: 'BD.MT.02.1255', // 12.2A
                    ['BD.DT.02.1009']: 'BD.MT.02.1256', //  12.2B
                    ['BD.DT.02.1103']: 'BD.MT.02.1257', // 12.2A
                    ['BD.DT.02.1104']: 'BD.MT.02.1258', // 12.2B
                    ['BD.DT.02.1102']: 'BD.MT.02.1259', // 12.1
                },
                hhCollection: [],
                hh12BCollection: [],
                hhCollectionCHCTRG: [],
                hhCollectionDVLQ: [],
                dsHhKq: [],
                dsHhKqForNN: [],
                noOpenLot: [],
                dvlqCollection: [],
                currentPageDvlqMultilot: 1,
                pageSizeDvlqMultilot: 5,
                winMedicineKqm: [],
                winMedicineKqmType0: [],
                winMedicineKqmType1: [],
                falseMedicineKqm: [],
                pageSizeMedicineKqm:5,
                currentPageWinMedicineKqm: 1,
                currentPageWinMedicineKqmType0: 1,
                currentPageWinMedicineKqmType1: 1,
                currentPageFalseMedicineKqm: 1,
                currentPageGoodlistOfLot: 1,
                currentPageGoodlistOfLot12_2B: 1,
                currentPageGoodlistOfNoLot: [],
                currentPageGoodlistOfNoLot12_2A: [],
                currentPageGoodlistOfNoLot12_2B: [],
                currentPageGoodlistOfNoLotCHCTRG: 1,
                currentPageGoodlistOfNoLotDVLQ: [],
                currentPageListContractorMedical: 1,
                currentPageListLotNoContractJoin: 1,
                currentPageListNotPassKT: 1,
                checkChangePageGoodOfNoLot: true,
                checkChangePageGoodOfNoLot12_2A: true,
                checkChangePageGoodOfNoLot12_2B: true,
                checkChangePageGoodOfNoLotDVLQ: true,
                pageSizeGoodOfLot: 5,
                pageSizeGoodOfLot12_2B: 5,
                pageSizeGoodOfNoLot: 30,
                pageSizeGoodOfNoLot12_2A: 30,
                pageSizeGoodOfNoLot12_2B: 30,
                pageSizeGoodOfNoLotCHCTRG: 30,
                pageSizeGoodOfNoLotDQLQ: 30,
                pageSizeContractorMedical: 30,
                pageSizeLotNoContractJoin: 30,
                pageSizePageListNotPassKT: 5,

                MEDICINE_TYPE_FOR_4 : [
                    {
                        code: 0,
                        name: 'Không bao gồm vị thuốc cổ truyền có dạng bào chế cao, cốm, bột, dịch chiết, tinh dầu, nhựa, gôm, thạch đã được tiêu chuẩn hóa'
                    },
                    {
                        code: 1,
                        name: 'Có dạng bào chế cao, cốm, bột, dịch chiết, tinh dầu, nhựa, gôm, thạch đã được tiêu chuẩn hóa'
                    }
                ],
                MEDICINE_TYPE_FOR_5 : [
                    {
                        code: 0,
                        name: 'Không bao gồm dược liệu có dạng bào chế cao, cốm, bột, dịch chiết, tinh dầu, nhựa, gôm, thạch đã được tiêu chuẩn hóa'
                    },
                    {
                        code: 1,
                        name: 'Có dạng bào chế cao, cốm, bột, dịch chiết, tinh dầu, nhựa, gôm, thạch đã được tiêu chuẩn hóa'
                    }
                ],

                /*END: KQLCNT*/

                /*DADTPT*/
                detailRes: null,
                /*END: DADTPT*/


                /*KHLCNT*/
                planTypeForKhlcnt: null,
                dtlPkgNoList: {},
                detailKhlcntRes: null,
                isDownloadFile: false,
                dtlPkgBidEstimatePrice : null,
                lotListKH: [],
                currentPageLotlist: 1,
                pageSize: 10,
                /*END: KHLCNT*/

                //TBST
                selectedValueLot: 0,
                selectedTabV2: 'tbst',
                dtlPreNotiContractRes: {},
                dtlKqmst: {},
                dtlNotifyContractRltRes: {},
                versionList: [],
                versionListDSN: [],
                versionListKQST: [],
                bidoNotifyViewTBST: {},
                //role
                selectedRole: '',

                //theo doi
                urlSub:"\/o\/egp-portal-contractor-selection-v2\/services\/sub",
                urlCheckMail:"\/o\/egp-portal-contractor-selection-v2\/services\/check-mail",
                email: '',
                emailOther: '',
                selectedrootRole: '',
                checkUserLoginHaveRoleNT: false,
                checkMail: false,
                subType: '',
                cancel: false,
                listSub: [],
                functionId: '',
                functionCode: '',
                functionName: '',
                procuringEntityName: '',

                // theo doi
                //DSNDTHC
                detailEbidShortList: {},
                totalCost12_2AKhongLo: [],
                totalbidAmount12_2AKhongLo: [],
                totalTax12_2AKhongLo: [],
                totalAmount12_2AKhongLo: [],
                totalPriceExcludeTax12_2BKhongLo: [],
                totalUnitPrice12_2BKhongLo: [],
                totalCost12_2BKhongLo: [],
                totalAmountBeforeTax12_2BKhongLo: [],
                totalImportTax12_2BKhongLo: [],
                totalTaxSpecial12_2BKhongLo: [],
                totalAmount12_2BKhongLo: [],
                totalAmountNoLotCHCTRG: [],
                totalAmountNoLotDVLQ: [],
                idDSN: '',
                bidoPreBidConferenceVersionList: [],
                biduClarifyReqInvAndContentViewVersionList: [],
                biduPetitionContractorVersionList: [],

                isHaveBidPriceDetailOfContractor: false,
                isHaveBidPriceDetailOfGoods: false,
                isHaveBidPriceDetailOfGoodsEn: false,
                isNoInternetAndNoDometic: false,
                isHaveManyCurrency: false,
                listMedicineQM: [],
                listMedicineQMType0: [],
                listMedicineQMType1: [],
                isLoadKqlcnt: false,
            }
        },
        validations: {
            email: {
                MSG0002: this.egpValidate('MSG0002', {
                    field: 'email'
                }, window.validators.required),
            },
        },
        filters: {

            formatDateAndH: function (date) {
                return date ? moment(date).format('DD/MM/YYYY HH:mm') : '';
            },

            formatDate: function (date) {
                return date ? moment(date).format('DD/MM/YYYY') : '';
            },

            formatMonth: function (date) {
                return date ? moment(date).format('MM/YYYY') : '';
            },

            formatHour: function (date) {
                return date ? moment(date).format('HH:mm') : '';
            },

            currency(value) {
                if (value) {
                    return new Number(value).toLocaleString('vi-VN',{maximumFractionDigits:4});
                } else return value;
            },

            fixedValue(value) {
                if (value) {
                    // return + (Math.round(value + "e+2")  + "e-2");
                    return new Number(value).toLocaleString('vi-VN',{maximumFractionDigits:4});
                } else return value;
            }
        },

        methods: {
            popupSpinning(){
                let p = this.$loading({ fullscreen:true ,text:"Vui lòng thử lại trong giây lát ..." });
                setTimeout(() => {
                    p.close();
                }, 5000);
            },
            fixedValue(value) {
                if (value) {
                    return new Number(value).toLocaleString('vi-VN',{maximumFractionDigits:4});
                } else return value;
            },

            actionChangeTagDefault(type){
                if(type == 'kqmt'){
                    this.changeTag("kqmt");
                }else if(type == 'tbmt'){
                    this.changeTag("tbmt");
                }
                return 'active';
            },


            sortListVersionKH(arr) {
                return arr?.sort((a, b) => (a.planVersion > b.planVersion) ? 1 : -1);

            },

            isValidViewHsmt(detail) {
                if (detail?.bidoNotifyContractorM?.bidForm == 'DTHC') {

                    if (Liferay.ThemeDisplay.isSignedIn()) {
                        const userInfo = localStorage.getItem("userDTO");

                        let userDTO = JSON.parse(localStorage.getItem('userDTO'));
                        if (userDTO) {
                            let orgCodes = detail?.bidContractorShortlistMDTO?.contractorList?.map(it => it.orgCode);

                            let orgCode = userDTO.orgCode;
                            return orgCodes.includes(orgCode) || orgCode == detail?.bidContractorShortlistMDTO?.procuringEntityCode || orgCode == detail?.bidContractorShortlistMDTO?.investorCode;
                        } else {
                            return false;
                        }
                    }
                    return false;
                }
                return true;
            },

            parseFailKTList(arr) {
                let result = []

                arr?.forEach((it, index, self) => {
                    if (result.filter(i => i.contractorCode === it.contractorCode).length == 0) {
                        let obj = {
                            "contractorCode": it.contractorCode,
                            "child": self.filter(j => j.contractorCode == it.contractorCode),
                            "evalType": self.filter(j => j.contractorCode == it.contractorCode).map(j => j.evalType).sort((a,b) => a - b ).toString()
                        };
                        result.push(obj);
                    }

                })
                return result;
            },

            getFailReason(evalType){
                return this.MAP_EVAL_TYPE[evalType] ? this.MAP_EVAL_TYPE[evalType] : '';
            },

            changeCancelTag(tag){
                this.tagCancel = tag;
            },
            onChangeCancel(){
                if(!this.cancelBid?.recoveryDate){
                    this.tagCancel = 1;
                }
            },

            downloadTBMT(){
                let docDefinition = {
                    content: [
                        [
                            {
                                text: 'THÔNG BÁO MỜI THẦU',
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                text: 'Thông tin cơ bản',
                                margin: [0, 0, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Mã TBMT',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.notifyNo}],
                                        [{text:'Ngày đăng tải',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.publicDate)}],
                                        [{text:'Phiên bản thay đổi',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.notifyVersion}]
                                    ]
                                }
                            },
                        ],
                        [
                            {
                                text: 'Thông tin chung của KHLCNT',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Mã KHLCNT',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.planNo}],
                                        [{text:'Phân loại KHLCNT',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.planType,this.planTypesVe)}],
                                        [{text: (this.bidoNotifyView.planType == 'DTPT') ? 'Tên dự án' : 'Tên dự toán mua sắm',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.projectName ? this.bidoNotifyView?.projectName : this.bidoNotifyView?.pName}]
                                    ]
                                }
                            },
                        ],
                        [
                            {
                                text: 'Thông tin gói thầu',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Tên gói thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidName}],
                                        [{text:'Mã gói thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidNo}],
                                        (this.bidoNotifyView.planType && this.bidoNotifyView.planType === 'DTPT') ? [{text:'Chủ đầu tư',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.investorName}] : null,
                                        [{text:'Bên mời thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.procuringEntityName}],
                                        [{text:'Nguồn vốn',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.capitalDetail}],
                                        [{text:'Lĩnh vực',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.investField,this.catInvestFields)}],
                                        [{text:'Hình thức lựa chọn nhà thầu',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.bidForm,this.bidForms)}],
                                        [{text:'Loại hợp đồng',fillColor: '#DDDDDD'},{text: (this.tbmt?.bidpPlanDetail?.ctype)? this.getNameCatByCodeCat(this.tbmt?.bidpPlanDetail?.ctype,this.dmLhdLcnt): this.getNameCatByCodeCat(this.bidoNotifyView?.cType,this.dmLhdLcnt)}],
                                        ('CPTPP' === this.processApply || 'UKFTA' === this.processApply || 'EVFTA' === this.processApply) ? [{text:'Nội khối/ Quốc tế',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.isDomestic == 1) ? 'Nội khối' : 'Quốc tế'}] : null,
                                        !('CPTPP' === this.processApply || 'UKFTA' === this.processApply || 'EVFTA' === this.processApply) ? [{text:'Trong nước/ Quốc tế',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.isDomestic == 1) ? 'Trong nước' : 'Quốc tế'}] : null,
                                        [{text:'Phương thức lựa chọn nhà thầu',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.bidMode,this.dmPtlcnt)}],
                                        [{text:'Thời gian thực hiện hợp đồng',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.contractPeriod ?  (this.bidoNotifyView?.contractPeriod + ' ' + this.getNameOfPeriod(this.bidoNotifyView?.contractPeriodUnit)) : (this.bidoNotifyView?.cPeriod + ' ' + this.getNameOfPeriod(this.bidoNotifyView?.cPeriodUnit))}],
                                        (this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length > 0 && this.dtlTdNs?.bidpPlanDetail?.isMultiLot == 1) ? [{text:'Số lượng phần (lô)',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length}] : null
                                    ].filter(it => it != null)
                                }
                            },
                        ],
                        [
                            {
                                text: 'Cách thức dự thầu',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Hình thức dự thầu',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView && this.bidoNotifyView?.isInternet == 1?'Qua mạng':'Không qua mạng') + ((this.dtlTdNs?.bidpPlanDetail?.isMultiLot == 1 && this.bidoNotifyView?.isInternet == 1) ? ', Nhà thầu tham dự 1 hoặc nhiều phần (lô)' : '' )}],
                                        [{text:'Địa điểm phát hành ' + (this.bidoNotifyView.isInternet==0 ?'HSMT':'e-HSMT'),fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.issueLocation}],
                                        this.processApply == 'ADB' || this.processApply == 'WB' ? (this.bidoNotifyView?.isInternet==1 ? [{text: 'Chi phí nộp e-HSDT',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.bidForm == 'DTRR' || this.bidoNotifyView?.bidForm == 'DTHC' || this.bidoNotifyView?.bidForm == 'MSTT') ? '330.000 VNĐ' : (this.bidoNotifyView?.bidForm == 'CHCT' || this.bidoNotifyView?.bidForm == 'CHCTRG')? '220.000 VNĐ' : ''}] : null) : (this.bidoNotifyView?.isInternet==1 ? [{text: 'Chi phí nộp e-HSDT',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.bidForm == 'DTRR' || this.bidoNotifyView?.bidForm == 'DTHC' || this.bidoNotifyView?.bidForm == 'MSTT') ? '330.000 VND' : (this.bidoNotifyView?.bidForm == 'CHCT' || this.bidoNotifyView?.bidForm == 'CHCTRG')? '220.000 VND' : ''}] : null),
                                        this.bidoNotifyView?.isInternet==0 ? [{text: 'Giá bán HSMT',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.feeValue ? this.currency(this.bidoNotifyView?.feeValue) : 'Miễn phí'}] : null,
                                        [{text:'Địa điểm nhận ' + (this.bidoNotifyView.isInternet==0 ?'HSDT':'e-HSDT'),fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.receiveLocation}],
                                        [{text:'Địa điểm thực hiện gói thầu',fillColor: '#DDDDDD'},{text: this.getBidLocationPdf()}],
                                    ].filter(it=> it != null)
                                }
                            },
                        ],

                        [
                            {
                                text: 'Thông tin dự thầu',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Thời điểm đóng thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.bidCloseDate)}],
                                        [{text:'Thời điểm mở thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.bidOpenDate)}],
                                        [{text:'Địa điểm mở thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidOpenLocation}],
                                        [{text: (this.bidoNotifyView?.bidForm == 'CHCTRG') ? 'Hiệu lực báo giá' : 'Hiệu lực hồ sơ dự thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidValidityPeriod + ' ' + this.getNameOfPeriod(this.bidoNotifyView?.bidValidityPeriodUnit)}],
                                        (this.bidoNotifyView?.guaranteeValue || this.bidoNotifyView?.bidGuaranteeValue) ? [{text: 'Số tiền đảm bảo dự thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.guaranteeValue ? (this.currency(this.bidoNotifyView?.guaranteeValue) + ' ' + (this.processApply == 'ADB' || this.processApply == 'WB' ? 'VNĐ' : this.bidoNotifyView?.bidPriceUnit)) : ( this.bidoNotifyView?.bidGuaranteeValue ? (this.currency(this.bidoNotifyView?.bidGuaranteeValue) + ' ' + (this.processApply == 'ADB' || this.processApply == 'WB' ? 'VNĐ' : this.bidoNotifyView?.bidPriceUnit)) : '')}] : null,
                                        (this.bidoNotifyView?.investField != 'TV' && this.bidoNotifyView?.bidForm != 'CHCTRG') ? [{text: 'Hình thức đảm bảo dự thầu',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.guaranteeForm ? this.bidoNotifyView?.guaranteeForm : (this.bidoNotifyView?.bidGuaranteeForm ? this.bidoNotifyView?.bidGuaranteeForm : '') }] : null,
                                    ].filter(it => it != null)
                                }
                            },
                        ],

                        [
                            {
                                text: 'Thông tin quyết định phê duyệt',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Số quyết định phê duyệt',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionNo}],
                                        [{text:' Ngày phê duyệt',fillColor: '#DDDDDD'},{text: this.formatDatePDF(this.tbmt?.bidInvContractorOfflineDTO?.decisionDate)}],
                                        [{text:'Cơ quan ban hành quyết định',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionAgency}],
                                        [{text:'Quyết định phê duyệt',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionFileName}],
                                    ]
                                }
                            },
                        ],
                        (this.processApply != 'KHAC' &&(this.tbmt?.bidoNotifyContractorM?.status == '03' ||  this.tbmt?.bidoNotifyContractorP?.status == '03')) ? [
                            {
                                text: (this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thông tin huỷ thông báo mời thầu':'Thông tin huỷ thầu',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Lí do huỷ thông báo mời thầu':'Lí do huỷ thầu',fillColor: '#DDDDDD'},{text: this.processApply == 'CPTPP' ? this.getNameCatByCodeCat(this.dtlTdNs?.bidCancelingResponse?.cancelReason,this.reasonCancelBidCPTPP) : this.getNameCatByCodeCat(this.dtlTdNs?.bidCancelingResponse?.cancelReason,this.reasonCancelBid)}],
                                        [{text:'Số quyết định',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelDecisionNo}],
                                        [{text:'Ngày phê duyệt quyết định',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDecisionDate)}],
                                        [{text:'Văn bản quyết định đính kèm',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelFileAttachName}],
                                        [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thời điểm huỷ thông báo mời thầu':'Thời điểm huỷ thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDate)}],
                                    ]
                                }
                            },
                        ] : null,
                        (this.processApply == 'KHAC' &&(this.tbmt?.bidoNotifyContractorM?.status == '03' ||  this.tbmt?.bidoNotifyContractorP?.status == '03')) ? [
                            {
                                text: (this.dtlTdNs?.bidoBidStatusDTO?.status == 'NEW')?'Thông tin huỷ thông báo mời thầu':'Thông tin huỷ thầu',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:(this.dtlTdNs?.bidoBidStatusDTO?.status == 'NEW')?'Lí do huỷ thông báo mời thầu':'Lí do huỷ thầu',fillColor: '#DDDDDD'},{text: this.processApply == 'CPTPP' ? this.dtlTdNs?.bidoNotifyContractorP?.cancelReason : this.dtlTdNs?.bidoNotifyContractorP?.cancelReason}],
                                        [{text:'Số quyết định',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidoNotifyContractorP?.cancelDecisionNo}],
                                        [{text:'Ngày phê duyệt quyết định',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs.bidoNotifyContractorP?.cancelDecisionDate)}],
                                        [{text:'Văn bản quyết định đính kèm',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelFileAttachName}],
                                        [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thời điểm huỷ thông báo mời thầu':'Thời điểm huỷ thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDate)}],
                                    ]
                                }
                            },
                        ] : null,
                        (this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length > 1 && this.bidoNotifyView?.isInternet != 1) ? [
                            {
                                text: 'Thông tin các phần (lô)',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [22,90,100,100,70,83],
                                    body: [
                                        [{text:'STT',fillColor: '#DDDDDD'},{text:'Tên từng phần/lô',fillColor: '#DDDDDD'},{text:'Giá từng phần lô (VND)',fillColor: '#DDDDDD'},{text:"Dự toán (VND)",fillColor: '#DDDDDD'},{text:"Số tiền bảo đảm (VND)",fillColor: '#DDDDDD'},{text:'Thời gian thực hiện hợp đồng',fillColor: '#DDDDDD'}],
                                    ].concat(this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.map((e,index) => {
                                        return [{text:index + 1},
                                            {text:e?.lotName},
                                            {text:this.currency(e?.lotPrice)},
                                            {text:this.currency(e?.lotEstimatePrice)},
                                            {text:this.currency(e?.lotGuaranteeValue)},
                                            {text:e?.cperiod + ' ' + this.getNameOfPeriodV2(e?.cperiodUnit)}
                                        ]
                                    }))
                                }
                            },
                        ] : null,
                    ].filter(item => item != null),
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                };
                pdfMake.createPdf(docDefinition).download("\n" + "Thông báo mời thầu.pdf");
            },

            downloadTBMTEn(){
                let docDefinition = {
                    content: [
                        [
                            {
                                text: 'Invitation to Bid'.toUpperCase(),
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                text: 'Basic information',
                                margin: [0, 0, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Invitation to Bid No',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.notifyNo}],
                                        [{text:'Published date',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.publicDate)}],
                                        [{text:'Version',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.notifyVersion}]
                                    ]
                                }
                            },
                        ],
                        [
                            {
                                text: 'Plan Information',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Plan no',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.planNo}],
                                        [{text:'Procurement plan category',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.planType,this.planTypesVe)}],
                                        [{text: (this.bidoNotifyView.planType == 'DTPT') ? 'Project name' : 'Title of budget estimates',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.projectName ? this.bidoNotifyView?.projectName : this.bidoNotifyView?.pName}]
                                    ]
                                }
                            },
                        ],
                        [
                            {
                                text: 'Bid Infomartion',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Title of procurement package',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidName}],
                                        (this.bidoNotifyView.planType && this.bidoNotifyView.planType === 'DTPT') ? [{text:'Investor',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.investorName}] : null,
                                        [{text:'Procuring Entity',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.procuringEntityName}],
                                        [{text:'Funding',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.capitalDetail}],
                                        [{text:'Procurement category',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.investField,this.catInvestFields)}],
                                        [{text:'Procurement method',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.bidForm,this.bidForms)}],
                                        [{text:'Contract type',fillColor: '#DDDDDD'},{text: (this.tbmt?.bidpPlanDetail?.ctype)? this.getNameCatByCodeCat(this.tbmt?.bidpPlanDetail?.ctype,this.dmLhdLcnt): this.getNameCatByCodeCat(this.bidoNotifyView?.cType,this.dmLhdLcnt)}],
                                        ('CPTPP' === this.processApply || 'UKFTA' === this.processApply || 'EVFTA' === this.processApply) ? [{text:'National/ International',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.isDomestic == 1) ? 'National' : 'International'}] : null,
                                        !('CPTPP' === this.processApply || 'UKFTA' === this.processApply || 'EVFTA' === this.processApply) ? [{text:'National/ International',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.isDomestic == 1) ? 'National' : 'International'}] : null,
                                        [{text:'Procurement procedure',fillColor: '#DDDDDD'},{text: this.getNameCatByCodeCat(this.bidoNotifyView?.bidMode,this.dmPtlcnt)}],
                                        [{text:'Contract performance period',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.contractPeriod ?  (this.bidoNotifyView?.contractPeriod + ' ' + this.getNameOfPeriodV2(this.bidoNotifyView?.contractPeriodUnit)) : (this.bidoNotifyView?.cPeriod + ' ' + this.getNameOfPeriodV2(this.bidoNotifyView?.cPeriodUnit))}],
                                        (this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length > 0 && this.dtlTdNs?.bidpPlanDetail?.isMultiLot == 1) ? [{text:'The number of lots',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length}] : null
                                    ].filter(it => it != null)
                                }
                            },
                        ],
                        [
                            {
                                text: 'Submission method',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Submission method',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView && this.bidoNotifyView?.isInternet == 1?'Online':'Offline')}],
                                        [{text:'Place of issuing bidding documents',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.issueLocation}],
                                        this.bidoNotifyView?.isInternet==1 ? [{text: 'Price of bidding documents',fillColor: '#DDDDDD'},{text: (this.bidoNotifyView?.bidForm == 'DTRR' || this.bidoNotifyView?.bidForm == 'DTHC' || this.bidoNotifyView?.bidForm == 'MSTT') ? '330,000 VND' : (this.bidoNotifyView?.bidForm == 'CHCT' || this.bidoNotifyView?.bidForm == 'CHCTRG')? '220,000 VND' : ''}] : null,
                                        this.bidoNotifyView?.isInternet==0 ? [{text: 'Price of bidding documents',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.feeValue ? this.currency(this.bidoNotifyView?.feeValue) : 'Free'}] : null,
                                        [{text:'Place of receiving bidding documents',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.receiveLocationEn}],
                                        [{text:'Place of performance',fillColor: '#DDDDDD'},{text: this.getBidLocationPdf()}],
                                    ].filter(it=> it != null)
                                }
                            },
                        ],

                        [
                            {
                                text: 'Bid information',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Bid closing time',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.bidCloseDate)}],
                                        [{text:'Bid opening time',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.bidoNotifyView?.bidOpenDate)}],
                                        [{text:'Place of opening bid',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidOpenLocationEn}],
                                        [{text: (this.bidoNotifyView?.bidForm == 'CHCTRG') ? 'Validity of bids' : 'Validity of bids',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidValidityPeriod + ' ' + this.getNameOfPeriodV2(this.bidoNotifyView?.bidValidityPeriodUnit)}],
                                        (this.bidoNotifyView?.guaranteeValue || this.bidoNotifyView?.bidGuaranteeValue) ? [{text: 'Bid security amount',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.guaranteeValue ? (this.currency(this.bidoNotifyView?.guaranteeValue) + ' ' + this.bidoNotifyView?.bidPriceUnit) : ( this.bidoNotifyView?.bidGuaranteeValue ? (this.currency(this.bidoNotifyView?.bidGuaranteeValue) + ' ' + this.bidoNotifyView?.bidPriceUnit) : '')}] : null,
                                        (this.bidoNotifyView?.investField != 'TV' && this.bidoNotifyView?.bidForm != 'CHCTRG') ? [{text: 'Form of bid security',fillColor: '#DDDDDD'},{text: this.bidoNotifyView?.bidGuaranteeFormEn ? this.bidoNotifyView?.bidGuaranteeFormEn : (this.bidoNotifyView?.bidGuaranteeFormEn ? this.bidoNotifyView?.bidGuaranteeFormEn : '') }] : null,
                                    ].filter(it => it != null)
                                }
                            },
                        ],

                        [
                            {
                                text: 'Approval Information',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [180,320],
                                    body: [
                                        [{text:'Approval decision No.',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionNoEn}],
                                        [{text:' Approval date',fillColor: '#DDDDDD'},{text: this.formatDatePDF(this.tbmt?.bidInvContractorOfflineDTO?.decisionDateEn)}],
                                        [{text:'Decision-making body',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionAgencyEn}],
                                        [{text:'Approval decision',fillColor: '#DDDDDD'},{text: this.tbmt?.bidInvContractorOfflineDTO?.decisionFileNameEn}],
                                    ]
                                }
                            },
                        ],
                        // (this.processApply != 'KHAC' &&(this.tbmt?.bidoNotifyContractorM?.status == '03' ||  this.tbmt?.bidoNotifyContractorP?.status == '03')) ? [
                        //     {
                        //         text: (this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thông tin huỷ thông báo mời thầu':'Thông tin huỷ thầu',
                        //         margin: [0, 10, 0, 5],
                        //     },
                        //     {
                        //         table: {
                        //             font: 'TimesNewRoman',
                        //             widths: [180,320],
                        //             body: [
                        //                 [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Lí do huỷ thông báo mời thầu':'Lí do huỷ thầu',fillColor: '#DDDDDD'},{text: this.processApply == 'CPTPP' ? this.getNameCatByCodeCat(this.dtlTdNs?.bidCancelingResponse?.cancelReason,this.reasonCancelBidCPTPP) : this.getNameCatByCodeCat(this.dtlTdNs?.bidCancelingResponse?.cancelReason,this.reasonCancelBid)}],
                        //                 [{text:'Approval decision number',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelDecisionNo}],
                        //                 [{text:'Approval date',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDecisionDate)}],
                        //                 [{text:'Approval decision file',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelFileAttachName}],
                        //                 [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thời điểm huỷ thông báo mời thầu':'Thời điểm huỷ thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDate)}],
                        //             ]
                        //         }
                        //     },
                        // ] : null,
                        // (this.processApply == 'KHAC' &&(this.tbmt?.bidoNotifyContractorM?.status == '03' ||  this.tbmt?.bidoNotifyContractorP?.status == '03')) ? [
                        //     {
                        //         text: (this.dtlTdNs?.bidoBidStatusDTO?.status == 'NEW')?'Thông tin huỷ thông báo mời thầu':'Thông tin huỷ thầu',
                        //         margin: [0, 10, 0, 5],
                        //     },
                        //     {
                        //         table: {
                        //             font: 'TimesNewRoman',
                        //             widths: [180,320],
                        //             body: [
                        //                 [{text:(this.dtlTdNs?.bidoBidStatusDTO?.status == 'NEW')?'Lí do huỷ thông báo mời thầu':'Lí do huỷ thầu',fillColor: '#DDDDDD'},{text: this.processApply == 'CPTPP' ? this.dtlTdNs?.bidoNotifyContractorP?.cancelReason : this.dtlTdNs?.bidoNotifyContractorP?.cancelReason}],
                        //                 [{text:'Số quyết định',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidoNotifyContractorP?.cancelDecisionNo}],
                        //                 [{text:'Ngày phê duyệt quyết định',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs.bidoNotifyContractorP?.cancelDecisionDate)}],
                        //                 [{text:'Văn bản quyết định đính kèm',fillColor: '#DDDDDD'},{text: this.dtlTdNs?.bidCancelingResponse?.cancelFileAttachName}],
                        //                 [{text:(this.dtlTdNs?.bidoBidStatus?.status == 'NEW')?'Thời điểm huỷ thông báo mời thầu':'Thời điểm huỷ thầu',fillColor: '#DDDDDD'},{text: this.formatDateForPDF(this.dtlTdNs?.bidCancelingResponse?.cancelDate)}],
                        //             ]
                        //         }
                        //     },
                        // ] : null,
                        (this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.length > 1 && this.bidoNotifyView?.isInternet != 1) ? [
                            {
                                text: 'Lot information',
                                margin: [0, 10, 0, 5],
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [22,90,100,100,70,83],
                                    body: [
                                        [{text:'No',fillColor: '#DDDDDD'},{text:'Lot title',fillColor: '#DDDDDD'},{text:"Lot's estimated price",fillColor: '#DDDDDD'},{text:"Lot's budget estimates",fillColor: '#DDDDDD'},{text:"Bid security amount",fillColor: '#DDDDDD'},{text:'Implementation period',fillColor: '#DDDDDD'}],
                                    ].concat(this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.lotDTOList?.map((e,index) => {
                                        return [{text:index + 1},
                                            {text:e?.lotName},
                                            {text:this.currency(e?.lotPrice)},
                                            {text:this.currency(e?.lotEstimatePrice)},
                                            {text:this.currency(e?.lotGuaranteeValue)},
                                            {text:e?.cperiod + ' ' + this.getNameOfPeriodV2(e?.cperiodUnit)}
                                        ]
                                    }))
                                }
                            },
                        ] : null,
                    ].filter(item => item != null)
                };
                pdfMake.createPdf(docDefinition).download("\n" + "Invitation to Bid.pdf");
            },

            checkYCLR(){
                if(this.stepCode == 'notify-contractor-step-1-tbmt'){
                    return 0;
                }
                let arrayYclr= [];
                this.biduClarifyReqInvAndContentViewVersionList?.forEach(e => {
                    e?.biduClarifyReqInvAndContentViewList?.forEach(item => {
                        if(item?.signResDate == null && !arrayYclr.find(it => it?.reqNo == item?.reqNo)){
                            arrayYclr.push(item);
                        }
                    })
                })
                return arrayYclr.length;
            },
            isTbmtKqmQt(){
                return this.processApply == 'LDT' && (this.bidoNotifyView?.isInternet == 0 && this.bidoNotifyView?.isDomestic == 0) || (this.dtlKqlcnt?.bideContractorInputResultDTO?.isDomestic == 0 && this.dtlKqlcnt?.bideContractorInputResultDTO?.isInternet == 0 );
            },
            isTbmstKqmQt(){
                return this.processApply == 'LDT' && this.dtlPreNotiContractRes?.isInternet == 0 &&  this.dtlPreNotiContractRes?.isDomestic == 0;
            },

            checkKN(){
                let arrayKN= []
                this.biduPetitionContractorVersionList?.forEach(e => {
                    e?.biduPetitionContractorDTOList?.forEach(item => {
                        let petition = this.getContentKn(item.content);
                        petition?.forEach(element =>{
                            // if(element?.petitionPeriod == 'E-HSMT' && element?.resDate == null && this.bidoNotifyView?.bidOpenDate && (new Date() > new Date(this.bidoNotifyView?.bidOpenDate))){
                            //     arrayKN.push(element);
                            // }
                            if(element?.resDate == null && this.checkPublicDateKn(item?.reqDate)){
                                arrayKN.push(element);
                            }
                        })

                        // if(this.getContentKn(item.content)[0]?.petitionPeriod == 'KQDT' &&this.dtlKqlcnt?.bideContractorInputResultDTO?.publicDate &&  this.checkPublicDateKn(this.dtlKqlcnt?.bideContractorInputResultDTO?.publicDate) && item?.resDate == null ){
                        //     arrayKN.push(item);
                        // }
                    })
                })
                return arrayKN.length;
            },
            checkPublicDateKn(date){
                let validTime = 7 * 24 * 60 * 60 * 1000;
                if(new Date().getTime() - new Date(date).getTime() < validTime){
                    return false;
                }
                return true;
            },

            checkIsEn(){
                if(this.currentUrl.includes("en/")) return true;
                return false;
            },
            changeLanguage(lang){

                if(lang == 'vi'){
                    this.isVnLanguage = true
                    let str = this.rootUrl + "/vi"+this.currentUrl.replace("en/","").replace("vi/","");

                    console.log("str : ", str)

                    window.open(str, '_self');
                }else if(lang == 'en'){
                    this.isVnLanguage = false
                    let str = this.rootUrl + "/en"+this.currentUrl.replace("en/","").replace("vi/","");
                    console.log("str : ", str)
                    window.open(str, '_self');

                }
            },

            getBidLocationPdf(){
                let location= ''
                if(this.tbmt?.bidpBidLocationList?.length > 0){
                    for (let item of this.tbmt?.bidpBidLocationList){
                        location += ((item?.wardName) ? (item?.wardName + ',') : '') + ((item?.districtName) ? (item?.districtName + ',') : '') + item?.provName + '\n'
                    }
                }
                if(this.tbmt?.lsBidpBidLocationDTO?.length > 0){
                    for (let item of this.tbmt?.lsBidpBidLocationDTO){
                        location += ((item?.wardName) ? (item?.wardName + ',') : '') + ((item?.districtName) ? (item?.districtName + ',') : '') + item?.provName + '\n'
                    }
                }
                return location;
            },

            filterBidderDxtc(list){
                if(list)
                    return  list.filter(it => {
                        return it.lotNoValueDTOList?.length > 0 && it.lotNoValueDTOList[0].lotPrice > 0
                    } );

            },
            getLotNameColumn(){
                if(this.bidoNotifyView?.isMedicine == 1){
                    if(this.bidoNotifyView?.medicalType == 0 || this.bidoNotifyView?.medicalType == 1){
                        return 'Tên hoạt chất';
                    }
                    if(this.bidoNotifyView?.medicalType == 2){
                        return 'Tên thành phần thuốc';
                    }
                    if(this.bidoNotifyView?.medicalType == 4){
                        return 'Tên dược liệu';
                    }
                    if(this.bidoNotifyView?.medicalType == 5){
                        return 'Tên vị thuốc cổ truyền';
                    }
                }
                return 'Tên phần/lô';
            },
            reRenderDXTC() {
                /* To load detail api */
                let apiUrl = "";

                /* chung api phan adb, wb cua tbmt */

                // apiUrl = ('ADB' === this.processApply || 'WB' === this.processApply || 'KHAC' === this.processApply)
                //     ? this.urlDetailKqmtVk : this.urlDetailKqmtLdt;

                apiUrl = ('ADB' === this.processApply || 'WB' === this.processApply || 'KHAC' === this.processApply)
                    ? this.urlDetailKqmtVk : this.urlDetailKqmtLdtTC;

                if ('ADB' === this.processApply || 'WB' === this.processApply || 'KHAC' === this.processApply) {
                    payload = {
                        id: this.notifyId,
                        packType: 2
                    }
                } else {
                    // payload = {
                    //     notifyNo: this.notifyNo,
                    //     type: "TBMT",
                    //     packType: 2
                    // }

                    payload = {
                        notifyNo: this.notifyNo,
                        type: "TBMT",
                        packType: 2,
                        viewType: 0,
                        notifyId: this.notifyId,
                    }
                }
                if ('ADB' === this.processApply || 'WB' === this.processApply || 'KHAC' === this.processApply) {

                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {

                            axios.post(apiUrl+"?token="+token, payload).then(res => {


                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlRoundMngResTC = res.data;
                                    if (this.bidMode == '1_MTHS') {
                                        this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['bidFinalPrice'], ['asc']);
                                    }
                                    if (this.bidMode == '1_HTHS') {
                                        this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['contractorName'], ['asc']);
                                    }
                                }
                            });
                        });
                    });



                } else {


                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {
                            axios.post(
                                this.urlNotifyKqmtLdt+"?token="+token, payload
                            ).then(response => {


                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {

                                    this.dtlRoundMngResTC.bidNoContractorResponse = response.data?.bidNoContractorResponse;
                                }
                            })

                        });
                    });

                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {
                            axios.post(
                                this.urlRoundMngKqmtLdt+"?token="+token, payload
                            ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlRoundMngResTC.bidoBidroundMngViewDTO = response.data?.bidoBidroundMngViewDTO;
                                    this.bidStatus = response?.data?.bidoBidroundMngViewDTO?.bidStatus;
                                }
                            })

                        });
                    });


                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {

                            this.isLoadingTC = true;
                            axios.post(
                                this.urlBidOpenKqmtLdt+"?token="+token, payload
                            ).then(response => {


                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {

                                    this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = response.data?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList
                                    if (this.bidMode == '1_MTHS') {
                                        this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['bidFinalPrice'], ['asc']);
                                    }
                                    if (this.bidMode == '1_HTHS') {
                                        this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['contractorName'], ['asc']);
                                    }
                                }
                                grecaptcha.ready(res => {
                                    grecaptcha.execute(this.siteKey,
                                        {action: 'submit'}).then(token2 => {

                                        this.payloadSearch = payload;

                                        axios.post(this.urlLotOpenSubmissionKqmtLdt+"?token="+token2,payload).then(res => {



                                            if(typeof res.data == 'number'){
                                                this.popupSpinning()
                                            }else {
                                                this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidSubmissionDTOList.map(it => {
                                                    it.lotNoValueDTOList = res.data?.filter(lot => lot.contractorCode == it.contractorCode);
                                                    return it;
                                                })
                                                this.isLoadingTC = false;
                                                let bidoBidSubmissionsV1 = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                                                let bidoLotOpenDetailsV1 = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                                                // check call 2 API cùng lúc
                                                if (bidoLotOpenDetailsV1) {
                                                    bidoLotOpenDetailsV1?.forEach(item => {
                                                        const bidSub = bidoBidSubmissionsV1?.filter(e => e?.contractorCode === item?.contractorCode)[0];
                                                        item.ventureName = bidSub?.ventureName;
                                                        item.ventureCode = bidSub?.ventureCode;
                                                        item.fileId = bidSub?.fileId;
                                                        item.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                                                        item.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                                                        item.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                                                        item.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === item?.lotNo)[0]?.bidContractPeriod;

                                                    })
                                                    this.bidoLotOpenGroupsOfDXTC = _(bidoLotOpenDetailsV1).groupBy('lotNo').map((items, subject) => {
                                                        return {items};
                                                    }).value();
                                                    this.bidoLotOpenGroupsOfDXTC.forEach(f => {
                                                        if (f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                                                            f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                                                        }
                                                        if (f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                                                            f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                                        }
                                                    })
                                                }
                                            }
                                        }).catch(err => this.isLoadingTC = false)

                                    });
                                });

                            }).catch(err => this.isLoadingTC = false)

                        });
                    });



                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {

                            axios.post(
                                this.urlLotOpenDetailKqmtLdt+"?token="+token, payload
                            ).then(res => {

                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else{
                                    this.dtlRoundMngResTC.bidSubmissionByContractorViewResponse.bidoLotOpenDetailDTOS = res.data;
                                    let bidoBidSubmissions = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                                    let bidoLotOpenDetails = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                                    // check call 2 API cùng lúc
                                    if (bidoBidSubmissions?.[0]?.lotNoValueDTOList) {
                                        bidoLotOpenDetails?.forEach(item => {
                                            const bidSub = bidoBidSubmissions?.filter(e => e?.contractorCode === item?.contractorCode)[0];
                                            item.ventureName = bidSub?.ventureName;
                                            item.ventureCode = bidSub?.ventureCode;
                                            item.fileId = bidSub?.fileId;
                                            item.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                                            item.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                                            item.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                                            item.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === item?.lotNo)[0]?.bidContractPeriod;

                                        })
                                        this.bidoLotOpenGroupsOfDXTC = _(bidoLotOpenDetails).groupBy('lotNo').map((items, subject) => {
                                            return {items};
                                        }).value();
                                        this.bidoLotOpenGroupsOfDXTC.forEach(f => {
                                            if (f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                                                f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                                            }
                                            if (f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                                                f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                            }
                                        })
                                    }}
                            })
                        });
                    });



                }
                //         if(apiUrl === this.urlDetailKqmtLdtTC && this.processApply === 'LDT' && this.dtlRoundMngRes?.bidoBidroundMngViewDTO?.isMultiLot === true){
                //             this.viewInforNTofDXTC = 0;
                //             let bidoBidSubmissions = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                //             let bidoLotOpenDetails = this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                //             bidoLotOpenDetails?.forEach(item => {
                //                 const bidSub = bidoBidSubmissions?.filter(e => e?.contractorCode === item?.contractorCode)[0];
                //                 item.ventureName = bidSub?.ventureName;
                //                 item.ventureCode = bidSub?.ventureCode;
                //                 item.fileId = bidSub?.fileId;
                //                 item.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                //                 item.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                //                 item.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                //                 item.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === item?.lotNo)[0]?.bidContractPeriod;
                //
                //             })
                //             this.bidoLotOpenGroupsOfDXTC = _(bidoLotOpenDetails).groupBy('lotNo').map((items, subject) => {
                //                 return {items};
                //             }).value();
                //             this.bidoLotOpenGroupsOfDXTC.forEach( f => {
                //                 if(f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                //                     f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                //                 }
                //                 if(f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                //                     f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                //                 }
                //             })
                //         }
                //     })
                // }
            },
            renderNotifyPage(notifyNo){
                payload = {
                    "pageSize": 1,
                    "pageNumber": 0,
                    "query": [
                        {
                            "index": "es-contractor-selection",
                            "keyWord": notifyNo,
                            "matchType": "exact",
                            "matchFields": [
                                "notifyNo",
                                "bidName"
                            ],
                            "filters": [
                                {
                                    "fieldName": "type",
                                    "searchType": "in",
                                    "fieldValues": [
                                        "es-notify-contractor"
                                    ]
                                }
                            ]
                        }
                    ]
                }

                const payloadPreNotify = {
                    "pageSize": 1,
                    "pageNumber": 0,
                    "query": [
                        {
                            "index": "es-contractor-selection",
                            "keyWord": notifyNo,
                            "matchType": "exact",
                            "matchFields": [
                                "notifyNo",
                                "bidName"
                            ],
                            "filters": [
                                {
                                    "fieldName": "type",
                                    "searchType": "in",
                                    "fieldValues": [
                                        "es-pre-notify-contractor"
                                    ]
                                }
                            ]
                        }
                    ]
                }


                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        // console.log("payload : ", this.formatPayloadSearchWidthNotify(payload))
                        axios.post(
                            this.elasticSearch+"?token="+token, [payload]
                        ).then(response => {


                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    let listResultSearch = response.data?.page?.content;
                                    if (listResultSearch?.length > 0) {
                                        let result = listResultSearch[0];
                                        window.open(`${this.detailUrl}&type=es-notify-contractor&stepCode=${result?.stepCode}&id=${result?.id}&notifyId=${result?.notifyId}&inputResultId=${result?.inputResultId}&bidOpenId=${result?.bidOpenId}&techReqId=${result?.techReqId}&bidPreNotifyResultId=${result?.bidPreNotifyResultId}&bidPreOpenId=${result?.bidPreOpenId}&processApply=${result?.processApply}&bidMode=${result?.bidMode}&notifyNo=${result?.notifyNo}&planNo=${result?.planNo}&pno=${result?.pno}`, '_self');
                                    } else {

                                        grecaptcha.ready(res => {
                                            grecaptcha.execute(this.siteKey,
                                                {action: 'submit'}).then(token2 => {

                                                axios.post(this.elasticSearch+"?token="+token2, [payloadPreNotify]).then(
                                                    res => {

                                                        if(typeof res.data == 'number'){
                                                            this.popupSpinning()
                                                        }else {
                                                            let listRs = res.data?.page?.content;
                                                            if (listRs?.length > 0) {
                                                                let rs = listRs[0];
                                                                window.open(`${this.detailUrl}&type=${rs?.type}&stepCode=${rs?.stepCode}&id=${rs?.id}&notifyId=${rs?.notifyId}&inputResultId=${rs?.inputResultId}&bidOpenId=${rs?.bidOpenId}&techReqId=${rs?.techReqId}&bidPreNotifyResultId=${rs?.bidPreNotifyResultId}&bidPreOpenId=${rs?.bidPreOpenId}&processApply=${rs?.processApply}&bidMode=${rs?.bidMode}&notifyNo=${rs?.notifyNo}&planNo=${rs?.planNo}&pno=${rs?.pno}`, '_self');
                                                            }
                                                        }
                                                    }
                                                )

                                            });
                                        });


                                    }
                                }
                            }
                        );

                    });
                });


            },
            downloadAllAttachedFile(){
                if((!this.isSignIn() && this.dtlPreNotiContractRes?.investField == 'XL' ) || (!this.isSignIn() && this.bidoNotifyView?.investField == 'XL' && this.processApply == 'LDT')){
                    this.$warning({
                        title: 'Lưu ý',
                        content: "Vui lòng đăng nhập để tải toàn bộ file.",
                        centered: true
                    });
                    return;
                }
                let allFileDOM = document.getElementsByClassName('file-download-all');
                if(allFileDOM?.length == 0){
                    return;
                }
                let listFileId = {}
                for (let i = 0; i < allFileDOM.length;i++){
                    const fileObj = allFileDOM[i].id.split(',')
                    listFileId[fileObj[0]] = allFileDOM[i].id.slice(fileObj[0].length + 1);
                }
                let stringDownloadMultiFileToZip = '';
                let nameFileZip = `File đính kèm ${this.notifyNo}.zip`;
                // for(var i = 0; i < listFileId.length; i++){
                //     stringDownloadMultiFileToZip = stringDownloadMultiFileToZip.concat(",",listFileId[i]);
                // };
                // stringDownloadMultiFileToZip = stringDownloadMultiFileToZip.slice(1);
                this.downloadFileZIP(listFileId,nameFileZip)
                // console.log("fileId",allFileDOM?.map(it => it?.id));
            },
            downloadFileZIP(stringDownloadMultiFileToZip, nameFileZip) {
                // url = `http://localhost:1234/api/download/files/browser/public?fileIds=${stringDownloadMultiFileToZip}&fileName=${nameFileZip}`;
                // window.open(url, '_self').close();
                this.isDownloadFile = true;
                axios.get('http://localhost:1234/api/download/files/browser/public', {
                    params: {
                        mapFiles: stringDownloadMultiFileToZip,
                        fileName: nameFileZip
                    },
                    responseType: 'blob'
                }).then(response =>{
                    var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                    var fileLink = document.createElement('a');
                    fileLink.href = fileURL;
                    fileLink.setAttribute('download', nameFileZip);
                    document.body.appendChild(fileLink);
                    fileLink.click();
                    this.isDownloadFile = false;
                }).catch(err => {
                    this.isDownloadFile = false;
                    this.$error({
                        title: 'Lỗi',
                        content: 'Tải file không thành công. Vui lòng kiểm tra kết nối mạng hoặc liên hệ Tổng đài 1900 6126 để được hỗ trợ.',
                        centered: true
                    })
                })
            },
            onClickNewTabAll: function () {
                if (this.processApply && (this.processApply === 'ADB' || this.processApply === 'WB')) {
                    let urlEdoc = this.urlADBWBFe + "?formCode=ALL&id="
                        + this.dtlTdNs.bidoNotifyContractorP.id + "&fileName=Hồ sơ mời thầu";
                    //let urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode=ALL&fileName=Hồ sơ mời thầu&subCode=" + '';
                    window.open(urlEdoc);
                } else {
                    let str = this.urlContractorFe + "?formCode=ALL&id="
                        + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=Hồ sơ mời thầu";

                    window.open(str);
                }

            },
            onClickNewTabHSMSTAll: function() {
                this.urlEdoc = this.urlContractorFe +"/hsmst" + "?id="
                    + this.dtlTdNs.id  + "&lotNo=" + this.dtlTdNs.bidNo + "&contractorCode=" + this.dtlTdNs.procuringEntityCode + "&formCode=ALL";
                var popout = window.open(this.urlEdoc);
            },
            checkCollapseShow(code) {
                const collapseId = document.getElementById("collapseOne" + code);
                const iconFa = document.getElementById("icon-fa" + code);
                if (collapseId && iconFa && collapseId.classList.contains('show')) {
                    if (!iconFa.classList.contains('fa-angle-right')) {
                        iconFa.classList.add("fa-angle-right");
                    }
                    if (iconFa.classList.contains('fa-angle-down')) {
                        iconFa.classList.remove("fa-angle-down");
                    }
                } else {
                    if (iconFa.classList.contains('fa-angle-right')) {
                        iconFa.classList.remove("fa-angle-right");
                    }
                    if (!iconFa.classList.contains('fa-angle-down')) {
                        iconFa.classList.add("fa-angle-down");
                    }
                }
            },
            onClickNewTabMst: function (itemDetail, chapterNames) {
                if (this.dtlTdNs.processApply && (this.dtlTdNs.processApply === 'ADB' || this.dtlTdNs.processApply === 'WB')) {
                    if ('C3' === itemDetail.pcode) {
                        this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.id + "&formCode="
                            + itemDetail.pcode + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code;
                        var popout = window.open(this.urlEdoc);
                    } else if ('C7' === itemDetail.code
                        && (this.dtlTdNs.investField == 'XL'
                            || this.dtlTdNs.investField == 'HH')) {
                        this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.id + "&formCode="
                            + itemDetail.code + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code + "&type=download";
                        var popout = window.open(this.urlEdoc);
                        window.setTimeout(function () {
                            popout.close();
                        }, 1000);
                    } else {
                        this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.id + "&formCode="
                            + itemDetail.code + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + '';
                        var popout = window.open(this.urlEdoc);
                    }
                } else {
                    this.urlEdoc = this.urlContractorFe +"/hsmst" + "?id="
                        + this.dtlTdNs.id  + "&lotNo=" + this.dtlTdNs.bidNo + "&contractorCode=" + this.dtlTdNs.procuringEntityCode + "&formCode=" + itemDetail.code;
                    // this.urlEdoc = this.urlEdocTemp + "?formCode=" + itemDetail.code + "&id="
                    //     + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=" + this.convertName(chapterNames);
                    var popout = window.open(this.urlEdoc);
                }

            },
            viewAllGoodsInNewTab(arr,goodsList){
                for (let item of arr) {
                    // this.onClickViewGood( item.formCode, this.getNameByFormCode(item.formCode))
                    this.onClickViewGood( item.formCode, this.getNameByFormCode(item.formCode),item.notifyNo,item.notifyVersion,goodsList)
                }
            },
            backPreviousPage(){
                window.history.go(-1);
            },
            breadcrumbRedirect(path) {
                let url = this.siteURL;
                if (path) url = `${url}/${path}`;
                window.location = url;
            },
            filterPriceUsd(value) {
                let priceVal;
                if (value) {
                    priceVal = value?.filter(x => x.moneyType === 'USD').map(x => x.invest);
                }
                return priceVal ? priceVal[0] : '0';
            },
            filterPriceEur(value) {
                let priceVal;
                if (value) {
                    priceVal = value?.filter(x => x.moneyType === 'EUR').map(x => x.invest);
                }
                return priceVal ? priceVal[0] : '0';
            },

            filterExchangeRateUSD(value){
                let exchangeRate;
                if (value) {
                    exchangeRate = value?.filter(x => x.exchangeRate !== null && x.moneyType ==='USD').map(x => x.exchangeRate);
                }
                return exchangeRate ? exchangeRate[0] : '0';
            },
            filterExchangeRateEUR(value){
                let exchangeRate;
                if (value) {
                    exchangeRate = value?.filter(x => x.exchangeRate !== null && x.moneyType ==='EUR').map(x => x.exchangeRate);
                }
                return exchangeRate ? exchangeRate[0] : '0';
            },

            filterPriceVnd(value) {
                let priceVal;
                if (value) {
                    priceVal = value?.filter(x => x.moneyType === 'VND').map(x => x.invest);
                }
                return priceVal ? priceVal[0] : '0';
            },
            checkObjectVentureCodeIncludesArray(arr, ventureName) {
                return arr.map(it => it.ventureName).includes(ventureName);
            },
            checkObjectParnerShipIncludesArray(arr, partnership) {
                return arr.map(it => it.partnership).includes(partnership);
            },
            checkObjectVentureCodeIncludesArrayDSN(arr, partnership) {
                return arr.map(it => it.partnership).includes(partnership);
            },
            downloadFile(fileId, fileName) {
                this.isDownloadFile = true;
                if(this.downloadFilePublic){
                    axios.get('http://localhost:1234/api/download/file/browser/public', {
                        params: {
                            fileId: fileId
                        },
                        responseType: 'blob'
                    }).then(response => {

                        this.isDownloadFile = false;
                        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                        var fileLink = document.createElement('a');

                        fileLink.href = fileURL;
                        fileLink.setAttribute('download', fileName);
                        document.body.appendChild(fileLink);
                        fileLink.click();
                    }).catch(error => {
                        this.isDownloadFile = false;
                        this.$error({
                            title: this.isEnglish ? 'Error' : 'Lỗi',
                            content: this.isEnglish ? 'File download failed. Please check your network connection or contact Hotline 1900 6126 for support' : 'Tải file không thành công. Vui lòng kiểm tra kết nối mạng hoặc liên hệ Tổng đài 1900 6126 để được hỗ trợ',
                            centered: true
                        });

                    });
                }else {
                    this.downloadFileNoPublic(fileId, fileName);
                }
            },
            getNameCatByCodeCat(code, listCat) {
                if (!listCat)
                    return code;
                const temp = listCat.filter(el => el.code == code).pop();
                return temp ? (this.checkIsEn() ? temp?.nameEn : temp.name) : code;
            },
            loadPkgDetail(pkgId,bidEstimatePrice) {
                this.currentPageLotlist = 1;
                /* To load pkg detail api */
                if (pkgId) {
                    this.dtlPkgNoList = {}
                    let payload = {
                        id: pkgId
                    };

                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {
                            axios.post(this.urlDetailBidKhlcnt+"?token="+token, payload).then(res => {


                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else {

                                    this.dtlPkgNoList = res.data;
                                    this.dtlKqlcnt = res.data.resultDTO;
                                    this.inputResultId = res.data?.resultDTO?.id;
                                    this.isNoInternetAndNoDometic = this.checkNoInternetAndNoDometic(this.dtlPkgNoList);
                                    this.isHaveBidPriceDetailOfContractor = this.checkHaveBidPriceDetailOfContractor(this.getBidResultValid(this.convertArrayVenterName(this.dtlKqlcnt?.lotResultDTO[this.selectedValue]?.contractorList)), this.isNoInternetAndNoDometic);
                                    if (this.dtlKqlcnt?.lotResultDTO[this.selectedValue]?.goodsList) {
                                        this.isHaveBidPriceDetailOfGoods = this.checkHaveBidPriceDetailOfGoods(JSON.parse(this.dtlKqlcnt?.lotResultDTO[this.selectedValue]?.goodsList), this.isNoInternetAndNoDometic);
                                    }
                                    if (this.dtlPkgNoList?.bidPriceDetail) {
                                        this.isHaveManyCurrency = this.checkHaveManyCurrency(JSON.parse(this.dtlPkgNoList?.bidPriceDetail));
                                    }

                                    if (this.dtlKqlcnt?.isInternet == 0 && this.dtlKqlcnt?.isMedicine == 1) {
                                        let lotResultMedicineKqm = this.dtlKqlcnt?.lotResultDTO?.find(it => it?.goodsList?.length > 0);
                                        if (lotResultMedicineKqm) {
                                            let goodsListMedicineKqm = JSON.parse(lotResultMedicineKqm?.goodsList || '[]');
                                            this.winMedicineKqm = goodsListMedicineKqm?.filter(lot => lot?.winContractors?.length > 0);
                                            if (this.dtlPkgNoList?.bidpBidLotList?.[0]?.medicines == 4 || this.dtlPkgNoList?.bidpBidLotList?.[0]?.medicines == 5) {
                                                this.winMedicineKqm = this.winMedicineKqm.map(it => {
                                                    if (it.medicineType == undefined || it.medicineType == null) {
                                                        it.medicineType = goodsListMedicineKqm?.find(it => it.medicineType != undefined && it.medicineType != null)?.medicineType;
                                                    }
                                                    return it;
                                                })
                                                this.winMedicineKqmType0 = this.winMedicineKqm?.filter(it => it?.medicineType == 0);
                                                this.winMedicineKqmType1 = this.winMedicineKqm?.filter(it => it?.medicineType == 1);
                                            }
                                            this.falseMedicineKqm = goodsListMedicineKqm?.filter(lot => !lot?.winContractors?.length || lot?.falseContractors?.length > 0);
                                        }
                                    }
                                    this.lotListKH = res.data?.bidpBidLotList?.sort((a, b) => a.lotNo > b.lotNo ? 1 : -1);
                                }
                            }).catch(err => {
                                console.error("error load pkg detail response {} ", err);
                            })

                        });
                    });



                };
                this.dtlPkgBidEstimatePrice = bidEstimatePrice;
            },
            totalTableDa() {
                if (this.detailRes?.linkedPublishPlan) {
                    return this.detailRes.linkedPublishPlan.reduce(function (total, item) {
                        return total + item.totalBidPrice;
                    }, 0);
                }

            },
            clickViewDetail(notifyNo, selectedRole) {
                let url = "";
                if (this.processApply == 'LDT') {
                    url = this.kongUrl + '/contractorfe/bid-proposals/' + notifyNo + '?notifyType=TBMT&currentRole=' + selectedRole
                }else if (this.processApply == 'ADB' || this.processApply == 'WB') {
                    url = this.kongUrl + '/adbwbfe/bid-proposals-adb-wb/' + notifyNo + '?notifyType=TBMT&currentRole=' + selectedRole
                } else {
                    url = this.kongUrl + '/contractorfe/bid-proposals-other/' + notifyNo + '?notifyType=TBMT&currentRole=' + selectedRole

                }

                this.openUrl(url);

            },
            checkUserValidTbmt(createdBy) {
                if (createdBy) {
                    let arrCreatedBy = createdBy.split("-");
                    let userDTO = JSON.parse(localStorage.getItem('userDTO'));
                    if (userDTO) {
                        let orgCode = userDTO.orgCode;
                        return !(arrCreatedBy[0] == orgCode)
                    }
                    return true;
                }

                return true;

            },
            getNowDate() {
                let dt = new Date();
                const myTimeZone = 7;
                dt.setTime(dt.getTime() + myTimeZone * 60 * 60 * 1000);
                return dt.toISOString().replace('Z', '');
            },
            compareBidCloseDateIsClose(bidCloseDate) {
                return bidCloseDate > this.getNowDate();
            },

            // showHintFlow() {
            //     return Liferay.ThemeDisplay.isSignedIn() ? 'display: block;writing-mode: vertical-rl;' : 'display: none';
            // },
            openKHLCNT(planId, planNo) {
                window.open(`${this.detailUrl}&type=es-plan-project-p&stepCode=plan-step-1&id=${planId}&planNo=${planNo}`, '_self');
            },
            getDiffTimes(bidCloseDate) {
                let checkEn = this.checkIsEn();
                let results = 0 + ' ngày ' + 0 + ' giờ ' + 0 + ' phút';
                if (!bidCloseDate) {
                    results = 0 + ' ngày ' + 0 + ' giờ ' + 0 + ' phút';
                    return results;
                }
                let closeDate = new Date(bidCloseDate);
                let nowDate = new Date(this.countTime);

                /* get total seconds between the times */

                if (nowDate < closeDate) {
                    let delta = Math.abs(nowDate.getTime() - closeDate.getTime()) / 1000;
                    /* calculate  days */
                    const days = Math.floor(delta / 86400);
                    delta -= days * 86400;
                    /* calculate hours */
                    const hours = Math.floor(delta / 3600) % 24;
                    delta -= hours * 3600;
                    /* calculate minutes */
                    const minutes = Math.floor(delta / 60) % 60;
                    delta -= minutes * 60;
                    results = checkEn ? (days + ' days ' + hours + ' hours ' + minutes + ' minutes') : (days + ' ngày ' + hours + ' giờ ' + minutes + ' phút');
                } else {
                    results = checkEn ? '0 days 0 hours 0 minutes ' : ' 0 ngày 0 giờ 0 phút';

                }

                return results;
            },
            toUperCase(str) {
                return str ? str.toUpperCase() : '';
            },
            numToVND() {
                let t = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"],
                    r = function (r, n) {
                        let o = "", a = Math.floor(r / 10), e = r % 10;
                        return a > 1 ? (o = " " + t[a] + " mươi", 1 == e && (o += " mốt")) : 1 == a ? (o = " mười", 1 == e && (o += " một")) : n && e > 0 && (o = " lẻ"), 5 == e && a >= 1 ? o += " lăm" : 4 == e && a >= 1 ? o += " bốn" : (e > 1 || 1 == e && 0 == a) && (o += " " + t[e]), o
                    },
                    n = function (n, o) {
                        let a = "", e = Math.floor(n / 100);
                        n = n % 100;
                        return o || e > 0 ? (a = " " + t[e] + " trăm", a += r(n, !0)) : a = r(n, !1), a
                    }, o = function (t, r) {
                        let o = "", a = Math.floor(t / 1e6);
                        t = t % 1e6;
                        a > 0 && (o = n(a, r) + " triệu", r = !0);
                        let e = Math.floor(t / 1e3);
                        t = t % 1e3;
                        return e > 0 && (o += n(e, r) + " ngàn", r = !0), t > 0 && (o += n(t, r)), o
                    };
                return {
                    doc: function (r) {
                        if (0 == r) return t[0];
                        let n = "", a = "";
                        do {
                            let ty = r % 1e9;
                            r = Math.floor(r / 1e9);
                            n = r > 0 ? o(ty, !0) + a + n : o(ty, !1) + a + n, a = " tỷ";
                        }
                        while (r > 0);
                        let rs = n.trim();
                        return rs.charAt(0).toUpperCase() + rs.slice(1) + " đồng";
                    }
                }
            },

            hasJsonStructure(str) {
                if (typeof str !== 'string') return false;
                try {
                    const result = JSON.parse(str);
                    const type = Object.prototype.toString.call(result);
                    return type === '[object Object]'
                        || type === '[object Array]';
                } catch (err) {
                    return false;
                }
            },

            parseJsonToObject(value) {
                if (value && this.hasJsonStructure(value)) {
                    let obj = JSON.parse(value);
                    return obj
                }

            },
            getCompetentPersons(value) {
                if(value &&  this.hasJsonStructure(value)){
                    var arrVal = JSON.parse(value);
                    return arrVal.toString();
                }

            },
            isDisplayTechScore(){
                if(this.bidoNotifyView?.investField == 'TV'){
                    return true;
                }
                let dgvkt = this.dtlTdNs?.bidoInvBiddingDTO?.find(it => it.formCode == 'BD.CG.02.0104');
                if(!dgvkt){
                    return false;
                }
                try {
                    const formValue = JSON.parse(dgvkt.formValue);
                    return [1, '1'].includes(formValue?.evalTechnical);
                } catch (e){}
                return false;
            },
            // mapCPeriod(lotNo){
            //     let lot = this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.lotDTOList.find(it => it.lotNo == lotNo);
            //     if(lot && lot?.cperiodUnit){
            //         return lot?.cperiod + ' ' + this.getNameOfPeriod(lot?.cperiodUnit);
            //     }
            //     return '';
            // },
            mapCPeriod(contractorCode){
                let contractor = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.filter(it => it.contractorCode == contractorCode);
                if(contractor?.length > 0){
                    return contractor[0]?.contractPeriodDT != null ? (contractor[0]?.contractPeriodDT + ' ' + this.getNameOfPeriod(contractor[0]?.contractPeriodDTUnit)) : null;
                }
                return null;
            },
            // onClickViewGood(formCode, fileName) {
            //
            //     let url = this.urlContractorFe + "?type=HSDT" +
            //         "&lotNo=" + this.getLotNo() +
            //         "&contractorCode=" + this.getContractorCodeWinner() +
            //         "&viewMode=view" +
            //         "&formCode=" + formCode +
            //         "&fileName=" + fileName;
            //
            //     var popout = window.open(url);
            // },
            onClickViewGood(formCode, fileName,notifyNo,notifyVersion,goodsList) {
                formCode = this.MAP_FORM_CODE_HH_KQ[formCode];
                if(goodsList){
                    let findFormValue = JSON.parse(goodsList).filter(it => it.formCode == formCode && it.contractorCode == this.getContractorCodeWinner() ).map(it => it.formValue);

                    if (findFormValue.length > 0 ){
                        localStorage.setItem(formCode,JSON.stringify(findFormValue[0]));
                    } else {
                        localStorage.removeItem(formCode);
                    }
                }
                let url = this.urlContractorFe + "?type=KQLCNT" +
                    "&lotNo=" + this.getLotNo() +
                    "&contractorCode=" + this.getContractorCodeWinner() +
                    "&viewMode=view" +
                    "&formCode=" + formCode +
                    "&fileName=" + fileName +
                    "&notifyNo=" + notifyNo +
                    "&notifyVersion="+ notifyVersion;

                var popout = window.open(url);


                // if (this.dtlProcessApply && (this.dtlProcessApply === 'ADB' || this.dtlProcessApply === 'WB')) {
                //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode=ALL&fileName=Hồ sơ mời thầu&subCode=" + '';
                //     var popout = window.open(this.urlEdoc);
                //     // if ('C3' === itemDetail.pcode) {
                //     //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode=ALL&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code;
                //     //     var popout = window.open(this.urlEdoc);
                //     // } else if ('C7' === itemDetail.code
                //     //     && this.bidoNotifyView
                //     //     && (this.bidoNotifyView.investField == 'XL'
                //     //         || this.bidoNotifyView.investField == 'HH')) {
                //     //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode=ALL&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code + "&type=download";
                //     //     var popout = window.open(this.urlEdoc);
                //     //     window.setTimeout(function () {
                //     //         popout.close();
                //     //     }, 1000);
                //     // } else {
                //     //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode=ALL&fileName=" + this.convertName(chapterNames) + "&subCode=" + '';
                //     //     var popout = window.open(this.urlEdoc);
                //     // }
                // } else {
                //     this.urlEdoc = this.urlContractorFe + "?formCode=ALL&id="
                //         + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=Hồ sơ mời thầu";
                //     // this.urlEdoc = this.urlEdocTemp + "?formCode=" + itemDetail.code + "&id="
                //     //     + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=" + this.convertName(chapterNames);
                //     var popout = window.open(this.urlEdoc);
                // }

            },
            getNameByFormCode(formCode) {
                if (this.bidaInvChapterConfList) {
                    let list = this.bidaInvChapterConfList.filter(it => it.code == formCode);
                    if (list?.length > 0) {
                        return list[0].tempName;
                    } else {
                        return "";
                    }
                }
                return ""

            },
            getBidResultValid(arr) {
                return arr?.filter(it => it.bidResult == 1);
            },
            getBidResultInValid(arr) {
                return arr?.filter(it => it.bidResult == 0);
            },
            getBiResultWithMedical() {
                // this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[selectedValue]?.contractorList
                let list = [];
                if(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO.length > 0){
                    this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO.forEach((e,i)=>{
                        // list = list.concat(e?.contractorList);
                        let goodLists =[];
                        try {
                            goodLists = JSON.parse(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.[0]?.goodsList);
                        } catch (e){
                            console.error(e);
                        }
                        list = list.concat(this.convertArrayVenterName(e?.contractorList.map(item =>{
                            item.lotNo = e.lotNo;
                            item.lotName = e.lotName;
                            const mapLot = goodLists?.filter(lot => lot.lotNo == e.lotNo && lot.contractorCode == item.orgCode);
                            if(mapLot?.length > 0){
                                item.donGia = mapLot[0].donGia;
                                item.quantity = mapLot[0].quantity;
                                item.tienDo = mapLot[0].tienDo;
                                item.newContractorName = mapLot[0].newContractorName;
                            }
                            const mapMedicineType = goodLists?.find(lot => lot.lotNo == e.lotNo)?.medicineType
                            item.medicineType = mapMedicineType != undefined ? mapMedicineType : goodLists?.[0]?.medicineType;
                            return item;
                        })));
                    });
                }
                if(list.length > 0) list= list?.sort((a,b) => a?.data[0]?.lotNo?.localeCompare(b?.data[0]?.lotNo));
                return list;
            },
            convertArrayVenterName(arr) {

                let arrResponse = [];

                if (arr) {
                    for (let e of arr) {
                        if (e.ventureName && !this.checkObjectVentureCodeIncludesArray(arrResponse, e.ventureName)) {
                            arrResponse.push({
                                ventureName: e.ventureName,
                                contractorName: e.ventureName,
                                bidResult: e.bidResult,
                                data: arr?.filter(it => it.ventureName == e.ventureName)
                            })
                        } else if (!e.ventureName) {
                            arrResponse.push({
                                ventureName: null,
                                contractorName: e.contractorName,
                                bidResult: e.bidResult,
                                data: [e]
                            })
                        }

                    }

                    if(arrResponse.length > 0){
                        arrResponse = _.orderBy(arrResponse,['contractorName'],['asc']);
                    }
                }
                return arrResponse;
                // return arrResponse.filter(it => it.ventureName != null);

            },
            getOrgCodeFromVenture(arr){
                if(arr && arr.length > 0 ){
                    let code = arr?.find(it => it.role == 1)?.orgCode;
                    return code ? code : arr[0]?.orgCode ;
                }
                return '';
            }
            ,
            checkResultBid(bideContractorInputResultDTO) {

                let str = "Không có nhà thầu trúng thầu";
                if (bideContractorInputResultDTO) {
                    if (!((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO.isInternet == 1)) {
                        if (bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.contractorList.filter(it => it.bidResult != 0).length > 0) {
                            str = "Có nhà thầu trúng thầu";
                        } else {
                            str = "Không có nhà thầu trúng thầu";

                        }
                    }


                    if (((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO.isInternet == 1)
                        && this.getBidResultInValid(this.convertArrayVenterName(bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList))?.length > 0) {
                        str = "Không có nhà thầu trúng thầu";
                    }

                    if (((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO?.isInternet == 1)
                        && this.getBidResultValid(this.convertArrayVenterName(bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList))?.length > 0) {
                        str = "Có nhà thầu trúng thầu";
                    }
                    if (bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.contractorList.length == 0){
                        str = "Không có nhà thầu tham dự";
                    };
                }

                return str;
            },
            checkResultBidEn(bideContractorInputResultDTO) {
                const checkEn = this.checkIsEn();

                let str = "No winning contractors";
                if (bideContractorInputResultDTO) {
                    if (!((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO.isInternet == 1)) {
                        if (bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.contractorList.filter(it => it.bidResult != 0).length > 0) {
                            str = "Have the winning bidders";
                        } else {
                            str = "No winning contractors";

                        }
                    }


                    if (((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO.isInternet == 1)
                        && this.getBidResultInValid(this.convertArrayVenterName(bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList))?.length > 0) {
                        str = "No winning contractors";
                    }

                    if (((this.processApply == 'LDT' || this.processApply == 'KHAC') && bideContractorInputResultDTO?.isInternet == 1)
                        && this.getBidResultValid(this.convertArrayVenterName(bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList))?.length > 0) {
                        str = "Have the winning bidders";
                    }
                    if (bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.contractorList.length == 0){
                        str = "No winning contractors";
                    };
                }

                return str;
            },

            checkBidderDKQ(obj) {
                // xử lý data cũ
                if(obj?.status == 0 || obj?.status == 1 || obj?.status == 3) return 'Đã có kết quả';
                if(obj?.status == 2 ) return 'Chưa có kết quả';


                return obj.contractorList.length > 0 ? ((this.getBidResultValid(this.convertArrayVenterName(obj?.contractorList))?.length + this.getBidResultInValid(this.convertArrayVenterName(obj?.contractorList))?.length > 0)  ? 'Đã có kết quả' : 'Chưa có kết quả') :  'Đã có kết quả';
                // return ((obj.status == 1 && obj.contractorList.length > 0) || (obj.status == 0 && obj.reason)) ? 'Đã có kết quả' : 'Không có kết quả';
            },
            getlotResultDTONoContractJoin(listLostResult){
                return listLostResult.filter(e => e?.contractorList?.length == 0);
            },
            checkResultLot(lot){
                // xử lý data cũ
                if(lot?.status == 0) return 'Không có nhà thầu trúng thầu';
                if(lot?.status == 1) return 'Có nhà thầu trúng thầu';
                if(lot?.status == 2) return '';
                if(lot?.status == 3) return 'Không có nhà thầu tham dự';

                if(lot?.contractorList?.length == 0) return 'Không có nhà thầu tham dự';
                if (this.getBidResultValid(this.convertArrayVenterName(lot?.contractorList))?.length > 0) {
                    return "Có nhà thầu trúng thầu";
                }
                return "Không có nhà thầu trúng thầu"
            },

            pagingGoodList(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlist - 1) * this.pageSizeGood, this.currentPageGoodlist * this.pageSizeGood)
                }
                return [];

            },

            pagingGoodListV2(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistV2 - 1) * this.pageSizeGood, this.currentPageGoodlistV2 * this.pageSizeGood)
                }
                return [];

            },

            changePageGood(page) {

                this.currentPageGoodlist = page;

            },
            changePageGoodV2(page) {

                this.currentPageGoodlistV2 = page;

            },
            pagingGoodsListMedicineKqm(goodList,currentPage){
                if (goodList) {
                    return goodList.slice((currentPage - 1) * this.pageSizeMedicineKqm, currentPage * this.pageSizeMedicineKqm)
                }
                return [];
            },
            changeGoodsListMedicineKqm(page){
                this.currentPageWinMedicineKqm = page;
            },
            changeGoodsListMedicineKqmType1(page){
                this.currentPageWinMedicineKqmType1 = page;
            },
            changeFalseGoodsListMedicineKqm(page){
                this.currentPageFalseMedicineKqm = page;
            },

            getQuantityBidderValid(arr) {
                return arr?.filter(it => it.result == 2);
            },
            removeDuplicateObjectInArray(arr, key) {
                if (arr)
                    return [...new Map(arr.map(item => [item[key], item])).values()]
                return []
            },
            getQuantityBidderValidKqlcnt() {
                if (this.processApply == 'ADB' || this.processApply == 'WB') {
                    return this.getQuantityBidderValid(this.removeDuplicateObjectInArray(this.dtlBidoBidNotifyRes.lsBideLotEvalResultViewDTO, 'contractorCode')).length;
                } else {
                    return 'Chưa có lsBideLotEvalResultViewDTO đâu';
                }
            },
            changeTag(tab) {
                this.selectedTab = tab;
                if (this.processApply != 'KHAC' && tab == 'kqlcnt') {
                    if(!this.dtlKqlcnt) {
                        this.loadDetailKqlcntLdt();
                    }
                }
            },
            changeTagV2(tab) {
                this.selectedTabV2 = tab;
            }
            ,
            checkConditionKqlcnt(stepCode) {
                return stepCode == 'notify-contractor-step-4-kqlcnt';
            },
            checkConditionDsntdkt(stepCode, isInternet) {

                return (stepCode == 'notify-contractor-step-3-dsntdkt' || stepCode == 'notify-contractor-step-4-kqlcnt') && this.techReqId != 'undefined' && isInternet;
            },
            checkConditionBbmt(stepCode, isInternet) {

                return (stepCode == 'notify-contractor-step-2-kqmt'
                    || stepCode == 'notify-contractor-step-3-dsntdkt'
                    || stepCode == 'notify-contractor-step-4-kqlcnt') && this.bidMode == '1_MTHS' && isInternet;
            },
            checkConditionBbmtDkKt(stepCode, isInternet) {

                return (stepCode == 'notify-contractor-step-2-kqmt'
                        || stepCode == 'notify-contractor-step-3-dsntdkt'
                        || stepCode == 'notify-contractor-step-4-kqlcnt')
                    && (this.processApply == 'LDT' || this.processApply == 'CPTPP' || this.processApply == 'KHAC') && this.bidMode == '1_HTHS' && isInternet;
            },
            checkConditionBbmtDxTc(stepCode, bidMode, bidStatus, isInternet) {


                return (stepCode == 'notify-contractor-step-2-kqmt'
                        || stepCode == 'notify-contractor-step-3-dsntdkt'
                        || stepCode == 'notify-contractor-step-4-kqlcnt')
                    && (this.processApply == 'LDT' || this.processApply == 'CPTPP' || this.processApply == 'KHAC') && this.bidMode == '1_HTHS'
                    && (bidStatus == 'PUB_KQLCNT' || bidStatus == 'OPEN_DXTC' || (bidStatus == 'CANCEL_BID' && stepCode == 'notify-contractor-step-4-kqlcnt')) && isInternet;
            },

            //ADB,WB,VK dùng chung API version tbmt,kqmt
            loadDetail() {
                switch (this.stepCode) {
                    case "project-step-1":
                        this.loadDetailDadtpt();
                        this.loadListVerDadtpt();
                        break;
                    case "plan-step-1":
                        this.loadDetailKhLcnt();
                        this.loadListVerKhlcnt();
                        break;
                    case "notify-contractor-step-1-tbmt":
                        this.functionCode = this.notifyNo;
                        if (this.processApply == 'KHAC') {
                            this.loadDetailTbmtVk();
                            this.loadListVersionTbmtVk();
                        }  else if(this.processApply == 'ADB' || this.processApply == 'WB'){
                            this.loadDetailTbmtAdbWb();
                            this.loadListVersionTbmtVk();
                        }
                        else {
                            this.loadDetailTbmtLdt();
                            this.loadListVersionTbmtLdt();
                            this.loadDetailReoffer();
                        }
                        break;
                    case "notify-contractor-step-2-kqmt":
                        if (this.processApply == 'KHAC') {
                            this.loadDetailTbmtVk();
                            this.loadListVersionTbmtVk();
                            this.loadDetailKqmtVk();
                        } else if(this.processApply == 'ADB' || this.processApply == 'WB'){
                            this.loadDetailTbmtAdbWb();
                            this.loadListVersionTbmtVk();
                            this.loadDetailKqmtAdbWb();
                        } else {
                            this.loadDetailTbmtLdt();
                            this.loadDetailKqmtLdt();
                            this.loadListVersionTbmtLdt();
                            this.loadDetailReoffer();
                        }
                        break;
                    case "notify-contractor-step-3-dsntdkt":
                        if (this.processApply == 'KHAC') {
                            this.loadDetailTbmtVk();
                            this.loadDetailKqmtVk();
                            this.loadDetailDsntdktVk();
                            this.loadListVersionTbmtVk();

                        } else {
                            this.loadDetailTbmtLdt();
                            this.loadDetailKqmtLdt();
                            this.loadDetailDsntdktLdt();
                            this.loadListVersionTbmtLdt();
                            this.loadDetailReoffer();
                        }
                        break;
                    case "notify-contractor-step-4-kqlcnt":
                        if (this.processApply == 'KHAC') {
                            this.loadDetailTbmtVk();
                            this.loadDetailKqmtVk();
                            this.loadDetailDsntdktVk();
                            this.loadDetailKqlcntVk();
                            this.loadListVersionTbmtVk();
                        } else if(this.processApply == 'ADB' || this.processApply == 'WB'){
                            this.loadDetailTbmtAdbWb();
                            this.loadListVersionTbmtVk();
                            this.loadDetailKqmtAdbWb();
                            this.loadDetailKqlcntLdt();
                            this.loadListVersionTbmtVk();
                        } else {
                            this.loadDetailTbmtLdt();
                            this.loadDetailKqmtLdt();
                            this.loadDetailDsntdktLdt();
                            this.loadDetailKqlcntLdt();
                            this.loadListVersionTbmtLdt();
                            this.loadDetailReoffer();
                        }
                        break;
                    case "pre-notify-contractor-step-1-tbmst":
                        this.loadDetailTbmst();
                        this.loadListVerTbmst();
                        break;
                    case "pre-notify-contractor-step-2-kqmst":
                        this.loadDetailTbmst();
                        this.loadListVerTbmst();
                        this.loadDetailKqmst();
                        break;
                    case "pre-notify-contractor-step-3-kqst":
                        this.loadDetailTbmst();
                        this.loadListVerTbmst();
                        this.loadDetailKqmst();
                        this.loadDetailKqst();
                        this.loadListVerKqst();
                        break;
                    case "short-list-detail":
                        this.loadShortListDetail('first');
                        break;
                    case "pre-notify-contractor-step-4-kqlcnt":
                        this.loadDetailTbmst();
                        this.loadListVerTbmst();
                        this.loadDetailKqst();
                        this.loadListVerKqst();
                        this.loadDetailKqlcntLdt();
                        break;
                }
            },
            filterFormValueAttrFileBmMST(value, formCode) {
                const formValue = value && value.length > 0 ? value?.filter(x => x.formCode === formCode).map(x => x.formValue) : [];
                return formValue;
            },
            loadDetailTbmst() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(this.urlDetailTbst+"?token="+token, {id: this.notifyId}).then(res => {


                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlPreNotiContractRes = res.data;
                                this.dtlTdNs = res.data;
                                this.bidoNotifyViewTBST.bidForm = this.dtlPreNotiContractRes?.bidForm;
                                if (this.dtlPreNotiContractRes.bidaInvChapterConfList && this.dtlPreNotiContractRes.bidaInvChapterConfList.length > 0) {
                                    if (this.dtlPreNotiContractRes?.bidForm == 'CHCTRG') {
                                        this.chapterTreesCHCTRG = this.getListChapterCHCTRG(this.dtlPreNotiContractRes.bidaInvChapterConfList);
                                    } else {
                                        this.chapterTrees = this.getListChapter(this.dtlPreNotiContractRes.bidaInvChapterConfList);
                                    }
                                    this.sortParentList();
                                }
                                if (this.bidoNotifyViewTBST !== null) {
                                }
                            }
                        })

                    });
                });

            },
            loadShortListVersion() {

                axios.post(this.urlListVerDsndthc, {shortListNo: this.detailEbidShortList?.shortListNo}).then(res => {
                    this.versionListDSN = res?.data?.versionList;
                })


            },
            loadShortListDetail(type) {
                if(type == 'first'){

                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {
                            axios.post(this.urlDetailDsndthc+"?token="+token, {id: this.id}).then(res => {


                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.detailEbidShortList = res.data;
                                    this.loadShortListVersion();
                                }
                            });

                        });
                    });

                    // this.idDSN = this.id;

                } else {
                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {

                            axios.post(this.urlDetailDsndthc+"?token="+token, {id: this.id}).then(res => {

                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else{
                                    this.detailEbidShortList = res.data;}
                            });
                        });
                    });


                }

            },
            renderUrlDetailShortList(id) {
                window.open(`${this.detailUrl}&type=es-plan-p-contractor-shortlist-p&stepCode=short-list-detail&id=${id}`, '_blank');
            },
            convertJson(value) {
                if (value) {
                    let lstContract = JSON.parse(value);
                    lstContract = lstContract ? lstContract : [];
                    let lst = this.convertArrayVenterNameForDSN(lstContract);
                    return lst;
                }
            },
            convertArrayVenterNameForDSN(arr) {

                let arrResponse = [];
                for (let e of arr) {
                    if (e.partnership && !this.checkObjectVentureCodeIncludesArrayDSN(arrResponse, e.partnership)) {
                        arrResponse.push({
                            partnership: e.partnership,
                            data: arr?.filter(it => it.partnership == e.partnership)
                        })
                    } else if (!e.partnership) {
                        arrResponse.push({
                            partnership: null,
                            data: [e]
                        })
                    }
                }
                return arrResponse;
                // return arrResponse.filter(it => it.ventureName != null);

            },
            loadListVerTbmst() {


                axios.post(this.urlListVerTbst, {notifyNo: this.notifyNo}).then(res => {
                    this.versionList = this.sortListVersion(res.data.versionList);
                })
            },

            loadListVerKqst() {
                axios.post(this.urlListVerKqst, {notifyNo: this.notifyNo}).then(res => {
                    this.versionListKQST = this.sortListVersion(res.data.versionList);
                })
            },

            loadDetailKqmst() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(this.urlDetailKqmst+"?token="+token, {notifyNo: this.notifyNo}).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlKqmst = res.data;
                            }
                        })

                    });
                });


            },
            checkObjectVentureCodeIncludesInArray(arr, ventureCode) {
                return arr.map(it => it.ventureCode).includes(ventureCode);
            },
            getPartnerVentureContractorList(list) {
                let arrResponse = [];
                if (list){
                    for (let e of list) {
                        if (e.ventureCode && !this.checkObjectVentureCodeIncludesInArray(arrResponse, e.ventureCode)) {
                            arrResponse.push({
                                ventureCode: e.ventureCode,
                                data: list?.filter(it => it.ventureCode == e.ventureCode)
                            })
                        } else if (!e.ventureCode) {
                            arrResponse.push({
                                ventureCode: null,
                                data: [e]
                            })
                        }

                    }
                }
                return arrResponse;

            },

            loadDetailKqst() {
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(this.urlDetailKqst+"?token="+token, {id: this.bidPreNotifyResultId}).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlNotifyContractRltRes = res.data;
                            }
                        })
                    });
                });


            },

            sortListVersion(arr) {
                return arr?.sort((a, b) => (a.notifyVersion > b.notifyVersion) ? 1 : -1);

            },


            sortListVersionKH(arr) {
                return arr?.sort((a, b) => (a.planVersion > b.planVersion) ? 1 : -1);

            },

            openUrl(url) {
                window.open(url, '_blank');
            },

            onChangeVersion() {
                this.loadDetail();
            },

            getListContractorList(list) {


                let data = [];
                if (list?.lotResultDTO) {
                    list.lotResultDTO.forEach((it, idx) => {

                        if (idx == this.selectedValueLot) {
                            data.push(...JSON.parse(it.contractorList));
                        }
                    })
                    return data;
                } else {
                    return [];
                }


            },

            getPartnerShipContractorList(list) {
                let arr = this.getListContractorList(list);
                let arrResponse = [];

                for (let e of arr) {
                    if (e.partnership && !this.checkObjectParnerShipIncludesArray(arrResponse, e.partnership)) {
                        arrResponse.push({
                            partnership: e.partnership,
                            data: arr?.filter(it => it.partnership == e.partnership)
                        })
                    } else if (!e.partnership) {
                        arrResponse.push({
                            partnership: null,
                            data: [e]
                        })
                    }

                }
                return arrResponse;

            },


            loadDetailDadtpt() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlDetailDadtpt+"?token="+token, {id: this.id}
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else{
                                this.detailRes = response.data;
                                this.functionName = response.data?.name;
                                this.functionCode = response.data?.pno;
                                this.detailRes.linkedPublishPlan = this.detailRes?.linkedPublishPlan.concat(response.data?.bidpProjectProjectPlanList?.map(item =>
                                {
                                    item.investTotal = item.planBidTotal;
                                    item.totalBidPrice = item.planBidTotal;
                                    item.investTotalUnit = item.planBidTotalUnit || 'VND';
                                    item.name = item.planName;
                                    return item;
                                }))
                            }}
                        );
                    });
                });


            },
            loadListVerDadtpt() {
                axios.post(
                    this.urlListVerDadtpt, {pno: this.pno}
                ).then(response => {
                        this.versionList = this.sortListVersion(response.data.versionList);
                    }
                );
            },
            loadDetailKhLcnt() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlDetailKhlcnt+"?token="+token, {id: this.id}
                        ).then(res => {

                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.detailKhlcntRes = res.data;


                                    if (!this.detailKhlcntRes.bidpPlanDetailToProjectList
                                        || this.detailKhlcntRes.bidpPlanDetailToProjectList.length == 0) {
                                        this.detailKhlcntRes.bidpPlanDetailToProjectList = [{
                                            bidPrice: 0,
                                            bidPriceUnit: "VND",
                                        }]
                                    }
                                    if (!this.detailKhlcntRes.bidPoBidpPlanProjectDetailView) {
                                        this.detailKhlcntRes.bidPoBidpPlanProjectDetailView = {
                                            publicDate: new Date()
                                        }
                                    }

                                    this.planTypeForKhlcnt = this.detailKhlcntRes.bidPoBidpPlanProjectDetailView.planType;
                                    this.functionName = res.data?.bidPoBidpPlanProjectDetailView?.name;
                                    this.functionCode = res.data?.bidPoBidpPlanProjectDetailView?.planNo;

                                }
                            }
                        );

                    });
                });



            },
            loadListVerKhlcnt() {
                axios.post(
                    this.urlListVerKhlcnt, {planNo: this.planNo}
                ).then(response => {
                        this.versionList = this.sortListVersionKH(response.data.versionList);

                    }
                );
            },
            loadDetailBidForKhlcnt() {
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlDetailBidKhlcnt+"?token="+token, {id: this.id}
                        ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.detailDsntdkt = response.data;
                                }
                            }
                        );

                    });
                });


            },
            loadDetailDsndthc() {
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlDetailDsndthc+"?token="+token, {id: this.id}
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else{
                                this.detailDsntdkt = response.data;

                            }}
                        );
                    });
                });


            },
            loadListVerDsndthc() {


                axios.post(
                    this.urlListVerDsndthc, {id: this.id}
                ).then(response => {
                        this.detailDsntdkt = response.data;

                    }
                );



            },
            loadDetailDsntdktVk() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {


                        axios.post(
                            this.urlDetailDsntdktVk+"?token="+token, {id: this.techReqId}
                        ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.detailDsntdkt = response.data;
                                    this.listContractor = JSON.parse(response.data?.bidrBidOpenTechResultOutDTO?.contractorList || '[]');
                                    if (this.listContractor?.length > 0) {
                                        this.listContractor = _.orderBy(this.listContractor, ['contractorName'], ['asc'])
                                    }
                                }
                            }
                        );
                    });
                });

            },
            loadDetailDsntdktLdt() {
                if (this.techReqId) {

                    grecaptcha.ready(res => {
                        grecaptcha.execute(this.siteKey,
                            {action: 'submit'}).then(token => {

                            axios.post(
                                this.urlDetailDsntdktLdt+"?token="+token, {id: this.techReqId}
                            ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else{
                                    this.dtlBidoBidNotifyRes = response.data;
                                    this.dtlListContractor = this.dtlBidoBidNotifyRes?.lsBideLotEvalResultViewDTO?.filter(e => e.result === '2' || e.result === '0');
                                    this.dtlWinningContractor = this.dtlListContractor?.filter(e => e.evalType == 3 && e.result === '2');
                                    if(this.dtlWinningContractor?.length > 0) {
                                        this.dtlWinningContractor = _.orderBy(this.dtlWinningContractor, ['contractorName'], ['asc']);
                                    }
                                    this.dtlFalseContractor = this.parseFailKTList(this.dtlListContractor?.filter(e => e.result === '0'));
                                    if(this.dtlFalseContractor?.length > 0) {
                                        this.dtlFalseContractor = _.orderBy(this.dtlFalseContractor, ['contractorName'], ['asc']);
                                    }
                                    this.dtlBidoBidNotifyRes?.bidoLotOpenDetails?.forEach(e => {
                                        e.cperiod = this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.lotDTOList?.filter(e1 => e?.lotNo === e1?.lotNo)[0]?.cperiod;
                                        e.cperiodUnit = this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.lotDTOList?.filter(e1 => e?.lotNo === e1?.lotNo)[0]?.cperiodUnit;
                                    });
                                    this.dtlWinningContractorMedicine = this.dtlBidoBidNotifyRes?.bidoLotOpenDetails?.filter(e => 'Y' === e.passedYn);
                                    if(this.dtlWinningContractorMedicine?.length > 0){
                                        this.dtlWinningContractorMedicine = _.orderBy(this.dtlWinningContractorMedicine,['contractorName'],['asc'])
                                    }
                                    this.dtlFalseContractorMedicine = this.dtlBidoBidNotifyRes?.bidoLotOpenDetails?.filter(e => 'Y' !== e.passedYn);
                                    if(this.dtlFalseContractorMedicine?.length > 0){
                                        this.dtlFalseContractorMedicine = _.orderBy(this.dtlFalseContractorMedicine,['contractorName'],['asc'])
                                    }

                                    this.winningContractorMultiLot = this.dtlBidoBidNotifyRes?.bidoLotOpenDetails?.filter(e => 'Y' === e.passedYn);
                                    let listCtWinMultilot = [];
                                    this.winningContractorMultiLot?.forEach(it => {
                                        if(!listCtWinMultilot.includes(it?.contractorCode)){
                                            listCtWinMultilot.push(it?.contractorCode)
                                        }
                                    })
                                    this.totalCtWinning = listCtWinMultilot.length;
                                    this.falseContractorMultiLot = this.dtlBidoBidNotifyRes?.bidoLotOpenDetails?.filter(e => 'Y' !== e.passedYn);
                                    this.winningContractorMultiLotGroupNT = _(this.winningContractorMultiLot).groupBy('contractorCode').map((items, subject) => {
                                        return {items};
                                    }).value();
                                    this.winningContractorMultiLotGroupLo = _(this.winningContractorMultiLot).groupBy('lotNo').map((items, subject) => {
                                        return {items};
                                    }).value();
                                    this.winningContractorMultiLotGroupLo.forEach( f => {
                                        if(f?.items?.length > 0) {
                                            f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                        }
                                    })
                                    this.falseContractorMultiLotGroupNT = _(this.falseContractorMultiLot).groupBy('contractorCode').map((items, subject) => {
                                        return {items};
                                    }).value();
                                    this.falseContractorMultiLotGroupLo = _(this.falseContractorMultiLot).groupBy('lotNo').map((items, subject) => {
                                        return {items};
                                    }).value();
                                    this.falseContractorMultiLotGroupLo.forEach( f => {
                                        if (f?.items?.length > 0) {
                                            f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                        }
                                    })

                                }}
                            );
                        });
                    });


                }

            },
            loadDetailKqlcntVk() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {


                        axios.post(
                            this.urlDetailKqlcntVk+"?token="+token, {id: this.inputResultId}
                        ).then(response => {

                                if (typeof response.data == 'number') {
                                    this.popupSpinning()
                                } else {
                                    // this.dtlKqlcntRes = res.data;
                                    this.dtlKqlcntRes = response.data.bidoNotifyContractorOutMDTO;
                                    this.dtlKqlcnt = response.data;

                                    let contractorWinner = this.getContractorCodeWinner();
                                    if (contractorWinner) {
                                        this.getBidaInvChapterConfs(
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidField,
                                            "HSDT",
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidForm,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidMode,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.ctype,
                                            this.processApply);


                                        this.getOpenGoodsGet(this.getLotNo(), contractorWinner)
                                    }
                                }
                            }
                        );
                    });
                });


            },
            getContractorCodeWinner() {
                if (((this.processApply == 'LDT' || this.processApply == 'KHAC')
                    && this.dtlKqlcnt.bideContractorInputResultDTO?.isInternet == 1)) {
                    let contractorList = this.dtlKqlcnt.bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList?.filter(it => it.bidResult == 1);
                    if (contractorList?.length > 0) {
                        if (contractorList.length > 1) {
                            return contractorList.filter(it => it.role == 1)?.orgCode;

                        } else {
                            return contractorList[0]?.orgCode;

                        }
                    }
                } else {
                    let contractorList = this.dtlKqlcnt.bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList?.filter(it => it.bidResult == 1);

                    if (contractorList?.length > 0) {
                        if (contractorList.length > 1) {
                            return contractorList[0]?.orgCode;
                        } else {
                            return contractorList.filter(it => it.role == 1)[0]?.orgCode;
                        }
                    }

                }


            },
            loadDetailKqlcntLdt() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        this.isLoadKqlcnt = true;
                        axios.post(
                            this.urlDetailKqlcntLdt+"?token="+token, {id: this.inputResultId}
                        ).then(response => {
                                // this.detailKqlcnt = response.data;

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.isLoadKqlcnt = false;
                                    this.dtlKqlcnt = response.data;
                                    this.isNoInternetAndNoDometic = this.checkNoInternetAndNoDometic(this.dtlKqlcnt?.bideContractorInputResultDTO);
                                    let goodListEn = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.find(it => it.goodsListEn && it.goodsListEn != '[]');
                                    let goodListVi = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.find(it => it.goodsList && it.goodsList != '[]');
                                    this.isHaveBidPriceDetailOfContractor = this.checkHaveBidPriceDetailOfContractor(this.getBidResultValid(this.convertArrayVenterName(goodListVi?.contractorList)), this.isNoInternetAndNoDometic);
                                    if (this.dtlKqlcnt?.bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.goodsList) {
                                        this.isHaveBidPriceDetailOfGoods = this.checkHaveBidPriceDetailOfGoods(JSON.parse(goodListVi?.goodsList || '[]'), this.isNoInternetAndNoDometic);
                                    }
                                    if (this.dtlKqlcnt?.bideContractorInputResultDTO.lotResultDTO[this.selectedValue]?.goodsListEn) {
                                        this.isHaveBidPriceDetailOfGoodsEn = this.checkHaveBidPriceDetailOfGoods(JSON.parse(goodListEn?.goodsListEn || '[]'), this.isNoInternetAndNoDometic);
                                    }
                                    if (this.dtlKqlcnt.bidpPlanDetailDTO?.bidPriceDetail) {
                                        this.isHaveManyCurrency = this.checkHaveManyCurrency(JSON.parse(this.dtlKqlcnt.bidpPlanDetailDTO?.bidPriceDetail));
                                    }
                                    let contractorWinner = this.getContractorCodeWinner();
                                    if (contractorWinner) {
                                        this.getBidaInvChapterConfs(
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidField,
                                            "HSDT",
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidForm,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidMode,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.ctype,
                                            this.processApply);


                                        this.getOpenGoodsGet(this.getLotNo(), contractorWinner)
                                    }
                                    //Lấy danh sách hàng hóa
                                    if (this.dtlKqlcnt?.bideContractorInputResultDTO?.bidField == 'HH') {
                                        let resultLot = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.find(it => it?.goodsList);
                                        try {
                                            this.listMedicineQM = JSON.parse(resultLot?.goodsList || '[]').map(it => {
                                                if (it.contractorCode == null) {
                                                    it.uom = null;
                                                }
                                                return it;
                                            });
                                        } catch (e) {
                                        }
                                        if (this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 4 || this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5) {
                                            this.listMedicineQM = this.listMedicineQM.map(it => {
                                                if (it.medicineType == undefined || it.medicineType == null) {
                                                    it.medicineType = this.listMedicineQM?.find(it => it.medicineType == undefined && it.medicineType != null)?.medicineType;
                                                }
                                                return it;
                                            })
                                            this.listMedicineQMType1 = this.listMedicineQM?.filter(it => it.medicineType == 1);
                                            this.listMedicineQMType0 = this.listMedicineQM?.filter(it => it.medicineType == 0);
                                        }
                                        this.dsHhKq = JSON.parse(resultLot?.goodsList || '[]');
                                        this.dsHhKqForNN = JSON.parse(resultLot?.goodsList || '[]');
                                        if (!Array.isArray(this.dsHhKq)) {
                                            this.dsHhKq = this.dsHhKq?.dsHhKq;
                                            this.dsHhKqForNN = this.dsHhKqForNN?.dsHhKq
                                        }
                                        this.noOpenLot = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.filter(e => e?.contractorList?.length == 0);
                                        // this.dsHhKq = JSON.parse(this.contractorInputResult.lotResultDTO[0]?.goodsList || '[]');


                                        if (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1) {
                                            if (this.isBDL12_2()) {
                                                const hh12A = this.dsHhKq?.filter(e => e.dsHH?.some(h => false === h.keKhai12b && e.contractorCode));
                                                this.hhCollection = hh12A
                                                    ?.map(e => {
                                                        e.dsHH = e.dsHH.filter(h => !this.stringNullOrEmpty(h.keKhai12b) && !h.keKhai12b);
                                                        return e;
                                                    });
                                                this.hhCollection?.map(e => {
                                                    e.dsHH?.map(h => {
                                                        if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                                            h.bidItem = h.name;
                                                        }
                                                    });
                                                });
                                                // ?.map((item, i) => ({index: i, item}));
                                                //     ?.slice((this.hhPage - 1) * this.formPageSize, (this.hhPage - 1) * this.formPageSize + this.formPageSize);

                                                const hh12B = this.dsHhKqForNN?.filter(e => e.dsHH?.some(h => true === h.keKhai12b || this.stringNullOrEmpty(h.keKhai12b) && e.contractorCode));
                                                this.hh12BCollection = hh12B
                                                    ?.map(e => {
                                                        e.dsHH = e.dsHH.filter(h => h.keKhai12b || this.stringNullOrEmpty(h.keKhai12b));
                                                        return e;
                                                    });
                                                this.hh12BCollection?.map(e => {
                                                    e.dsHH?.map(h => {
                                                        if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                                            h.bidItem = h.name;
                                                        }
                                                    });
                                                });
                                                // ?.map((item, i) => ({index: i, item}));
                                                // ?.slice((this.hh12BPage - 1) * this.formPageSize, (this.hh12BPage - 1) * this.formPageSize + this.formPageSize);
                                            } else {
                                                this.hhCollection = this.dsHhKq?.filter(e => e.contractorCode);
                                                this.hhCollection?.map(e => {
                                                    e.dsHH?.map(h => {
                                                        if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                                            h.bidItem = h.name;
                                                        }
                                                    });
                                                });
                                            }
                                            if (this.isDVLQ()) {
                                                const goods = JSON.parse(resultLot?.goodsList || '[]');
                                                this.dvlqCollection = goods?.dsDvlqKq?.filter(it => it.contractorCode);
                                            }
                                        }
                                        ;
                                    }
                                    if (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMedicine == 1 && this.dtlKqlcnt?.bideContractorInputResultDTO?.isInternet == 1) {
                                        this.listInternetMedicineNoCt = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.filter(lot => lot.isInLotOpenDetail == 0)
                                    }
                                    this.listNotPassKT = [];
                                    this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.forEach(item => this.listNotPassKT = this.listNotPassKT.concat(item.listNotPassKT))
                                    this.listNotPassKT = this.listNotPassKT?.sort((a, b) => a?.lotNo?.localeCompare(b?.lotNo) || a?.contractorCode?.localeCompare(b?.contractorCode));
                                    if (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMedicine == 1 && this.dtlKqlcnt?.bideContractorInputResultDTO?.isInternet == 0) {
                                        let lotResultMedicineKqm = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.find(it => it?.goodsList?.length > 0);
                                        if (lotResultMedicineKqm) {
                                            let goodsListMedicineKqm = JSON.parse(lotResultMedicineKqm?.goodsList || '[]');
                                            this.winMedicineKqm = goodsListMedicineKqm?.filter(lot => lot?.winContractors?.length > 0);
                                            if (this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 4 || this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5) {
                                                this.winMedicineKqm = this.winMedicineKqm.map(it => {
                                                    if (it.medicineType == undefined || it.medicineType == null) {
                                                        it.medicineType = goodsListMedicineKqm?.find(it => it.medicineType != undefined && it.medicineType != null)?.medicineType;
                                                    }
                                                    return it;
                                                })
                                                this.winMedicineKqmType0 = this.winMedicineKqm?.filter(it => it?.medicineType == 0);
                                                this.winMedicineKqmType1 = this.winMedicineKqm?.filter(it => it?.medicineType == 1);
                                            }
                                            this.falseMedicineKqm = goodsListMedicineKqm?.filter(lot => !lot?.winContractors?.length || lot?.falseContractors?.length > 0);
                                        }
                                    }

                                    // adb-wb
                                    if (this.processApply == 'ADB' || this.processApply == 'WB') {
                                        let winningCode = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[0]?.winningCode;
                                        let goodsListAdb = JSON.parse(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[0].goodsList || '[]');
                                        if (winningCode) {
                                            this.goodsListAdb = goodsListAdb.find(it => it.contractorCode == winningCode && it.formCode == 'BD.MT.02.1309')?.formValue?.lotContent?.Table;
                                            this.serviceListAdb = goodsListAdb.find(it => it.contractorCode == winningCode && it.formCode == 'BD.MT.02.1311')?.formValue?.lotContent?.Table;
                                        }
                                    }
                                    if (this.processApply == 'LDT' && (this.dtlKqlcnt?.bideContractorInputResultDTO?.bidField == 'TV' || this.dtlKqlcnt?.bideContractorInputResultDTO?.bidField == 'PTV')) {
                                        let goodList = JSON.parse(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[0]?.goodsList || '[]');
                                        let serviceDg = JSON.parse(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[0]?.serviceDg || '[]');
                                        this.listServiceTG = goodList?.listTG?.filter(it => it.orgCode == contractorWinner);
                                        this.listServiceDCCD = serviceDg?.listTG?.filter(it => it.orgCode == contractorWinner);
                                        this.listServiceTG_1 = goodList?.listDG?.filter(it => it.orgCode == contractorWinner);
                                        this.listServiceDCCD_1 = serviceDg?.listDG?.filter(it => it.orgCode == contractorWinner);
                                    }
                                }
                            }
                        ).catch(err => {
                            this.isLoadKqlcnt = false;
                        });

                    });
                });


            },
            getDanhSachHangHoa() {
                let contractorWinner = this.getContractorCodeWinner();
                //Lấy danh sách hàng hóa
                if (this.dtlKqlcnt?.bideContractorInputResultDTO?.bidField == 'HH') {
                    let resultLot = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.find(it => it?.goodsList);
                    this.dsHhKq = JSON.parse(resultLot?.goodsList || '[]');
                    this.dsHhKqForNN = JSON.parse(resultLot?.goodsList || '[]');
                    this.noOpenLot = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.filter(e => e?.contractorList?.length == 0);
                    // this.dsHhKq = JSON.parse(this.contractorInputResult.lotResultDTO[0]?.goodsList || '[]');
                    if (!Array.isArray(this.dsHhKq)){
                        this.dsHhKq = this.dsHhKq?.dsHhKq;
                        this.dsHhKqForNN = this.dsHhKqForNN?.dsHhKq
                    }


                    if (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot != 1) {
                        if( this.dsHhKq.length == 0){

                            this.dsHhKq = this.openGoodsList?.map(e =>{
                                e.formCode = this.MAP_FORM_CODE_HH_KQ[e.formCode];
                                e.formValue = JSON.parse(e.formValue);
                                return e;
                            });
                        }
                        if (this.isBDL12_2()) {
                            this.hhCollection = this.dsHhKq?.filter(e => (e.formCode == "BD.MT.02.1255" || e.formCode == "BD.MT.02.1257") && e.contractorCode == contractorWinner);
                            this.hhCollection?.map((hangHoa,indexHangHoa)=> {
                                this.currentPageGoodlistOfNoLot12_2A[indexHangHoa] = 1;
                                this.totalCost12_2AKhongLo[indexHangHoa] = 0;
                                this.totalbidAmount12_2AKhongLo[indexHangHoa] = 0;
                                this.totalTax12_2AKhongLo[indexHangHoa] = 0;
                                this.totalAmount12_2AKhongLo[indexHangHoa] = 0;
                                hangHoa?.formValue?.lotContent?.Table.forEach((e, i) => {
                                    this.totalCost12_2AKhongLo[indexHangHoa] = this.totalCost12_2AKhongLo[indexHangHoa] + (e?.cost ? e?.cost : 0);
                                    this.totalbidAmount12_2AKhongLo[indexHangHoa] = this.totalbidAmount12_2AKhongLo[indexHangHoa] + (e?.bidAmount ? e?.bidAmount : 0);
                                    this.totalTax12_2AKhongLo[indexHangHoa] = this.totalTax12_2AKhongLo[indexHangHoa] + (e?.tax ? e?.tax : 0);
                                    this.totalAmount12_2AKhongLo[indexHangHoa] = this.totalAmount12_2AKhongLo[indexHangHoa] + (e?.amount ? e?.amount : 0);
                                });
                            });

                            this.hh12BCollection = this.dsHhKq?.filter(e => (e.formCode == "BD.MT.02.1256" || e.formCode == "BD.MT.02.1258") && e.contractorCode == contractorWinner);

                            this.hh12BCollection?.map((hangHoa,indexHangHoa)=> {
                                this.currentPageGoodlistOfNoLot12_2B[indexHangHoa] = 1;
                                this.totalPriceExcludeTax12_2BKhongLo[indexHangHoa] = 0;
                                this.totalUnitPrice12_2BKhongLo[indexHangHoa] = 0;
                                this.totalCost12_2BKhongLo[indexHangHoa] = 0;
                                this.totalAmountBeforeTax12_2BKhongLo[indexHangHoa] = 0;
                                this.totalImportTax12_2BKhongLo[indexHangHoa] = 0;
                                this.totalTaxSpecial12_2BKhongLo[indexHangHoa] = 0;
                                this.totalAmount12_2BKhongLo[indexHangHoa] = 0;
                                hangHoa?.formValue?.lotContent?.Table.forEach((e, i) => {
                                    this.totalPriceExcludeTax12_2BKhongLo[indexHangHoa] = this.totalPriceExcludeTax12_2BKhongLo[indexHangHoa] + (e?.priceExcludeTax ? e?.priceExcludeTax : 0);
                                    this.totalUnitPrice12_2BKhongLo[indexHangHoa] = this.totalUnitPrice12_2BKhongLo[indexHangHoa] + (e?.unitPrice ? e?.unitPrice : 0);
                                    this.totalCost12_2BKhongLo[indexHangHoa] = this.totalCost12_2BKhongLo[indexHangHoa] + (e?.cost ? e?.cost : 0);
                                    this.totalAmountBeforeTax12_2BKhongLo[indexHangHoa] = this.totalAmountBeforeTax12_2BKhongLo[indexHangHoa] + (e?.amountBeforeTax ? e?.amountBeforeTax : 0);
                                    this.totalImportTax12_2BKhongLo[indexHangHoa] = this.totalImportTax12_2BKhongLo[indexHangHoa] + (e?.importTax ? e?.importTax : 0);
                                    this.totalTaxSpecial12_2BKhongLo[indexHangHoa] = this.totalTaxSpecial12_2BKhongLo[indexHangHoa] + (e?.taxSpecial ? e?.taxSpecial : 0);
                                    this.totalAmount12_2BKhongLo[indexHangHoa] = this.totalAmount12_2BKhongLo[indexHangHoa] + (e?.amount ? e?.amount : 0);
                                });
                            });
                        } else {
                            this.hhCollection = this.dsHhKq?.filter(e => (e.formCode == "BD.MT.02.1252" || e.formCode == "BD.MT.02.1259") && e.contractorCode == contractorWinner);
                            this.hhCollection?.map((e,indexHangHoa) => {
                                this.currentPageGoodlistOfNoLot[indexHangHoa] = 1;
                                e.dsHH?.map(h => {
                                    if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                        h.bidItem = h.name;
                                    }
                                });
                            });
                            try {
                                this.hhCollection?.forEach(
                                    it => it?.formValue?.lotContent?.Table?.sort((a, b) => (a.currentItemIndex + '').localeCompare(b.currentItemIndex + ''))
                                )
                            } catch (e){
                            }
                        }
                        this.hhCollectionCHCTRG = this.dsHhKq?.filter(e => (e.formCode == "BD.MT.02.1251") && e.contractorCode == contractorWinner);
                        this.hhCollectionCHCTRG?.map(e => {
                            e.dsHH?.map(h => {
                                if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                    h.bidItem = h.name;
                                }
                            });
                        });
                        this.totalAmountNoLotCHCTRG = 0;
                        this.hhCollectionCHCTRG[0]?.formValue?.lotContent?.Table.forEach((e, i) => {
                            this.totalAmountNoLotCHCTRG = this.totalAmountNoLotCHCTRG + (e?.amount ? e?.amount : 0);
                        });

                        this.hhCollectionDVLQ = this.dsHhKq?.filter(e => (e.formCode == "BD.MT.02.1253" || e.formCode == "BD.MT.02.1254") && e.contractorCode == contractorWinner);
                        this.hhCollectionDVLQ?.map(e => {
                            e.dsHH?.map(h => {
                                if (this.isVatTu() && this.stringNullOrEmpty(h.bidItem)) {
                                    h.bidItem = h.name;
                                }
                            });
                        });

                        // this.totalAmountNoLotDVLQ = [];
                        this.hhCollectionDVLQ?.map((hangHoa,indexHangHoa)=>{
                            this.currentPageGoodlistOfNoLotDVLQ[indexHangHoa] = 1;
                            this.totalAmountNoLotDVLQ[indexHangHoa] = 0;
                            hangHoa.formValue?.lotContent?.Table.forEach((e, i) => {
                                this.totalAmountNoLotDVLQ[indexHangHoa] = this.totalAmountNoLotDVLQ[indexHangHoa] + (e?.intoMoney ? e?.intoMoney : 0);
                            });
                        });
                    }
                }
            },
            stringNullOrEmpty(strInput) {
                return strInput === undefined || strInput === null || strInput === '';
            },
            loadKqlcntPlan(){


                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlDetailKqlcntLdt+"?token="+token, {id: this.inputResultId}
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlKqlcnt = response.data?.bideContractorInputResultDTO;
                                if (this.dtlKqlcnt?.isInternet == 0 && this.dtlKqlcnt?.isMedicine == 1) {
                                    let lotResultMedicineKqm = this.dtlKqlcnt?.lotResultDTO?.find(it => it?.goodsList?.length > 0);
                                    if (lotResultMedicineKqm) {
                                        let goodsListMedicineKqm = JSON.parse(lotResultMedicineKqm?.goodsList || '[]');
                                        this.winMedicineKqm = goodsListMedicineKqm?.filter(lot => lot?.winContractors?.length > 0);
                                        if (this.dtlPkgNoList?.bidpBidLotList?.[0]?.medicines == 4 || this.dtlPkgNoList?.bidpBidLotList?.[0]?.medicines == 5) {
                                            this.winMedicineKqm = this.winMedicineKqm.map(it => {
                                                if (it.medicineType == undefined || it.medicineType == null) {
                                                    it.medicineType = goodsListMedicineKqm?.find(it => it.medicineType != undefined && it.medicineType != null)?.medicineType;
                                                }
                                                return it;
                                            })
                                            this.winMedicineKqmType0 = this.winMedicineKqm?.filter(it => it?.medicineType == 0);
                                            this.winMedicineKqmType1 = this.winMedicineKqm?.filter(it => it?.medicineType == 1);
                                        }
                                        this.falseMedicineKqm = goodsListMedicineKqm?.filter(lot => !lot?.winContractors?.length || lot?.falseContractors?.length > 0);
                                    }
                                }
                            }
                        } )
                    });
                });







            },
            loadDetailKqlcntLdtByBidId(id) {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlDetailKqlcntLdtByBidId+"?token="+token, {id: id}
                        ).then(response => {
                                // this.detailKqlcnt = response.data;

                                if (typeof response.data == 'number') {
                                    this.popupSpinning()
                                } else {
                                    this.dtlKqlcnt = response.data;

                                    let contractorWinner = this.getContractorCodeWinner();
                                    if (contractorWinner) {
                                        this.getBidaInvChapterConfs(
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidField,
                                            "HSDT",
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidForm,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.bidMode,
                                            this.dtlKqlcnt.bidpPlanDetailDTO?.ctype,
                                            this.processApply);


                                        this.getOpenGoodsGet(this.getLotNo(), contractorWinner)
                                    }
                                }
                            }
                        );
                    });
                });


            },
            getLotNo() {
                if (this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.length > 0)
                    return this.dtlKqlcnt.bideContractorInputResultDTO.lotResultDTO[this.selectedValue].lotNo;
                else {
                    return this.dtlKqlcnt.bidpPlanDetailDTO?.bidNo;
                }
            },
            getOpenGoodsGet(lotNo, contractorCode) {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(this.detailOpenGoodsGet+"?token="+token,
                            [
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.CG.02.0192"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.CG.02.0197"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1150"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1008"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1009"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1103"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1104"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.DT.02.1102"},
                                {lotNo: lotNo, contractorCode: contractorCode, formCode: "BD.MT.02.1088"}
                            ]
                        ).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.openGoodsList = res.data;
                                this.getDanhSachHangHoa();
                            }
                        })

                    });
                });


            },
            getContractorCodeWinner() {
                if (((this.processApply == 'LDT' || this.processApply == 'KHAC')
                    && this.dtlKqlcnt.bideContractorInputResultDTO?.isInternet == 1)) {
                    let contractorList = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList?.filter(it => it.bidResult == 1);
                    if (contractorList?.length > 0) {
                        if (contractorList.length > 1) {
                            return contractorList.filter(it => it.role == 1)[0]?.orgCode;

                        } else {
                            return contractorList[0]?.orgCode;

                        }
                    }
                } else {
                    let contractorList = this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO[this.selectedValue]?.contractorList?.filter(it => it.bidResult == 1);

                    if (contractorList?.length > 0) {
                        if (contractorList.length > 1) {
                            return contractorList[0]?.orgCode;
                        } else {
                            return contractorList.filter(it => it.role == 1)[0]?.orgCode;
                        }
                    }

                }


            },
            getBidaInvChapterConfs(bidField, bidFile, bidForm, bidMode, contractType, processType) {
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {


                        axios.post(this.detailBidaInvChapterConfs+"?token="+token,
                            {
                                bidField: {equals: bidField},
                                bidFile: {equals: bidFile},
                                bidForm: {equals: bidForm},
                                bidMode: {equals: bidMode},
                                contractType: {equals: contractType},
                                processType: {equals: processType}
                            }
                        ).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.bidaInvChapterConfList = res.data;
                            }
                        })
                    });
                });

            },
            getBidaInvChapterConfsHH(bidField, bidFile, bidForm, bidMode, contractType, processType, isMultiLot, medicalType) {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(this.detailBidaInvChapterConfs+"?token="+token,
                            {
                                bidField: {equals: bidField},
                                bidFile: {equals: bidFile},
                                bidForm: {equals: bidForm},
                                bidMode: {equals: bidMode},
                                contractType: {equals: contractType},
                                processType: {equals: processType},
                                isMultiLot: {equals: isMultiLot},
                                medicalType: {equals: isMultiLot? (medicalType == 2 ? 1 : medicalType) : 0}
                            }
                        ).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.bidaInvChapterConfList = res.data;
                            }
                        })

                    });
                });

            },
            loadDetailKqmtLdt() {
                this.isLoadingKT = true;
                let payload = {
                    notifyNo: this.notifyNo,
                    notifyId: this.notifyId,
                    type: "TBMT",
                    packType: this.bidMode == '1_MTHS' ? 0 : 1
                }


                // axios.post(
                //     this.urlDetailKqmtLdt, payload
                // ).then(response => {
                //         this.dtlRoundMngRes = response.data;
                //         if(this.bidMode == '1_MTHS'){
                //             this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList,['bidFinalPrice'], ['asc']);
                //         }
                //         if(this.bidMode == '1_HTHS'){
                //             this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['contractorName'], ['asc']);
                //         }
                //         this.bidStatus = response?.data?.bidoBidroundMngViewDTO?.bidStatus;
                //         //Lấy danh sách lô theo nhà thầu
                //         let bidoBidSubmissions = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                //         let bidoLotOpenDetails = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                //         bidoLotOpenDetails?.forEach(itemLot => {
                //             const bidSub = bidoBidSubmissions?.filter(e => e?.contractorCode === itemLot?.contractorCode)[0];
                //             itemLot.ventureName = bidSub?.ventureName;
                //             itemLot.ventureCode = bidSub?.ventureCode;
                //             itemLot.fileId = bidSub?.fileId;
                //             itemLot.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                //             itemLot.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                //             itemLot.totalGuaranteeValue = bidSub?.totalGuaranteeValue;
                //             itemLot.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                //             itemLot.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.bidContractPeriod;
                //             itemLot.estimateDateMedical = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.estimateDateMedical;
                //             itemLot.techScore = bidSub?.techScore
                //             // bidSub.lotNoValueDTOList[0].bidOpenView.filter(e => e?.lotNo === itemLot?.lotNo)[0].discountPercent = itemLot.discountPercent;
                //         });
                //         this.bidoLotOpenGroupsOfDXKT = _(bidoLotOpenDetails).groupBy('lotNo').map((items, subject) => {
                //             return {items};
                //         }).value();
                //         this.bidoLotOpenGroupsOfDXKT.forEach( f => {
                //             if(f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                //                 f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                //             }
                //             if(f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                //                 f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                //             }
                //         })
                //     }
                // );

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlNotifyKqmtLdt+"?token="+token, payload
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlRoundMngRes.bidNoContractorResponse = response.data?.bidNoContractorResponse;
                            }
                        })
                    });
                });


                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlRoundMngKqmtLdt+"?token="+token, payload
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlRoundMngRes.bidoBidroundMngViewDTO = response.data?.bidoBidroundMngViewDTO;
                                this.bidStatus = response?.data?.bidoBidroundMngViewDTO?.bidStatus;
                            }
                        })

                    });
                });

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        this.isLoadingKT = true;
                        axios.post(this.urlBidOpenKqmtLdt+"?token="+token, payload)
                            .then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = response.data?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList
                                    if (this.bidMode == '1_MTHS') {
                                        this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['bidFinalPrice'], ['asc']);
                                    }
                                    if (this.bidMode == '1_HTHS') {
                                        this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['contractorName'], ['asc']);
                                    }
                                }

                                grecaptcha.ready(res => {
                                    grecaptcha.execute(this.siteKey,
                                        {action: 'submit'}).then(token => {


                                        axios.post(this.urlLotOpenSubmissionKqmtLdt+"?token="+token,payload).then(res => {

                                            if(typeof res.data == 'number'){
                                                this.popupSpinning()
                                            }else {
                                                this.isLoadingKT = false;
                                                this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList.map(it => {
                                                    it.lotNoValueDTOList = res.data?.filter(lot => lot.contractorCode == it.contractorCode);
                                                    return it;
                                                })
                                                let bidoBidSubmissionsV1 = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                                                let bidoLotOpenDetailsV1 = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                                                if (bidoLotOpenDetailsV1) {
                                                    bidoLotOpenDetailsV1?.forEach(itemLot => {
                                                        const bidSub = bidoBidSubmissionsV1?.filter(e => e?.contractorCode === itemLot?.contractorCode)[0];
                                                        itemLot.ventureName = bidSub?.ventureName;
                                                        itemLot.ventureCode = bidSub?.ventureCode;
                                                        itemLot.fileId = bidSub?.fileId;
                                                        itemLot.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                                                        itemLot.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                                                        itemLot.totalGuaranteeValue = bidSub?.totalGuaranteeValue;
                                                        itemLot.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                                                        itemLot.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.bidContractPeriod;
                                                        itemLot.estimateDateMedical = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.estimateDateMedical;
                                                        itemLot.techScore = bidSub?.techScore
                                                        // bidSub.lotNoValueDTOList[0].bidOpenView.filter(e => e?.lotNo === itemLot?.lotNo)[0].discountPercent = itemLot.discountPercent;
                                                    });
                                                    this.bidoLotOpenGroupsOfDXKT = _(bidoLotOpenDetailsV1).groupBy('lotNo').map((items, subject) => {
                                                        return {items};
                                                    }).value();
                                                    this.bidoLotOpenGroupsOfDXKT.forEach(f => {
                                                        if (f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                                                            f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                                                        }
                                                        if (f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                                                            f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                                        }
                                                    })
                                                }
                                            }

                                        }).catch(err => this.isLoadingKT = false)


                                    });
                                });


                            })
                            .catch(err => this.isLoadingKT = false)



                    });
                });

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlLotOpenDetailKqmtLdt+"?token="+token, payload
                        ).then(res => {

                            if(typeof res.data == 'number'){
                                this.popupSpinning()
                            }else {
                                this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidoLotOpenDetailDTOS = res.data;
                                let bidoBidSubmissions = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList;
                                let bidoLotOpenDetails = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidoLotOpenDetailDTOS;
                                if (bidoBidSubmissions?.[0]?.lotNoValueDTOList) {
                                    bidoLotOpenDetails?.forEach(itemLot => {
                                        const bidSub = bidoBidSubmissions?.filter(e => e?.contractorCode === itemLot?.contractorCode)[0];
                                        itemLot.ventureName = bidSub?.ventureName;
                                        itemLot.ventureCode = bidSub?.ventureCode;
                                        itemLot.fileId = bidSub?.fileId;
                                        itemLot.bidValidityNum = bidSub?.bidValidityNum; // Hiệu lực E-HSDT
                                        itemLot.bidGuarantee = bidSub?.bidGuarantee; // BDDT
                                        itemLot.totalGuaranteeValue = bidSub?.totalGuaranteeValue;
                                        itemLot.bidGuaranteeValidity = bidSub?.bidGuaranteeValidity; // Hiệu lực BDDT
                                        itemLot.bidContractPeriod = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.bidContractPeriod;
                                        itemLot.estimateDateMedical = bidSub?.lotNoValueDTOList[0]?.bidOpenView?.filter(e => e?.lotNo === itemLot?.lotNo)[0]?.estimateDateMedical;
                                        itemLot.techScore = bidSub?.techScore
                                        // bidSub.lotNoValueDTOList[0].bidOpenView.filter(e => e?.lotNo === itemLot?.lotNo)[0].discountPercent = itemLot.discountPercent;
                                    });
                                    this.bidoLotOpenGroupsOfDXKT = _(bidoLotOpenDetails).groupBy('lotNo').map((items, subject) => {
                                        return {items};
                                    }).value();
                                    this.bidoLotOpenGroupsOfDXKT.forEach(f => {
                                        if (f?.items?.length > 0 && this.bidMode == '1_MTHS') {
                                            f.items = _.orderBy(f?.items, ['lotFinalPrice'], ['asc']);
                                        }
                                        if (f?.items?.length > 0 && this.bidMode == '1_HTHS') {
                                            f.items = _.orderBy(f?.items, ['contractorName'], ['asc']);
                                        }
                                    })
                                }
                            }
                        })

                    });
                });




            },
            loadDetailKqmtVk() {
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlDetailKqmtVk+"?token="+token, {id: this.notifyId}
                        ).then(response => {

                                if (typeof response.data == 'number') {
                                    this.popupSpinning()
                                } else {
                                    this.dtlRoundMngRes = response.data;
                                    if (this.bidMode == '1_MTHS') {
                                        this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList, ['bidFinalPrice'], ['asc']);
                                    } else {
                                        this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = _.orderBy(this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList, ['contractorName'], ['asc']);
                                    }
                                    this.bidStatus = response.data?.bidoBidroundOutMngViewDTO?.bidStatus;
                                    // this.bidoNotifyView = response.data.bidoNotifyContractorP;
                                }
                            }
                        );

                    });
                });


            },
            loadDetailKqmtAdbWb() {


                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(
                            this.urlDetailKqmtAdbWb+"?token="+token, {
                                notifyNo: this.notifyNo,
                                type: 'TBMT',
                                packType: 0
                            }
                        ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    console.log("response kqmt vk: ", response)
                                    this.dtlRoundMngRes = response.data;
                                    if (this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList) {
                                        this.dtlRoundMngRes.bidSubmissionByContractorViewResponse.bidSubmissionDTOList = this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.map(it => {
                                            if (it.bidPrice) {
                                                it.bidPrice = it.bidPrice.toFixed();
                                            }
                                            if (it.bidFinalPrice) {
                                                it.bidFinalPrice = it.bidFinalPrice.toFixed();
                                            }
                                            return it;
                                        })
                                    }
                                }
                                // this.bidoNotifyView = response.data.bidoNotifyContractorP;
                            }
                        );

                    });
                });



            },
            getNameOfPeriod(code) {
                if (code == 'D') return 'ngày';
                if (code == 'T') return 'tháng';
                if (code == 'M') return 'tháng';
                if (code == 'Q') return 'quý';
                if (code == 'N') return 'năm';
                if (code == 'Y') return 'năm';
                return '';
            },
            getNameOfPeriodV2(code) {
                const checkEn = this.checkIsEn();
                if (code == 'D') return checkEn ? 'days' : 'ngày';
                if (code == 'T') return checkEn ? 'months' : 'tháng';
                if (code == 'M') return checkEn ? 'months' : 'tháng';
                if (code == 'Q') return checkEn ? 'quarter' : 'quý';
                if (code == 'N') return checkEn ? 'years' : 'năm';
                if (code == 'Y') return checkEn ? 'years' : 'năm';
                return '';
            },
            getListChapterCHCTRG(list) {
                return list.filter(it => it?.lev == 1);
            },
            getListChapter(list) {
                let lstFinal = list;
                /* remove level > 1*/
                /*lstFinal = list.sort((a, b) => a.lev > b.lev && 1 || -1).filter(x => x.lev <= 1);*/
                lstFinal = list.sort((a, b) => a.lev > b.lev && 1 || -1);
                var map = {}, node, roots = [], i;
                for (i = 0; i < lstFinal.length; i += 1) {
                    map[lstFinal[i].code] = i;
                    lstFinal[i].children = [];
                }
                for (i = 0; i < lstFinal.length; i += 1) {
                    node = lstFinal[i];
                    if (node.pcode != undefined && node.pcode != null) {
                        if (map[node.pcode] != undefined && map[node.pcode] != null) {
                            if (lstFinal[map[node.pcode]] != undefined
                                && lstFinal[map[node.pcode]] != null) {
                                if (lstFinal[map[node.pcode]].children != undefined
                                    && lstFinal[map[node.pcode]].children != null) {
                                    lstFinal[map[node.pcode]].children.push(node);
                                } else {
                                    roots.push(node);
                                }
                            } else {
                                roots.push(node);
                            }
                        } else {
                            roots.push(node);
                        }
                    } else {
                        roots.push(node);
                    }
                    /*if (node.pcode && map[node.pcode] && list[map[node.pcode]] && list[map[node.pcode]].children) {
                        // if you have dangling branches check that map[node.parentId] exists
                        list[map[node.pcode]].children.push(node);
                    } else {
                        roots.push(node);
                    }*/
                }
                return roots;
            },
            sortParentList() {
                this.chapterTrees = this.chapterTrees.sort((a, b) => a.orderIndex > b.orderIndex && 1 || -1);
                this.chapterTrees.forEach((ct) => {
                    ct.children = this.sortChildren(ct.children);
                })

                this.chapterTreesCHCTRG = this.chapterTreesCHCTRG.sort((a, b) => a.orderIndex > b.orderIndex && 1 || -1);

            },
            sortChildren(chapterTrees) {
                if (!chapterTrees || chapterTrees.length === 0) {
                    return [];
                }
                chapterTrees = chapterTrees.sort((a, b) => a.orderIndex > b.orderIndex && 1 || -1);
                chapterTrees.forEach((ct) => {
                    ct.children = this.sortChildren(ct.children);
                })
                return chapterTrees;
            },
            filterFormValueAttrFileBm(value, chapterCode) {
                const formValue = value && value.length > 0 ? value?.filter(x => x.chapterCode === chapterCode).map(x => x.formValue) : [];
                return formValue;
            },
            filterItemChildren(list, agreeFrame) {

                return list.filter(it => {
                    if (this.bidoNotifyView?.investField == 'HH') {
                        if ((agreeFrame == 0 || agreeFrame == null)
                            && (it.code == 'BD.CG.02.0099' || it.code == 'BD_CONTRACT_CONDITION' || it.code == 'BD.MT.02.0861')) {
                            return it;
                        }
                        if (agreeFrame == 1 && it.code == 'BD.MT.02.0869') {
                            return it;
                        }
                        if (it.code != 'BD.MT.02.0869' && it.code != 'BD.CG.02.0099' && it.code != 'BD.MT.02.0861' && it.code != 'BD_CONTRACT_CONDITION') {
                            return it;
                        }
                    } else {
                        return it;
                    }

                })


            },
            filterFormValueFromCode(value, formCode) {
                const formValue = value && value.length > 0 ? value?.filter(x => x.formCode === formCode).map(x => x.formValue) : [];
                return formValue;
            },
            filterFormValueAndFileFromChapter(value, chapterCode){
                let listFile = [];
                const formValue = value && value.length > 0 ? value?.filter(x => x.chapterCode === chapterCode).map(x => x.formValue) : [];
                for (let item of formValue){
                    let jsonValue = this.paseJson(item);
                    if(this.addFileToListChapter(jsonValue) && this.addFileToListChapter(jsonValue).length > 0){
                        listFile = listFile.concat(this.addFileToListChapter(jsonValue));
                    }
                }
                return listFile;
            },
            filterFormValueAndFileFromCode(value, formCode){
                let listFile = [];
                const formValue = value && value.length > 0 ? value?.filter(x => x.formCode === formCode).map(x => x.formValue) : [];

                for (let item of formValue){
                    const jsonValue = this.paseJson(item);
                    if(this.addFileToListChapter(jsonValue) && this.addFileToListChapter(jsonValue).length > 0){
                        listFile = listFile.concat(this.addFileToListChapter(jsonValue));
                    }
                }
                return listFile;
            },
            addFileToListChapter(jsonValue){
                const listFile = [];
                // if(formCode === 'BD.MT.02.1260'){
                //     if(jsonValue?.fileGia){
                //         listFile.push(jsonValue?.fileGia);
                //     }
                //     if(jsonValue?.fileKT){
                //         listFile.push(jsonValue?.fileKT);
                //     }
                //     if(jsonValue?.fileLinhTinh){
                //         listFile.push(jsonValue?.fileLinhTinh);
                //     }
                // }
                if(jsonValue?.fileGia){
                    listFile.push(jsonValue?.fileGia);
                }
                if(jsonValue?.fileKT){
                    listFile.push(jsonValue?.fileKT);
                }
                if(jsonValue?.fileNLKN){
                    listFile.push(jsonValue?.fileNLKN);
                }
                if(jsonValue?.fileTech){
                    listFile.push(jsonValue?.fileTech);
                }
                if(jsonValue?.fileOther){
                    listFile.push(jsonValue?.fileOther);
                }
                if(jsonValue?.file){
                    listFile.push(jsonValue?.file);
                }
                if(jsonValue?.filePaint){
                    listFile.push(jsonValue?.filePaint);
                }
                if(jsonValue?.fileDesign){
                    listFile.push(jsonValue?.fileDesign);
                }
                if(jsonValue?.fileDesign1){
                    listFile.push(jsonValue?.fileDesign1);
                }
                if(jsonValue?.fileDesign2){
                    listFile.push(jsonValue?.fileDesign2);
                }
                if(jsonValue?.fileDesign3){
                    listFile.push(jsonValue?.fileDesign3);
                }
                if(jsonValue?.fileDesign4){
                    listFile.push(jsonValue?.fileDesign4);
                }
                if(jsonValue?.fileName1){
                    listFile.push(jsonValue?.fileName1);
                }
                if(jsonValue?.fileName2){
                    listFile.push(jsonValue?.fileName2);
                }
                if(jsonValue?.fileName){
                    listFile.push(jsonValue?.fileName);
                }
                if(jsonValue?.fileOption){
                    listFile.push(jsonValue?.fileOption);
                }
                if(jsonValue?.fileDKCT){
                    listFile.push(jsonValue?.fileDKCT);
                }
                if(jsonValue?.fileBMHD){
                    listFile.push(jsonValue?.fileBMHD);
                }
                if(jsonValue?.filePVCC){
                    listFile.push(jsonValue?.filePVCC);
                }
                if(jsonValue?.fileDGKT){
                    listFile.push(jsonValue?.fileDGKT);
                }
                if(jsonValue?.fileTCDG){
                    listFile.push(jsonValue?.fileTCDG);
                }
                if(jsonValue?.fileDKC){
                    listFile.push(jsonValue?.fileDKC);
                }
                //file ADB WB
                if(this.processApply == 'ADB' || this.processApply == 'WB') {
                    if (jsonValue?.dataRow1?.thrPlan) {
                        listFile.push(jsonValue?.dataRow1?.thrPlan);
                    }
                    if (jsonValue?.fileAttach) {
                        listFile.push(jsonValue?.fileAttach);
                    }
                    if (jsonValue?.listFileAttachs) {
                        jsonValue?.listFileAttachs?.forEach(item => listFile.push(item));
                    }
                    if (jsonValue?.investorAddress) {
                        listFile.push(jsonValue?.investorAddress);
                    }
                    if (jsonValue?.dkc15_1) {
                        listFile.push(jsonValue?.dkc15_1);
                    }
                    if (jsonValue?.dataRow1?.fristPlan) {
                        listFile.push(jsonValue?.dataRow1?.fristPlan);
                    }
                    if (jsonValue?.dkc14_1_fileId) {
                        listFile.push(jsonValue);
                    }
                }
                return listFile;
            },
            paseJson(value) {
                let arrVal;
                if (value) {
                    arrVal = JSON.parse(value);
                }
                return arrVal;
            },
            convertName(str) {
                let newStr = "";
                if (str) {
                    let arr = str.split(/\s+/);
                    newStr = arr.join("_");

                }
                return newStr;
            },
            convertStringToObject(str) {
                let obj = JSON.parse(str);

                return obj
            },
            showClarify() {
                this.isShowClarify = !this.isShowClarify;
            },
            getContentKn(content){
                try {
                    // content = JSON.parse(content);
                    // let reqContent = '';
                    // content.forEach(it => reqContent += it.reqContent + '</br>');
                    // return reqContent;
                    return JSON.parse(content);
                } catch (e){
                    return [''];
                }
            },
            getTypeKn(type){
                if(type == 'LCNT_QM') return 'Những vấn đề liên quan đến quá trình LCNT qua mạng';
                if(type == 'KQDT') return 'Những vấn đề liên quan đến kết quả LCNT';
                return 'Những vấn đề liên quan đến e-HSMT';
            }
            ,
            checkEnableTabKn(petitionList){
                let kn = 0;
                petitionList?.forEach(it => {
                    try {
                        if(JSON.parse(it.content)?.filter(it => it?.petitionPeriod != 'KQDT')?.length > 0){
                            kn +=1;
                        }
                    } catch(e){

                    }
                });
                return kn > 0;
            },

            getMapContractSignDate(lotResultDTO,isMultiLot){
                let mapSignDate = new Map();
                lotResultDTO?.forEach(it => {
                    let winContractorList = it.contractorList?.filter(it => it.bidResult == 1);
                    if (winContractorList?.length > 1) {
                        winContractorList = winContractorList.filter(it => it.role == 1);
                    }
                    if(winContractorList[0]?.contractSignDate) {
                        mapSignDate.set(winContractorList[0]?.orgCode, winContractorList[0]);
                    }
                })
                if(isMultiLot == 1) {
                    for (const [key, value] of mapSignDate) {
                        value.lotList = [];
                        lotResultDTO.forEach(it => {
                            if (it?.contractorList?.filter(ct => ct?.orgCode == value?.orgCode && ct?.bidResult == 1 && (!ct?.role || ct?.role != 2))?.length > 0) {
                                value.lotList.push({lotNo: it?.lotNo, lotName: it?.lotName});
                            }
                        })
                        mapSignDate.set(key, value);
                    }
                }
                return mapSignDate;
            },
            showOrgCode(orgName,orgCode){
                if (orgCode.startsWith("vn")){
                    return orgCode;
                }
                return orgName;
            },
            showOrgCodeValue(taxCode,orgCode){
                if (orgCode.startsWith("vn")){
                    return orgCode;
                }
                return taxCode;
            },
            parseClarifyList(arr) {
                let result = []

                arr?.forEach((it, index, self) => {
                    if (result.filter(i => i.reqNo === it.reqNo).length == 0) {
                        let obj = {
                            "reqName": it.reqName,
                            "reqNo": it.reqNo,
                            "child": self.filter(j => j.reqNo == it.reqNo)?.sort((a,b) => {return new Date(a?.signReqDate).getTime() - new Date(b?.signReqDate).getTime();})
                        };
                        result.push(obj);
                        console.log('obj',obj);
                    }

                })
                return result;
            },
            onClickNewTab: function (itemDetail, chapterNames) {
                if (this.processApply && (this.processApply === 'ADB' || this.processApply === 'WB')) {
                    // if ('C3' === itemDetail.pcode) {
                    //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode="
                    //         + itemDetail.pcode + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code;
                    //     var popout = window.open(this.urlEdoc);
                    // } else if ('C7' === itemDetail.code
                    //     && this.bidoNotifyView
                    //     && (this.bidoNotifyView?.investField == 'XL'
                    //         || this.bidoNotifyView?.investField == 'HH')) {
                    //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode="
                    //         + itemDetail.code + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + itemDetail.code + "&type=download";
                    //     var popout = window.open(this.urlEdoc);
                    //     window.setTimeout(function () {
                    //         popout.close();
                    //     }, 1000);
                    // } else {
                    //     this.urlEdoc = this.urlEdocAdbTemp + "?id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&formCode="
                    //         + itemDetail.code + "&fileName=" + this.convertName(chapterNames) + "&subCode=" + '';
                    //     var popout = window.open(this.urlEdoc);
                    // }
                    // if(this.bidoNotifyView.investField != 'HH' && itemDetail.code == 'C4'){
                    //     itemDetail.code = 'CHAP4_ALL';
                    // }
                    if(this.bidoNotifyView.investField != 'HH' && this.processApply == 'ADB' && itemDetail.code == 'C4'){
                        itemDetail.code = 'CHAP4_ALL';
                    }
                    let urlEdoc = this.urlADBWBFe + "?formCode=" + itemDetail.code + "&id=" + this.dtlTdNs.bidoNotifyContractorP.id + "&fileName=" + this.convertName(chapterNames);
                    window.open(urlEdoc);
                } else {
                    this.urlEdoc = this.urlContractorFe + "?formCode=" + itemDetail.code + "&id="
                        + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=" + this.convertName(chapterNames);
                    // this.urlEdoc = this.urlEdocTemp + "?formCode=" + itemDetail.code + "&id="
                    //     + this.dtlTdNs.bidoNotifyContractorM.id + "&fileName=" + this.convertName(chapterNames);
                    var popout = window.open(this.urlEdoc);
                }

            },
            loadDetailTbmtAdbWb(){

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {


                        axios.post(
                            this.urlDetailTbmtAdbWb+"?token="+token, {id: this.notifyId}
                        ).then(response => {

                            if(typeof response.data == 'number'){
                                this.popupSpinning()
                            }else{
                                console.log("response tbmt vk: ", response)

                                this.dtlTdNs = response.data;
                                this.tbmt = response.data;
                                this.bidoNotifyView = this.dtlTdNs.bidoNotifyContractorP;

                                if(this.bidoNotifyView?.bidForm == 'DTHC') this.downloadFilePublic = false;

                                this.functionName = this.bidoNotifyView?.bidName;
                                this.functionCode = this.notifyNo;
                                if (this.bidoNotifyView?.planType == 'TX' || this.bidoNotifyView?.planType == 'KHAC'){
                                    this.procuringEntityName= this.bidoNotifyView?.procuringEntityName;
                                } else {
                                    this.procuringEntityName= this.bidoNotifyView?.investorName;
                                }
                                if (response.data.bidaInvChapterConfList && response.data.bidaInvChapterConfList.length > 0) {

                                    if (this.bidoNotifyView?.bidForm == 'CHCTRG') {
                                        this.chapterTreesCHCTRG = this.getListChapterCHCTRG(this.tbmt.bidaInvChapterConfList);
                                    } else {
                                        this.chapterTrees = this.getListChapter(this.tbmt.bidaInvChapterConfList);

                                    }
                                    this.sortParentList();
                                }
                                if (this.tbmt.bidoInvFileDTO) {
                                    this.attachedFiles = this.paseJson(this.tbmt?.bidoInvFileDTO?.attachedFiles);
                                }
                                this.biduPetitionContractorVersionList = response?.data?.biduPetitionContractorVersionDTOList; //Kiến nghị
                                this.bidoPreBidConferenceVersionList = response?.data?.bidoPreBidConferenceVersionDTOList; //Hội nghị tiền đấu thầu
                                this.biduClarifyReqInvAndContentViewVersionList = response?.data?.biduClarifyReqInvAndContentViewVersionDTOList; //Làm rõ HSMT
                            }}
                        );


                    });
                });


            }
            ,

            loadDetailReoffer(){
                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {

                        axios.post(this.urlReoffer+"?token="+token, {notifyId: this.notifyId}).then(
                            res => {

                                if(typeof res.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlReoffer = res?.data;
                                }
                            }
                        )
                    });
                });


            },

            generatePdfReoffer(dtlReoffer,bidoNotifyView){
                let bodyTbl = [
                    [
                        { text: 'STT',fillColor: '#DDDDDD' },
                        { text: 'Mã định danh',fillColor: '#DDDDDD' },
                        { text: 'Tên nhà thầu',fillColor: '#DDDDDD' },
                        { text: 'Giá chào lại sau khi xử lý tình huống chào vượt giá (VND)',fillColor: '#DDDDDD'}
                    ]
                ];
                dtlReoffer?.openReoffers?.forEach((ct,index) => {
                    bodyTbl.push([{text: (index + 1)},{text: ct?.contractorCode},{text: ct?.ventureName ? ct?.ventureName : ct?.contractorName},{text: this.currency(ct?.bidFinalPrice)}])
                })
                const tableReoffer = [
                    {
                        table: {
                            widths: ['6%','20%', '35%', '40%'],
                            body: bodyTbl
                        },
                        fontSize: 11
                    },
                ];


                var docDefinition = {
                    content: [
                        [
                            {
                                text: 'BIÊN BẢN MỞ HỒ SƠ CHÀO LẠI GIÁ',
                                alignment: 'center',
                                bold: true,
                                margin: [0, 15],
                                fontSize: 13,
                            },
                            {
                                table: {
                                    widths: ['30%', '30%','20%','20%'],
                                    body: [
                                        [{ text: 'Số TBCLG',fillColor: '#DDDDDD' }, { text: dtlReoffer?.reofferDTO?.reofferNo,colSpan: 3},{text:''},{text:''}],
                                        [{ text: 'Số TBMT',fillColor: '#DDDDDD' }, { text: dtlReoffer?.reofferDTO?.notifyNo,colSpan: 3},{text:''},{text:''}],
                                        [{ text: 'Tên gói thầu',fillColor: '#DDDDDD' },{ text: dtlReoffer?.reofferDTO?.bidName,colSpan: 3},{text:''},{text:''} ],
                                        bidoNotifyView.planType == 'DTPT' ? [{ text: 'Chủ đầu tư',fillColor: '#DDDDDD' }, { text: bidoNotifyView?.investorName ,colSpan: 3},{text:''},{text:''}] : null,
                                        [{ text: 'Bên mời thầu',fillColor: '#DDDDDD' }, { text: bidoNotifyView?.procuringEntityName,colSpan: 3},{text:''},{text:''}],
                                        [{ text: bidoNotifyView?.bidEstimatePrice ? 'Giá dự toán' : 'Giá gói thầu',fillColor: '#DDDDDD' }, { text: (bidoNotifyView?.bidEstimatePrice ? this.currency(bidoNotifyView?.bidEstimatePrice) : this.currency(bidoNotifyView?.bidPrice)) + ' ' + bidoNotifyView.bidPriceUnit,colSpan: 3},{text:''},{text:''}],
                                        [{ text: 'Loại hợp đồng',fillColor: '#DDDDDD' }, { text: this.getNameCatByCodeCat(bidoNotifyView?.contractType,this.dmLhdLcnt)},{ text: 'Hình thức LCNT',fillColor: '#DDDDDD' }, { text: this.getNameCatByCodeCat(bidoNotifyView?.bidForm,this.bidForms)}],
                                        [{ text: 'Thời điểm hoàn thành mở chào lại giá',fillColor: '#DDDDDD' }, { text: this.formatDateForPDF(dtlReoffer?.openReoffers?.[0]?.createdDate),colSpan: 3},{text:''},{text:''}],
                                    ].filter(it => it != null),
                                },
                                margin: [0,0,0,10],
                                fontSize: 11,
                            },
                            {
                                table: {
                                    widths: ['78%', '22%'],
                                    body: [
                                        [{ text: ''}, { text: '[Số lượng nhà thầu:' + dtlReoffer?.openReoffers?.length + ' ]' }]
                                    ],
                                },
                                margin: [0, 8],
                                layout: 'noBorders',
                                fontSize: 11,
                            },
                            ...tableReoffer
                        ],
                    ],
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                }

                pdfMake.createPdf(docDefinition).download("\n" +"Biên_bản_mở_chào_lại_giá.pdf");
            },

            loadDetailTbmtVk() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlDetailTbmtVk+"?token="+token, {id: this.notifyId}
                        ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlTdNs = response.data;
                                    this.tbmt = response.data;
                                    this.biduPetitionContractorVersionList = response?.data?.biduPetitionContractorVersionDTOList; //Kiến nghị
                                    this.bidoPreBidConferenceVersionList = response?.data?.bidoPreBidConferenceVersionDTOList; //Hội nghị tiền đấu thầu
                                    this.biduClarifyReqInvAndContentViewVersionList = response?.data?.biduClarifyReqInvAndContentViewVersionDTOList; //Làm rõ HSMT
                                    this.bidoNotifyView = this.dtlTdNs.bidoNotifyContractorP;
                                    this.passSelectedTab();

                                    if (this.bidoNotifyView?.bidForm == 'DTHC') this.downloadFilePublic = false;

                                    this.functionName = this.bidoNotifyView?.bidName;
                                    this.functionCode = this.notifyNo;
                                    if (this.bidoNotifyView?.planType == 'TX' || this.bidoNotifyView?.planType == 'KHAC') {
                                        this.procuringEntityName = this.bidoNotifyView?.procuringEntityName;
                                    } else {
                                        this.procuringEntityName = this.bidoNotifyView?.investorName;
                                    }
                                    if (response.data.bidaInvChapterConfList && response.data.bidaInvChapterConfList.length > 0) {

                                        if (this.bidoNotifyView?.bidForm == 'CHCTRG') {
                                            this.chapterTreesCHCTRG = this.getListChapterCHCTRG(this.tbmt.bidaInvChapterConfList);
                                        } else {
                                            this.chapterTrees = this.getListChapter(this.tbmt.bidaInvChapterConfList);

                                        }
                                        this.sortParentList();
                                    }
                                    if (this.tbmt.bidoInvFileDTO && this.tbmt.bidoInvFileDTO.attachedFiles) {
                                        this.attachedFiles = this.paseJson(this.detailTbmt.bidoInvFileDTO.attachedFiles);
                                    }
                                    if (this.tbmt?.cancelBidHistoryList?.length > 0 && this.tbmt?.bidoNotifyContractorP?.status == '03') {
                                        this.tbmt.cancelBidHistoryList.unshift({
                                            cancelNumber: this.tbmt?.cancelBidHistoryList?.[0]?.cancelNumber + 1,
                                            cancelReason: this.dtlTdNs?.bidoNotifyContractorP?.cancelReason,
                                            cancelDecisionNo: this.dtlTdNs?.bidoNotifyContractorP?.cancelDecisionNo,
                                            cancelDecisionDate: this.dtlTdNs?.bidoNotifyContractorP?.cancelDecisionDate,
                                            cancelFileAttachName: this.dtlTdNs?.bidoNotifyContractorP?.cancelFileAttachName,
                                            cancelDate: this.dtlTdNs?.bidoNotifyContractorP?.cancelDate
                                        })
                                    }
                                    if (this.tbmt?.cancelBidHistoryList?.length > 0) {
                                        this.cancelBid = this.tbmt?.cancelBidHistoryList?.[0];
                                    }
                                }
                            }
                        );

                    });
                });



            },
            loadListVersionTbmtVk() {
                axios.post(
                    this.urlListVerTbmtVk, {notifyNo: this.notifyNo}
                ).then(response => {
                        this.versionList = this.sortListVersion(response.data);
                    }
                );
            },
            loadDetailTbmtLdt() {

                grecaptcha.ready(res => {
                    grecaptcha.execute(this.siteKey,
                        {action: 'submit'}).then(token => {
                        axios.post(
                            this.urlDetailTbmtLdt, {id: this.notifyId}
                        ).then(response => {

                                if(typeof response.data == 'number'){
                                    this.popupSpinning()
                                }else {
                                    this.dtlTdNs = response.data;
                                    this.tbmt = response.data;
                                    this.bidoNotifyView = response.data.bidoNotifyContractorM;
                                    this.passSelectedTab();

                                    if (this.bidoNotifyView?.bidForm == 'DTHC') this.downloadFilePublic = false;

                                    this.functionName = this.bidoNotifyView?.bidName;
                                    this.functionCode = this.notifyNo;
                                    if (this.bidoNotifyView?.planType == 'TX' || this.bidoNotifyView?.planType == 'KHAC') {
                                        this.procuringEntityName = this.bidoNotifyView?.procuringEntityName;
                                    } else {
                                        this.procuringEntityName = this.bidoNotifyView?.investorName;
                                    }


                                    if (response.data.bidaInvChapterConfList && response.data.bidaInvChapterConfList.length > 0) {

                                        if (this.bidoNotifyView?.bidForm == 'CHCTRG') {
                                            this.chapterTreesCHCTRG = this.getListChapterCHCTRG(this.tbmt.bidaInvChapterConfList);
                                        } else {
                                            this.chapterTrees = this.getListChapter(this.tbmt.bidaInvChapterConfList);

                                        }
                                        this.sortParentList();
                                    }
                                    if (this.tbmt.bidoInvFileDTO && this.tbmt.bidoInvFileDTO.attachedFiles) {
                                        this.attachedFiles = this.paseJson(this.detailTbmt.bidoInvFileDTO.attachedFiles);
                                    }

                                    if (this.dtlTdNs.bidoPreNotifyContractorResult) {
                                        if (this.bidoNotifyView.isPrequalification == 1 && this.bidoNotifyView.isInternet == 1) {
                                            this.haveSeeHSMT = false;
                                            this.downloadFilePublic = false;
                                        }
                                        this.bidoPreNotifyContractorResult = this.dtlTdNs.bidoPreNotifyContractorResult;
                                        this.groupShortListPreNotifyContractorResult();
                                    }
                                    if (this.bidoNotifyView?.investField == 'PTV') {
                                        this.getBidaInvChapterConfs(response?.data?.bidpPlanDetail?.bidField,
                                            "HSDT",
                                            response?.data?.bidpPlanDetail?.bidForm,
                                            response?.data?.bidpPlanDetail?.bidMode,
                                            response?.data?.bidpPlanDetail?.ctype,
                                            response?.data?.bidpPlanDetail?.processApply)
                                    }
                                    if (this.bidoNotifyView?.investField == 'HH') {
                                        this.getBidaInvChapterConfsHH(response?.data?.bidpPlanDetail?.bidField,
                                            "HSDT",
                                            response?.data?.bidpPlanDetail?.bidForm,
                                            response?.data?.bidpPlanDetail?.bidMode,
                                            response?.data?.bidpPlanDetail?.ctype,
                                            response?.data?.bidpPlanDetail?.processApply,
                                            response?.data?.bidpPlanDetail?.isMultiLot,
                                            this.bidoNotifyView?.medicalType
                                        )
                                    }
                                    if ((this.tbmt?.bidoNotifyContractorM?.status == '03' || this.tbmt?.bidoNotifyContractorP?.status == '03') && this.dtlTdNs?.bidCancelingResponse?.cancelType != 2 && this.dtlTdNs?.bidCancelingResponse?.cancelType != 3 && this.tbmt?.cancelBidHistoryList?.length > 0) {
                                        this.tbmt.cancelBidHistoryList.unshift({
                                            cancelNumber: this.tbmt?.cancelBidHistoryList?.[0]?.cancelNumber + 1,
                                            cancelReason: this.dtlTdNs?.bidCancelingResponse?.cancelReason,
                                            cancelDecisionNo: this.dtlTdNs?.bidCancelingResponse?.cancelDecisionNo,
                                            cancelDecisionDate: this.dtlTdNs?.bidCancelingResponse?.cancelDecisionDate,
                                            cancelFileAttachName: this.dtlTdNs?.bidCancelingResponse?.cancelFileAttachName,
                                            cancelDate: this.dtlTdNs?.bidCancelingResponse?.cancelDate
                                        })
                                    }
                                    if (this.tbmt?.cancelBidHistoryList?.length > 0) {
                                        this.cancelBid = this.tbmt?.cancelBidHistoryList?.[0];
                                    }
                                }
                            }
                        );

                    });
                });



            },
            loadListVersionTbmtLdt() {
                axios.post(
                    this.urlListVerTbmtLdt, {notifyNo: this.notifyNo}
                ).then(response => {
                        this.versionList = this.sortListVersion(response.data.versionList);
                        this.biduPetitionContractorVersionList = response?.data?.biduPetitionContractorVersionDTOList; //Kiến nghị
                        this.bidoPreBidConferenceVersionList = response?.data?.bidoPreBidConferenceVersionDTOList; //Hội nghị tiền đấu thầu
                        this.biduClarifyReqInvAndContentViewVersionList = response?.data?.biduClarifyReqInvAndContentViewVersionDTOList; //Làm rõ HSMT
                    }
                );
            },

            loadCatList() {
                let isLoadCat = localStorage.getItem('isLoadCatIndexLCNT');
                if (isLoadCat == null || JSON.parse(isLoadCat) != '1') {
                    axios.post(this.getCategory,
                        {
                            "categoryTypeCodeLst": [
                                "DM_TTPDDA",
                                "DM_KHLCNT",
                                "DM_LVLCNT",
                                "DM_HTLCNT", /* hinh thuc LCNT */
                                "BID_INVEST_FORM",
                                "BID_CONTRACT_TYPE",
                                "DM_QT", /* quy trinh */
                                "DM_PTLCNT", /* phuong thuc LCNT */
                                "FORM_OF_SPENDING",
                                "BIDO_BID_STATUS", /* Trang thai goi thau */
                                "BID_NOTIFY_STATUS",
                                "DM_GROUP_DA",
                                "DM_HTQLDA",
                                "DM_HTDT",
                                "BID_PLAN_STATUS",
                                "DM_LHDLCNT",
                                "DM_QT",
                                "BIDO_BID_STATUS",
                                "DM_TRANG_THAI",
                                "DM_CQMS",
                                "DM_CQMS_LV1",
                                "DM_LYDO_HT_CPTPP",
                                "DM_LYDO_HT",
                                "CAT_COUNTRY_LIST"
                            ]
                        }
                    ).then(res => {
                        if (res != undefined && res.status === 200) {
                            this.dmCqms = res.data.categories.DM_CQMS;
                            this.dmCqmsLv1 = res.data.categories.DM_CQMS_LV1;
                            this.dmGroupDa = res.data.categories.DM_GROUP_DA;
                            this.bidoStatus = res.data.categories.BIDO_BID_STATUS;
                            this.htqlDa = res.data.categories.DM_HTQLDA;
                            this.dmHtdt = res.data.categories.DM_HTDT;
                            this.planTypesVe = res.data.categories.DM_KHLCNT;
                            this.planAppVeStatus = res.data.categories.DM_TTPDDA;
                            this.catInvestFields = res.data.categories.DM_LVLCNT;
                            this.bidForms = res.data.categories.DM_HTLCNT;
                            this.dmQt = res.data.categories.DM_QT;
                            this.dmPtlcnt = res.data.categories.DM_PTLCNT;
                            this.dmSpendingCat = res.data.categories.FORM_OF_SPENDING;
                            this.dmBidStatusCat = res.data.categories.BIDO_BID_STATUS;
                            this.notiStatusCat = res.data.categories.BID_NOTIFY_STATUS;
                            this.bidPlanStatus = res.data.categories.BID_PLAN_STATUS;
                            this.dmLhdLcnt = res.data.categories.DM_LHDLCNT;
                            this.contractTypes = res.data.categories.BID_CONTRACT_TYPE;
                            this.processApplies = res.data.categories.DM_QT;
                            this.dmTrangThais = res.data.categories.DM_TRANG_THAI;
                            this.reasonCancelBidCPTPP = res.data.categories.DM_LYDO_HT_CPTPP;
                            this.reasonCancelBid = res.data.categories.DM_LYDO_HT;
                            this.catCountryList = res.data.categories.CAT_COUNTRY_LIST;
                            localStorage.setItem("dmCqms", JSON.stringify(this.dmCqms));
                            localStorage.setItem("dmCqmsLv1", JSON.stringify(this.dmCqmsLv1));
                            localStorage.setItem("dmGroupDa", JSON.stringify(this.dmGroupDa));
                            localStorage.setItem("bidoStatus", JSON.stringify(this.bidoStatus));
                            localStorage.setItem("htqlDa", JSON.stringify(this.htqlDa));
                            localStorage.setItem("dmHtdt", JSON.stringify(this.dmHtdt));
                            localStorage.setItem("planTypesVe", JSON.stringify(this.planTypesVe));
                            localStorage.setItem("planAppVeStatus", JSON.stringify(this.planAppVeStatus));
                            localStorage.setItem("catInvestFields", JSON.stringify(this.catInvestFields));
                            localStorage.setItem("bidForms", JSON.stringify(this.bidForms));
                            localStorage.setItem("dmQt", JSON.stringify(this.dmQt));
                            localStorage.setItem("dmPtlcnt", JSON.stringify(this.dmPtlcnt));
                            localStorage.setItem("dmSpendingCat", JSON.stringify(this.dmSpendingCat));
                            localStorage.setItem("dmBidStatusCat", JSON.stringify(this.dmBidStatusCat));
                            localStorage.setItem("notiStatusCat", JSON.stringify(this.notiStatusCat));
                            localStorage.setItem("bidPlanStatus", JSON.stringify(this.bidPlanStatus));
                            localStorage.setItem("dmLhdLcnt", JSON.stringify(this.dmLhdLcnt));
                            localStorage.setItem("contractTypes", JSON.stringify(this.contractTypes));
                            localStorage.setItem("processApplies", JSON.stringify(this.processApplies));
                            localStorage.setItem("dmTrangThais", JSON.stringify(this.dmTrangThais));
                            localStorage.setItem("reasonCancelBidCPTPP", JSON.stringify(this.reasonCancelBidCPTPP));
                            localStorage.setItem("reasonCancelBid", JSON.stringify(this.reasonCancelBid));
                            localStorage.setItem("catCountryList", JSON.stringify(this.catCountryList));

                            localStorage.setItem('isLoadCatIndexLCNT', '1');
                        }
                    })
                } else {
                    this.dmCqms = JSON.parse(localStorage.getItem('dmCqms'));
                    this.dmCqmsLv1 = JSON.parse(localStorage.getItem('dmCqmsLv1'));
                    this.dmGroupDa = JSON.parse(localStorage.getItem('dmGroupDa'));
                    this.bidoStatus = JSON.parse(localStorage.getItem('bidoStatus'));
                    this.htqlDa = JSON.parse(localStorage.getItem('htqlDa'));
                    this.dmHtdt = JSON.parse(localStorage.getItem('dmHtdt'));
                    this.planTypesVe = JSON.parse(localStorage.getItem('planTypesVe'));
                    this.planAppVeStatus = JSON.parse(localStorage.getItem('planAppVeStatus'));
                    this.catInvestFields = JSON.parse(localStorage.getItem('catInvestFields'));
                    this.bidForms = JSON.parse(localStorage.getItem('bidForms'));
                    this.dmQt = JSON.parse(localStorage.getItem('dmQt'));
                    this.dmPtlcnt = JSON.parse(localStorage.getItem('dmPtlcnt'));
                    this.dmSpendingCat = JSON.parse(localStorage.getItem('dmSpendingCat'));
                    this.dmBidStatusCat = JSON.parse(localStorage.getItem('dmBidStatusCat'));
                    this.notiStatusCat = JSON.parse(localStorage.getItem('notiStatusCat'));
                    this.bidPlanStatus = JSON.parse(localStorage.getItem('bidPlanStatus'));
                    this.dmLhdLcnt = JSON.parse(localStorage.getItem('dmLhdLcnt'));
                    this.contractTypes = JSON.parse(localStorage.getItem('contractTypes'));
                    this.processApplies = JSON.parse(localStorage.getItem('processApplies'));
                    this.dmTrangThais = JSON.parse(localStorage.getItem('dmTrangThais'));
                    this.reasonCancelBidCPTPP = JSON.parse(localStorage.getItem('reasonCancelBidCPTPP'));
                    this.reasonCancelBid = JSON.parse(localStorage.getItem('reasonCancelBid'));
                    this.catCountryList = JSON.parse(localStorage.getItem('catCountryList'));
                }

                axios.post(this.getCategory,{
                    'categoryTypeCodeLst': ['DM_LOAI_CT_TB']
                }).then( res => {
                        this.workTypeList = res.data?.categories?.DM_LOAI_CT_TB;
                    }
                )

            },
            getNameCatByCodeCat(code, listCat) {
                if (!listCat)
                    return code;
                const temp = listCat.filter(el => el.code == code).pop();
                return temp ? (this.checkIsEn() ? temp?.nameEn : temp.name) : code;
            },
            generateKqmtPDFAdbWb(detailKqmtCheck){
                let table1tui = [];

                if ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) {
                    var table1tuiv1 = {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [25,75,74,75,40,75,50,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')?60:null,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1) ?60:null
                            ].filter(it => it != null),
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                    {text: (detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? 'Hiệu lực báo giá (ngày)' : ((detailKqmtCheck?.bidoBidroundMngViewDTO?.isInternet) ? 'Hiệu lực E-HSDT (ngày)' :   'Hiệu lực HSDT (ngày)'), fillColor: '#DDDDDD',},
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},

                                ].filter(it => it != null)
                            ]
                        }
                    };
                    table1tui.push(table1tuiv1);

                    detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                        table1tui[0].table.body.push(
                            [{text: (index + 1)},
                                {text: element?.contractorCode},
                                {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                // {text: this.currency(element?.lotNoValueDTOList[0]?.lotPrice), alignment: 'right'},
                                {text: this.currency(element?.bidPrice), alignment: 'right'},
                                {text: this.currency(element?.saleNumber), alignment: 'center'},
                                {text: this.currency(element?.lotNoValueDTOList[0]?.lotFinalPrice), alignment: 'right'},
                                {text: element?.bidValidityNum},
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') &&  this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null,
                            ].filter(it => it!= null))
                    });
                }
                if (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) {
                    var table1tuiv2 = {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [25,55,60,60,35,50,40,53,45,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')?35:null,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1) ?35:null
                            ].filter(it => it != null),
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                    {text: detailKqmtCheck?.bidoBidroundMngViewDTO?.isInternet ? 'Hiệu lực E-HSDT (ngày)' :   'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                                    {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',},
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1)) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},

                                ].filter(it => it != null)
                            ]
                        }
                    };
                    table1tui.push(table1tuiv2);

                    detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                        table1tui[0].table.body.push(
                            [{text: (index + 1)},
                                {text: element?.contractorCode},
                                {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                {text: this.currency(element?.bidPrice), alignment: 'right'},
                                {text: this.currency(element?.saleNumber), alignment: 'center'},
                                {text: this.currency(element?.bidFinalPrice),alignment: 'right'},
                                {text: element?.bidValidityNum},
                                {text: this.currency(element?.bidGuarantee ? element?.bidGuarantee : detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue) + ((this.checkMuoiTrieu(element?.bidGuarantee) || this.checkMuoiTrieu(detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue)) ? ' (Cam kết trong đơn dự thầu)' : '')},
                                {text: element?.bidGuaranteeValidity},
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null
                            ].filter(it => it != null))
                    });
                }
                var dataTable = [];
                dataTable.push([{
                    text: 'Mã TBMT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.notifyNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Tên gói thầu',
                    fillColor: '#DDDDDD',
                }, {
                    // text: detailKqmtCheck?.bidoNotifyContractorP?.bidName,
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Số lượng nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoBidroundMngViewDTO?.countContractor,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Thời điểm hoàn thành mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateForPDF((detailKqmtCheck?.bidoBidroundMngViewDTO?.successBidOpenDate) ? (detailKqmtCheck?.bidoBidroundMngViewDTO?.successBidOpenDate) : (detailKqmtCheck?.bidoBidStatus?.successBidOpenDate)),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Lĩnh vực',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField, this.catInvestFields),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                var dataTable2 = [];
                dataTable2.push([{
                    text: 'Mã KHLCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.planNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Tên kế hoạch LCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.planName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Loại hợp đồng',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoBidroundMngViewDTO?.contractType, this.dmLhdLcnt),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                // dataTable2.push([{
                //     text: 'Thời gian thực hiện hợp đồng',
                //     fillColor: '#DDDDDD',
                // }, {
                //     text: detailKqmtCheck?.bidoBidroundMngViewDTO?.cperiod + " " + this.getNameOfPeriod(detailKqmtCheck?.bidoBidroundMngViewDTO?.cperiodUnit),
                //     colSpan: 3,
                // }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Hình thức lựa chọn nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidForm, this.bidForms),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                dataTable2.push([{
                    text: 'Phương thức lựa chọn nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode, this.dmPtlcnt),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Thời điểm đóng mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateForPDF(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidCloseDate),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                if (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidEstimatePrice) {
                    dataTable2.push([{
                        text: 'Giá dự toán',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidEstimatePrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                } else {
                    dataTable2.push([{
                        text: 'Giá gói thầu',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidPrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                }


                var docDefinition = {
                    content: [
                        [
                            {
                                text:  'BIÊN BẢN MỞ THẦU',
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                text: 'Thông tin chung',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable
                                }
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                            {
                                text: 'Thông tin gói thầu',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable2
                                }
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                            {text: 'Thông tin nhà thầu'},
                            table1tui
                        ],

                    ],
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                }

                pdfMake.createPdf(docDefinition).download("\n" + "Biên bản mở thầu.pdf");
            },
            //pdf make bien ban mo thau TBMT
            generateKqmtPDFVkAdb(detailKqmtCheck,isTabTC) {

                var table1tui = [];

                // if ((detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) {
                var table1tuiv1 = {
                    table: {
                        font: 'TimesNewRoman',
                        fontSize: 11,
                        lineHeight: 1.2,
                        widths: [10, 65, 60, 75, 25, 75,50,45,50],
                        body: [
                            [{text: 'STT', fillColor: '#DDDDDD',},
                                {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                                // ((detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                //     text: 'Thời gian thực hiện hợp đồng',
                                //     fillColor: '#DDDDDD',
                                // } : null,
                                {text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',},
                                {text: 'Thời gian thực hiện HĐ', fillColor: '#DDDDDD',},
                                // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},

                            ]
                        ]
                    }
                };
                table1tui.push(table1tuiv1);

                detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    table1tui[0].table.body.push(
                        [{text: (index + 1)},
                            {text: element?.contractorCode},
                            {text: (element.ventureName) ? element.ventureName : element.contractorName},
                            {text: this.currency(element?.bidPrice), alignment: 'right'},
                            {text: this.currency(element?.saleNumber), alignment: 'center'},
                            {text: this.currency(element?.bidFinalPrice), alignment: 'right'},
                            {text: this.currency(element?.bidGuarantee), alignment: 'right'},
                            {text: element?.bidGuaranteeValidity},
                            {text: (element?.contractPeriodDT ? element?.contractPeriodDT : '') + " " + this.getNameOfPeriod(element?.contractPeriodDTUnit)}
                        ])
                });
                // }
                // if (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) {
                //     var table1tuiv2 = {
                //         table: {
                //             font: 'TimesNewRoman',
                //             fontSize: 11,
                //             lineHeight: 1.2,
                //             widths: [25, 80, 75, 74, 45, 50, 65, 50],
                //             body: [
                //                 [{text: 'STT', fillColor: '#DDDDDD',},
                //                     {text: 'Mã định danh', fillColor: '#DDDDDD',},
                //                     {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                //                     {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                //                     {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                //                     // {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                //                     {text: 'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                //                     {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                //                     {text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',},
                //                     // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                //
                //                 ]
                //             ]
                //         }
                //     };
                //     table1tui.push(table1tuiv2);
                //     detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                //         table1tui[0].table.body.push(
                //             [{text: (index + 1)},
                //                 {text: element?.contractorCode},
                //                 {text: (element.ventureName) ? element.ventureName : element.contractorName},
                //                 {text: this.currency(element?.bidPrice), alignment: 'right'},
                //                 {text: this.currency(element?.saleNumber), alignment: 'center'},
                //                 // {text: this.currency(element?.lotNoValueDTOList[0].lotFinalPrice),alignment: 'right'},
                //                 {text: element?.bidValidityNum},
                //                 {text: this.currency(element?.bidGuarantee)},
                //                 {text: element?.bidGuaranteeValidity}
                //             ])
                //     });
                // }


                var tableDxkt = [
                    {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: (detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG') ? [25, 115, 120, 115, 116] : [25, 75, 75, 80, 75, 70,75],
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Hiệu lực E-HSĐXKT(ngày)', fillColor: '#DDDDDD',},
                                    (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                        text: 'Bảo đảm dự thầu(VND)',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                        text: 'Hiệu lực của BĐ DT (ngày)',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    {
                                        text: 'Thời gian thực hiện HĐ',
                                        fillColor: '#DDDDDD',
                                    }
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',}
                                ].filter(it => it != null)
                            ]
                        }
                    },
                ];

                detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    tableDxkt[0].table.body.push(
                        [{text: (index + 1)},
                            {text: element?.contractorCode},
                            {text: (element.ventureName) ? element.ventureName : element.contractorName},
                            {text: element?.bidValidityNum},
                            (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {text: this.formatNumberFunction(element?.bidGuarantee)} : null,
                            (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {text: element?.bidGuaranteeValidity} : null,
                            {text: (element?.contractPeriodDT ? element?.contractPeriodDT : '') + " " + this.getNameOfPeriod(element?.contractPeriodDTUnit)}
                            // {text: element?.alternativeTech == 0 ? 'Không' : 'Có'}
                        ].filter(it => it != null))
                });


                var tableDxtc = [
                    {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [10, 60, 60, 70, 35, 70, 65, 40,46],
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỉ lệ giảm giá %', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá', fillColor: '#DDDDDD',},
                                    {text: 'Bảo đảm dự thầu(VND)', fillColor: '#DDDDDD',},
                                    {text: 'Hiệu lực BĐDT (ngày)', fillColor: '#DDDDDD',},
                                    {text: 'Thời gian thực hiện hợp đồng', fillColor: '#DDDDDD',},
                                    // !(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG') ? {
                                    //     text: 'Bảo đảm dự thầu (VND)',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    // !(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG') ? {
                                    //     text: 'Hiệu lực của BĐ DT (ngày)',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',}
                                ].filter(it => it != null),
                            ]
                        }
                    },
                ];

                detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    tableDxtc[0].table.body.push([{text: (index + 1)},
                        {text: element?.contractorCode},
                        {text: (element.ventureName) ? element.ventureName : element.contractorName},
                        {text: this.currency(element?.bidPrice)},
                        {text: this.currency(element?.saleNumber)},
                        {text: this.currency(element?.bidFinalPrice)},
                        {text: this.currency(element?.bidGuarantee)},
                        // {text: this.currency(element?.lotNoValueDTOList[0].lotFinalPrice) + " " + element?.lotNoValueDTOList[0].lotPriceUnit},
                        {text: element?.bidGuaranteeValidity},
                        {text: element?.contractPeriodDT + " " + this.getNameOfPeriod(element?.contractPeriodDTUnit)},
                        // ((!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG'))) ? {text: this.formatNumberFunction(element?.bidGuarantee)} : null,
                        // (!(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundOutMngViewDTO?.bidForm == 'CHCTRG')) ? {text: element?.bidGuaranteeValidity} : null,
                        // {text: (element?.alternativeTech == 0) ? 'Không' : 'Có'}
                    ].filter(it => it != null));
                });


                var dataTable = [];
                dataTable.push([{
                    text: 'Mã TBMT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoNotifyContractorP.notifyNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Tên gói thầu',
                    fillColor: '#DDDDDD',
                }, {
                    // text: detailKqmtCheck?.bidoNotifyContractorP?.bidName,
                    text: detailKqmtCheck?.bidoNotifyContractorP.bidName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Số lượng nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: (detailKqmtCheck?.bidoBidroundOutMngViewDTO?.notifyNo == 'IB2300127676')?1:detailKqmtCheck?.bidoBidroundOutMngViewDTO?.countContractor ,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Thời điểm hoàn thành mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: (isTabTC == 1) ? this.formatDateForPDF(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.successBidOpenDateTc) : this.formatDateForPDF(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.successBidOpenDate),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Lĩnh vực',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoBidroundOutMngViewDTO?.investField, this.catInvestFields),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                var dataTable2 = [];
                dataTable2.push([{
                    text: 'Mã KHLCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoNotifyContractorP.planNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Tên kế hoạch LCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoNotifyContractorP.planName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Loại hợp đồng',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoNotifyContractorP?.cType, this.dmLhdLcnt),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Thời gian thực hiện hợp đồng',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoNotifyContractorP.cPeriod + " " + this.getNameOfPeriod(detailKqmtCheck?.bidoNotifyContractorP.cPeriodUnit),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Hình thức lựa chọn nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoNotifyContractorP.bidForm, this.bidForms),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                // dataTable2.push([{
                //     text: 'Phương thức lựa chọn nhà thầu',
                //     fillColor: '#DDDDDD',
                // }, {
                //     text: this.getNameCatByCodeCat(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode, this.dmPtlcnt),
                //     colSpan: 3,
                // }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Thời điểm đóng mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateForPDF(detailKqmtCheck?.bidoNotifyContractorP.bidCloseDate),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                if (detailKqmtCheck?.bidoNotifyContractorP?.bidEstimatePrice) {
                    dataTable2.push([{
                        text: 'Dự toán',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidoNotifyContractorP?.bidEstimatePrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                }
                // }else{
                if (detailKqmtCheck?.bidoNotifyContractorP?.bidPrice) {

                    dataTable2.push([{
                        text: 'Giá gói thầu',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidoNotifyContractorP?.bidPrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                }


                var docDefinition = {
                    content: [
                        [
                            {
                                text: 'BIÊN BẢN MỞ THẦU',
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                text: 'Thông tin chung',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable
                                }
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                            {
                                text: 'Thông tin gói thầu',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable2
                                }
                            },
                            (detailKqmtCheck?.bidoNotifyContractorP?.bidMode == '1_HTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidoNotifyContractorP?.bidMode == '1_HTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (isTabTC != 1 && detailKqmtCheck?.bidoNotifyContractorP?.bidMode == '1_HTHS') ? {text: 'Kết quả mở hồ sơ đề xuất kỹ thuật',} : {},
                            (isTabTC != 1 && detailKqmtCheck?.bidoNotifyContractorP?.bidMode == '1_HTHS') ? tableDxkt : {},
                            (isTabTC != 1 && detailKqmtCheck?.bidoNotifyContractorP?.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (isTabTC == 1 && detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? {text: 'Kết quả mở hồ sơ đề xuất tài chính',} : {},
                            (isTabTC == 1 && detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundOutMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? tableDxtc : {},
                            (detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_MTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_MTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_MTHS') ? {text: 'Thông tin nhà thầu',} : {},
                            (detailKqmtCheck?.bidoNotifyContractorP.bidMode == '1_MTHS') ? table1tui : {},


                        ],

                    ],
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                }
                pdfMake.createPdf(docDefinition).download("\n" + "Biên bản mở thầu.pdf");
            },
            genFooterPDF(currentPage, pageCount, pageSize){
                return {
                    stack: [
                        {
                            canvas: [
                                {
                                    type: 'line',
                                    x1: 0,
                                    y1: 5,
                                    x2: pageSize.width,
                                    y2: 5,
                                    lineWidth: 0.5,
                                },
                            ],
                            margin: [0, 10, 0, 0]
                        },
                        {
                            columns: [
                                {
                                    text: ' Tài liệu được in từ Hệ thống e-GP tại địa chỉ https://muasamcong.mpi.gov.vn.',
                                    width: '70%',
                                    margin: [40, 0, 0, 0]
                                },
                                {
                                    text: currentPage.toString(),
                                    alignment: 'right',
                                    margin: [0, 0, 50, 0]
                                },
                            ],
                            italics: true,
                            fontSize: 10,
                            margin: [0, 5, 0, 0]
                        },
                    ],
                }
            },
            generateKqmtPDFVk(detailKqmtCheck,isTabTC) {

                var table1tui = [
                    // {
                    //     table: {
                    //         font: 'TimesNewRoman',
                    //         fontSize: 11,
                    //         lineHeight: 1.2,
                    //         widths: [25, 50, 50, 50, 50, 50, 45, 50, 45, 45],
                    //         body: [
                    //             [{text: 'STT', fillColor: '#DDDDDD',},
                    //                 {text: 'Mã định danh', fillColor: '#DDDDDD',},
                    //                 {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                    //                 {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                    //                 {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                    //                 {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                    //                 {text: 'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                    //                 (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm =='CHCTRG'))?{text: 'Bảo đảm dự thầu(VND)', fillColor: '#DDDDDD',}:null,
                    //                 (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm =='CHCTRG'))?{text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',}:null,
                    //                 ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm =='CHCTRG'))?{text: 'Thời gian thực hiện HĐ', fillColor: '#DDDDDD',}:null,
                    //                 // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                    //
                    //             ]
                    //         ]
                    //     }
                    // },
                ];

                if ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) {
                    var table1tuiv1 = {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [25,75,74,75,40,75,50,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')?60:null,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1) ?60:null
                            ].filter(it => it != null),
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                    {text: (detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? 'Hiệu lực báo giá (ngày)' : ((detailKqmtCheck?.bidoBidroundMngViewDTO?.isInternet) ? 'Hiệu lực E-HSDT (ngày)' :   'Hiệu lực HSDT (ngày)'), fillColor: '#DDDDDD',},
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},

                                ].filter(it => it != null)
                            ]
                        }
                    };
                    table1tui.push(table1tuiv1);

                    detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                        table1tui[0].table.body.push(
                            [{text: (index + 1)},
                                {text: element?.contractorCode},
                                {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                // {text: this.currency(element?.lotNoValueDTOList[0]?.lotPrice), alignment: 'right'},
                                {text: this.currency(element?.bidPrice), alignment: 'right'},
                                {text: this.currency(element?.saleNumber), alignment: 'center'},
                                {text: this.currency(element?.bidFinalPrice), alignment: 'right'},
                                {text: element?.bidValidityNum},
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') &&  this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null,
                            ].filter(it => it!= null))
                    });
                }
                if (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) {
                    var table1tuiv2 = {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [25,55,60,60,35,50,40,53,45,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')?40:null,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1) ?40:null
                            ].filter(it => it != null),
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                    {text: detailKqmtCheck?.bidoBidroundMngViewDTO?.isInternet ? 'Hiệu lực E-HSDT (ngày)' :   'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                                    {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',},
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // MPI_EGP_20022_BH-7856 PTV thì view Chi tiết xem mẫu tiến độ
                                    // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV')) ? {
                                    //     text: 'Chi tiết xem mẫu tiến độ',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1)) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},

                                ].filter(it => it != null)
                            ]
                        }
                    };
                    table1tui.push(table1tuiv2);

                    detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                        table1tui[0].table.body.push(
                            [{text: (index + 1)},
                                {text: element?.contractorCode},
                                {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                {text: this.currency(element?.bidPrice), alignment: 'right'},
                                {text: this.currency(element?.saleNumber), alignment: 'center'},
                                {text: this.currency(element?.bidFinalPrice),alignment: 'right'},
                                {text: element?.bidValidityNum},
                                {text: this.currency(element?.bidGuarantee ? element?.bidGuarantee : detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue) + ((this.checkMuoiTrieu(element?.bidGuarantee) || this.checkMuoiTrieu(detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue)) ? ' (Cam kết trong đơn dự thầu)' : '')},
                                {text: element?.bidGuaranteeValidity},
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && (this.bidoNotifyView?.medicalType == 0 || this.bidoNotifyView?.bidForm == 'CHCTRG') && this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null,
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.medicalType != 0 && this.bidoNotifyView?.bidForm != 'CHCTRG' && this.bidoNotifyView?.isInternet == 1)) && this.bidoNotifyView?.isMedicine != 1) ? {text: 'Xem chi tiết tại mẫu tiến độ'} : null
                            ].filter(it => it != null))
                    });
                }


                var tableDxkt = [
                    {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            // widths: (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? [25, 115, 120, 115,116,100]: (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG'))?[25, 90, 95, 90, 90, 92]:[25, 115, 120, 115,100,100] ,
                            widths: [25,80, 120, 48,
                                !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?75:null,
                                !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?60:null,
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL') && this.bidoNotifyView?.isMedicine != 1) ?70:null,
                                ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ?70:null
                            ].filter(it => it != null),
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Hiệu lực E-HSĐXKT(ngày)', fillColor: '#DDDDDD',},
                                    (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                        text: 'Bảo đảm dự thầu(VND)',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                        text: 'Hiệu lực của BĐ DT (ngày)',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' && this.bidoNotifyView?.isMedicine != 1) ? {
                                    //     text: 'Chi tiết xem mẫu tiến độ',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',}
                                ].filter(it => it != null)
                            ]
                        }
                    },
                ];

                detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    tableDxkt[0].table.body.push(
                        [{text: (index + 1)},
                            {text: element?.contractorCode},
                            {text: (element.ventureName) ? element.ventureName : element.contractorName},
                            {text: element?.bidValidityNum},
                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: this.formatNumberFunction(element?.bidGuarantee ? element?.bidGuarantee : detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue) +
                                    ((this.checkMuoiTrieu(element?.bidGuarantee) || this.checkMuoiTrieu(detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue)) ? ' (Cam kết trong đơn dự thầu)' : '')} : null,
                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: element?.bidGuaranteeValidity} : null,
                            ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && (this.bidoNotifyView?.medicalType == 0 || this.bidoNotifyView?.bidForm == 'CHCTRG') && this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null,
                            ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.medicalType != 0 && this.bidoNotifyView?.bidForm != 'CHCTRG' && this.bidoNotifyView?.isInternet == 1))&& this.bidoNotifyView?.isMedicine != 1) ? {text:'Xem chi tiết tại mẫu tiến độ'} : null
                            // {text: element?.alternativeTech == 0 ? 'Không' : 'Có'}
                        ].filter(it => it != null))
                });


                var tableDxtc = [
                    {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            // widths: (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? [20, 80, 85, 80, 60, 80, 68] :[10,55,60,70,40,70,40,65,45],
                            // widths: [50,60,65,30,55,25,40,47,
                            //     !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?45:null,
                            //     !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?45:null,
                            //     (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL') && this.bidoNotifyView?.isMedicine != 1 ?40:null,
                            //     (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1)  ?40:null
                            // ].filter(it => it != null),
                            widths: [60,70,75,58,75,this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? 35 : null,41,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL') && this.bidoNotifyView?.isMedicine != 1 ?40:null,
                                (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.isMedicine != 1)  ?40:null
                            ].filter(it => it != null),
                            body: [
                                [
                                    // {text: 'STT', fillColor: '#DDDDDD',},
                                    {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                    {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                    {text: 'Tỉ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                    {text: 'Giá dự thầu sau giảm giá', fillColor: '#DDDDDD',},
                                    this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? {text: 'Điểm kỹ thuật', fillColor: '#DDDDDD',} : null,
                                    {text: 'Hiệu lực E-HSĐXTC (ngày)', fillColor: '#DDDDDD',},
                                    // !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? {
                                    //     text: 'Bảo đảm dự thầu (VND)',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    // !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? {
                                    //     text: 'Hiệu lực của BĐ DT (ngày)',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian thực hiện hợp đồng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' && this.bidoNotifyView?.isMedicine != 1) ? {
                                    //     text: 'Chi tiết xem mẫu tiến độ',
                                    //     fillColor: '#DDDDDD',
                                    // } : null,
                                    ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && this.bidoNotifyView?.isMedicine != 1) ? {
                                        text: 'Thời gian giao hàng',
                                        fillColor: '#DDDDDD',
                                    } : null,
                                    // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',}
                                ].filter(it => it != null),
                            ]
                        }
                    },
                ];

                detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    tableDxtc[0].table.body.push([
                        // {text: (index + 1)},
                        {text: element?.contractorCode},
                        {text: (element.ventureName) ? element.ventureName : element.contractorName},
                        {text: this.currency(element?.lotNoValueDTOList?.[0].lotPrice) + " " + element?.bidPriceUnit},
                        {text: this.currency(element?.saleNumber)},
                        {text: this.currency(element?.lotNoValueDTOList?.[0].lotFinalPrice) + " " + element?.lotNoValueDTOList?.[0].lotPriceUnit},
                        this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? {text: element?.techScore || element?.lotNoValueDTOList?.[0]?.bidOpenView?.[0]?.techScore } : null,
                        {text: element?.bidValidityNum},
                        // ((!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG'))) ? {text: this.formatNumberFunction(element?.bidGuarantee ? element?.bidGuarantee : detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue) + (element?.bidGuarantee ? '' : ' (VND) (Cam kết tiền mặt)')} : null,
                        // (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: element?.bidGuaranteeValidity} : null,
                        ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') && (this.bidoNotifyView?.medicalType == 0 || this.bidoNotifyView?.bidForm == 'CHCTRG') && this.bidoNotifyView?.isMedicine != 1) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null,
                        ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.bidoNotifyView?.medicalType != 0 && this.bidoNotifyView?.bidForm != 'CHCTRG' && this.bidoNotifyView?.isInternet == 1)) && this.bidoNotifyView?.isMedicine != 1) ? {text:'Xem chi tiết tại mẫu tiến độ'} : null
                        // {text: (element?.alternativeTech == 0) ? 'Không' : 'Có'}
                    ].filter(it => it != null));
                });
                if(detailKqmtCheck?.bidoBidroundMngViewDTO?.isMultiLot) {
                    // 1 tui
                    if (this.viewInforNT == 0) {
                        table1tui = [];
                        if (detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG') {
                            table1tuiv1 = {
                                table: {
                                    font: 'TimesNewRoman',
                                    fontSize: 11,
                                    lineHeight: 1.2,
                                    widths: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? (!this.isMedicine() ? [30, 60, 31, 60, 31, 45, 30, 40, 30, 40, 40] : [33, 70, 33, 70, 33, 50, 33, 45, 33, 46]) : (!this.isMedicine() ? [40, 70, 45, 70, 40, 50, 40, 50, 50] : [45, 85, 50, 84, 45, 55, 45, 55]),
                                    body: [
                                        [
                                            {text: 'Mã phần/lô', fillColor: '#DDDDDD',},
                                            {text: this.getLotNameColumn(), fillColor: '#DDDDDD',},
                                            {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                            {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                            detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? {
                                                text: this.isMedicine() ? 'Hiệu lực HSDT (ngày)' : 'Hiệu lực E-HSDT (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? {
                                                text: 'Giá trị bảo đảm dự thầu (VND)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            {text: 'Hiệu lực của BĐDT (ngày)', fillColor: '#DDDDDD',},

                                            {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                            {text: 'Tỉ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                            {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                            !this.isMedicine() ? {
                                                text: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField === 'HH' ? ('Thời gian giao hàng (ngày)') : 'Thời gian thực hiện hợp đồng (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                                        ].filter(it => it != null)
                                    ]
                                }
                            };
                            table1tui.push(table1tuiv1);
                            this.bidoLotOpenGroupsOfDXKT?.forEach((element, index) => {
                                table1tui[0].table.body.push(
                                    [
                                        {text: element?.items[0]?.lotNo},
                                        {
                                            text: element?.items[0]?.lotName,
                                            colSpan: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? (!this.isMedicine() ? 10 : 9) : (!this.isMedicine() ? 8 : 7)
                                        },
                                    ]);
                                element?.items.forEach(it => {
                                    table1tui[0].table.body.push(
                                        [
                                            {text: ''},
                                            {text: ''},
                                            {text: it?.contractorCode},
                                            {text: it?.ventureName ? it?.ventureName : it?.contractorName},
                                            detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? {text: it?.bidValidityNum} : null,
                                            detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? {text: (it?.bidGuarantee ? this.currency(it?.bidGuarantee) : (it?.totalGuaranteeValue ? (this.currency(it?.totalGuaranteeValue) + ' ') : '')) + ((this.checkMuoiTrieu(it?.bidGuarantee) || this.checkMuoiTrieu(it?.totalGuaranteeValue)) ? ' (Cam kết trong đơn dự thầu)' : '')} : null,
                                            {text: it?.bidGuaranteeValidity},

                                            {text: this.currency(it?.lotPrice)},
                                            {text: it?.discountPercent ? it?.discountPercent : '-'},
                                            {text: this.currency(it?.lotFinalPrice)},
                                            !this.isMedicine() ? {text: this.isMedical() ? (it?.estimateDateMedical ? it?.estimateDateMedical : '') : (it?.bidContractPeriod ? it?.bidContractPeriod : '')} : null,
                                        ].filter(it => it != null)
                                    )
                                })
                            });
                        } else {
                            table1tuiv1 = {
                                table: {
                                    font: 'TimesNewRoman',
                                    fontSize: 11,
                                    lineHeight: 1.2,
                                    widths: (!this.isMedicine() ? [40, 70, 45, 70, 40, 50, 40, 50, 50] : [45, 85, 50, 84, 45, 55, 45, 55]),
                                    body: [
                                        [
                                            {text: 'Mã phần/lô', fillColor: '#DDDDDD',},
                                            {text: 'Tên phần/lô', fillColor: '#DDDDDD',},
                                            {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                            {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                            {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                            {text: 'Tỉ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                            {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                            {text: 'Hiệu lực của báo giá (ngày)', fillColor: '#DDDDDD',},
                                            !this.isMedicine() ? {
                                                text: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField === 'HH' ? ('Thời gian giao hàng (ngày)') : 'Thời gian thực hiện hợp đồng (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                                        ].filter(it => it != null)
                                    ]
                                }
                            };
                            table1tui.push(table1tuiv1);
                            this.bidoLotOpenGroupsOfDXKT?.forEach((element, index) => {
                                table1tui[0].table.body.push(
                                    [
                                        {text: element?.items[0]?.lotNo},
                                        {
                                            text: element?.items[0]?.lotName,
                                            colSpan: 8
                                        },
                                    ]);
                                element?.items.forEach(it => {
                                    table1tui[0].table.body.push(
                                        [
                                            {text: ''},
                                            {text: ''},
                                            {text: it?.contractorCode},
                                            {text: it?.ventureName ? it?.ventureName : it?.contractorName},

                                            {text: this.currency(it?.lotPrice)},
                                            {text: it?.discountPercent ? it?.discountPercent : '-'},
                                            {text: this.currency(it?.lotFinalPrice)},
                                            {text: it?.bidValidityNum},
                                            !this.isMedicine() ? {text: it?.estimateDateMedical ? it?.estimateDateMedical : ''} : null,
                                        ].filter(it => it != null)
                                    )
                                })
                            });
                        }
                    } else {
                        // view theo nhà thầu 1 túi
                        table1tui = [];
                        table1tuiv1 = {
                            table: {
                                font: 'TimesNewRoman',
                                fontSize: 11,
                                lineHeight: 1.2,
                                widths: detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? (!this.isMedicine() ? [37, 60, 38, 31, 60, 35, 60, 30, 60, 35] : [44, 60, 41, 34, 60, 34, 75, 30, 75]) : (!this.isMedicine() ? [52, 67, 47, 38, 90, 44, 90, 35] : [66, 81, 55, 38, 90, 44, 90]),
                                body: [
                                    [
                                        {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                        {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                        {text: 'Số phần của gói thầu đã tham dự', fillColor: '#DDDDDD',},
                                        {
                                            text: detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? 'Hiệu lực HSDT (ngày)' : 'Hiệu lực của báo giá (ngày)',
                                            fillColor: '#DDDDDD',
                                        },
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                            text: 'Giá trị bảo đảm dự thầu (VND)',
                                            fillColor: '#DDDDDD',
                                        } : null,
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                            text: 'Hiệu lực của BĐ DT (ngày)',
                                            fillColor: '#DDDDDD',
                                        } : null,
                                        {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                        {text: 'Tỉ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                        {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                        !this.isMedicine() ? {
                                            text: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField === 'HH' ? ('Thời gian giao hàng (ngày)') : 'Thời gian thực hiện hợp đồng (ngày)',
                                            fillColor: '#DDDDDD',
                                        } : null,
                                        // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                                    ].filter(it => it != null)
                                ]
                            }
                        };
                        table1tui.push(table1tuiv1);
                        this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.forEach((element, index) => {
                            table1tui[0].table.body.push(
                                [
                                    {text: element?.contractorCode},
                                    {
                                        text: element?.ventureName ? element?.ventureName : element?.contractorName,
                                    },
                                    {
                                        text: element?.lotNoValueDTOList?.[0]?.bidOpenView?.length,
                                    },
                                    {
                                        text: element?.bidValidityNum,
                                    },
                                    detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                        text: element?.bidGuarantee ? (this.currency(element?.bidGuarantee) + (this.checkMuoiTrieu(element?.bidGuarantee) ? ' (Cam kết trong đơn dự thầu)' : '')) : (this.currency(element?.totalGuaranteeValue) + (this.checkMuoiTrieu(element?.totalGuaranteeValue) ? ' (Cam kết trong đơn dự thầu)' : ''))
                                    } : null,
                                    detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                        text: element?.bidGuaranteeValidity,
                                    } : null,
                                    {
                                        text: this.currency(element?.lotNoValueDTOList?.[0]?.lotPrice),
                                    },
                                    {
                                        text: !element?.lotNoValueDTOList?.[0]?.saleNumber && element?.lotNoValueDTOList?.[0]?.lotPrice !== element?.lotNoValueDTOList?.[0]?.lotFinalPrice ?
                                            '(giảm giá chi tiết theo từng phần)' : (element?.lotNoValueDTOList?.[0]?.saleNumber ? element?.lotNoValueDTOList?.[0]?.saleNumber : '0'),
                                    },
                                    {
                                        text: this.currency(element?.lotNoValueDTOList?.[0]?.lotFinalPrice),
                                    },
                                    !this.isMedicine() ? {
                                        text: '',
                                    } : null,
                                ].filter(it => it != null));
                            element?.lotNoValueDTOList?.[0]?.bidOpenView.forEach(it => {
                                table1tui[0].table.body.push(
                                    [
                                        {text: ''},
                                        {text: ''},
                                        {text: it?.lotNo + '-' + it?.lotName},
                                        {text: ''},
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {text: this.currency(it?.bidGuaranteed)} : null,
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {text: it?.contractPeriodDT} : null,
                                        {text: this.currency(it?.lotPrice)},
                                        {text: it?.discountPercent ? it?.discountPercent : '0'},
                                        {text: this.currency(it?.lotFinalPrice)},
                                        !this.isMedicine() ? {text: this.dtlRoundMngRes?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? (this.isMedical() ? (it?.estimateDateMedical ? it?.estimateDateMedical : '') : (it?.bidContractPeriod ? it?.bidContractPeriod : '')) : (it?.estimateDateMedical ? it?.estimateDateMedical : '')} : null,
                                    ].filter(it => it != null)
                                )
                            })
                        });
                    }

                    // table1tuiv1 = {
                    //     table: {
                    //         font: 'TimesNewRoman',
                    //         fontSize: 11,
                    //         lineHeight: 1.2,
                    //         widths: [40,55,80,35,60,35,60,30,60],
                    //         body: [
                    //             [
                    //                 {text: 'Mã định danh', fillColor: '#DDDDDD',},
                    //                 {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                    //                 {text: 'Số phần của gói thầu đã tham dự', fillColor: '#DDDDDD',},
                    //                 {text: 'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                    //                 {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                    //                 {text: 'Hiệu lực của BĐ DT (ngày)', fillColor: '#DDDDDD',},
                    //                 {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                    //                 {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                    //                 {text: 'Giá dự thầu sau giảm giá(VND)', fillColor: '#DDDDDD',},
                    //                 // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                    //             ].filter(it => it != null)
                    //         ]
                    //     }
                    // };
                    // table1tui.push(table1tuiv1);

                    // detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                    //     table1tui[0].table.body.push(
                    //         [
                    //             {text: element?.contractorCode},
                    //             {text: (element.ventureName) ? element.ventureName : element.contractorName},
                    //             // {text: this.currency(element?.lotNoValueDTOList[0]?.lotPrice), alignment: 'right'},
                    //             {text: element?.lotNoValueDTOList[0]?.bidOpenView.length},
                    //             {text: element?.bidValidityNum},
                    //             {text: this.currency(element?.bidGuarantee)},
                    //             {text: element?.bidGuaranteeValidity},
                    //             {text:this.currency(element?.lotNoValueDTOList[0]?.lotPrice)},
                    //             {text:element?.lotNoValueDTOList[0]?.saleNumber},
                    //             {text:this.currency(element?.lotNoValueDTOList[0]?.lotFinalPrice)},
                    //         ]);
                    //     element?.lotNoValueDTOList[0]?.bidOpenView.forEach(it => {
                    //         table1tui[0].table.body.push(
                    //             [
                    //                 {text: ''},
                    //                 {text: ''},
                    //                 {text: it?.lotNo + '-' + it?.lotName},
                    //                 {text: ''},
                    //                 {text: this.currency(it?.bidGuaranteed)},
                    //                 {text: it?.contractPeriodDT},
                    //                 {text: this.currency(it?.lotPrice)},
                    //                 {text: it?.discountPercent},
                    //                 {text: this.currency(it?.lotFinalPrice)},
                    //             ]
                    //         )
                    //     })
                    // });

                    // tui kt
                    if (this.viewInforNTofDXKT == 0){
                        tableDxkt = [
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    fontSize: 11,
                                    lineHeight: 1.2,
                                    // widths: (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? [25, 115, 120, 115,116,100]: (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG'))?[25, 90, 95, 90, 90, 92]:[25, 115, 120, 115,100,100] ,
                                    // widths: [55,75, 70, 75,30,
                                    //     !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?70:null,
                                    //     !(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ?40:null,
                                    //     (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')?45:null,
                                    //     (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH') ?45:null
                                    // ].filter(it => it != null),
                                    widths: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? (!this.isMedicine() ? [55, 75, 70, 75, 34, 70, 40, 45] : [60, 87, 78, 87, 38, 78, 45]) : (!this.isMedicine() ? [75, 100, 95, 100, 62, 50] : [90, 115, 110, 115, 61]),
                                    body: [
                                        [
                                            {text: 'Mã phần/lô', fillColor: '#DDDDDD',},
                                            {text: this.getLotNameColumn(), fillColor: '#DDDDDD',},
                                            {text: 'Mã định danh ', fillColor: '#DDDDDD',},
                                            {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                            {text: 'Hiệu lực E-HSĐXKT (ngày)', fillColor: '#DDDDDD',},
                                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                                text: 'Giá trị bảo đảm dự thầu (VND)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                                text: 'Hiệu lực của BĐ DT (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            !this.isMedicine() ? {
                                                text: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField === 'HH' ? ('Thời gian giao hàng (ngày)') : 'Thời gian thực hiện hợp đồng',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL')) ? {
                                            //     text: 'Thời gian thực hiện hợp đồng',
                                            //     fillColor: '#DDDDDD',
                                            // } : null,
                                            // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && this.isMedical() )) ? {
                                            //     text: 'Tiến độ cung cấp',
                                            //     fillColor: '#DDDDDD',
                                            // } : null,
                                            // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH' && !this.isMedical() )) ? {
                                            //     text: 'Thời gian giao hàng(ngày)',
                                            //     fillColor: '#DDDDDD',
                                            // } : null,
                                            // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',}
                                        ].filter(it => it != null)
                                    ]
                                }
                            },
                        ];

                        this.bidoLotOpenGroupsOfDXKT.forEach((element) => {
                            tableDxkt[0].table.body.push([
                                // {text: element?.contractorCode},
                                // {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                // {text:  element?.lotNoValueDTOList[0]?.bidOpenView?.length},
                                // {text: element?.bidValidityNum},
                                // (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: this.formatNumberFunction(element?.bidGuarantee ? element?.bidGuarantee : detailKqmtCheck?.bidoBidroundMngViewDTO?.bidGuaranteeValue) + (element?.bidGuarantee ? '' : ' (VND) (Cam kết tiền mặt)')} : null,
                                // (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: element?.bidGuaranteeValidity} : null,
                                // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH')) ? {text: ((element?.contractPeriodDT) ? (element?.contractPeriodDT) : '') + " " + ((element?.contractPeriodDT) ? this.getNameOfPeriod(element?.contractPeriodDTUnit) : '')} : null
                                // // {text: element?.alternativeTech == 0 ? 'Không' : 'Có'}
                                {text: element?.items[0]?.lotNo},
                                {text: element?.items[0]?.lotName},
                                {text: ''},
                                {text: ''},
                                {text: ''},
                                (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: ''} : null,
                                (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: ''} : null,
                                // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH')) ? {text: ''} : null,
                                !this.isMedicine() ? {text: ''} : null,

                            ].filter(it => it != null));
                            element?.items.forEach(it => {
                                tableDxkt[0].table.body.push([
                                    {text: ''},
                                    {text: ''},
                                    {text: it?.contractorCode},
                                    {text: it?.ventureName ? it?.ventureName : it?.contractorName},
                                    {text: it?.bidValidityNum},
                                    (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: (it?.bidGuarantee ? this.currency(it?.bidGuarantee) : (it?.totalGuaranteeValue ? (this.currency(it?.totalGuaranteeValue) + ' ') : '')) + ((this.checkMuoiTrieu(it?.bidGuarantee) || this.checkMuoiTrieu(it?.totalGuaranteeValue)) ? ' (Cam kết trong đơn dự thầu)' : '')} : null,
                                    (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {text: it?.bidGuaranteeValidity} : null,
                                    // ((detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' ||  detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'PTV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'XL' || detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'HH')) ? {text: this.isMedical() ? (it?.estimateDateMedical ? it?.estimateDateMedical : '') : (it?.bidContractPeriod ? it?.bidContractPeriod : '')} : null
                                    !this.isMedicine() ? {text: this.isMedical() ? (it?.estimateDateMedical ? it?.estimateDateMedical : '') : (it?.bidContractPeriod ? it?.bidContractPeriod : '')} : null,
                                ].filter(it => it != null));
                            })
                        });
                    } else {
                        tableDxkt = [
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    fontSize: 11,
                                    lineHeight: 1.2,
                                    widths: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField !== 'TV' && detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm !== 'CHCTRG' ? (!this.isMedicine() ? [55, 75, 70, 75, 70, 60, 66] : [60, 97, 88, 97, 78, 60]) : (!this.isMedicine() ? [85, 110, 105, 110, 74] : [98, 135, 130, 135]),
                                    body: [
                                        [
                                            {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                            {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                            {text: 'Số phần của gói thầu đã tham dự', fillColor: '#DDDDDD',},
                                            {
                                                text: 'Hiệu lực E-HSĐXKT (ngày)',
                                                fillColor: '#DDDDDD',
                                            },
                                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                                text: 'Giá trị bảo đảm dự thầu (VND)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            (!(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG')) ? {
                                                text: 'Hiệu lực của BĐ DT (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            !this.isMedicine() ? {
                                                text: detailKqmtCheck?.bidoBidroundMngViewDTO?.investField === 'HH' ? ('Thời gian giao hàng (ngày)') : 'Thời gian thực hiện hợp đồng (ngày)',
                                                fillColor: '#DDDDDD',
                                            } : null,
                                            // {text: 'Phương án kỹ thuật thay thế', fillColor: '#DDDDDD',},
                                        ].filter(it => it != null)
                                    ]
                                }
                            },
                        ];
                        this.dtlRoundMngRes?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.forEach((element, index) => {
                            tableDxkt[0].table.body.push(
                                [
                                    {text: element?.contractorCode},
                                    {
                                        text: element?.ventureName ? element?.ventureName : element?.contractorName,
                                    },
                                    {
                                        text: element?.lotNoValueDTOList?.[0]?.bidOpenView?.length,
                                    },
                                    {
                                        text: element?.bidValidityNum,
                                    },
                                    detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                        text: element?.bidGuarantee ? (this.currency(element?.bidGuarantee) + (this.checkMuoiTrieu(element?.bidGuarantee) ? ' (Cam kết trong đơn dự thầu)' : '')) : (this.currency(element?.totalGuaranteeValue) + (this.checkMuoiTrieu(element?.totalGuaranteeValue) ? ' (Cam kết trong đơn dự thầu)' : ''))
                                    } : null,
                                    detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {
                                        text: element?.bidGuaranteeValidity,
                                    } : null,
                                    !this.isMedicine() ? {
                                        text: '',
                                    } : null,
                                ].filter(it => it != null));
                            element?.lotNoValueDTOList?.[0]?.bidOpenView.forEach(it => {
                                tableDxkt[0].table.body.push(
                                    [
                                        {text: ''},
                                        {text: ''},
                                        {text: it?.lotNo + '-' + it?.lotName},
                                        {text: ''},
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {text: this.currency(it?.bidGuaranteed)} : null,
                                        detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? {text: it?.contractPeriodDT} : null,
                                        !this.isMedicine() ? {text: this.dtlRoundMngRes?.bidoBidroundMngViewDTO?.bidForm != 'CHCTRG' ? (this.isMedical() ? (it?.estimateDateMedical ? it?.estimateDateMedical : '') : (it?.bidContractPeriod ? it?.bidContractPeriod : '')) : (it?.estimateDateMedical ? it?.estimateDateMedical : '')} : null,
                                    ].filter(it => it != null)
                                )
                            })
                        });
                    }

                    if (this.processApply === 'LDT') {
                        // tui tc
                        if(this.viewInforNTofDXTC == 0) {
                            tableDxtc = [
                                {
                                    table: {
                                        font: 'TimesNewRoman',
                                        fontSize: 11,
                                        lineHeight: 1.2,
                                        // widths: (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? [20, 80, 85, 80, 60, 80, 68] :[10,55,60,70,40,70,40,65,45],
                                        widths: (this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1) ? [40, 70, 70, 70, 33, 60, 60, 60] : [50, 80, 80, 80, 60, 60, 60],
                                        body: [
                                            [
                                                {text: 'Mã phần/lô', fillColor: '#DDDDDD',},
                                                {text: this.getLotNameColumn(), fillColor: '#DDDDDD',},
                                                {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                                {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                                this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? {
                                                    text: 'Điểm kỹ thuật',
                                                    fillColor: '#DDDDDD'
                                                } : null,
                                                {text: 'Giá dự thầu(VND)', fillColor: '#DDDDDD',},
                                                {text: 'Tỉ lệ giảm giá(%)', fillColor: '#DDDDDD',},
                                                {text: 'Giá dự thầu sau giảm giá(VND)', fillColor: '#DDDDDD',},
                                            ].filter(item => item != null),
                                        ]
                                    }
                                },
                            ];
                            this.bidoLotOpenGroupsOfDXTC.forEach((element, index) => {
                                tableDxtc[0].table.body.push([
                                    {text: element?.items[0]?.lotNo},
                                    {text: element.items[0]?.lotName},
                                    {text: ''},
                                    {text: ''},
                                    this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? {text: ''} : null,
                                    {text: ''},
                                    {text: ''},
                                    {text: ''},
                                ].filter(item => item != null));
                                element?.items.forEach(it => {
                                    tableDxtc[0].table.body.push([
                                        {text: ''},
                                        {text: ''},
                                        {text: it?.contractorCode},
                                        {text: it?.ventureName ? it?.ventureName : it?.contractorName},
                                        this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1 ? {text: it?.techScore} : null,
                                        {text: this.currency(it?.lotPrice)},
                                        {text: it?.discountPercent ? it?.discountPercent : '-'},
                                        {text: this.currency(it?.lotFinalPrice)},
                                    ].filter(item => item != null));
                                })
                            });
                        } else {
                            tableDxtc = [
                                {
                                    table: {
                                        font: 'TimesNewRoman',
                                        fontSize: 11,
                                        lineHeight: 1.2,
                                        widths: (this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1) ? [60, 70, 70, 50, 33, 75, 30, 75] : [60, 70, 70, 50, 95, 30, 95],
                                        body: [
                                            [
                                                {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                                {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                                {text: 'Số phần của gói thầu đã tham dự', fillColor: '#DDDDDD',},
                                                {
                                                    text: 'Hiệu lực E-HSĐXTC (ngày)',
                                                    fillColor: '#DDDDDD',
                                                },
                                                (this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1) ? {
                                                    text: 'Điểm kỹ thuật',
                                                    fillColor: '#DDDDDD',
                                                } : null,
                                                {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                                {text: 'Tỉ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                                {text: 'Giá dự thầu sau giảm giá (VND)', fillColor: '#DDDDDD',},
                                            ].filter(it => it != null)
                                        ]
                                    }
                                },
                            ];
                            this.dtlRoundMngResTC?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.forEach((element, index) => {
                                tableDxtc[0].table.body.push(
                                    [
                                        {text: element?.contractorCode},
                                        {
                                            text: element?.ventureName ? element?.ventureName : element?.contractorName,
                                        },
                                        {
                                            text: element?.lotNoValueDTOList?.[0]?.bidOpenView?.length,
                                        },
                                        {
                                            text: element?.bidValidityNum,
                                        },
                                        (this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1) ? {text: ''} : null,
                                        {text: ''},
                                        {
                                            text: (!element?.saleNumber && element?.bidPrice !== element?.bidFinalPrice) ? '(giảm giá chi tiết theo từng phần)' : (element?.saleNumber ? element?.saleNumber : '-'),
                                        },
                                        {text: ''},
                                    ].filter(it => it != null));
                                element?.lotNoValueDTOList?.[0]?.bidOpenView.forEach(it => {
                                    tableDxtc[0].table.body.push(
                                        [
                                            {text: ''},
                                            {text: ''},
                                            {text: it?.lotNo + '-' + it?.lotName},
                                            {text: ''},
                                            (this.isDisplayTechScore() || this.bidoNotifyView?.isMedicine == 1) ? {text:it?.techScore}:null,
                                            {text: this.currency(it?.lotPrice)},
                                            {text: it?.discountPercentLo ? it?.discountPercentLo : '-'},
                                            {text: this.currency(it?.lotFinalPrice)},
                                        ].filter(it => it != null)
                                    )
                                })
                            })
                        }

                    } else if (this.processApply === 'KHAC' || this.processApply === 'CPTPP') {
                        tableDxtc = [
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    fontSize: 11,
                                    lineHeight: 1.2,
                                    // widths: (detailKqmtCheck?.bidoBidroundMngViewDTO?.investField == 'TV' || detailKqmtCheck?.bidoBidroundMngViewDTO?.bidForm == 'CHCTRG') ? [20, 80, 85, 80, 60, 80, 68] :[10,55,60,70,40,70,40,65,45],
                                    // widths: [40,55,80,35,60,35,60,30,60],
                                    widths: [60,75,90,55,70,40,65],
                                    body: [
                                        [
                                            {text: 'Mã định danh', fillColor: '#DDDDDD',},
                                            {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                            {text: 'Số phần của gói thầu đã tham dự', fillColor: '#DDDDDD',},
                                            {text: 'Hiệu lực HSDT (ngày)', fillColor: '#DDDDDD',},
                                            // {text: 'Bảo đảm dự thầu (VND)', fillColor: '#DDDDDD',},
                                            // {text: 'Hiệu lực BĐ DT (ngày)', fillColor: '#DDDDDD',},
                                            {text: 'Giá dự thầu (VND)', fillColor: '#DDDDDD',},
                                            {text: 'Tỷ lệ giảm giá (%)', fillColor: '#DDDDDD',},
                                            {text: 'Giá dự thầu sau giảm giá(VND)', fillColor: '#DDDDDD',},
                                        ],
                                    ]
                                }
                            },
                        ];
                        detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList.forEach((element, index) => {
                            tableDxtc[0].table.body.push([
                                {text: element?.contractorCode},
                                {text: (element.ventureName) ? element.ventureName : element.contractorName},
                                {text: element?.lotNoValueDTOList[0]?.bidOpenView.length},
                                {text: element?.bidValidityNum},
                                // {text: this.currency(element?.bidGuarantee)},
                                // {text: element?.bidGuaranteeValidity},
                                {text:''},
                                {text:''},
                                {text:''}
                            ]);
                            element?.lotNoValueDTOList[0]?.bidOpenView.forEach(it => {
                                tableDxtc[0].table.body.push([
                                    {text: ''},
                                    {text: ''},
                                    {text: it?.lotNo + '-' + it?.lotName},
                                    {text: ''},
                                    // {text: ''},
                                    // {text: ''},
                                    {text:this.currency(it?.lotPrice)},
                                    {text:it?.discountPercentLo ? it?.discountPercentLo : '-' },
                                    {text:this.currency(it?.lotFinalPrice)}
                                ]);
                            })
                        });
                    }
                }

                var dataTable = [];
                dataTable.push([{
                    text: 'Mã TBMT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.notifyNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Tên gói thầu',
                    fillColor: '#DDDDDD',
                }, {
                    // text: detailKqmtCheck?.bidoNotifyContractorP?.bidName,
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Số lượng nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: (detailKqmtCheck?.bidoBidroundMngViewDTO?.notifyNo == 'IB2300127676')?1:detailKqmtCheck?.bidoBidroundMngViewDTO?.countContractor,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Thời điểm hoàn thành mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateForPDF(detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.[0]?.createdDateBidOpen),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Lĩnh vực',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoBidroundMngViewDTO?.investField, this.catInvestFields),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                var dataTable2 = [];
                dataTable2.push([{
                    text: 'Mã KHLCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.planNo,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Tên kế hoạch LCNT',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.planName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Loại hợp đồng',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidoBidroundMngViewDTO?.ctype, this.dmLhdLcnt),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Thời gian thực hiện hợp đồng',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmtCheck?.bidoBidroundMngViewDTO?.cperiod + " " + this.getNameOfPeriod(detailKqmtCheck?.bidoBidroundMngViewDTO?.cperiodUnit),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Hình thức lựa chọn nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidForm, this.bidForms),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                dataTable2.push([{
                    text: 'Phương thức lựa chọn nhà thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.getNameCatByCodeCat(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode, this.dmPtlcnt),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable2.push([{
                    text: 'Thời điểm đóng mở thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateForPDF(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidCloseDate),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);

                if (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidEstimatePrice) {
                    dataTable2.push([{
                        text: 'Giá dự toán',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidEstimatePrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                } else {
                    dataTable2.push([{
                        text: 'Giá gói thầu',
                        fillColor: '#DDDDDD',
                    }, {
                        text: this.currency(detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidPrice) + ' VND',
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                }


                var docDefinition = {
                    content: [
                        [
                            {
                                text: this.selectedTab == 'kqmt' ? 'BIÊN BẢN MỞ THẦU' : (this.selectedTab == 'kqmtKT' ? 'BIÊN BẢN E-HSĐXKT' : 'BIÊN BẢN E-HSĐXTC'  ),
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                text: 'Thông tin chung',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable
                                }
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                            {
                                text: 'Thông tin gói thầu',
                            },
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable2
                                }
                            },
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (isTabTC != '1' && detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS') ? {text: 'Kết quả mở hồ sơ đề xuất kỹ thuật',} : {},
                            (isTabTC != '1' && detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS') ? tableDxkt : {},

                            (isTabTC == '1' && detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? {text: 'Kết quả mở hồ sơ đề xuất tài chính',} : {},
                            (isTabTC == '1' && detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'PUB_KQLCNT')) ? tableDxtc : {},
                            (isTabTC == '1' && detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_HTHS' && (detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'OPEN_DXTC'
                                || detailKqmtCheck.bidoBidroundMngViewDTO.bidStatus == 'PUB_KQLCNT') && detailKqmtCheck?.bidSubmissionByContractorViewResponse?.bidSubmissionDTOList?.length == 0 ) ? {text:'Không có dữ liệu', alignment: 'center',margin: [0,10]} : {},
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_MTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_MTHS') ? {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            } : {},
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_MTHS') ? {text: 'Thông tin nhà thầu',} : {},
                            (detailKqmtCheck?.bidNoContractorResponse?.bidNotification?.bidMode == '1_MTHS') ? table1tui : {},


                        ],

                    ],
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                }

                pdfMake.createPdf(docDefinition).download("\n" + "Biên bản mở thầu.pdf");
            },

            isValidCompareDateBug8779(){
                return new Date().getTime() > new Date('2023-05-13').getTime();
            },
            currency(value) {
                if (value) {
                    return new Number(value).toLocaleString('vi-VN',{maximumFractionDigits:4});
                } else return value;
            },
            formatNumberFunction(value) {
                if (value) {
                    return (value + "").split('').reverse().reduce((prev, next, index) => {
                        return ((index % 3) ? next : (next + '.')) + prev
                    })
                    // return value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,').replace(".00", "");
                } else return value;
            },
            formatDateForPDF(date) {
                if(!date) return '';
                return moment(date).format('DD/MM/YYYY HH:mm');
            },
            formatDatePDF(date) {
                if(!date) return '';
                return moment(date).format('DD/MM/YYYY');
            },
            openTabPTV(lotNo,contractorCode){
                let findPtvFormCode = this.bidaInvChapterConfList.filter(it => ['BD.CG.02.0282','BD.DT.02.1157','BD.DT.02.1145','BD.DT.02.1146'].includes(it.code)).map(it => it.code);
                let url = null;
                if (findPtvFormCode?.length === 1) {
                    this.ptvFormCode = findPtvFormCode.length > 0 ? findPtvFormCode.pop() : '';
                    url = this.urlContractorFe + "?type=INV_HSDT" +
                        "&lotNo=" + lotNo +
                        "&contractorCode=" + contractorCode +
                        "&viewMode=view" +
                        "&formCode=" + this.ptvFormCode +
                        "&fileName=" +
                        "&notifyNo=" + this.notifyNo +
                        "&notifyVersion=" + this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.notifyVersion +
                        "&investField=PTV";
                } else {

                    const formCodeTG = findPtvFormCode.includes('BD.CG.02.0282') ? 'BD.CG.02.0282' : '';
                    const formCodeTGRG = findPtvFormCode.includes('BD.DT.02.1157') ? 'BD.DT.02.1157' : '';
                    const formCodeDG = findPtvFormCode.includes('BD.DT.02.1145') ? 'BD.DT.02.1145' : '';
                    const formCodeDGDC = findPtvFormCode.includes('BD.DT.02.1146') ? 'BD.DT.02.1146' : '';
                    url = this.urlContractorFe + "/ptv"+ "?type=INV_HSDT" +
                        "&lotNo=" + lotNo +
                        "&contractorCode=" + contractorCode +
                        "&viewMode=view" +
                        "&formCodeTG=" +formCodeTG +
                        "&formCodeTGRG=" +formCodeTGRG +
                        "&formCodeDG=" +formCodeDG +
                        "&formCodeDGDC=" +formCodeDGDC +
                        "&fileName=" +
                        "&notifyNo=" + this.notifyNo +
                        "&notifyVersion=" + this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.notifyVersion +
                        "&investField=PTV";
                }
                console.log('url', url);
                if(url){
                    window.open(url);
                }
            },
            openTabHH(lotNo,contractorCode){
                const findHhFormCode = this.bidaInvChapterConfList.filter(it => ['BD.CG.02.0196', 'BD.MT.02.1246', 'BD.DT.02.1148'].includes(it.code)).map(it => it.code);
                let url = null;
                if (findHhFormCode?.length === 1) {
                    url = this.urlContractorFe + "?type=INV_HSDT" +
                        "&lotNo=" + lotNo +
                        "&contractorCode=" + contractorCode +
                        "&viewMode=view" +
                        "&formCode=" + findHhFormCode +
                        "&fileName=" +
                        "&notifyNo=" + this.notifyNo +
                        "&notifyVersion=" + this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.notifyVersion +
                        "&investField=HH";
                }
                if (findHhFormCode?.length === 2) {
                    const formCodeTG = findHhFormCode.includes('BD.CG.02.0196') ? 'BD.CG.02.0196' : '';
                    const formCodeDG = findHhFormCode.includes('BD.DT.02.1148') ? 'BD.DT.02.1148' : '';
                    const formCode = findHhFormCode.includes('BD.MT.02.1246') ? 'BD.MT.02.1246' : '';
                    url = this.urlContractorFe + "/hh"+ "?type=INV_HSDT" +
                        "&lotNo=" + lotNo +
                        "&contractorCode=" + contractorCode +
                        "&viewMode=view" +
                        "&formCodeTG=" +formCodeTG +
                        "&formCodeDG=" +formCodeDG +
                        "&formCode=" +formCode +
                        "&fileName=" +
                        "&notifyNo=" + this.notifyNo +
                        "&notifyVersion=" + this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.notifyVersion +
                        "&investField=HH";
                }
                console.log('url', url);
                if(url){
                    window.open(url);
                }

            },
            // theo doi
            showHintFlow() {
                return (Liferay.ThemeDisplay.isSignedIn() && this.checkUserLoginHaveRoleNT) ? 'display: block;' : 'display: none';
            },

            isSignIn(){
                return Liferay.ThemeDisplay.isSignedIn();
            },
            loadUserInfo() {
                if (Liferay.ThemeDisplay.isSignedIn()) {
                    Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-org-info', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({}),
                    }).then(data => data.json())
                        .then((res) => {
                            this.selectedrootRole = res.userInfo.roleDefault;
                            this.email = res.userInfo.contactEmail.trim();
                            this.orgCodeOfUserLogin = res.orgInfoCommon?.orgCode;
                            this.groupShortListPreNotifyContractorResult();
                            this.checkMailFunction();
                        });
                    Liferay.Util.fetch('/o/egp-portal-personal-page/services/menus', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            langKey: "VI",
                            keyModule: "PO",
                            rootRole: null
                        }),
                    }).then(data => data.json())
                        .then((res) => {
                            res?.selectedrootRole === 'NT' ? this.checkUserLoginHaveRoleNT = true : this.checkUserLoginHaveRoleNT = false;
                        }).catch(err => {
                        console.error("error in load root roles {} ", err);
                    });
                }
            },
            cutStringWith50(input) {
                if(typeof input === 'string'){
                    if (input.length > 50) {
                        return input.substring(0, 50) + '...';
                    }
                }
                return input;
            },
            pagingLotList(lotList) {
                if (lotList) {
                    return lotList.slice((this.currentPageLotlist - 1) * this.pageSize, this.currentPageLotlist * this.pageSize)
                }
                return [];

            },

            changePageLot(page) {

                this.currentPageLotlist = page;

            },
            checkMailFunction() {
                if (this.type) {
                    if (this.type === "es-pre-notify-contractor") {
                        //functionId Theo dõi
                        this.functionId = this.notifyId;
                        this.functionCode = this.notifyNo;
                        this.subType = 'SUB_TBMST';
                    } else if (this.type === "es-notify-contractor") {
                        //functionId Theo dõi
                        this.functionId = this.id;
                        this.functionCode = this.notifyNo;
                        this.subType = 'SUB_TBMT';
                    } else if (this.type == 'es-bidp-project-p') {
                        this.functionId = this.id;
                        this.subType = 'SUB_PROJECT_DTPT';
                    } else if (this.type == 'es-plan-project-p') {
                        this.functionId = this.id;
                        this.functionCode = this.planNo;
                        this.subType = 'SUB_KHLCNT';
                    }
                }
                axios.post(this.urlCheckMail, {
                    email: this.email,
                    subType: this.subType,
                    functionCode: this.functionCode
                }).then(res => {
                    this.checkMail = res.data.success;
                })
            },
            showModal(subType) {
                this.subType = subType;
                this.cancel = true;
            },
            handleOk() {
                if (this.$v.$invalid || this.changeEmail() == false || this.changeEmailOther() == false) {
                    this.$v.$touch();
                    return;
                } else {
                    subs = {
                        email: this.email,
                        subType: this.subType,
                        status: 1,
                        functionId: this.id,
                        functionCode: this.functionCode,
                        functionName: this.functionName,
                        procuringEntityName: this.procuringEntityName,
                        ipAddress: "127.0.0.1"
                    }
                    this.listSub.push(subs);
                    subsOther = {
                        email: this.emailOther,
                        subType: this.subType,
                        status: 1,
                        functionId: this.id,
                        functionCode: this.functionCode,
                        functionName: this.functionName,
                        procuringEntityName: this.procuringEntityName,
                        ipAddress: "127.0.0.1"
                    }
                    if (this.email === this.emailOther) {
                        this.$notification.error({
                            message: 'Email khác không được trùng với email mặc định'
                        });
                        return;
                    }
                    if (this.emailOther.length > 0) {
                        this.listSub.push(subsOther);
                    }
                    this.create();
                }
            },
            create() {
                axios.post(this.urlSub, {
                        subs: this.listSub
                    }
                ).then(res => {
                    this.cancel = false;
                    this.$notification.success({
                        message: 'Đăng kí thành công'
                    });
                    this.checkMail = true;
                    this.email = '';
                }).catch(err => {
                    if (err.response.data.includes('401 Unauthorized')){
                        this.$notification.error({
                            message: 'Phiên đăng nhập của bạn đã hết hạn. Vui lòng đăng nhập lại !!!'
                        })
                        setTimeout(() => {
                            window.open('/c/portal/logout', '_self');
                        }, 2000);
                    } else {
                        this.$notification.error({
                            message: 'Đăng kí thất bại'
                        })
                    }
                })
            },
            changeEmail() {
                const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(this.email);
            },
            changeEmailOther() {
                const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if (this.emailOther.length > 0){
                    return re.test(this.emailOther);
                } else {
                    return true;
                }
            },
            closeCancel() {
                this.cancel = false;
            },
            isCHCTRG(){
                return this.dtlKqlcnt?.bideContractorInputResultDTO?.bidForm == 'CHCTRG'
            },
            isTG(){
                return ['TG','TG_DGCD','TG_DGDC','TG_TTG','TG_CD_DC','TG_CD_TTG','TG_DC_TTG','TG_CD_DC_TTG'].includes(this.dtlKqlcnt?.bideContractorInputResultDTO?.ctype)
            },
            isDGDC(){
                return ['DGDC','TG_DGDC','TG_CD_DC_TTG','DGCD_DC','TG_CD_DC','TG_DC_TTG','CD_DC_TTG','DC_TTG'].includes(this.dtlKqlcnt?.bideContractorInputResultDTO?.ctype);
            },
            isDGCD(){
                return ['DGCD','TG_DGCD','DGCD_DC','TG_CD_DC_TTG','TG_CD_DC','TG_CD_TTG','CD_DC_TTG','CD_TTG','TGG_DGCD','TGG_CD_DC'].includes(this.dtlKqlcnt?.bideContractorInputResultDTO?.ctype);
            },
            isTTG(){
                return this.dtlKqlcnt?.bideContractorInputResultDTO?.ctype?.includes('TTG')
            },
            pagingList(list,type){
                if(list && type == 'TG'){
                    return list.slice((this.currentPageTG - 1) * this.pageSizeTvPtv, this.currentPageTG * this.pageSizeTvPtv)
                }
                if(list && type == 'TG_1'){
                    return list.slice((this.currentPageTG_1 - 1) * this.pageSizeTvPtv, this.currentPageTG_1 * this.pageSizeTvPtv)
                }
                if(list && type == 'DCCD'){
                    return list.slice((this.currentPageDCCD - 1) * this.pageSizeTvPtv, this.currentPageDCCD * this.pageSizeTvPtv)
                }
                if(list && type == 'DCCD_1'){
                    return list.slice((this.currentPageDCCD_1 - 1) * this.pageSizeTvPtv, this.currentPageDCCD_1 * this.pageSizeTvPtv)
                }
                return [];
            },
            changePageTG(page,type){
                if(type == 'DCCD') this.currentPageDCCD = page;
                if(type == 'DCCD_1') this.currentPageDCCD_1 = page;
                if(type == 'TG') this.currentPageTG= page;
                if(type == 'TG_1') this.currentPageTG_1 = page;
            },

            //Phân trang cho danh sách lô phần hàng hóa 12.1 và 12.2A
            pagingGoodListOfLot(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfLot - 1) * this.pageSizeGoodOfLot, this.currentPageGoodlistOfLot * this.pageSizeGoodOfLot)
                }
                return [];
            },
            changePageGoodOfLot(page) {
                this.currentPageGoodlistOfLot = page;
            },
            //Phân trang cho danh sách lô phần hàng hóa 12.2B
            pagingGoodListOfLot12_2B(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfLot12_2B - 1) * this.pageSizeGoodOfLot12_2B, this.currentPageGoodlistOfLot12_2B * this.pageSizeGoodOfLot12_2B)
                }
                return [];
            },
            changePageGoodOfLot12_2B(page) {
                this.currentPageGoodlistOfLot12_2B = page;
            },
            //Phân trang cho danh sách không lô hàng hóa 12.1
            pagingGoodListOfNoLot(goodList,indexHangHoa) {
                console.log('this.checkChangePageGoodOfNoLot', this.checkChangePageGoodOfNoLot);
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfNoLot[indexHangHoa] - 1) * this.pageSizeGoodOfNoLot, this.currentPageGoodlistOfNoLot[indexHangHoa] * this.pageSizeGoodOfNoLot)
                }
                return [];
            },
            changePageGoodOfNoLot(page,indexHangHoa) {
                this.checkChangePageGoodOfNoLot = !this.checkChangePageGoodOfNoLot;
                this.currentPageGoodlistOfNoLot[indexHangHoa] = page;
            },
            //Phân trang cho danh sách không lô hàng hóa 12.2A
            pagingGoodListOfNoLot12_2A(goodList,indexHangHoa) {
                console.log('this.checkChangePageGoodOfNoLot12_2A', this.checkChangePageGoodOfNoLot12_2A);
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfNoLot12_2A[indexHangHoa] - 1) * this.pageSizeGoodOfNoLot12_2A, this.currentPageGoodlistOfNoLot12_2A[indexHangHoa] * this.pageSizeGoodOfNoLot12_2A)
                }
                return [];
            },
            changePageGoodOfNoLot12_2A(page,indexHangHoa) {
                this.checkChangePageGoodOfNoLot12_2A = !this.checkChangePageGoodOfNoLot12_2A;
                this.currentPageGoodlistOfNoLot12_2A[indexHangHoa] = page;
            },
            //Phân trang cho danh sách không lô hàng hóa 12.2B
            pagingGoodListOfNoLot12_2B(goodList,indexHangHoa) {
                console.log('this.checkChangePageGoodOfNoLot12_2B', this.checkChangePageGoodOfNoLot12_2B);
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfNoLot12_2B[indexHangHoa] - 1) * this.pageSizeGoodOfNoLot12_2B, this.currentPageGoodlistOfNoLot12_2B[indexHangHoa] * this.pageSizeGoodOfNoLot12_2B)
                }
                return [];
            },
            changePageGoodOfNoLot12_2B(page,indexHangHoa) {
                this.checkChangePageGoodOfNoLot12_2B = !this.checkChangePageGoodOfNoLot12_2B;
                this.currentPageGoodlistOfNoLot12_2B[indexHangHoa] = page;
            },
            //Phân trang cho danh sách không lô chào hàng cạnh tranh rút gọn
            pagingGoodListOfNoLotCHCTRG(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfNoLotCHCTRG - 1) * this.pageSizeGoodOfNoLotCHCTRG, this.currentPageGoodlistOfNoLotCHCTRG * this.pageSizeGoodOfNoLotCHCTRG)
                }
                return [];
            },
            changePageGoodOfNoLotCHCTRG(page) {
                this.currentPageGoodlistOfNoLotCHCTRG = page;
            },
            //Phân trang cho danh sách không lô dịch vụ liên quan
            pagingGoodListOfNoLotDVLQ(goodList,indexHangHoa) {
                console.log('this.checkChangePageGoodOfNoLotDVLQ', this.checkChangePageGoodOfNoLotDVLQ);
                if (goodList) {
                    return goodList.slice((this.currentPageGoodlistOfNoLotDVLQ[indexHangHoa] - 1) * this.pageSizeGoodOfNoLotDQLQ, this.currentPageGoodlistOfNoLotDVLQ[indexHangHoa] * this.pageSizeGoodOfNoLotDQLQ)
                }
                return [];
            },
            changePageGoodOfNoLotDVLQ(page,indexHangHoa) {
                this.checkChangePageGoodOfNoLotDVLQ = !this.checkChangePageGoodOfNoLotDVLQ;
                this.currentPageGoodlistOfNoLotDVLQ[indexHangHoa] = page;
            },
            // dvlq co lo
            pagingDvlqMultiLot(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageDvlqMultilot - 1) * this.pageSizeDvlqMultilot, this.currentPageDvlqMultilot * this.pageSizeDvlqMultilot)
                }
                return [];
            },
            changePageDvlqMultiLot(page) {
                this.currentPageDvlqMultilot = page;
            },

            //Phân trang cho danh sách nhà thầu thuốc
            pagingListContractorMedical(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageListContractorMedical - 1) * this.pageSizeContractorMedical, this.currentPageListContractorMedical * this.pageSizeContractorMedical)
                }
                return [];
            },
            changePageContractorMedical(page) {
                this.currentPageListContractorMedical = page;
            },
            //Phân trang cho danh sách lo khong co nha thau tham du
            pagingListLotNoContractJoin(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageListLotNoContractJoin - 1) * this.pageSizeLotNoContractJoin, this.currentPageListLotNoContractJoin * this.pageSizeLotNoContractJoin)
                }
                return [];
            },
            changePageLotNoContractJoin(page) {
                this.currentPageListLotNoContractJoin = page;
            },


            pagingListNotPassKT(goodList) {
                if (goodList) {
                    return goodList.slice((this.currentPageListNotPassKT - 1) * this.pageSizePageListNotPassKT, this.currentPageListNotPassKT * this.pageSizePageListNotPassKT)
                }
                return [];
            },
            changePageLotNotPassKT(page) {
                this.currentPageListNotPassKT = page;
            },



            //Hàm lấy danh sách nhà thầu pass ST
            /**
             * @author HoanTV7
             */
            groupShortListPreNotifyContractorResult() {
                let contractorList = [];
                this.bidoPreNotifyContractorResult?.lotResultDTO?.forEach(element => {
                    if(element.contractorList.length > 0){
                        contractorList = contractorList.concat(JSON.parse(element.contractorList));
                    }
                });
                const partners = contractorList?.filter(e => (e.partnership && e.result == 1)) || [];
                const contractorGroup = _.groupBy(partners, 'partnership');
                this.contractorGroup = Object.keys(contractorGroup)?.map(c => contractorGroup[c]) || [];
                const notPartners = contractorList?.filter(e => !(e.partnership) && e.result == 1) || [];
                notPartners?.forEach(e => {
                    this.contractorGroup = [...this.contractorGroup, [e]];
                });
                //check xem user đang đang nhập có trong danh sách ngắn ko
                this.contractorGroup.forEach(group => {
                    group.forEach(contractor => {
                        if(contractor?.orgCode == this.orgCodeOfUserLogin){
                            this.haveSeeHSMT = true;
                        }
                    });
                });
                //Nếu là BTM tạo HSMT thì được xem
                if(this.bidoNotifyView?.procuringEntityCode === this.orgCodeOfUserLogin){
                    this.haveSeeHSMT = true;
                }
            },

            downloadFileNoPublic(fileId, fileName) {
                this.isDownloadFile = true;
                const token = null;
                if(token != null){
                    axios.get('http://localhost:1234/api/download/file/browser', {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        },
                        params: {
                            fileId: fileId
                        },
                        responseType: 'blob'
                    }).then(response =>{
                        this.isDownloadFile = false;
                        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                        var fileLink = document.createElement('a');
                        fileLink.href = fileURL;
                        fileLink.setAttribute('download', fileName);
                        document.body.appendChild(fileLink);
                        fileLink.click();
                    }).catch(error => {
                        this.isDownloadFile = false;
                        this.$error({
                            title: 'Lỗi',
                            content: 'Tải file không thành công. Vui lòng kiểm tra kết nối mạng hoặc liên hệ Tổng đài 1900 6126 để được hỗ trợ',
                            centered: true
                        });
                    });
                }else{
                    this.isDownloadFile = false;
                    this.$error({
                        title: 'Lỗi',
                        content: 'Tải file không thành công. Bạn phải là Nhà thầu trong danh sách ngắn hoặc liên hệ Tổng đài 1900 6126 để được hỗ trợ',
                        centered: true
                    });
                }
            },

            showPopupNotDownload(){
                this.$warning({
                    title: 'Lưu ý',
                    content: "Vui lòng đăng nhập để tải Hồ sơ thiết kế/Bản vẽ.",
                    centered: true
                });
            },

            showPopupNotDownloadKqm(){
                this.$warning({
                    title: 'Lưu ý',
                    content: "Đơn vị cần phải đăng nhập để tải các file đính kèm khác.",
                    centered: true
                });
            },
            // file biên bản mở thầu so tuyển
            generatePdfKqmst(detailKqmstCheck) {
                var table = [
                    {
                        table: {
                            font: 'TimesNewRoman',
                            fontSize: 11,
                            lineHeight: 1.2,
                            widths: [40, '*', '*', '*'],
                            body: [
                                [{text: 'STT', fillColor: '#DDDDDD',},
                                    {
                                        text: 'Mã định danh',
                                        fillColor: '#DDDDDD',
                                    }, {text: 'Tên nhà thầu', fillColor: '#DDDDDD',},
                                    {
                                        text: 'Thời gian có hiệu lực của E-HSDST',
                                        fillColor: '#DDDDDD',
                                    }],
                            ]
                        }
                    },
                ];

                this.getPartnerVentureContractorList(this.dtlKqmst?.listVenture).forEach((element, index) => {
                    table[0].table.body.push(
                        [
                            {text: (index + 1)},
                            {
                                text: element.data?.length > 1 ? (element.data?.map(e => e.contractorCode)?.join('\n\n')) : element.data[0].contractorCode
                            },
                            {
                                text: element.data.length > 1 ? element.data[0].ventureName : element.data[0]?.contractorName,
                            },
                            {
                                text: element.data[0]?.bidValidityNum,
                            }
                        ]);
                });
                var dataTable = [];
                dataTable.push([{
                    text: 'Số E-TBMST',
                    fillColor: '#DDDDDD',
                }, {text: detailKqmstCheck?.bidoBidroundPreMngViewDTO?.notifyNo, colSpan: 3,}, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Tên gói thầu',
                    fillColor: '#DDDDDD',
                }, {text: detailKqmstCheck?.bidoBidroundPreMngViewDTO?.bidName, colSpan: 3,}, {text: ''}, {text: ''}]);
                if (detailKqmstCheck?.bidoBidroundPreMngViewDTO?.planType == 'DTPT') {
                    dataTable.push([{
                        text: 'Tên chủ đầu tư',
                        fillColor: '#DDDDDD',
                    }, {
                        text: detailKqmstCheck?.bidoBidroundPreMngViewDTO?.investorName,
                        colSpan: 3,
                    }, {text: ''}, {text: ''}]);
                }
                dataTable.push([{
                    text: 'Tên bên mời thầu',
                    fillColor: '#DDDDDD',
                }, {
                    text: detailKqmstCheck?.bidoBidroundPreMngViewDTO?.procuringEntityName,
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Giá gói thầu',
                    fillColor: '#DDDDDD',
                }, {text: this.currency(detailKqmstCheck?.bidoBidroundPreMngViewDTO?.bidPrice) + ' ' + detailKqmstCheck?.bidoBidroundPreMngViewDTO?.bidPriceUnit, colSpan: 3,}, {text: ''}, {text: ''}]);
                dataTable.push([{
                    text: 'Loại hợp đồng',
                    fillColor: '#DDDDDD',
                }, {text: this.getNameCatByCodeCat(detailKqmstCheck?.bidoPreQualificationContractorMDTO?.cType, this.dmLhdLcnt)}, {
                    text: 'Hình thức lựa chọn nhà thầu',
                    fillColor: '#CCCCCC',
                }, {text: this.getNameCatByCodeCat(detailKqmstCheck?.bidoBidroundPreMngViewDTO?.bidForm, this.bidForms)}]);
                dataTable.push([{
                    text: 'Thời điểm hoàn thành mở E-HSDST',
                    fillColor: '#DDDDDD',
                }, {
                    text: this.formatDateAndHV2(detailKqmstCheck?.bidoBidroundPreMngViewDTO?.successBidOpenDate),
                    colSpan: 3,
                }, {text: ''}, {text: ''}]);
                var docDefinition = {
                    content: [
                        [
                            {
                                text: 'BIÊN BẢN MỞ THẦU',
                                fontSize: 14,
                                alignment: 'center',
                                bold: true,
                                margin: [0, 20],
                            },
                        ],
                        [
                            {
                                table: {
                                    font: 'TimesNewRoman',
                                    widths: [130, 120, 130, 120],
                                    body: dataTable
                                }
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                            {
                                text: '[Tổng số nhà thầu tham dự: ' + detailKqmstCheck?.bidoBidroundPreMngViewDTO?.countContractor + ']',
                                alignment: 'right',
                            },
                            {
                                text: '\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t',
                            },
                        ],
                        table,
                    ],
                    footer: (currentPage, pageCount, pageSize) => { return this.genFooterPDF(currentPage, pageCount, pageSize) },
                }

                pdfMake.createPdf(docDefinition).download("\n" + "Biên bản mở thầu.pdf");
            },
            formatDateAndHV2: function (date) {
                if (date)
                    return moment(date).format('DD/MM/YYYY HH:mm:ss');
            },
            getTotalAmount() {
                return this.hhCollection?.reduce((val, cur) => val += cur.amount, 0);
            },
            getTotalAmountKhongLo(indexHangHoa) {
                return this.hhCollection[indexHangHoa]?.formValue?.lotContent?.Table?.reduce((val, cur) => val += (cur?.currentParentIndex ? 0  :  (cur.amount ? cur.amount : (cur.bidPrice * cur.qty))), 0);
            },
            stringNullOrEmpty(strInput){
                return strInput === undefined || strInput === null || strInput === '';
            },
            isMedicine(){
                return !this.stringNullOrEmpty(this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.isMedicine) && this.dtlTdNs?.bidNoContractorResponse?.bidNotification?.isMedicine === 1;
            },
            isMedical(){
                return this.dtlRoundMngRes?.bidNoContractorResponse?.bidNotification?.medicalType === 1 || this.dtlRoundMngRes?.bidNoContractorResponse?.bidNotification?.medicalType === 2;
            },
            isBDL12_2(){
                try {
                    return 0 === JSON.parse(this.dtlTdNs?.bidoInvBiddingDTO?.find(e => 'BD_DATA_TABLE' === e.formCode)?.formValue)?.dataRow135?.price;
                    // let dgvkt = this.dtlTdNs?.bidoInvBiddingDTO?.find(it => it.formCode == 'BD.CG.02.0104');
                } catch (e) {
                    return false;
                }
            },
            isVatTuAndAfterChangeForm(){
                return this.isVatTu() && new Date(this.dtlKqlcnt?.bideContractorInputResultDTO?.lastModifiedDate) > new Date(2023,8,12,23,59,0)
            },
            isVatTu(){
                return [1, 2].includes(this.dtlRoundMngRes?.bidNoContractorResponse?.bidNotification?.medicalType);
            },
            isVatTuInternetLot(){
                return [1, 2].includes(this.dtlRoundMngRes?.bidNoContractorResponse?.bidNotification?.medicalType) && !this.isCHCTRG();;
            },
            isCHCTRG() {
                return 'CHCTRG' == this.dtlRoundMngRes?.bidNoContractorResponse?.bidNotification?.bidForm;
            },
            isDVLQ() {
                try {
                    return '1' == JSON.parse(this.dtlTdNs?.bidoInvBiddingDTO?.find(e => 'BD.MT.02.1226' === e.formCode || 'BD.MT.02.1480' === e.formCode)?.formValue)?.service;
                } catch (e) {
                    return false;
                }
            },
            getTotalAmountDvlq(){
                return this.dvlqCollection?.reduce((val, cur) => val += cur.amount, 0);
            },
            checkMedicineType(medicineType){
                let list = this.winMedicineKqm.concat(this.falseMedicineKqm);
                return list?.find(it => it?.medicineType == medicineType);
            },
            getTotalAmountqAdbWb(list){
                return list?.reduce((val,cur) => val += cur.amount,0)
            },
            colspanDsHH(){
                let colspan = 8;
                if (this.isVatTuInternetLot()) {
                    colspan += 8;
                }
                if (this.isBDL12_2()) {
                    colspan += 7;
                } else {
                    colspan += 2;
                }
                return colspan;
            },
            winContractor() {
                var check = false;
                if(this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO?.length)
                    this.dtlKqlcnt?.bideContractorInputResultDTO?.lotResultDTO.forEach( e=>{
                        if(e?.contractorList?.length){
                            e?.contractorList?.forEach( item => {
                                if(item?.bidResult) check = true;
                            });
                        }
                    })
                return check;
            },
            htmlTableToExcelDSHH12_1OR12_2A(type){
                var data = document.getElementById('tblToExcl12_1OR12_2A');
                var excelFile = XLSX.utils.table_to_book(data, {sheet: "sheet1"});
                XLSX.write(excelFile, { bookType: type, bookSST: true, type: 'base64' });
                if(this.isBDL12_2()){
                    XLSX.writeFile(excelFile, 'BẢNG DỰ THẦU HÀNG HÓA ĐƯỢC SẢN XUẤT GIA CÔNG TẠI VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.' + type);
                } else {
                    XLSX.writeFile(excelFile, 'Danh sách hàng hóa -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.' + type);
                }
            },
            htmlTableToExcelDSHH12_2B(type){
                var data = document.getElementById('tblToExcl12_2B');
                var excelFile = XLSX.utils.table_to_book(data, {sheet: "sheet1"});
                XLSX.write(excelFile, { bookType: type, bookSST: true, type: 'base64' });
                XLSX.writeFile(excelFile, 'BẢNG GIÁ DỰ THẦU CỦA HÀNG HÓA ĐƯỢC SẢN XUẤT, GIA CÔNG NGOÀI NƯỚC ĐÃ ĐƯỢC NHẬP KHẨU HOẶC SẼ ĐƯỢC NHẬP KHẨU VÀO VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.' + type);
            },
            exportExcelThuoc(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                let headerTitles = ['STT', 'Mã phần lô', 'Mã thuốc', 'Tên thuốc', 'Tên hoạt chất/ thành phần dược liệu', 'Nồng độ, hàm lượng', 'GĐKLH hoặc GPNK', 'Đường dùng', 'Dạng bào chế', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá trúng thầu (VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu', 'Nhóm thuốc', 'Thời gian thực hiện'];
                if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot != 1){
                    headerTitles = ['STT', 'Mã thuốc', 'Tên thuốc', 'Tên hoạt chất/ thành phần dược liệu', 'Nồng độ, hàm lượng', 'GĐKLH hoặc GPNK', 'Đường dùng', 'Dạng bào chế', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá trúng thầu (VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu', 'Nhóm thuốc', 'Thời gian thực hiện'];
                }
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.listMedicineQM.map((e, i) => {
                    let row = null;
                    if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1){
                        row = worksheet.addRow([(i + 1), e?.lotNo, e?.medicineCode, e?.tenThuoc || e?.name, e?.tenHoatChat, e?.nongDo, e?.gdklh, e?.duongDung, e?.dangBaoChe, e?.csSanXuat, e?.nuocSanXuat, e?.quyCach, e?.uom, this.currency(e?.quantity), this.currency(e?.donGia), this.currency(e?.amount), e?.contractorName, e?.groupMedicine, e?.tienDo]);
                    } else {
                        row = worksheet.addRow([(i + 1), e?.medicineCode, e?.tenThuoc || e?.name, e?.tenHoatChat, e?.nongDo, e?.gdklh, e?.duongDung, e?.dangBaoChe, e?.csSanXuat, e?.nuocSanXuat, e?.quyCach, e?.uom, this.currency(e?.quantity), this.currency(e?.donGia), this.currency(e?.amount), e?.contractorName, e?.groupMedicine, e?.tienDo]);
                    }

                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i < (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1 ? 20 : 19); i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                    // row.eachCell((cell, index) => {
                    //     cell.border = {
                    //         top: {style: 'thin'},
                    //         left: {style: 'thin'},
                    //         bottom: {style: 'thin'},
                    //         right: {style: 'thin'}
                    //     };
                    // });
                });
                // const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.getTotalAmountKhongLo()) ,''])
                // worksheet.mergeCells(`A${total.number}:G${total.number}`);
                // total.eachCell((cell, index) => {
                //     cell.border = {
                //         top: {style: 'thin'},
                //         left: {style: 'thin'},
                //         bottom: {style: 'thin'},
                //         right: {style: 'thin'}
                //     };
                // });
                // const textTotal = worksheet.getCell(`A${total.number}`);
                // textTotal.alignment = {horizontal: 'center'};

                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG DỰ THẦU HÀNG HÓA -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelThuocNew(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                let headerTitles = ['Mã phần lô', 'STT theo HSMT', 'Tên sản phẩm', 'Nồng độ, hàm lượng', 'Dạng bào chế', 'Số ĐKLH/ Giấy phép NK', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá(VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu', 'Nhóm TCTK', 'Thời gian thực hiện', 'Hiệu lực của hợp đồng'];
                if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot != 1){
                    headerTitles = [ 'STT theo HSMT', 'Tên sản phẩm', 'Nồng độ, hàm lượng', 'Dạng bào chế', 'Số ĐKLH/ Giấy phép NK', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá(VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu', 'Nhóm TCTK', 'Thời gian thực hiện', 'Hiệu lực của hợp đồng'];
                }
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.listMedicineQMType1.map((e, i) => {
                    let row = null;
                    if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1){
                        row = worksheet.addRow([e?.lotNo,e?.pos, e?.lotName, e?.nongDo, e?.dangBaoChe, e?.gdklh, e?.coSoSanXuat, e?.coSoCungCap, e?.quyCach, e?.uom, this.currency(e?.quantity), this.currency(e?.donGia), this.currency(e?.amount), e?.contractorName, e?.groupMedicine, e?.tienDo,e?.cperiod]);
                    } else {
                        row = worksheet.addRow([e?.pos, e?.lotName, e?.nongDo, e?.dangBaoChe, e?.gdklh, e?.coSoSanXuat, e?.coSoCungCap, e?.quyCach, e?.uom, this.currency(e?.quantity), this.currency(e?.donGia), this.currency(e?.amount), e?.contractorName, e?.groupMedicine, e?.tienDo,e?.cperiod]);
                    }

                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i < (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1 ? 18 : 17); i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                    // row.eachCell((cell, index) => {
                    //     cell.border = {
                    //         top: {style: 'thin'},
                    //         left: {style: 'thin'},
                    //         bottom: {style: 'thin'},
                    //         right: {style: 'thin'}
                    //     };
                    // });
                });
                // const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.getTotalAmountKhongLo()) ,''])
                // worksheet.mergeCells(`A${total.number}:G${total.number}`);
                // total.eachCell((cell, index) => {
                //     cell.border = {
                //         top: {style: 'thin'},
                //         left: {style: 'thin'},
                //         bottom: {style: 'thin'},
                //         right: {style: 'thin'}
                //     };
                // });
                // const textTotal = worksheet.getCell(`A${total.number}`);
                // textTotal.alignment = {horizontal: 'center'};

                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_hang_hoa_' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelThuocColo(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');
                const thuocMoi = (this.lotListKH?.[0]?.medicines == 5 || this.lotListKH?.[0]?.medicines == 4)
                const thuoc5 = (this.lotListKH?.[0]?.medicines == 5)
                const thuoc4 = (this.lotListKH?.[0]?.medicines == 4)
                let headerTitles = []
                let row = []

                if(thuocMoi){
                    headerTitles = [
                        'Mã phần lô',
                        'TT',
                        thuoc5 ? 'Tên vị thuốc' : 'Tên dược liệu',
                        'Nhóm TCKT',
                        'Bộ phận dùng',
                        'Tên khoa học',
                        'Dạng sơ chế/ Phương pháp chế biến',
                        'Tiêu chuẩn chất lượng',
                        'Đơn vị tính',
                        'Số lượng',
                        'Giá kế hoạch',
                        'Thành tiền',
                        'Giá dự toán ước tính từng lô']
                }
                // thuốc cũ
                if(!thuocMoi){
                    headerTitles = [
                        'STT',
                        'Mã phần/lô',
                        'Tên hoạt chất/ Tên thành phần thuốc',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Mã thuốc',
                        this.lotListKH?.[0]?.medicine == 1 ? 'Tên thuốc hoặc tương đương điều trị' : null,
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Nồng độ, hàm lượng',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Đường dùng',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Dạng bào chế',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Đơn vị tính',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Nhóm thuốc',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Số lượng',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Giá kế hoạch',
                        this.lotListKH?.[0]?.medicineCode == null ? null : 'Thành tiền',
                        'Giá dự toán ước tính từng lô',
                        this.lotListKH?.[0]?.medicineCode == null ? 'Giá ước tính từng lô' : null,
                        this.lotListKH?.[0]?.medicineCode == null ? 'Thời gian thực hiện hợp đồng' : null,
                        this.lotListKH?.[0]?.medicineCode == null ? 'Loại thuốc' : null
                    ].filter(it => it != null)
                }
                //End Thông tin chung
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                if(thuocMoi){
                    (this.lotListKH).map((e, i) => {
                        row = worksheet.addRow([
                            e.lotNo,
                            (i + 1),
                            e?.lotName,
                            e?.groupMedicine ? e?.groupMedicine : '',
                            e?.medicineCode ?e?.medicineCode : '',
                            e?.tenThuoc ? e?.tenThuoc : '',
                            e?.dangBaoChe ? e?.dangBaoChe : '',
                            e?.nongDo ? e.nongDo : '',
                            e?.uom ? e?.uom : '' ,
                            e?.quantity ? e?.quantity : '' ,
                            e?.pricePlan ? this.currency(e?.pricePlan) : '',
                            (e?.quantity && e?.pricePlan) ? this.currency(e?.quantity * e?.pricePlan) : '',
                            e?.lotEstimatePrice ? this.currency(e?.lotEstimatePrice) : '',
                        ].filter(it => it != null));
                    });
                }
                if(!thuocMoi){
                    (this.lotListKH).map((e, i) => {
                        row = worksheet.addRow([
                            (i + 1),
                            e?.lotNo,
                            e?.lotName,
                            this.lotListKH?.[0]?.medicineCode == null ? null : e?.medicineCode ? e?.medicineCode : '',
                            this.lotListKH?.[0]?.medicine == 1 ? (e?.tenThuoc ? e?.tenThuoc : '')  : null,
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.nongDo ? e?.nongDo : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.duongDung ? e?.duongDung : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.dangBaoChe ? e?.dangBaoChe : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.uom ? e?.uom : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.groupMedicine ? e?.groupMedicine : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.quantity ? e?.quantity : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : (e?.pricePlan ? this.currency(e?.pricePlan) : ''),
                            this.lotListKH?.[0]?.medicineCode == null ? null : ((e?.quantity && e?.pricePlan) ? this.currency(e?.quantity * e?.pricePlan ) : ''),
                            e?.lotEstimatePrice ? this.currency(e?.lotEstimatePrice) : '',
                            this.lotListKH?.[0]?.medicineCode == null ? (e.lotPrice ? this.currency(e.lotPrice) : '') : null,
                            this.lotListKH?.[0]?.medicineCode == null ? `${e?.cperiod} ${e?.cperiodUnit}` : null,
                            this.lotListKH?.[0]?.medicineCode == null ? (e?.medicines == '0' ? 'Thuốc Generic' : e?.medicines == '1' ? 'Thuốc biệt dược' : e?.medicines == '2' ? 'Thuốc cổ truyền' : '') : null
                        ].filter(it => it != null));
                    });
                }
                const sttRow = worksheet.getCell(`A${row.number}`);
                sttRow.alignment = {horizontal: 'left'};
                for (let i = 1; i < (this.lotListKH?.[0]?.medicineCode == null ? 8 : 14); i++) {
                    row.getCell(i).border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                }
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_phan_lo_' + this.lotListKH?.[0].bidNo + '.xlsx');
                });

            },
            exportExcelBaseMedicine(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');
                let row = []
                const headerTitles = [
                    'STT',
                    'Mã phần (lô)',
                    'Tên phần (lô)',
                    'Đơn vị tính',
                    'Số lượng',
                    'Đơn giá(VND)',
                    'Thành tiền (VND)',
                    'Thời gian thực hiện hợp đồng',
                    'Giá dự toán ước tính từng lô (VND)'
                ]
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.lotListKH?.forEach((e, i) => {
                    row = worksheet.addRow([
                        (i + 1),
                        e?.lotNo ? e?.lotNo : '' ,
                        e?.lotName ? e?.lotName : '' ,
                        e?.uom ? e?.uom : '',
                        e?.quantity ? e?.quantity : '',
                        this.currency(e?.pricePlan),
                        this.currency(e?.quantity * e?.pricePlan) ,
                        e?.cperiod + ' ' + this.getNameOfPeriod(e?.cperiodUnit),
                        e?.lotEstimatePrice ? this.currency(e?.lotEstimatePrice) : ''
                    ]);
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i <= headerTitles.length; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });

                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_phan_lo_' + this.lotListKH?.[0].bidNo + '.xlsx');
                });

            },

            exportExcelColo(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                headerTitles = [
                    'STT', 'Mã phần/lô', 'Tên phần/lô', 'Giá ước tính từng lô', 'Giá dự toán ước tính từng lô', 'Thời gian thực hiện hợp đồng'
                ].filter(it => it != null);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                (this.lotListKH).map((e, i) => {
                    let row = worksheet.addRow([
                        i + 1,
                        e?.lotNo,
                        e?.lotName,
                        this.currency(e?.lotPrice),
                        this.currency(e?.lotEstimatePrice),
                        `${e?.cperiod} ${this.getNameOfPeriod(e?.cperiodUnit)}`
                    ]);
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i < 7; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_phan_lo_' + this.lotListKH?.bidNo + '.xlsx');
                });

            },
            exportExcelThuocNewVer0(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                let headerTitles = ['Mã phần lô', 'STT theo HSMT', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ?'Tên vị thuốc cổ truyền' : 'Tên dược liệu', 'Bộ phận dùng', 'Tên khoa học', 'Nguồn gốc', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ? 'Phương pháp chế biến' : 'Dạng sơ chế', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ? 'Số ĐKLH/ Giấy phép NK' : 'Tiêu chuẩn chất lượng/ Số công bố TCCL', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá (VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu','Nhóm TCKT','Thời gian thực hiện','Hiệu lực của hợp đồng'];
                if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot != 1){
                    headerTitles = ['STT theo HSMT', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ?'Tên vị thuốc cổ truyền' : 'Tên dược liệu', 'Bộ phận dùng', 'Tên khoa học', 'Nguồn gốc', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ? 'Phương pháp chế biến' : 'Dạng sơ chế', this.dtlKqlcnt?.bidpPlanDetailDTO?.detailLotList?.[0]?.medicines == 5 ? 'Số ĐKLH/ Giấy phép NK' : 'Tiêu chuẩn chất lượng/ Số công bố TCCL', 'Tên cơ sở sản xuất', 'Nước sản xuất', 'Quy cách đóng gói', 'Đơn vị tính', 'Số lượng', 'Đơn giá (VND)', 'Thành tiền (VND)', 'Nhà thầu trúng thầu','Nhóm TCKT','Thời gian thực hiện','Hiệu lực của hợp đồng'];
                }
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.listMedicineQMType0.map((e, i) => {
                    let row = null;
                    if(this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1){
                        row = worksheet.addRow([e?.lotNo,e?.pos, e?.lotName, e?.medicineCode, e?.tenThuoc, e?.origin, e?.dangBaoChe, e?.gdklh, e?.coSoSanXuat, e?.coSoCungCap, e?.quyCach, e?.uom, this.currency(e?.quantity),  this.currency(e?.donGia),this.currency(e?.amount) ,e?.contractorName,e?.groupMedicine, e?.tienDo,e?.cperiod]);
                    } else {
                        row = worksheet.addRow([e?.pos,e?.lotName, e?.medicineCode, e?.tenThuoc, e?.origin, e?.dangBaoChe, e?.gdklh, e?.coSoSanXuat, e?.coSoCungCap, e?.quyCach, e?.uom, this.currency(e?.quantity),  this.currency(e?.donGia),this.currency(e?.amount) , e?.contractorName,e?.groupMedicine, e?.tienDo,e?.cperiod]);
                    }

                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i < (this.dtlKqlcnt?.bideContractorInputResultDTO?.isMultiLot == 1 ? 20 : 19); i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                    // row.eachCell((cell, index) => {
                    //     cell.border = {
                    //         top: {style: 'thin'},
                    //         left: {style: 'thin'},
                    //         bottom: {style: 'thin'},
                    //         right: {style: 'thin'}
                    //     };
                    // });
                });
                // const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.getTotalAmountKhongLo()) ,''])
                // worksheet.mergeCells(`A${total.number}:G${total.number}`);
                // total.eachCell((cell, index) => {
                //     cell.border = {
                //         top: {style: 'thin'},
                //         left: {style: 'thin'},
                //         bottom: {style: 'thin'},
                //         right: {style: 'thin'}
                //     };
                // });
                // const textTotal = worksheet.getCell(`A${total.number}`);
                // textTotal.alignment = {horizontal: 'center'};

                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_hang_hoa_' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelKhongLo(indexHangHoa){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                const headerTitles = ['STT', 'Danh mục hàng hóa', 'Đơn vị tính', 'Khối lượng', 'Xuất xứ [ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]', 'Mã HS', 'Đơn giá dự thầu (đã bao gồm thuế, phí, lệ phí (nếu có))', 'Thành tiền đã bao gồm thuế, phí, lệ phí (nếu có))', 'Thời gian giao hàng (ngày)/ Tiến độ cung cấp'].concat(this.isVatTuAndAfterChangeForm() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)'] : [])
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hhCollection[indexHangHoa]?.formValue?.lotContent?.Table?.map((e, i) => {
                    const row = worksheet.addRow([e.currentItemIndex ? e.currentItemIndex : (i + 1), e?.name, e?.uom, e?.qty, e?.origin, e?.label, this.currency(e?.bidPrice), this.currency(e?.amount ? e?.amount : (e?.bidPrice * e?.qty)), e?.cPeriod].concat(this.isVatTuAndAfterChangeForm() ? [e?.investCapital ? e?.investCapital : '' ,e?.ratedQuantity ? e?.ratedQuantity : '' ,e?.circulationNum ? e?.circulationNum : '',e?.yearManufacture ? e?.yearManufacture : '',e?.feature ? e?.feature : '' ,e?.model ? e?.model : ''] : []));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                });
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.getTotalAmountKhongLo(indexHangHoa)) ,''].concat(this.isVatTuAndAfterChangeForm() ? ['','','','','',''] : []))
                worksheet.mergeCells(`A${total.number}:G${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG DỰ THẦU HÀNG HÓA -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelKhongLo12_2A(indexHangHoa){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                const headerTitles = ['STT', 'Danh mục hàng hóa', 'Đơn vị tính', 'Khối lượng [ghi theo phạm vi cung cấp]', 'Xuất xứ [Ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]', 'Mã HS', 'Đơn giá EXW', 'Giá EXW', 'Chi phí vận chuyển, bảo hiểm và các dịch vụ khác (đã bao gồm thuế VAT) để vận chuyển hàng hóa đến địa điểm dự án', 'Thành tiền không bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thuế tiêu thụ đặc biệt (nếu có), thuế VAT phải nộp trong trường hợp nhà thầu được trao hợp đồng', 'Thành tiền đã bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thời gian giao hàng (ngày)/ Tiến độ cung cấp'].concat(this.isVatTuAndAfterChangeForm() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)']: []);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hhCollection[indexHangHoa]?.formValue?.lotContent?.Table?.map((e, i) => {
                    const row = worksheet.addRow([(i + 1), e?.name, e?.uom, e?.qty, e?.origin, e?.label, this.currency(e?.exwUnitPrice), this.currency(e?.exwPrice), this.currency(e?.cost), this.currency(e?.bidAmount), this.currency(e?.tax), this.currency(e?.amount), e?.cPeriod].concat(this.isVatTuAndAfterChangeForm() ? [e?.investCapital ? e?.investCapital : '' ,e?.ratedQuantity ? e?.ratedQuantity : '' ,e?.circulationNum ? e?.circulationNum : '',e?.yearManufacture ? e?.yearManufacture : '',e?.feature ? e?.feature : '' ,e?.model ? e?.model : ''] : []));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                });
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '', '',this.currency(this.totalCost12_2AKhongLo[indexHangHoa]) ,this.currency(this.totalbidAmount12_2AKhongLo[indexHangHoa]) ,this.currency(this.totalTax12_2AKhongLo[indexHangHoa]) ,this.currency(this.totalAmount12_2AKhongLo[indexHangHoa]) ,''].concat(this.isVatTuAndAfterChangeForm() ? ['','','','','',''] : []))
                worksheet.mergeCells(`A${total.number}:G${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG DỰ THẦU HÀNG HÓA ĐƯỢC SẢN XUẤT GIA CÔNG TẠI VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelKhongLo12_2B(indexHangHoa){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                const headerTitles = ['STT', 'Danh mục hàng hóa', 'Đơn vị tính', 'Khối lượng', 'Xuất xứ [Ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]', 'Mã HS', 'Đơn giá bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu', 'Thuế, phí, lệ phí liên quan đến nhập khẩu đối với một đơn vị hàng hóa', 'Đơn giá không bao gồm thuế, phí liên quan đến nhập khẩu', 'Giá từng hạng mục không bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu', 'Chi phí vận chuyển, bảo hiểm và các dịch vụ khác', 'Thành tiền không bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu, thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thuế, phí, lệ phí liên quan đến nhập khẩu đối với từng hạng mục', 'Thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thành tiền bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu, thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thời gian giao hàng (ngày)/ Tiến độ cung cấp'].concat(this.isVatTuAndAfterChangeForm() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)']: []);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hh12BCollection[indexHangHoa]?.formValue?.lotContent?.Table?.map((e, i) => {
                    const row = worksheet.addRow([(i + 1), e?.name, e?.uom, e?.qty, e?.origin, e?.label, this.currency(e?.priceIncludeTax), this.currency(e?.tax), this.currency(e?.priceExcludeTax), this.currency(e?.unitPrice), this.currency(e?.cost), this.currency(e?.amountBeforeTax), this.currency(e?.importTax), this.currency(e?.taxSpecial), this.currency(e?.amount), e?.cPeriod].concat(this.isVatTuAndAfterChangeForm() ? [e?.investCapital ? e?.investCapital : '' ,e?.ratedQuantity ? e?.ratedQuantity : '' ,e?.circulationNum ? e?.circulationNum : '',e?.yearManufacture ? e?.yearManufacture : '',e?.feature ? e?.feature : '' ,e?.model ? e?.model : ''] : []));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                });
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '', '',this.currency(this.totalPriceExcludeTax12_2BKhongLo[indexHangHoa]) ,this.currency(this.totalUnitPrice12_2BKhongLo[indexHangHoa]) ,this.currency(this.totalCost12_2BKhongLo[indexHangHoa]),this.currency(this.totalAmountBeforeTax12_2BKhongLo[indexHangHoa]) ,this.currency(this.totalImportTax12_2BKhongLo[indexHangHoa]) ,this.currency(this.totalTaxSpecial12_2BKhongLo[indexHangHoa]) ,this.currency(this.totalAmount12_2BKhongLo[indexHangHoa]) ,''].concat(this.isVatTuAndAfterChangeForm() ? ['','','','','','']: []))
                worksheet.mergeCells(`A${total.number}:G${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG GIÁ DỰ THẦU CỦA HÀNG HÓA ĐƯỢC SẢN XUẤT, GIA CÔNG NGOÀI NƯỚC ĐÃ ĐƯỢC NHẬP KHẨU HOẶC SẼ ĐƯỢC NHẬP KHẨU VÀO VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelNoLotCHCTRG(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                const headerTitles = ['STT', 'Danh mục hàng hóa', 'Đơn vị tính', 'Khối lượng', 'Xuất xứ [Ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]', 'Mã HS', 'Đơn giá dự thầu (đã bao gồm thuế, phí, lệ phí (nếu có))', 'Thành tiền đã bao gồm thuế, phí, lệ phí (nếu có))', 'Thời gian giao hàng'].concat(this.isVatTuAndAfterChangeForm() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)'] : [])
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hhCollectionCHCTRG[0]?.formValue?.lotContent?.Table?.map((e, i) => {
                    const row = worksheet.addRow([(i + 1), e?.name, e?.uom, e?.qty, e?.origin, e?.label,  this.currency(e?.bidPrice), this.currency(e?.amount), e?.cPeriod].concat(this.isVatTuAndAfterChangeForm() ? [e?.investCapital ? e?.investCapital : '' ,e?.ratedQuantity ? e?.ratedQuantity : '' ,e?.circulationNum ? e?.circulationNum : '',e?.yearManufacture ? e?.yearManufacture : '',e?.feature ? e?.feature : '' ,e?.model ? e?.model : ''] : []));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                });
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.totalAmountNoLotCHCTRG) ,''].concat(this.isVatTuAndAfterChangeForm() ? ['','','','','',''] : []))
                worksheet.mergeCells(`A${total.number}:G${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG CHÀO GIÁ HÀNG HÓA -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcelNoLotDVLQ(indexHangHoa){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung
                const headerTitles = ['STT', 'Mô tả dịch vụ', 'Khối lượng mời thầu', 'Đơn vị tính', 'Địa điểm thực hiện dịch vụ', 'Ngày hoàn thành dịch vụ', 'Đơn giá dự thầu', 'Thành tiền', 'Thời gian giao hàng (ngày)/ Tiến độ cung cấp']
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hhCollectionDVLQ[indexHangHoa]?.formValue?.lotContent?.Table?.map((e, i) => {
                    const row = worksheet.addRow([(i + 1), e?.description, e?.qty, e?.uom, e?.place, e?.dueDate,  this.currency(e?.bidPrice), this.currency(e?.intoMoney), e?.cPeriod]);
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                });
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '', '', '',this.currency(this.totalAmountNoLotDVLQ[indexHangHoa]) ,''])
                worksheet.mergeCells(`A${total.number}:G${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG GIÁ DỰ THẦU CHO DỊCH VỤ LIÊN QUAN -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });

            },
            exportExcel2_1OR12_2A(){
                // const wb = new ExcelJS.Workbook();
                // const ws = wb.addWorksheet('My Sheet');
                if(this.isBDL12_2()){
                    const workbook = new ExcelJS.Workbook();
                    const worksheet = workbook.addWorksheet('Danh sách hàng hóa');
                    // Thông tin chung
                    const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                    titleGeneralInfor.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                    const codeTBMT = worksheet.addRow([]);
                    codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                    codeTBMT.font = {
                        color: {argb: '000000'},
                        size: 12
                    };
                    codeTBMT.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                    worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                    const biddingPackage = worksheet.addRow([]);
                    biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                    biddingPackage.font = {
                        color: {argb: '000000'},
                        size: 12
                    };

                    biddingPackage.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                    worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                    const biddingParty = worksheet.addRow([]);
                    biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                    biddingParty.font = {
                        color: {argb: '000000'},
                        size: 12
                    };

                    biddingParty.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                    worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                    //End Thông tin chung

                    // const headerTitles = ['STT', 'Mã phần', 'Tên phần', 'Nhà thầu trúng thầu'].concat(!this.isVatTu() ? ['Danh mục hàng hóa'] : []).concat(this.isVatTu() ? ['Mặt hàng dự thầu','Mã hàng hóa', 'Phân nhóm'] : []).concat(['Đơn vị tính', 'Khối lượng', 'Hàng hóa được sản xuất, gia công ngoài nước?', 'Xuất xứ\n[ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]', 'Mã HS', 'Đơn giá EXW', 'Giá EXW', 'Chi phí vận chuyển, bảo hiểm và các dịch vụ khác', 'Thành tiền không bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thuế tiêu thụ đặc biệt (nếu có), thuế VAT phải nộp trong trường hợp nhà thầu được trao hợp đồng', 'Thành tiền đã bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT']);
                    const headerTitles = ['STT', 'Mã phần', 'Tên phần', 'Nhà thầu trúng thầu'].concat(!this.isVatTuInternetLot() ? ['Danh mục hàng hóa'] : []).concat(this.isVatTuInternetLot() ? ['Mặt hàng dự thầu','Mã hàng hóa', 'Phân nhóm'] : []).concat(['Đơn vị tính', 'Khối lượng', 'Xuất xứ\n[ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]'].concat(this.isVatTuInternetLot() ? ['Nguồn vốn đầu tư', 'Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)'] : []).concat(['Mã HS', 'Đơn giá EXW', 'Giá EXW', 'Chi phí vận chuyển, bảo hiểm và các dịch vụ khác', 'Thành tiền không bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thuế tiêu thụ đặc biệt (nếu có), thuế VAT phải nộp trong trường hợp nhà thầu được trao hợp đồng', 'Thành tiền đã bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT']));
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index + 1).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    this.hhCollection.map((e, i) => {
                        // const row = worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName].concat(!this.isVatTu() ? [''] : []).concat(this.isVatTu() ? ['','', ''] : []).concat(['', '', '', '', '', '', '', '', '', '', e?.amount ? this.currency(e?.amount) : '']));
                        const row = e.newContractorName ? worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName + ' (đã đổi tên thành ' + e.newContractorName + ')'].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['','', ''] : []).concat(['','','']).concat(this.isVatTuInternetLot() ? ['','','','','',''] : []).concat(['', '', '', '','', e?.amount ? this.currency(e?.amount) : '']))
                            : worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['','', ''] : []).concat(['','','']).concat(this.isVatTuInternetLot() ? ['','','','','',''] : []).concat(['', '', '', '','', e?.amount ? this.currency(e?.amount) : '']));
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        row.eachCell((cell, index) => {
                            cell.border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        });
                        if(this.isVatTuInternetLot()){
                            worksheet.mergeCells(`E${row.number}:V${row.number}`);
                        } else {
                            worksheet.mergeCells(`E${row.number}:L${row.number}`);
                        }
                        e?.dsHH?.map((hh, index) => {
                            // const childRow = worksheet.addRow(['', '', '', ''].concat(!this.isVatTu() ? [hh?.name] : []).concat(this.isVatTu() ? [hh?.bidItem, hh?.code, hh?.group] : []).concat([hh?.uom, hh?.qty, hh?.keKhai12b ? 'Có' : 'Không', hh?.origin, hh?.maHS, this.currency(hh?.exwUnitPrice), this.currency(hh?.exwPrice), this.currency(hh?.cost), this.currency(hh?.bidAmount), this.currency(hh?.tax), hh?.amount ? this.currency(hh?.amount) : '']));
                            const childRow = worksheet.addRow(['', '', '', ''].concat(!this.isVatTuInternetLot() ? [hh?.name] : []).concat(this.isVatTuInternetLot() ? [hh?.bidItem, hh?.code, hh?.group] : []).concat([hh?.uom, hh?.qty, hh?.origin]).concat(this.isVatTuInternetLot() ? [hh.investCapital,hh.ratedQuantity,hh.circulationNum,hh.yearManufacture,hh.feature,hh.model] : []).concat([hh?.maHS, this.currency(hh?.exwUnitPrice), this.currency(hh?.exwPrice), this.currency(hh?.cost), this.currency(hh?.bidAmount), this.currency(hh?.tax), hh?.amount ? this.currency(hh?.amount) : '']));
                            // const massRow = worksheet.getCell(`G${childRow.number}`);
                            // massRow.alignment = {horizontal: 'right'};
                            childRow.eachCell((cell, index) => {
                                cell.border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            });
                            worksheet.mergeCells(`A${childRow.number}:D${childRow.number}`);

                        });
                    });

                    workbook.xlsx.writeBuffer().then((data) => {
                        const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                        saveAs(blob, 'BẢNG DỰ THẦU HÀNG HÓA ĐƯỢC SẢN XUẤT GIA CÔNG TẠI VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                    });
                } else {
                    const workbook = new ExcelJS.Workbook();
                    const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                    // Thông tin chung
                    const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                    titleGeneralInfor.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                    const codeTBMT = worksheet.addRow([]);
                    codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                    codeTBMT.font = {
                        color: {argb: '000000'},
                        size: 12
                    };
                    codeTBMT.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                    worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                    const biddingPackage = worksheet.addRow([]);
                    biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                    biddingPackage.font = {
                        color: {argb: '000000'},
                        size: 12
                    };

                    biddingPackage.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                    worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                    const biddingParty = worksheet.addRow([]);
                    biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                    biddingParty.font = {
                        color: {argb: '000000'},
                        size: 12
                    };

                    biddingParty.alignment = {vertical: 'middle'};
                    worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                    worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                    //End Thông tin chung

                    const headerTitles = ['STT', 'Mã phần', 'Tên phần', 'Nhà thầu trúng thầu'].concat(!this.isVatTuInternetLot() ? ['Danh mục hàng hóa'] : []).concat(this.isVatTuInternetLot() ? ['Mặt hàng dự thầu', 'Mã hàng hóa', 'Phân nhóm'] : []).concat(['Đơn vị tính', 'Khối lượng', 'Xuất xứ\n[ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]']).concat(this.isVatTuInternetLot() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)'] : []).concat(['Mã HS', 'Đơn giá dự thầu\nđã bao gồm thuế, phí, lệ phí (nếu có))', 'Thành tiền\nđã bao gồm thuế, phí, lệ phí (nếu có))']);
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index + 1).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    this.hhCollection.map((e, i) => {
                        const row = e.newContractorName ? worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName + ' (đã đổi tên thành ' + e.newContractorName + ')'].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['', '', '','','','','','',''] : []).concat(['', '', '', '', '', e?.amount ? this.currency(e?.amount) : '']))
                            : worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['', '', '','','','','','',''] : []).concat(['', '', '', '', '', e?.amount ? this.currency(e?.amount) : '']));
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        row.eachCell((cell, index) => {
                            cell.border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        });
                        if(this.isVatTuInternetLot()){
                            worksheet.mergeCells(`E${row.number}:R${row.number}`);
                        } else {
                            worksheet.mergeCells(`E${row.number}:J${row.number}`);
                        }
                        e?.dsHH?.map((hh, index) => {
                            const childRow = worksheet.addRow(['', '', '', ''].concat(!this.isVatTuInternetLot() ? [hh?.name] : []).concat(this.isVatTuInternetLot() ? [hh.bidItem, hh?.code, hh?.group] : []).concat([hh?.uom, hh?.qty, hh?.origin]).concat(this.isVatTuInternetLot() ? [hh.investCapital,hh.ratedQuantity,hh.circulationNum,hh.yearManufacture,hh.feature,hh.model] :[]).concat([hh?.maHS,hh?.lotWiningPrice ? this.currency(hh?.lotWiningPrice) : '', hh?.amount ? this.currency(hh?.amount) : '']));
                            // const massRow = worksheet.getCell(`G${childRow.number}`);
                            // massRow.alignment = {horizontal: 'right'};
                            childRow.eachCell((cell, index) => {
                                cell.border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            });
                            worksheet.mergeCells(`A${childRow.number}:D${childRow.number}`);
                        });
                    });
                    const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', ''].concat(this.isVatTuInternetLot() ? ['', '','','','','','',''] : []).concat(['', '', '', '', '', this.getTotalAmount() ? this.currency(this.getTotalAmount()) : '']));
                    if(this.isVatTuInternetLot()){
                        worksheet.mergeCells(`A${total.number}:R${total.number}`);
                    } else {
                        worksheet.mergeCells(`A${total.number}:J${total.number}`);
                    }
                    total.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    const textTotal = worksheet.getCell(`A${total.number}`);
                    textTotal.alignment = {horizontal: 'center'};

                    workbook.xlsx.writeBuffer().then((data) => {
                        const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                        saveAs(blob, 'Danh sách hàng hóa -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                    });
                }
            },
            exportExcelDvlqMultilot(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách dịch vụ liên quan');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung

                const headerTitles = ['STT', 'Mã phần (lô)', 'Tên phần (lô)', 'Nhà thầu trúng thầu','Mô tả dịch vụ','Khối lượng mời thầu','Đơn vị tính','Địa điểm thực hiện dịch vụ','Ngày hoàn thành dịch vụ','Đơn giá dự thầu','Thành tiền đã bao gồm thuế, phí, lệ phí (nếu có)']
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.dvlqCollection.map((e, i) => {
                    const row = e.newContractorName ? worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName + ' (đã đổi tên thành ' + e.newContractorName + ')','','','','','','',this.currency(e?.amount) + '']) : worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName,'','','','','','',this.currency(e?.amount) + '']);
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });

                    worksheet.mergeCells(`E${row.number}:J${row.number}`);
                    e?.dsDvlq?.map((hh, index) => {
                        const childRow = worksheet.addRow(['', '', '', '',hh?.description,hh?.qty,hh?.uom,hh?.place,hh?.dueDate,this.currency(hh?.lotWiningPrice) ? this.currency(hh?.lotWiningPrice) + '' : (this.currency(hh?.lotWiningPrice) == 0) ? '0' : '',this.currency(hh?.amount) ? this.currency(hh?.amount)+ '' : this.currency(hh?.amount) == 0 ? '0' : '']);
                        // const massRow = worksheet.getCell(`G${childRow.number}`);
                        // massRow.alignment = {horizontal: 'right'};
                        childRow.eachCell((cell, index) => {
                            cell.border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        });
                        worksheet.mergeCells(`A${childRow.number}:D${childRow.number}`);
                    });
                });

                //
                const total = worksheet.addRow(['Tổng cộng giá dự thầu của hàng hóa đã bao gồm thuế, phí, lệ phí (nếu có)', '', '', '', '','','','','','',this.getTotalAmountDvlq() ? this.currency(this.getTotalAmountDvlq()) : '']);
                worksheet.mergeCells(`A${total.number}:J${total.number}`);
                total.eachCell((cell, index) => {
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                const textTotal = worksheet.getCell(`A${total.number}`);
                textTotal.alignment = {horizontal: 'center'};
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG DỊCH VỤ LIÊN QUAN -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });
            },
            exportExce12_2B(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách hàng hóa');

                // Thông tin chung
                const titleGeneralInfor = worksheet.addRow(['THÔNG TIN CHUNG ']);
                titleGeneralInfor.font = {
                    bold: true,
                    color: {argb: '000000'},
                    size: 12
                };
                worksheet.mergeCells(`A${titleGeneralInfor.number}:B${titleGeneralInfor.number}`);
                const codeTBMT = worksheet.addRow([]);
                codeTBMT.values = ['Mã TBMT ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo, '' , '', '', ''];
                codeTBMT.font = {
                    color: {argb: '000000'},
                    size: 12
                };
                codeTBMT.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${codeTBMT.number}:B${codeTBMT.number}`);
                worksheet.mergeCells(`C${codeTBMT.number}:G${codeTBMT.number}`);

                const biddingPackage = worksheet.addRow([]);
                biddingPackage.values = ['Tên gói thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.bidName, '' , '', '', ''];
                biddingPackage.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingPackage.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingPackage.number}:B${biddingPackage.number}`);
                worksheet.mergeCells(`C${biddingPackage.number}:G${biddingPackage.number}`);

                const biddingParty = worksheet.addRow([]);
                biddingParty.values = ['Tên bên mời thầu ', '', this.dtlKqlcnt?.bideContractorInputResultDTO?.procuringEntityName, '' , '', '', ''];
                biddingParty.font = {
                    color: {argb: '000000'},
                    size: 12
                };

                biddingParty.alignment = {vertical: 'middle'};
                worksheet.mergeCells(`A${biddingParty.number}:B${biddingParty.number}`);
                worksheet.mergeCells(`C${biddingParty.number}:G${biddingParty.number}`);

                //End Thông tin chung

                const headerTitles = ['STT', 'Mã phần', 'Tên phần', 'Nhà thầu trúng thầu'].concat(!this.isVatTuInternetLot() ? ['Danh mục hàng hóa'] : []).concat(this.isVatTuInternetLot() ? ['Mặt hàng dự thầu', 'Mã hàng hóa', 'Phân nhóm'] : []).concat(['Đơn vị tính', 'Khối lượng', 'Xuất xứ\n[ghi tên quốc gia, vùng lãnh thổ, ký mã hiệu, nhãn hiệu, hãng sản xuất]']).concat(this.isVatTuInternetLot() ? ['Nguồn vốn đầu tư','Số lượng định mức','Số lưu hành hoặc số giấy phép nhập khẩu','Năm sản xuất','Cấu hình, tính năng kỹ thuật cơ bản','Chủng loại (Models)'] : []).concat(['Mã HS', 'Đơn giá bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu', 'Thuế, phí, lệ phí liên quan đến nhập khẩu đối với một đơn vị hàng hóa', 'Đơn giá không bao gồm thuế, phí liên quan đến nhập khẩu', 'Giá từng hạng mục không bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu', 'Chi phí vận chuyển, bảo hiểm và các dịch vụ khác', 'Thành tiền không bao gồm thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thuế, phí, lệ phí liên quan đến nhập khẩu đối với từng hạng mục', 'Thuế tiêu thụ đặc biệt (nếu có), thuế VAT', 'Thành tiền bao gồm thuế, phí, lệ phí liên quan đến nhập khẩu, thuế tiêu thụ đặc biệt (nếu có), thuế VAT']);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index + 1).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                this.hh12BCollection.map((e, i) => {
                    const row = e.newContractorName ? worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e.contractorName + ' (đã đổi tên thành ' + e.newContractorName +' )'].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['', '', '','','','','','',''] : []).concat(['', '', '', '', '', '', '', '', '', '', '', '', '']))
                        : worksheet.addRow([(i + 1), e?.lotNo, e?.lotName, e?.contractorName].concat(!this.isVatTuInternetLot() ? [''] : []).concat(this.isVatTuInternetLot() ? ['', '', '','','','','','',''] : []).concat(['', '', '', '', '', '', '', '', '', '', '', '', '']));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    row.eachCell((cell, index) => {
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    if(this.isVatTuInternetLot()){
                        worksheet.mergeCells(`E${row.number}:W${row.number}`);
                    } else {
                        worksheet.mergeCells(`E${row.number}:P${row.number}`);
                    }
                    e?.dsHH?.map((hh, index) => {
                        const childRow = worksheet.addRow(['', '', '', ''].concat(!this.isVatTuInternetLot() ? [hh?.name] : []).concat(this.isVatTuInternetLot() ? [hh?.bidItem ? hh.bidItem : '', hh?.code ? hh.code : '', hh?.group ? hh.group : ''] : []).concat([hh?.uom, hh?.qty, hh?.origin]).concat(this.isVatTuInternetLot() ? [hh.investCapital,hh.ratedQuantity,hh.circulationNum,hh.yearManufacture,hh.feature,hh.model] :[]).concat([hh?.maHS, this.currency(hh?.priceIncludeTax), this.currency(hh?.tax), this.currency(hh?.priceExcludeTax), this.currency(hh?.unitPrice), this.currency(hh?.cost), this.currency(hh?.amountBeforeTax), this.currency(hh?.importTax), this.currency(hh?.taxSpecial), hh?.amount ? this.currency(hh?.amount) : '']));
                        // const massRow = worksheet.getCell(`G${childRow.number}`);
                        // massRow.alignment = {horizontal: 'right'};
                        childRow.eachCell((cell, index) => {
                            cell.border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        });
                        worksheet.mergeCells(`A${childRow.number}:D${childRow.number}`);
                    });
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'BẢNG GIÁ DỰ THẦU CỦA HÀNG HÓA ĐƯỢC SẢN XUẤT, GIA CÔNG NGOÀI NƯỚC ĐÃ ĐƯỢC NHẬP KHẨU HOẶC SẼ ĐƯỢC NHẬP KHẨU VÀO VIỆT NAM -' + this.dtlKqlcnt?.bideContractorInputResultDTO?.notifyNo + '.xlsx');
                });
            },
            checkEnableVentureColumn(arr){
                let venture = arr?.find(it => it?.ventureName != null);
                return venture;
            },
            checkEnableColumnsKqmMedicines(bidForm,planType,bidEstimatePrice,bidPrice){
                if(['TTH','TGTHCD','LCNT_DB','DPG'].includes(bidForm)) return true;
                if(bidForm == 'CDTRG' && planType == 'TX' && ( (bidEstimatePrice && bidEstimatePrice < 100000000) || bidPrice < 100000000 )) return true;
                return false;
            },
            checkMuoiTrieu(money){
                if(!this.stringNullOrEmpty(money)){
                    if(money < 10000000) return true;
                };
                return false;
            },
            isHiddenBidMode(bidForm, isInternet) {
                return [0, '0'].includes(isInternet) && ['LCNT_DB', 'CDTRG', 'TTH', 'TVCN'].includes(bidForm);
            },

            passSelectedTab(){
                if(!this.step){
                    this.step = 'tbmt';
                    this.selectedTab = this.step;

                }else{
                    if(this.step == 'bbmt' && this.checkConditionBbmt(this.stepCode,this.bidoNotifyView?.isInternet))
                        this.selectedTab = 'kqmt';
                    else if(this.step == 'bbmt' && this.checkConditionBbmtDkKt(this.stepCode,this.bidoNotifyView?.isInternet)){
                        this.selectedTab = 'kqmtKT';
                    } else if (this.step == 'kqlcnt-medicine'){
                        this.selectedTab = 'kqlcnt';
                    }
                    else{
                        this.selectedTab = this.step;
                    }
                }

            },

            checkNoInternetAndNoDometicKq() {
                return this.dtlKqlcnt?.bideContractorInputResultDTO?.isInternet == 0 && this.dtlKqlcnt?.bideContractorInputResultDTO?.isDomestic == 0;
            },

            checkNoInternetAndNoDometic(value) {
                return value?.isInternet == 0 && value.isDomestic == 0;
            },
            checkHaveBidPriceDetailOfContractor(contractorList, isNoInternetAndNoDometic){
                let isHaveBidPriceDetailOfContractor = false;
                if(isNoInternetAndNoDometic) {
                    contractorList?.forEach((con, index) => {
                        const bidPriceDetail = JSON.parse(con?.data[0]?.bidPriceDetail);
                        if(bidPriceDetail[0]?.invest || bidPriceDetail[0]?.moneyType || bidPriceDetail[0]?.exchangeRate) {
                            isHaveBidPriceDetailOfContractor = true;
                        }
                    });
                }
                return isHaveBidPriceDetailOfContractor;
            },
            checkHaveBidPriceDetailOfGoods(goodsList, isNoInternetAndNoDometic){
                let isHaveBidPriceDetailOfGoods = false;
                if(isNoInternetAndNoDometic) {
                    goodsList?.forEach((item, index) => {
                        if(item?.invest || item?.moneyType || item?.exchangeRate) {
                            isHaveBidPriceDetailOfGoods = true;
                        }
                    });
                }
                return isHaveBidPriceDetailOfGoods;
            },
            checkHaveManyCurrency(bidPriceDetail){
                console.log('bidPriceDetail',bidPriceDetail);
                return !(bidPriceDetail?.length === 1 && bidPriceDetail?.[0]?.moneyType === 'VND');
            },
            exportExcelKhongLoKhongThuocDapUng(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                headerTitles = [
                    'Mã định danh',
                    'Tên nhà thầu',
                    this.dtlBidoBidNotifyRes?.displayTechScore ? 'Điểm kỹ thuật (nếu có)' : null,
                    'Thời gian thực hiện hợp đồng',
                    'Lý do chọn nhà thầu'
                ].filter(it => it != null);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                (this.dtlWinningContractor).map((e, i) => {
                    let row = worksheet.addRow([
                        e?.contractorCode ? e?.contractorCode : '',
                        e?.ventureName ? e?.ventureName : e?.contractorName ? e?.contractorName :  '',
                        this.dtlBidoBidNotifyRes?.displayTechScore ? this.fixedValue(e?.techScore) : null,
                        this.mapCPeriod(e?.contractorCode) || (this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriod + ' ' + this.getNameOfPeriod(dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriodUnit) ),
                        this.paseJson(e?.content)?.reason ? this.paseJson(e?.content)?.reason : 'Đạt yêu cầu kỹ thuật'
                    ].filter(it => it != null));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i <= headerTitles.length; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_dat_ki_thuat' + '.xlsx');
                });
            },
            exportExcelKhongLoKhongThuocKhongDapUng(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                headerTitles = [
                    'Mã định danh',
                    'Tên nhà thầu',
                    this.dtlBidoBidNotifyRes?.displayTechScore ? 'Điểm kỹ thuật (nếu có)' : null,
                    'Thời gian thực hiện hợp đồng',
                    'Lý do không đáp ứng'
                ].filter(it => it != null);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                (this.dtlFalseContractor).map((e, i) => {
                    let row = worksheet.addRow([
                        e?.contractorCode ? e?.contractorCode : '',
                        e?.child[0]?.ventureName ? e?.child[0]?.ventureName : e?.child[0]?.contractorName ? e?.child[0]?.contractorName :  '',
                        this.dtlBidoBidNotifyRes?.displayTechScore ? this.fixedValue(e?.child[0]?.techScore) : null,
                        this.mapCPeriod(e?.contractorCode) || (this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriod + ' ' + this.getNameOfPeriod(dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriodUnit) ),
                        e?.evalType ? this.getFailReason(e?.evalType) : ''
                    ].filter(it => it != null));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i <= headerTitles.length; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_khong_dat_ki_thuat' + '.xlsx');
                });
            },
            exportExcelKhongLoCoThuoc(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                headerTitles = [
                    'Mã định danh',
                    'Tên nhà thầu',
                    'Điểm kỹ thuật (nếu có)',
                    'Thời gian thực hiện hợp đồng',
                    'Lý do chọn nhà thầu'
                ].filter(it => it != null);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                (this.dtlWinningContractorMedicine).map((e, i) => {
                    let row = worksheet.addRow([
                        e?.contractorCode ? e?.contractorCode : '',
                        e?.ventureName ? e?.ventureName : e?.contractorName ? e?.contractorName :  '',
                        this.fixedValue(e?.techScore) || '',
                        this.mapCPeriod(e?.contractorCode) || (this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriod + ' ' + this.getNameOfPeriod(this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriodUnit) ),
                        'Đạt yêu cầu kỹ thuật'
                    ].filter(it => it != null));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i <= headerTitles.length; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_dat_ki_thuat' + '.xlsx');
                });
            },
            exportExcelKhongLoCoThuocKhongDapUng(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                headerTitles = [
                    'Mã định danh',
                    'Tên nhà thầu',
                    'Điểm kỹ thuật (nếu có)',
                    'Thời gian thực hiện hợp đồng',
                    'Lý do không đáp ứng'
                ].filter(it => it != null);
                const headerRow = worksheet.addRow(headerTitles);
                headerRow.eachCell((cell, index) => {
                    cell.fill = {
                        type: 'pattern',
                        pattern: 'solid',
                        fgColor: {argb: 'EEEEEE'},
                        bgColor: {argb: ''}
                    };
                    cell.font = {
                        bold: true,
                        color: {argb: '000000'},
                        size: 12
                    };
                    cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                    worksheet.getColumn(index).width = 30;
                    cell.border = {
                        top: {style: 'thin'},
                        left: {style: 'thin'},
                        bottom: {style: 'thin'},
                        right: {style: 'thin'}
                    };
                });
                console.log('this.dtlFalseContractorMedicine', this.dtlFalseContractorMedicine);
                (this.dtlFalseContractorMedicine).map((e, i) => {
                    let row = worksheet.addRow([
                        e?.contractorCode ? e?.contractorCode : '',
                        e?.ventureName ? e?.ventureName : e?.contractorName ? e?.contractorName :  '',
                        this.fixedValue(e?.techScore) || '',
                        this.mapCPeriod(e?.contractorCode) || (this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriod + ' ' + this.getNameOfPeriod(this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.contractPeriodUnit) ),
                        this.MAP_EVAL_TYPE[e?.evalType] || e?.noPassedRson || ' '
                    ].filter(it => it != null));
                    const sttRow = worksheet.getCell(`A${row.number}`);
                    sttRow.alignment = {horizontal: 'left'};
                    for (let i = 1; i <= headerTitles.length; i++) {
                        row.getCell(i).border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    }
                });
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_khong_dat_ki_thuat' + '.xlsx');
                });
            },
            exportExcelDatKiThuatCoLo(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                if(this.viewInforNTofDSNTDKT == 0){
                    headerTitles = [
                        'Mã phần lô',
                        this.getLotNameColumn(),
                        'Tên nhà thầu',
                        (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? 'Điểm kỹ thuật (nếu có)' : null,
                        'Thời gian thực hiện hợp đồng',
                        'Lý do chọn nhà thầu'
                    ].filter(it => it != null);
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    (this.winningContractorMultiLotGroupLo).map((e, i) => {
                        let row = worksheet.addRow([
                            e?.items[0]?.lotNo ? e?.items[0]?.lotNo : '',
                            e?.items[0]?.lotName,
                            '',
                            (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? '' : null,
                            '',
                            '',
                        ].filter(it => it != null));
                        if((this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1)){
                            worksheet.mergeCells(`B${row.number}:F${row.number}`);
                        } else {
                            worksheet.mergeCells(`B${row.number}:E${row.number}`);
                        }
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        for (let i = 1; i <= headerTitles.length; i++) {
                            row.getCell(i).border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        }

                        e?.items?.map((item, itemIndex) => {
                            let row = worksheet.addRow([
                                '',
                                '',
                                item?.ventureName || item?.contractorName,
                                (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? (this.fixedValue(item?.content?.totalScore) || this.fixedValue(item?.techScore)) : null,
                                item?.cperiod + ' ' + (item?.cperiodUnit === 'D' ? ' ngày' : ' tháng'),
                                "Đạt yêu cầu kỹ thuật"
                            ].filter(it => it != null));

                            worksheet.mergeCells(`A${row.number}:B${row.number}`);


                            const sttRow = worksheet.getCell(`A${row.number}`);
                            sttRow.alignment = {horizontal: 'left'};
                            for (let i = 1; i <= headerTitles.length; i++) {
                                row.getCell(i).border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            }
                        });


                    });
                } else if(this.viewInforNTofDSNTDKT == 1){
                    headerTitles = [
                        'Mã định danh',
                        'Tên nhà thầu',
                        (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? 'Điểm kỹ thuật (nếu có)' : null,
                        'Thời gian thực hiện hợp đồng',
                        'Lý do chọn nhà thầu'
                    ].filter(it => it != null);
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    (this.winningContractorMultiLotGroupNT).map((e, i) => {
                        let row = worksheet.addRow([
                            e?.items[0]?.contractorCode ? e?.items[0]?.contractorCode : '',
                            e?.items[0]?.ventureName || e?.items[0]?.contractorName,
                        ].filter(it => it != null));
                        if((this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1)){
                            worksheet.mergeCells(`B${row.number}:E${row.number}`);
                        } else {
                            worksheet.mergeCells(`B${row.number}:D${row.number}`);
                        }
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        for (let i = 1; i <= headerTitles.length; i++) {
                            row.getCell(i).border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        }

                        e?.items?.map((item, itemIndex) => {
                            let row = worksheet.addRow([
                                '',
                                item?.lotName,
                                (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? (this.fixedValue(item?.content?.totalScore) || this.fixedValue(item?.techScore)) : null,
                                item?.cperiod + ' ' + (item?.cperiodUnit === 'D' ? ' ngày' : ' tháng'),
                                "Đạt yêu cầu kỹ thuật"
                            ].filter(it => it != null));

                            //worksheet.mergeCells(`A${row.number}:B${row.number}`);


                            const sttRow = worksheet.getCell(`A${row.number}`);
                            sttRow.alignment = {horizontal: 'left'};
                            for (let i = 1; i <= headerTitles.length; i++) {
                                row.getCell(i).border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            }
                        });


                    });
                }
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_dat_ki_thuat' + '.xlsx');
                });
            },
            exportExcelKhongDatKiThuatCoLo(){
                const workbook = new ExcelJS.Workbook();
                const worksheet = workbook.addWorksheet('Danh sách phần lô');

                //End Thông tin chung
                if(this.viewInforNTofDSNTDKT == 0){
                    headerTitles = [
                        'Mã phần lô',
                        this.getLotNameColumn(),
                        'Tên nhà thầu',
                        (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? 'Điểm kỹ thuật (nếu có)' : null,
                        'Thời gian thực hiện hợp đồng',
                        'Lý do không chọn nhà thầu'
                    ].filter(it => it != null);
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    (this.falseContractorMultiLotGroupLo).map((e, i) => {
                        let row = worksheet.addRow([
                            e?.items[0]?.lotNo ? e?.items[0]?.lotNo : '',
                            e?.items[0]?.lotName ? e?.items[0]?.lotName : '',
                            '',
                            (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? '' : null,
                            '',
                            '',
                        ].filter(it => it != null));
                        if((this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1)){
                            worksheet.mergeCells(`B${row.number}:F${row.number}`);
                        } else {
                            worksheet.mergeCells(`B${row.number}:E${row.number}`);
                        }
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        for (let i = 1; i <= headerTitles.length; i++) {
                            row.getCell(i).border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        }

                        e?.items?.map((item, itemIndex) => {
                            let row = worksheet.addRow([
                                '',
                                '',
                                item?.ventureName || item?.contractorName,
                                (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? (this.fixedValue(item?.content?.totalScore) || this.fixedValue(item?.techScore) || '') : null,
                                item?.cperiod + ' ' + (item?.cperiodUnit === 'D' ? ' ngày' : ' tháng'),
                                this.MAP_EVAL_TYPE[item?.evalType] || item?.noPassedRson || ' '
                            ].filter(it => it != null));

                            worksheet.mergeCells(`A${row.number}:B${row.number}`);


                            const sttRow = worksheet.getCell(`A${row.number}`);
                            sttRow.alignment = {horizontal: 'left'};
                            for (let i = 1; i <= headerTitles.length; i++) {
                                row.getCell(i).border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            }
                        });


                    });
                } else if(this.viewInforNTofDSNTDKT == 1){
                    headerTitles = [
                        'Mã định danh',
                        'Tên nhà thầu',
                        (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? 'Điểm kỹ thuật (nếu có)' : null,
                        'Thời gian thực hiện hợp đồng',
                        'Lý do không chọn nhà thầu'
                    ].filter(it => it != null);
                    const headerRow = worksheet.addRow(headerTitles);
                    headerRow.eachCell((cell, index) => {
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: {argb: 'EEEEEE'},
                            bgColor: {argb: ''}
                        };
                        cell.font = {
                            bold: true,
                            color: {argb: '000000'},
                            size: 12
                        };
                        cell.alignment = {vertical: 'middle', horizontal: 'center', wrapText: true};
                        worksheet.getColumn(index).width = 30;
                        cell.border = {
                            top: {style: 'thin'},
                            left: {style: 'thin'},
                            bottom: {style: 'thin'},
                            right: {style: 'thin'}
                        };
                    });
                    (this.falseContractorMultiLotGroupNT).map((e, i) => {
                        let row = worksheet.addRow([
                            e?.items[0]?.contractorCode ? e?.items[0]?.contractorCode : '',
                            e?.items[0]?.ventureName || e?.items[0]?.contractorName,
                        ].filter(it => it != null));
                        if((this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1)){
                            worksheet.mergeCells(`B${row.number}:E${row.number}`);
                        } else {
                            worksheet.mergeCells(`B${row.number}:D${row.number}`);
                        }
                        const sttRow = worksheet.getCell(`A${row.number}`);
                        sttRow.alignment = {horizontal: 'left'};
                        for (let i = 1; i <= headerTitles.length; i++) {
                            row.getCell(i).border = {
                                top: {style: 'thin'},
                                left: {style: 'thin'},
                                bottom: {style: 'thin'},
                                right: {style: 'thin'}
                            };
                        }

                        e?.items?.map((item, itemIndex) => {
                            let row = worksheet.addRow([
                                '',
                                item?.lotName,
                                (this.isDisplayTechScore() || this.dtlBidoBidNotifyRes?.bidNoContractorResponse?.bidNotification?.isMedicine == 1) ? (this.fixedValue(item?.content?.totalScore) || this.fixedValue(item?.techScore || '')) : null,
                                item?.cperiod + ' ' + (item?.cperiodUnit === 'D' ? ' ngày' : ' tháng'),
                                this.MAP_EVAL_TYPE[item?.evalType] || item.noPassedRson || ' '
                            ].filter(it => it != null));

                            // worksheet.mergeCells(`A${row.number}:B${row.number}`);


                            const sttRow = worksheet.getCell(`A${row.number}`);
                            sttRow.alignment = {horizontal: 'left'};
                            for (let i = 1; i <= headerTitles.length; i++) {
                                row.getCell(i).border = {
                                    top: {style: 'thin'},
                                    left: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    right: {style: 'thin'}
                                };
                            }
                        });


                    });
                }
                workbook.xlsx.writeBuffer().then((data) => {
                    const blob = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    saveAs(blob, 'Danh_sach_nha_thau_khong_dat_ki_thuat' + '.xlsx');
                });
            },
        },
        created() {
            this.loadUserInfo();

            this.selectedRole = localStorage.getItem("currentRole");
            this.isEnglish = this.checkIsEn();
            if(this.isEnglish){
                this.register = 'Register'
            }
            this.loadCatList();
            this.loadDetail();
            this.passSelectedTab();

        }
    })
</script> 