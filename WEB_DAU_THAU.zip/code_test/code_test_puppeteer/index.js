const puppeteer = require('puppeteer');

(async () => {
    console.log('=== BẮT ĐẦU TEST PUPPETEER VỚI MUASAMCONG ===\n');

    // Test với headless mode (stealth)
    const browser = await puppeteer.launch({
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-blink-features=AutomationControlled', // Tắt dấu hiệu automation
            '--disable-dev-shm-usage',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process'
        ]
    });

    const page = await browser.newPage();

    // Bypass headless detection
    await page.evaluateOnNewDocument(() => {
        // Override navigator.webdriver
        Object.defineProperty(navigator, 'webdriver', {
            get: () => false,
        });

        // Override chrome property
        window.chrome = {
            runtime: {},
        };

        // Override permissions
        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
        );

        // Override plugins
        Object.defineProperty(navigator, 'plugins', {
            get: () => [1, 2, 3, 4, 5],
        });

        // Override languages
        Object.defineProperty(navigator, 'languages', {
            get: () => ['vi-VN', 'vi', 'en-US', 'en'],
        });
    });

    // Set viewport giống real browser
    await page.setViewport({ width: 1920, height: 1080 });

    // Set user-agent thật
    await page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    );

    // Set extra headers
    await page.setExtraHTTPHeaders({
        'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    });

    console.log('✓ Đã khởi tạo browser với stealth mode');
    console.log('✓ Đang truy cập trang muasamcong...\n');

    try {
        const response = await page.goto('https://muasamcong.mpi.gov.vn/web/guest', {
            waitUntil: 'networkidle0',
            timeout: 60000
        });

        console.log(`Status code: ${response.status()}`);
        console.log(`URL hiện tại: ${page.url()}`);

        // Đợi một chút để JS render
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Lấy title
        const title = await page.title();
        console.log(`Title: ${title}\n`);

        // Chụp screenshot
        await page.screenshot({ path: 'test-muasamcong.png', fullPage: true });
        console.log('✓ Đã chụp screenshot: test-muasamcong.png\n');

        // Check các dấu hiệu bị chặn
        const checks = await page.evaluate(() => {
            const results = {
                hasRecaptcha: false,
                hasCloudflare: false,
                hasCaptcha: false,
                hasAccessDenied: false,
                hasMainContent: false,
                bodyText: '',
            };

            // Check reCAPTCHA
            results.hasRecaptcha = !!(
                document.querySelector('iframe[src*="recaptcha"]') ||
                document.querySelector('.g-recaptcha') ||
                document.querySelector('[data-sitekey]')
            );

            // Check Cloudflare
            const bodyText = document.body?.innerText || '';
            results.bodyText = bodyText.substring(0, 500);
            results.hasCloudflare = bodyText.includes('Checking your browser') ||
                bodyText.includes('Cloudflare') ||
                !!document.querySelector('#challenge-form');

            // Check CAPTCHA generic
            results.hasCaptcha = bodyText.toLowerCase().includes('captcha');

            // Check Access Denied
            results.hasAccessDenied = bodyText.includes('Access Denied') ||
                bodyText.includes('403 Forbidden') ||
                bodyText.includes('Truy cập bị từ chối');

            // Check main content (có load được nội dung chính không)
            results.hasMainContent = !!(
                document.querySelector('.portlet') ||
                document.querySelector('#content') ||
                document.querySelector('.container') ||
                document.querySelector('[class*="main"]')
            );

            return results;
        });

        // In kết quả kiểm tra
        console.log('=== KẾT QUẢ KIỂM TRA ===');
        console.log(`❌ reCAPTCHA: ${checks.hasRecaptcha ? 'CÓ - BỊ CHẶN!' : 'KHÔNG'}`);
        console.log(`❌ Cloudflare: ${checks.hasCloudflare ? 'CÓ - BỊ CHẶN!' : 'KHÔNG'}`);
        console.log(`❌ CAPTCHA: ${checks.hasCaptcha ? 'CÓ - BỊ CHẶN!' : 'KHÔNG'}`);
        console.log(`❌ Access Denied: ${checks.hasAccessDenied ? 'CÓ - BỊ CHẶN!' : 'KHÔNG'}`);
        console.log(`✓ Có nội dung chính: ${checks.hasMainContent ? 'CÓ' : 'KHÔNG'}\n`);

        // Kết luận
        const isBlocked = checks.hasRecaptcha || checks.hasCloudflare ||
            checks.hasCaptcha || checks.hasAccessDenied;

        if (isBlocked) {
            console.log('🚫 KẾT LUẬN: TRANG WEB ĐÃ CHẶN HEADLESS BROWSER!');
            console.log('→ Cần dùng thêm puppeteer-extra-plugin-stealth hoặc undetected-chromedriver\n');
        } else if (checks.hasMainContent) {
            console.log('✅ KẾT LUẬN: HEADLESS BROWSER HOẠT ĐỘNG BÌNH THƯỜNG!');
            console.log('→ Có thể crawl dữ liệu từ trang này\n');
        } else {
            console.log('⚠️ KẾT LUẬN: KHÔNG RÕ - TRANG CÓ THỂ ĐANG LOAD');
            console.log('→ Kiểm tra screenshot để xác nhận\n');
        }

        // In một mẫu nội dung
        console.log('=== MẪU NỘI DUNG TRANG ===');
        console.log(checks.bodyText);
        console.log('========================\n');

    } catch (error) {
        console.error('❌ LỖI:', error.message);
    }

    await browser.close();
    console.log('=== KẾT THÚC TEST ===');
})();