# Bidding Data Crawler

Hệ thống crawl dữ liệu đấu thầu quốc gia từ [muasamcong.mpi.gov.vn](https://muasamcong.mpi.gov.vn).

## Tính Năng

- ✅ Crawl danh sách thông tin đấu thầu theo ngày
- ✅ Crawl chi tiết từng bản ghi qua API
- ✅ Hỗ trợ 17+ loại bản ghi (TBMT, KHLCNT, Dự án, Hợp đồng...)
- ✅ Lưu trữ vào Supabase (PostgreSQL)
- ✅ Scheduler tự động hàng ngày
- ✅ Retry failed records
- ✅ Logging đầy đủ

## Cài Đặt

```bash
# Clone project
cd crawler

# Install dependencies
npm install

# Copy và config .env
cp .env.example .env

# Chạy migration database (nếu cần)
# Sử dụng file database/supabase_schema.sql trong Supabase SQL Editor
```

## Sử Dụng

### Crawl thủ công

```bash
# Crawl TBMT ngày hôm nay
node crawler.js

# Crawl theo khoảng thời gian
node crawler.js -s 2026-01-01 -e 2026-01-03

# Crawl nhiều loại bản ghi
node crawler.js -s 2026-01-01 -e 2026-01-01 -t es-notify-contractor,es-ct-contract

# Crawl kèm detail
node crawler.js -s 2026-01-01 -e 2026-01-01 -t es-notify-contractor -d

# Xem help
node crawler.js --help
```

### Scheduler tự động

```bash
# Start scheduler daemon
node scheduler.js

# Crawl ngày hôm qua và exit
node scheduler.js --yesterday

# Crawl pending details
node scheduler.js --details

# Retry failed records
node scheduler.js --retry

# Health check
node scheduler.js --health
```

### NPM Scripts

```bash
npm run crawl              # Crawl với default options
npm run crawl:yesterday    # Crawl ngày hôm qua
npm run crawl:tbmt         # Chỉ crawl TBMT
npm run crawl:all-types    # Crawl tất cả types chính
npm run scheduler          # Start scheduler daemon
```

## Cấu Trúc Thư Mục

```
crawler/
├── crawler.js          # Main crawler logic
├── scheduler.js        # Cron job scheduler
├── package.json        # Dependencies
├── .env.example        # Environment template
├── logs/               # Log files
│   ├── crawler.log
│   └── error.log
└── README.md

database/
├── supabase_schema.sql # Database schema

warehouse/
├── catalog_search/
│   ├── detail_api_mapping.json  # API endpoints mapping
│   └── ...
└── data_example_by_type/        # Sample data

documentation/
└── Tài liệu tìm hiểu về thầu.md # Business documentation
```

## Loại Bản Ghi Hỗ Trợ

| Type | Tên | Mô Tả |
|------|-----|-------|
| `es-bidp-project-p` | Dự án | Thông tin dự án đầu tư |
| `es-plan-project-p` | KHLCNT | Kế hoạch lựa chọn nhà thầu |
| `es-notify-contractor` | TBMT | Thông báo mời thầu |
| `es-ct-contract` | Hợp đồng | Thông tin hợp đồng |
| `es-ycbg` | YCBG | Yêu cầu báo giá |
| `es-ct-publish-frame` | TTK | Thỏa thuận khung |
| ... | ... | Xem đầy đủ trong `detail_api_mapping.json` |

## Database Schema

Schema được thiết kế với các bảng chính:

- `raw_records` - Lưu data thô từ crawler
- `projects` - Dự án
- `plans` - Kế hoạch LCNT
- `notifications` - TBMT
- `contracts` - Hợp đồng
- `crawl_logs` - Log crawl
- `investors` - Danh sách chủ đầu tư
- `contractors` - Danh sách nhà thầu

Chi tiết xem file `database/supabase_schema.sql`.

## Lưu Ý

### Rate Limiting
- Website sử dụng reCAPTCHA v3
- Crawler đã implement stealth mode để bypass
- Delay 10 giây giữa các request để tránh bị block

### reCAPTCHA
- Tự động xử lý thông qua browser context
- Không cần service giải captcha bên ngoài

### Data Storage
- Data được lưu vào `raw_records` trước
- Có thể process sang các bảng cụ thể sau
- Detail data được crawl riêng để tối ưu performance

## Schedule Mặc Định

| Job | Thời gian | Mô tả |
|-----|-----------|-------|
| Daily crawl | 2:00 AM | Crawl data ngày hôm trước |
| Detail crawl | 6:00 AM | Crawl pending details |
| Retry failed | 12:00 PM | Retry các records lỗi |
| Cleanup | 3:00 AM (Chủ nhật) | Xóa logs > 30 ngày |
| Health check | Mỗi giờ | Kiểm tra database connection |

## Troubleshooting

### Lỗi Timeout
- Tăng `CRAWLER_TIMEOUT` trong .env
- Kiểm tra network connection

### Lỗi reCAPTCHA
- Đảm bảo browser không bị detect là headless
- Tăng delay giữa các request

### Lỗi Database
- Kiểm tra Supabase credentials
- Đảm bảo schema đã được tạo

## License

MIT
