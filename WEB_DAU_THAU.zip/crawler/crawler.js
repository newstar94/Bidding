/**
 * Bidding Data Crawler - muasamcong.mpi.gov.vn
 * 
 * Sử dụng Puppeteer (headless) để crawl dữ liệu đấu thầu
 * - Khai thác Vue component __vue__ để gọi API search
 * - Intercept requests để bắt response data
 * - Hỗ trợ pagination và crawl theo ngày
 */

const puppeteer = require('puppeteer');
const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');

// Load config
const detailApiMapping = require('../warehouse/catalog_search/detail_api_mapping.json');

// Supabase config
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;

// Crawler config
const CONFIG = {
    baseUrl: 'https://muasamcong.mpi.gov.vn',
    searchPage: '/web/guest/contractor-selection?render=index',
    pageSize: 10,
    delayBetweenRequests: 10000, // 10 giây
    delayBetweenPages: 5000,     // 5 giây giữa các page
    maxRetries: 3,
    timeout: 60000
};

/**
 * Khởi tạo Supabase client
 */
function initSupabase() {
    return createClient(SUPABASE_URL, SUPABASE_KEY);
}

/**
 * Khởi tạo browser với stealth mode
 */
async function initBrowser() {
    console.log('🚀 Khởi tạo browser với stealth mode...');

    const browser = await puppeteer.launch({
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-blink-features=AutomationControlled',
            '--disable-dev-shm-usage',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--window-size=1920,1080'
        ]
    });

    return browser;
}

/**
 * Setup page với stealth configurations
 */
async function setupPage(browser) {
    const page = await browser.newPage();

    // Bypass headless detection
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        window.chrome = { runtime: {} };

        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
                Promise.resolve({ state: Notification.permission }) :
                originalQuery(parameters)
        );

        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
        Object.defineProperty(navigator, 'languages', { get: () => ['vi-VN', 'vi', 'en-US', 'en'] });
    });

    // Set viewport và user-agent
    await page.setViewport({ width: 1920, height: 1080 });
    await page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    );

    // Set headers
    await page.setExtraHTTPHeaders({
        'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    });

    return page;
}

/**
 * Setup request interception để bắt API responses
 */
async function setupInterception(page, dataCollector) {
    await page.setRequestInterception(true);

    page.on('request', request => {
        request.continue();
    });

    page.on('response', async response => {
        const url = response.url();

        try {
            // Bắt search response
            if (url.includes('/advance-search')) {
                const data = await response.json();
                if (data && data.page) {
                    dataCollector.searchResults.push(data);
                    console.log(`📥 Bắt được search response: ${data.page.totalElements} records`);
                }
            }

            // Bắt detail response
            if (url.includes('/get-by-id')) {
                const data = await response.json();
                if (data) {
                    dataCollector.detailResults.push({
                        url: url,
                        data: data,
                        timestamp: new Date().toISOString()
                    });
                    console.log(`📥 Bắt được detail response`);
                }
            }
        } catch (error) {
            // Ignore non-JSON responses
        }
    });
}

/**
 * Tạo payload search theo ngày và type
 */
function createSearchPayload(date, recordType, pageNumber = 0) {
    const fromDate = new Date(date);
    fromDate.setHours(0, 0, 0, 0);

    const toDate = new Date(date);
    toDate.setHours(23, 59, 59, 59);

    return {
        pageSize: CONFIG.pageSize,
        pageNumber: String(pageNumber),
        query: [
            {
                index: "es-contractor-selection",
                matchType: "all-1",
                matchFields: ["notifyNo", "bidName"],
                filters: [
                    {
                        fieldName: "publicDate",
                        searchType: "range",
                        from: fromDate.toISOString(),
                        to: toDate.toISOString()
                    },
                    {
                        fieldName: "type",
                        searchType: "in",
                        fieldValues: [recordType]
                    }
                ]
            }
        ]
    };
}

/**
 * Inject code vào trang để gọi Vue component
 */
async function injectSearchCode(page, payload) {
    return await page.evaluate((payloadStr) => {
        return new Promise((resolve, reject) => {
            const payload = JSON.parse(payloadStr);

            // Tìm Vue component
            const searchHome = document.getElementById("search-home");
            if (!searchHome || !searchHome.__vue__) {
                reject(new Error('Không tìm thấy Vue component'));
                return;
            }

            const VueComponent = searchHome.__vue__;

            // Override axiosSearch để lấy data
            const originalSearch = VueComponent.axiosSearch;

            grecaptcha.ready(() => {
                grecaptcha.execute(VueComponent.siteKey, { action: 'submit' })
                    .then(token => {
                        VueComponent.spinningSearch = true;
                        VueComponent.payloadSearch = payload;

                        axios.post(
                            VueComponent.elasticSearch + "?token=" + token,
                            VueComponent.formatPayloadSearchWidthNotify(payload)
                        ).then(response => {
                            VueComponent.spinningSearch = false;

                            if (typeof response.data === 'number') {
                                reject(new Error('Rate limited'));
                            } else {
                                resolve({
                                    success: true,
                                    data: response.data,
                                    page: response.data.page
                                });
                            }
                        }).catch(error => {
                            reject(error);
                        });
                    });
            });
        });
    }, JSON.stringify(payload));
}

/**
 * Navigate đến trang detail và intercept response
 */
async function getDetailData(page, record, typeConfig) {
    const detailUrl = buildDetailUrl(record, typeConfig);

    return new Promise(async (resolve, reject) => {
        let detailData = null;

        // Listen for detail API response
        const responseHandler = async (response) => {
            if (response.url().includes('/get-by-id')) {
                try {
                    detailData = await response.json();
                } catch (e) { }
            }
        };

        page.on('response', responseHandler);

        try {
            await page.goto(detailUrl, {
                waitUntil: 'networkidle0',
                timeout: CONFIG.timeout
            });

            // Đợi để đảm bảo API đã response
            await new Promise(r => setTimeout(r, 2000));

            page.off('response', responseHandler);
            resolve(detailData);
        } catch (error) {
            page.off('response', responseHandler);
            reject(error);
        }
    });
}

/**
 * Build URL chi tiết từ record data
 */
function buildDetailUrl(record, typeConfig) {
    const baseParams = {
        'p_p_id': 'egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2',
        'p_p_lifecycle': '0',
        'p_p_state': 'normal',
        'p_p_mode': 'view',
        '_egpportalcontractorselectionv2_WAR_egpportalcontractorselectionv2_render': 'detail-v2'
    };

    const params = new URLSearchParams(baseParams);
    params.set('type', record.type);
    params.set('stepCode', record.stepCode || typeConfig.stepCodes[0]);
    params.set('id', record.id);
    params.set('notifyId', record.notifyId || 'undefined');
    params.set('inputResultId', record.inputResultId || 'undefined');
    params.set('bidOpenId', record.bidOpenId || 'undefined');

    if (record.pno) params.set('pno', record.pno);
    if (record.planNo) params.set('planNo', record.planNo);
    if (record.notifyNo) params.set('notifyNo', record.notifyNo);

    return `${CONFIG.baseUrl}/web/guest/contractor-selection?${params.toString()}`;
}

/**
 * Lưu data vào Supabase
 */
async function saveToSupabase(supabase, tableName, data) {
    try {
        const { error } = await supabase
            .from(tableName)
            .upsert(data, { onConflict: 'id' });

        if (error) {
            console.error(`❌ Lỗi lưu vào ${tableName}:`, error.message);
            return false;
        }

        console.log(`✅ Đã lưu vào ${tableName}`);
        return true;
    } catch (error) {
        console.error(`❌ Exception khi lưu:`, error.message);
        return false;
    }
}

/**
 * Lưu raw data vào bảng raw_records
 */
async function saveRawRecord(supabase, record, detailData) {
    const rawRecord = {
        id: record.id,
        record_type: record.type,
        record_no: record.notifyNo || record.pno || record.planNo || record.contractCode,
        public_date: record.publicDate,
        list_data: record,
        detail_data: detailData,
        crawled_at: new Date().toISOString(),
        processed: false
    };

    return await saveToSupabase(supabase, 'raw_records', rawRecord);
}

/**
 * Log crawl session
 */
async function logCrawlSession(supabase, crawlDate, recordType, stats) {
    const logEntry = {
        crawl_date: crawlDate,
        record_type: recordType,
        total_records: stats.total,
        success_count: stats.success,
        error_count: stats.errors,
        start_time: stats.startTime,
        end_time: new Date().toISOString(),
        duration_seconds: Math.floor((Date.now() - new Date(stats.startTime).getTime()) / 1000),
        errors: stats.errorMessages
    };

    await saveToSupabase(supabase, 'crawl_logs', logEntry);
}

/**
 * Delay helper
 */
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Format date to YYYY-MM-DD
 */
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

/**
 * Crawl một ngày cho một loại record
 */
async function crawlDayByType(page, supabase, date, recordType) {
    const typeConfig = detailApiMapping.types[recordType];
    if (!typeConfig) {
        console.error(`❌ Không tìm thấy config cho type: ${recordType}`);
        return;
    }

    console.log(`\n📅 Crawling ${typeConfig.name} ngày ${formatDate(date)}...`);

    const stats = {
        total: 0,
        success: 0,
        errors: 0,
        startTime: new Date().toISOString(),
        errorMessages: []
    };

    try {
        // Navigate đến trang search
        await page.goto(CONFIG.baseUrl + CONFIG.searchPage, {
            waitUntil: 'networkidle0',
            timeout: CONFIG.timeout
        });

        // Đợi Vue component load
        await delay(3000);

        // Gọi search API page đầu tiên
        const payload = createSearchPayload(date, recordType, 0);
        let result;

        try {
            result = await injectSearchCode(page, payload);
        } catch (error) {
            console.error(`❌ Lỗi search: ${error.message}`);
            stats.errors++;
            stats.errorMessages.push(error.message);
            return stats;
        }

        if (!result || !result.page) {
            console.log(`⚠️ Không có dữ liệu cho ${formatDate(date)}`);
            return stats;
        }

        const totalPages = result.page.totalPages;
        const totalElements = result.page.totalElements;
        stats.total = totalElements;

        console.log(`📊 Tổng: ${totalElements} records, ${totalPages} pages`);

        // Process trang đầu tiên
        for (const record of result.page.content) {
            try {
                // Lưu raw record trước
                await saveRawRecord(supabase, record, null);
                stats.success++;
            } catch (error) {
                stats.errors++;
                stats.errorMessages.push(`Record ${record.id}: ${error.message}`);
            }
        }

        // Loop qua các trang còn lại
        for (let pageNum = 1; pageNum < totalPages; pageNum++) {
            console.log(`📄 Processing page ${pageNum + 1}/${totalPages}...`);

            await delay(CONFIG.delayBetweenRequests);

            const pagePayload = createSearchPayload(date, recordType, pageNum);

            try {
                const pageResult = await injectSearchCode(page, pagePayload);

                if (pageResult && pageResult.page && pageResult.page.content) {
                    for (const record of pageResult.page.content) {
                        try {
                            await saveRawRecord(supabase, record, null);
                            stats.success++;
                        } catch (error) {
                            stats.errors++;
                            stats.errorMessages.push(`Record ${record.id}: ${error.message}`);
                        }
                    }
                }
            } catch (error) {
                console.error(`❌ Lỗi page ${pageNum + 1}: ${error.message}`);
                stats.errors++;
                stats.errorMessages.push(`Page ${pageNum + 1}: ${error.message}`);
            }
        }

    } catch (error) {
        console.error(`❌ Lỗi crawl: ${error.message}`);
        stats.errors++;
        stats.errorMessages.push(error.message);
    }

    // Log session
    await logCrawlSession(supabase, formatDate(date), recordType, stats);

    console.log(`✅ Hoàn thành: ${stats.success}/${stats.total} records (${stats.errors} lỗi)`);
    return stats;
}

/**
 * Crawl detail cho các records đã có trong raw_records
 */
async function crawlDetails(page, supabase, recordType, limit = 100) {
    const typeConfig = detailApiMapping.types[recordType];
    if (!typeConfig) {
        console.error(`❌ Không tìm thấy config cho type: ${recordType}`);
        return;
    }

    console.log(`\n🔍 Crawling details cho ${typeConfig.name}...`);

    // Lấy records chưa có detail
    const { data: records, error } = await supabase
        .from('raw_records')
        .select('*')
        .eq('record_type', recordType)
        .is('detail_data', null)
        .limit(limit);

    if (error) {
        console.error(`❌ Lỗi query: ${error.message}`);
        return;
    }

    if (!records || records.length === 0) {
        console.log(`⚠️ Không có records cần crawl detail`);
        return;
    }

    console.log(`📊 Cần crawl detail cho ${records.length} records`);

    for (let i = 0; i < records.length; i++) {
        const record = records[i];
        console.log(`📄 [${i + 1}/${records.length}] Crawling detail cho ${record.record_no || record.id}...`);

        try {
            const detailData = await getDetailData(page, record.list_data, typeConfig);

            if (detailData) {
                // Update raw_record với detail data
                await supabase
                    .from('raw_records')
                    .update({
                        detail_data: detailData,
                        processed: true
                    })
                    .eq('id', record.id);

                console.log(`✅ Đã lấy detail`);
            } else {
                console.log(`⚠️ Không có detail data`);
            }

            // Delay giữa các request
            await delay(CONFIG.delayBetweenRequests);

        } catch (error) {
            console.error(`❌ Lỗi: ${error.message}`);
        }
    }
}

/**
 * Main crawler function
 */
async function runCrawler(options = {}) {
    const {
        startDate = new Date(),
        endDate = new Date(),
        recordTypes = ['es-notify-contractor'], // Default: TBMT
        crawlDetails: shouldCrawlDetails = false
    } = options;

    console.log('═══════════════════════════════════════════════════════');
    console.log('🕷️  BIDDING DATA CRAWLER - muasamcong.mpi.gov.vn');
    console.log('═══════════════════════════════════════════════════════');
    console.log(`📅 Từ: ${formatDate(startDate)} đến ${formatDate(endDate)}`);
    console.log(`📋 Types: ${recordTypes.join(', ')}`);
    console.log('═══════════════════════════════════════════════════════\n');

    const browser = await initBrowser();
    const page = await setupPage(browser);
    const supabase = initSupabase();

    const dataCollector = {
        searchResults: [],
        detailResults: []
    };

    await setupInterception(page, dataCollector);

    try {
        // Loop qua từng ngày
        const currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            // Loop qua từng record type
            for (const recordType of recordTypes) {
                await crawlDayByType(page, supabase, new Date(currentDate), recordType);
                await delay(CONFIG.delayBetweenPages);
            }

            // Chuyển sang ngày tiếp theo
            currentDate.setDate(currentDate.getDate() + 1);
        }

        // Crawl details nếu được yêu cầu
        if (shouldCrawlDetails) {
            for (const recordType of recordTypes) {
                await crawlDetails(page, supabase, recordType);
            }
        }

    } catch (error) {
        console.error('❌ Lỗi crawler:', error.message);
    } finally {
        await browser.close();
        console.log('\n🏁 Crawler đã hoàn thành!');
    }
}

/**
 * CLI Entry point
 */
async function main() {
    const args = process.argv.slice(2);

    // Parse arguments
    const options = {
        startDate: new Date(),
        endDate: new Date(),
        recordTypes: ['es-notify-contractor'],
        crawlDetails: false
    };

    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--start':
            case '-s':
                options.startDate = new Date(args[++i]);
                break;
            case '--end':
            case '-e':
                options.endDate = new Date(args[++i]);
                break;
            case '--types':
            case '-t':
                options.recordTypes = args[++i].split(',');
                break;
            case '--details':
            case '-d':
                options.crawlDetails = true;
                break;
            case '--help':
            case '-h':
                console.log(`
Usage: node crawler.js [options]

Options:
  -s, --start <date>    Start date (YYYY-MM-DD), default: today
  -e, --end <date>      End date (YYYY-MM-DD), default: today
  -t, --types <types>   Record types, comma-separated
                        Available types:
                        - es-bidp-project-p (Dự án)
                        - es-plan-project-p (KHLCNT)
                        - es-notify-contractor (TBMT)
                        - es-ct-contract (Hợp đồng)
                        - ... (see detail_api_mapping.json)
  -d, --details         Also crawl detail data
  -h, --help           Show this help

Examples:
  node crawler.js -s 2026-01-01 -e 2026-01-03 -t es-notify-contractor
  node crawler.js -s 2026-01-01 -e 2026-01-01 -t es-notify-contractor,es-ct-contract -d
                `);
                process.exit(0);
        }
    }

    await runCrawler(options);
}

// Export for module use
module.exports = {
    runCrawler,
    initBrowser,
    setupPage,
    createSearchPayload,
    injectSearchCode,
    getDetailData,
    saveToSupabase,
    CONFIG,
    detailApiMapping
};

// Run if called directly
if (require.main === module) {
    main().catch(console.error);
}
