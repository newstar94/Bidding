/**
 * ================================================================
 * CRAWLER: Thông Báo Mời Thầu (TBMT)
 * Nguồn: muasamcong.mpi.gov.vn  |  Type: es-notify-contractor
 * ================================================================
 * Hoạt động:
 *  - Vòng lặp vô tận, mỗi 5 giây gọi API 1 lần (1 ngày / lần gọi)
 *  - Bắt đầu từ ngày hiện tại, lùi dần về 17/09/2022
 *  - Xử lý phân trang: nếu totalElements > 50 thì gọi thêm trang
 *  - Lưu kết quả vào Supabase (bảng bidding_tbmt + bidding_tbmt_location)
 *  - Ghi progress vào bidding_crawl_progress để resume khi restart
 * ================================================================
 * Trước khi chạy:
 *  1. Chạy SQL trong database/bidding_tbmt_schema.sql trên Supabase
 *  2. Cập nhật TOKEN và COOKIE ở phần CONFIG bên dưới
 *  3. npm install (trong thư mục gốc hoặc crawler/)
 *  4. node crawler/tbmt_crawler.js
 * ================================================================
 */

require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const { createClient } = require('@supabase/supabase-js');

// ────────────────────────────────────────────────────────────────
// CONFIG — cập nhật TOKEN và COOKIE khi hết hạn
// ────────────────────────────────────────────────────────────────
const CONFIG = {
    /** URL API search (phần token có thể hết hạn, cần cập nhật) */
    API_URL: 'https://muasamcong.mpi.gov.vn/o/egp-portal-contractor-selection-v2/services/smart/search',

    /** Token lấy từ query string của request (cập nhật khi hết hạn) */
    TOKEN: process.env.MSC_TOKEN || 'REPLACE_YOUR_TOKEN_HERE',

    /** Cookie phiên làm việc (cập nhật khi hết hạn) */
    COOKIE: process.env.MSC_COOKIE || 'COOKIE_SUPPORT=true; GUEST_LANGUAGE_ID=vi_VN',

    /** Số bản ghi mỗi trang */
    PAGE_SIZE: 50,

    /** Độ trễ giữa các lần gọi API (ms) */
    DELAY_BETWEEN_CALLS: 5000,

    /** Độ trễ giữa các trang trong cùng 1 ngày (ms) */
    DELAY_BETWEEN_PAGES: 2000,

    /** Độ trễ khi gặp lỗi trước khi thử lại (ms) */
    DELAY_ON_ERROR: 15000,

    /** Ngày dừng (lùi về đến ngày này thì hết) */
    STOP_DATE: new Date('2022-09-17T00:00:00.000Z'),

    /** Tên job để lưu progress */
    JOB_NAME: 'tbmt_backward',
};

// ────────────────────────────────────────────────────────────────
// SUPABASE CLIENT (dùng service_role để ghi)
// ────────────────────────────────────────────────────────────────
const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
);

// ────────────────────────────────────────────────────────────────
// LOGGER đơn giản
// ────────────────────────────────────────────────────────────────
function log(level, msg, data = '') {
    const ts = new Date().toISOString();
    const prefix = { INFO: '📋', OK: '✅', WARN: '⚠️ ', ERR: '❌', SKIP: '⏭️ ' }[level] || '  ';
    console.log(`[${ts}] ${prefix} ${msg}`, data !== '' ? data : '');
}

// ────────────────────────────────────────────────────────────────
// UTILS
// ────────────────────────────────────────────────────────────────
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/** Format ngày thành chuỗi YYYY-MM-DD */
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

/** Tạo từ-đến cho 1 ngày (UTC) */
function dayRange(dateStr) {
    return {
        from: `${dateStr}T00:00:00.000Z`,
        to: `${dateStr}T23:59:59.059Z`,
    };
}

// ────────────────────────────────────────────────────────────────
// TẠO PAYLOAD SEARCH
// ────────────────────────────────────────────────────────────────
function buildPayload(dateStr, pageNumber = 0) {
    const { from, to } = dayRange(dateStr);
    return [
        {
            pageSize: String(CONFIG.PAGE_SIZE),
            pageNumber: String(pageNumber),
            query: [
                {
                    index: 'es-contractor-selection',
                    matchType: 'all-1',
                    matchFields: ['notifyNo', 'bidName'],
                    filters: [
                        {
                            fieldName: 'publicDate',
                            searchType: 'range',
                            from,
                            to,
                        },
                        {
                            fieldName: 'type',
                            searchType: 'in',
                            fieldValues: ['es-notify-contractor'],
                        },
                        {
                            fieldName: 'caseKHKQ',
                            searchType: 'not_in',
                            fieldValues: ['1'],
                        },
                    ],
                },
            ],
        },
    ];
}

// ────────────────────────────────────────────────────────────────
// GỌI API
// ────────────────────────────────────────────────────────────────
async function fetchPage(dateStr, pageNumber = 0) {
    const url = `${CONFIG.API_URL}?token=${encodeURIComponent(CONFIG.TOKEN)}`;
    const payload = buildPayload(dateStr, pageNumber);

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'accept': 'application/json, text/plain, */*',
            'content-type': 'application/json',
            'cookie': CONFIG.COOKIE,
            'referer': 'https://muasamcong.mpi.gov.vn/web/guest/contractor-selection',
        },
        body: JSON.stringify(payload),
    });

    if (!res.ok) {
        throw new Error(`HTTP ${res.status} ${res.statusText}`);
    }

    return await res.json();
}

// ────────────────────────────────────────────────────────────────
// TRANSFORM: chuyển record API → row bidding_tbmt
// ────────────────────────────────────────────────────────────────
function transformRecord(r) {
    return {
        id: r.id,
        notify_id: r.notifyId || null,
        bid_id: r.bidId || null,
        input_result_id: r.inputResultId || null,
        bid_open_id: r.bidOpenId || null,

        notify_no: r.notifyNo || null,
        notify_version: r.notifyVersion || '00',
        notify_no_stand: r.notifyNoStand || null,
        plan_no: r.planNo || null,
        type: r.type || 'es-notify-contractor',

        bid_name: r.bidName || null,   // JSONB array
        bid_form: r.bidForm || null,
        bid_mode: r.bidMode || null,
        bid_field: r.bidField || null,
        invest_field: r.investField || null,   // JSONB array
        plan_type: r.planType || null,
        work_type: r.workType || null,
        process_apply: r.processApply || null,
        step_code: r.stepCode || null,

        investor_code: r.investorCode || null,
        investor_name: r.investorName || null,
        procuring_entity_code: r.procuringEntityCode || null,
        procuring_entity_name: r.procuringEntityName || null,
        created_by: r.createdBy || null,

        public_date: r.publicDate || null,
        public_date_kqmt: r.publicDateKqmt || null,
        public_date_kqlcnt: r.publicDateKqlcnt || null,
        bid_open_date: r.bidOpenDate || null,
        bid_reality_open_date: r.bidRealityOpenDate || null,
        bid_close_date: r.bidCloseDate || null,
        decision_date: r.decisionDate || null,

        status: r.status || null,
        status_for_notify: r.statusForNotify || null,
        is_internet: r.isInternet ?? 1,
        is_pass: r.isPass ?? null,
        is_domestic: r.isDomestic ?? 1,

        bid_price: r.bidPrice || null,   // JSONB array
        bid_winning_price: r.bidWinningPrice || null,   // JSONB array
        winning_code: r.winningCode || null,   // JSONB array
        contractor_name: r.contractorName || null,   // JSONB array
        winning_contractor_name: r.winningContractorName || null, // JSONB array

        num_petition: r.numPetition || 0,
        num_clarify_req: r.numClarifyReq || 0,
        num_bidder_tech: r.numBidderTech || 0,
        num_bidder_join: r.numBidderJoin || 0,
        num_petition_hsmt: r.numPetitionHsmt || 0,
        num_petition_lcnt: r.numPetitionLcnt || 0,
        num_petition_kqlcnt: r.numPetitionKqlcnt || 0,
        score: r.score || null,

        crawled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
    };
}

// ────────────────────────────────────────────────────────────────
// LƯU VÀO SUPABASE
// ────────────────────────────────────────────────────────────────
async function saveToSupabase(records) {
    let newCount = 0;
    let dupCount = 0;

    for (const raw of records) {
        const row = transformRecord(raw);

        // Upsert bản ghi chính
        const { error } = await supabase
            .from('bidding_tbmt')
            .upsert(row, { onConflict: 'id', ignoreDuplicates: false });

        if (error) {
            log('ERR', `Lỗi upsert TBMT id=${row.id}:`, error.message);
            continue;
        }

        // Xử lý locations (xóa cũ → insert mới)
        if (raw.locations && raw.locations.length > 0) {
            await supabase.from('bidding_tbmt_location').delete().eq('tbmt_id', row.id);

            const locRows = raw.locations.map(l => ({
                tbmt_id: row.id,
                prov_code: l.provCode || null,
                prov_name: l.provName || null,
                district_code: l.districtCode || null,
                district_name: l.districtName || null,
                ward_code: l.wardCode || null,
                ward_name: l.wardName || null,
            }));

            const { error: locErr } = await supabase
                .from('bidding_tbmt_location')
                .insert(locRows);

            if (locErr) {
                log('WARN', `Location insert lỗi id=${row.id}:`, locErr.message);
            }
        }

        newCount++;
    }

    dupCount = records.length - newCount;
    return { newCount, dupCount };
}

// ────────────────────────────────────────────────────────────────
// PROGRESS — đọc / ghi ngày đang crawl
// ────────────────────────────────────────────────────────────────
async function loadProgress() {
    const { data, error } = await supabase
        .from('bidding_crawl_progress')
        .select('*')
        .eq('job_name', CONFIG.JOB_NAME)
        .single();

    if (error || !data) {
        log('WARN', 'Không đọc được progress, bắt đầu từ hôm nay');
        return { currentDate: new Date(), lastPage: 0 };
    }

    return {
        currentDate: new Date(data.crawl_date + 'T00:00:00Z'),
        lastPage: data.last_page || 0,
        totalSaved: data.records_saved || 0,
    };
}

async function saveProgress(dateStr, lastPage, totalSaved) {
    await supabase
        .from('bidding_crawl_progress')
        .upsert({
            job_name: CONFIG.JOB_NAME,
            crawl_date: dateStr,
            last_page: lastPage,
            records_saved: totalSaved,
            status: 'running',
            last_run_at: new Date().toISOString(),
        }, { onConflict: 'job_name' });
}

async function markDone() {
    await supabase
        .from('bidding_crawl_progress')
        .update({ status: 'done', last_run_at: new Date().toISOString() })
        .eq('job_name', CONFIG.JOB_NAME);
}

// ────────────────────────────────────────────────────────────────
// GHI LOG
// ────────────────────────────────────────────────────────────────
async function writeCrawlLog(entry) {
    await supabase.from('bidding_crawl_log').insert({
        job_name: CONFIG.JOB_NAME,
        crawl_date: entry.crawlDate,
        page_number: entry.pageNumber,
        records_fetched: entry.recordsFetched || 0,
        records_new: entry.recordsNew || 0,
        records_dup: entry.recordsDup || 0,
        http_status: entry.httpStatus || 200,
        error_msg: entry.errorMsg || null,
        duration_ms: entry.durationMs || 0,
        created_at: new Date().toISOString(),
    });
}

// ────────────────────────────────────────────────────────────────
// VÒNG LẶP CHÍNH
// ────────────────────────────────────────────────────────────────
async function main() {
    log('INFO', '═══════════════════════════════════════════');
    log('INFO', ' TBMT CRAWLER — muasamcong.mpi.gov.vn');
    log('INFO', `  Supabase: ${process.env.NEXT_PUBLIC_SUPABASE_URL}`);
    log('INFO', `  Dừng tại: ${formatDate(CONFIG.STOP_DATE)}`);
    log('INFO', `  Delay: ${CONFIG.DELAY_BETWEEN_CALLS / 1000}s / lần gọi`);
    log('INFO', '═══════════════════════════════════════════');

    // Đọc progress
    const progress = await loadProgress();
    let currentDate = progress.currentDate;
    let totalSaved = progress.totalSaved || 0;

    log('INFO', `Tiếp tục từ ngày: ${formatDate(currentDate)}`);

    // Vòng lặp vô tận
    while (true) {
        const dateStr = formatDate(currentDate);

        // Kiểm tra đã về đến ngày dừng chưa
        if (currentDate < CONFIG.STOP_DATE) {
            log('OK', `Đã crawl xong toàn bộ đến ${formatDate(CONFIG.STOP_DATE)}!`);
            log('INFO', 'Crawler chờ — restart để crawl lại từ đầu hoặc Ctrl+C để thoát.');
            await markDone();
            // Chờ vô tận (vẫn giữ process sống)
            await sleep(60 * 60 * 1000); // nghỉ 1 tiếng rồi log lại
            continue;
        }

        log('INFO', `─── Crawl ngày: ${dateStr} ───`);

        try {
            // Gọi trang đầu tiên để biết totalElements
            const t0 = Date.now();
            const firstRes = await fetchPage(dateStr, 0);
            const durationFirst = Date.now() - t0;

            const total = firstRes?.page?.totalElements ?? 0;
            const totalPages = Math.ceil(total / CONFIG.PAGE_SIZE) || 1;
            const firstContent = firstRes?.page?.content ?? [];

            log('INFO', `  Ngày ${dateStr}: ${total} bản ghi, ${totalPages} trang`);

            // Lưu trang 0
            let { newCount, dupCount } = await saveToSupabase(firstContent);
            totalSaved += newCount;
            log('OK', `  Trang 0: lưu ${newCount} mới, ${dupCount} trùng`);

            await writeCrawlLog({
                crawlDate: dateStr, pageNumber: 0,
                recordsFetched: firstContent.length, recordsNew: newCount, recordsDup: dupCount,
                httpStatus: 200, durationMs: durationFirst,
            });

            await saveProgress(dateStr, 0, totalSaved);

            // Xử lý các trang tiếp theo nếu có
            for (let page = 1; page < totalPages; page++) {
                log('INFO', `  → Trang ${page}/${totalPages - 1}...`);
                await sleep(CONFIG.DELAY_BETWEEN_PAGES);

                const pt0 = Date.now();
                const pageRes = await fetchPage(dateStr, page);
                const pageDur = Date.now() - pt0;
                const pageContent = pageRes?.page?.content ?? [];

                const saved = await saveToSupabase(pageContent);
                totalSaved += saved.newCount;
                log('OK', `  Trang ${page}: lưu ${saved.newCount} mới, ${saved.dupCount} trùng`);

                await writeCrawlLog({
                    crawlDate: dateStr, pageNumber: page,
                    recordsFetched: pageContent.length, recordsNew: saved.newCount, recordsDup: saved.dupCount,
                    httpStatus: 200, durationMs: pageDur,
                });

                await saveProgress(dateStr, page, totalSaved);
            }

            log('OK', `  ✓ Ngày ${dateStr} hoàn tất. Tổng đã lưu: ${totalSaved}`);

        } catch (err) {
            log('ERR', `Lỗi khi crawl ngày ${dateStr}:`, err.message);

            await writeCrawlLog({
                crawlDate: dateStr, pageNumber: 0,
                errorMsg: err.message, httpStatus: err.message.includes('HTTP') ? parseInt(err.message.split(' ')[1]) : 0,
            });

            log('WARN', `  Thử lại sau ${CONFIG.DELAY_ON_ERROR / 1000}s...`);
            await sleep(CONFIG.DELAY_ON_ERROR);
            continue; // Không lùi ngày khi lỗi, thử lại ngày hiện tại
        }

        // Lùi ngày đi 1 ngày
        currentDate = new Date(currentDate);
        currentDate.setUTCDate(currentDate.getUTCDate() - 1);
        await saveProgress(formatDate(currentDate), 0, totalSaved);

        // Chờ trước lần gọi tiếp
        log('INFO', `  Chờ ${CONFIG.DELAY_BETWEEN_CALLS / 1000}s...`);
        await sleep(CONFIG.DELAY_BETWEEN_CALLS);
    }
}

// ────────────────────────────────────────────────────────────────
// ENTRY POINT
// ────────────────────────────────────────────────────────────────
main().catch(err => {
    log('ERR', 'Lỗi không xử lý được:', err.message);
    process.exit(1);
});
