/**
 * Scheduler Service - Tự động crawl dữ liệu hàng ngày
 * 
 * Sử dụng node-cron để chạy crawler theo schedule
 * - Daily: Crawl dữ liệu ngày hôm trước
 * - Retry: Tự động retry các record failed
 */

const cron = require('node-cron');
const { runCrawler, CONFIG, detailApiMapping } = require('./crawler');
const { createClient } = require('@supabase/supabase-js');
const winston = require('winston');
require('dotenv').config();

// Logger configuration
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ timestamp, level, message }) => {
            return `${timestamp} [${level.toUpperCase()}]: ${message}`;
        })
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'logs/crawler.log' }),
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' })
    ]
});

// Supabase client
const supabase = createClient(
    process.env.SUPABASE_URL || CONFIG.supabaseUrl,
    process.env.SUPABASE_KEY || CONFIG.supabaseKey
);

/**
 * Danh sách record types cần crawl hàng ngày
 */
const DAILY_RECORD_TYPES = [
    'es-notify-contractor',     // TBMT - Quan trọng nhất
    'es-bidp-project-p',        // Dự án
    'es-plan-project-p',        // KHLCNT
    'es-ct-contract',           // Hợp đồng
    'es-ycbg',                  // Yêu cầu báo giá
    'es-ct-publish-frame'       // Thỏa thuận khung
];

/**
 * Lấy ngày hôm trước
 */
function getYesterday() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday;
}

/**
 * Format date to YYYY-MM-DD
 */
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

/**
 * Crawl dữ liệu của ngày hôm trước cho tất cả types
 */
async function crawlYesterday() {
    const yesterday = getYesterday();
    logger.info(`🚀 Bắt đầu crawl dữ liệu ngày ${formatDate(yesterday)}`);

    try {
        await runCrawler({
            startDate: yesterday,
            endDate: yesterday,
            recordTypes: DAILY_RECORD_TYPES,
            crawlDetails: false // Crawl list trước, detail sau
        });

        logger.info(`✅ Hoàn thành crawl ngày ${formatDate(yesterday)}`);
    } catch (error) {
        logger.error(`❌ Lỗi crawl: ${error.message}`);
    }
}

/**
 * Crawl chi tiết cho các records chưa có detail
 */
async function crawlPendingDetails() {
    logger.info('🔍 Bắt đầu crawl pending details...');

    try {
        // Lấy số lượng records cần crawl detail
        const { data, error } = await supabase
            .from('raw_records')
            .select('record_type', { count: 'exact' })
            .is('detail_data', null)
            .limit(1);

        if (error) {
            logger.error(`❌ Lỗi query: ${error.message}`);
            return;
        }

        const pendingCount = data?.length || 0;
        
        if (pendingCount === 0) {
            logger.info('✅ Không có records cần crawl detail');
            return;
        }

        logger.info(`📊 Có ${pendingCount} records cần crawl detail`);

        // Crawl details cho từng type
        await runCrawler({
            startDate: getYesterday(),
            endDate: getYesterday(),
            recordTypes: DAILY_RECORD_TYPES,
            crawlDetails: true
        });

        logger.info('✅ Hoàn thành crawl pending details');
    } catch (error) {
        logger.error(`❌ Lỗi crawl details: ${error.message}`);
    }
}

/**
 * Retry failed records từ ngày trước
 */
async function retryFailed() {
    logger.info('🔄 Bắt đầu retry failed records...');

    try {
        // Lấy logs có lỗi từ ngày hôm qua
        const yesterday = formatDate(getYesterday());
        const { data: logs, error } = await supabase
            .from('crawl_logs')
            .select('*')
            .eq('crawl_date', yesterday)
            .gt('error_count', 0);

        if (error || !logs || logs.length === 0) {
            logger.info('✅ Không có records cần retry');
            return;
        }

        logger.info(`📊 Có ${logs.length} sessions cần retry`);

        // TODO: Implement retry logic based on error details

    } catch (error) {
        logger.error(`❌ Lỗi retry: ${error.message}`);
    }
}

/**
 * Cleanup old logs (giữ 30 ngày)
 */
async function cleanupOldLogs() {
    logger.info('🧹 Cleanup old logs...');

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    try {
        const { error } = await supabase
            .from('crawl_logs')
            .delete()
            .lt('crawl_date', formatDate(thirtyDaysAgo));

        if (error) {
            logger.error(`❌ Lỗi cleanup: ${error.message}`);
        } else {
            logger.info('✅ Cleanup completed');
        }
    } catch (error) {
        logger.error(`❌ Exception cleanup: ${error.message}`);
    }
}

/**
 * Health check
 */
async function healthCheck() {
    try {
        const { data, error } = await supabase
            .from('crawl_logs')
            .select('id')
            .limit(1);

        if (error) {
            logger.error('❌ Health check failed: Database connection error');
            return false;
        }

        logger.info('✅ Health check passed');
        return true;
    } catch (error) {
        logger.error(`❌ Health check failed: ${error.message}`);
        return false;
    }
}

/**
 * Setup cron jobs
 */
function setupCronJobs() {
    logger.info('⏰ Setting up cron jobs...');

    // Daily crawl at 2:00 AM
    cron.schedule('0 2 * * *', async () => {
        logger.info('⏰ [CRON] Daily crawl triggered');
        await crawlYesterday();
    }, {
        timezone: 'Asia/Ho_Chi_Minh'
    });

    // Crawl pending details at 6:00 AM
    cron.schedule('0 6 * * *', async () => {
        logger.info('⏰ [CRON] Detail crawl triggered');
        await crawlPendingDetails();
    }, {
        timezone: 'Asia/Ho_Chi_Minh'
    });

    // Retry failed at 12:00 PM
    cron.schedule('0 12 * * *', async () => {
        logger.info('⏰ [CRON] Retry failed triggered');
        await retryFailed();
    }, {
        timezone: 'Asia/Ho_Chi_Minh'
    });

    // Cleanup old logs at 3:00 AM on Sunday
    cron.schedule('0 3 * * 0', async () => {
        logger.info('⏰ [CRON] Cleanup triggered');
        await cleanupOldLogs();
    }, {
        timezone: 'Asia/Ho_Chi_Minh'
    });

    // Health check every hour
    cron.schedule('0 * * * *', async () => {
        await healthCheck();
    }, {
        timezone: 'Asia/Ho_Chi_Minh'
    });

    logger.info('✅ Cron jobs setup completed');
    logger.info('   - Daily crawl: 2:00 AM');
    logger.info('   - Detail crawl: 6:00 AM');
    logger.info('   - Retry failed: 12:00 PM');
    logger.info('   - Cleanup logs: 3:00 AM Sunday');
    logger.info('   - Health check: Every hour');
}

/**
 * Main entry point
 */
async function main() {
    const args = process.argv.slice(2);

    logger.info('═══════════════════════════════════════════════════════');
    logger.info('🕷️  BIDDING CRAWLER SCHEDULER');
    logger.info('═══════════════════════════════════════════════════════');

    // Parse arguments
    if (args.includes('--yesterday') || args.includes('-y')) {
        // Run crawl for yesterday immediately
        await crawlYesterday();
        process.exit(0);
    }

    if (args.includes('--details') || args.includes('-d')) {
        // Crawl pending details immediately
        await crawlPendingDetails();
        process.exit(0);
    }

    if (args.includes('--retry') || args.includes('-r')) {
        // Retry failed immediately
        await retryFailed();
        process.exit(0);
    }

    if (args.includes('--health') || args.includes('-h')) {
        // Health check
        const healthy = await healthCheck();
        process.exit(healthy ? 0 : 1);
    }

    if (args.includes('--help')) {
        console.log(`
Usage: node scheduler.js [options]

Options:
  --yesterday, -y   Crawl data từ ngày hôm qua và exit
  --details, -d     Crawl pending details và exit
  --retry, -r       Retry failed records và exit
  --health, -h      Health check và exit
  --help           Show this help

Không có options sẽ start scheduler daemon với cron jobs.
        `);
        process.exit(0);
    }

    // Start scheduler daemon
    logger.info('🚀 Starting scheduler daemon...');
    
    // Initial health check
    const healthy = await healthCheck();
    if (!healthy) {
        logger.error('❌ Initial health check failed. Exiting...');
        process.exit(1);
    }

    // Setup cron jobs
    setupCronJobs();

    logger.info('✅ Scheduler is running. Press Ctrl+C to stop.');

    // Keep process alive
    process.on('SIGINT', () => {
        logger.info('🛑 Received SIGINT. Shutting down...');
        process.exit(0);
    });

    process.on('SIGTERM', () => {
        logger.info('🛑 Received SIGTERM. Shutting down...');
        process.exit(0);
    });
}

// Run
main().catch(error => {
    logger.error(`Fatal error: ${error.message}`);
    process.exit(1);
});
