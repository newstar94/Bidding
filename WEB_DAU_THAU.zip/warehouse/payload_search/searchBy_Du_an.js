// ----- Tìm theo "Dự án" vào ngày "Đăng tải" 25/12/2025, Tìm trong "Mã dự án" và "Tên dự án"
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "publicDate",
                        "searchType": "range",
                        "from": "2025-12-25T00:00:00.000Z",
                        "to": "2025-12-25T23:59:59.059Z"
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    }
                ]
            }
        ]
    }
],
// => "notifyNo": Mã dự án; "bidName": Tên dự án
// => "publicDate": Ngày đăng tải
// ----- Thêm thông tin thời điểm đóng thầu từ ngày 01/12/2025 đến 31/12/2025
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "bidCloseDate",
                        "searchType": "range",
                        "from": "2025-12-01T00:00:00.000Z",
                        "to": "2025-12-31T23:59:59.059Z"
                    },
                    {
                        "fieldName": "publicDate",
                        "searchType": "range",
                        "from": "2025-12-25T00:00:00.000Z",
                        "to": "2025-12-25T23:59:59.059Z"
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    }
                ]
            }
        ]
    }
]
// => "bidCloseDate": Thời điểm đóng thầu
// ----- Tìm theo "Bên mời thầu" và "Mã bên mời thầu", từ khóa "ndc" trong khoảng thời gian "Ngày phê duyệt" từ ngày 01/04/2025 đến 06/12/2025
// ----- Kết hợp tìm theo "Chủ đầu tư", từ khóa "black" trong khoảng thời gian "Ngày phê duyệt" từ ngày 01/04/2025 đến 06/12/2025
[
{
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
        {
            "index": "es-contractor-selection",
            "keyWord": "ndc",
            "keyWordNotMatch": "",
            "matchType": "all-1",
            "matchFields": [
                "procuringEntityName",
                "procuringEntityCode"
            ],
            "filters": [
                {
                    "fieldName": "bidCloseDate",
                    "searchType": "range",
                    "from": "2025-04-01T00:00:00.000Z",
                    "to": "2025-12-06T23:59:59.059Z"
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-notify-contractor"
                    ]
                },
                {
                    "fieldName": "caseKHKQ",
                    "searchType": "not_in",
                    "fieldValues": [
                        "1"
                    ]
                }
            ]
        },
        {
            "index": "es-contractor-selection",
            "keyWord": "black",
            "keyWordNotMatch": "",
            "matchType": "all-1",
            "matchFields": [
                "investorName",
                "investorCode"
            ],
            "filters": [
                {
                    "fieldName": "bidCloseDate",
                    "searchType": "range",
                    "from": "2025-04-01T00:00:00.000Z",
                    "to": "2025-12-06T23:59:59.059Z"
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-notify-contractor"
                    ]
                },
                {
                    "fieldName": "caseKHKQ",
                    "searchType": "not_in",
                    "fieldValues": [
                        "1"
                    ]
                }
            ]
        }
    ]
}
]
// => "procuringEntityName": Bên mời thầu; "procuringEntityCode": Mã bên mời thầu
// => "investorName": Chủ đầu tư; "investorCode": Mã chủ đầu tư
// => "bidCloseDate": Ngày phê duyệt ???

// ----- Tìm theo "Lĩnh vực đầu tư", mã lĩnh vực "HH"
[
{
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
        {
            "index": "es-contractor-selection",
            "matchType": "all-1",
            "matchFields": [
                "notifyNo",
                "bidName"
            ],
            "filters": [
                {
                    "fieldName": "investField",
                    "searchType": "in",
                    "fieldValues": [
                        "HH"
                    ]
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                }
            ]
        }
    ]
}
],
// => "investField": Lĩnh vực đầu tư, "HH": Mã lĩnh vực Hàng hóa
// ----- Tìm theo "Lĩnh vực đầu tư", mã lĩnh vực "Xây lắp", "Phi tư vấn", "Tư vấn", "Hỗn hợp"
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "investField",
                        "searchType": "in",
                        "fieldValues": [
                            "XL",
                            "PTV",
                            "TV",
                            "HON_HOP"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    }
                ]
            }
        ]
    }
]
// Mã lĩnh vực: "XL": Xây lắp; "PTV": Phi tư vấn; "TV": Tư vấn; "HON_HOP": Hỗn hợp
,
// ----- Tìm theo "Khu vực dự án" ở các tỉnh: Thành phố Hà nội, Tỉnh Ninh bình,... Xã Nội bài
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "locations.provCode",
                        "searchType": "in",
                        "fieldValues": [
                            "01",
                            "117",
                            "37",
                            "101"
                        ]
                    },
                    {
                        "fieldName": "locations.districtCode",
                        "searchType": "in",
                        "fieldValues": [
                            "00433"
                        ]
                    }
                ]
            }
        ]
    }
]
// => "locations.provCode": Mã tỉnh/thành phố; "locations.districtCode": Mã quận/huyện
,
// ----- Tìm theo Loại công trình, "Công trình giáo dục"
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "workType",
                        "searchType": "in",
                        "fieldValues": [
                            "CTGG"
                        ]
                    }
                ]
            }
        ]
    }
]
// => "workType": Loại công trình; "CTGG": Công trình giáo dục
,
// ----- Tìm theo "Giá gói thầu" từ 123 đến 6.788.888.888 và "Tổng mức đầu tư/Dự toán mua sắm" từ 456 đến 999.999.999
[
{
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
        {
            "index": "es-contractor-selection",
            "matchType": "all-1",
            "matchFields": [
                "notifyNo",
                "bidName"
            ],
            "filters": [
                {
                    "fieldName": "bidPrice",
                    "searchType": "range",
                    "from": 123,
                    "to": 6788888888
                },
                {
                    "fieldName": "investTotal",
                    "searchType": "range",
                    "from": 456,
                    "to": 999999999
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                }
            ]
        }
    ]
}
]
// => "bidPrice": Giá gói thầu; "investTotal": Tổng mức đầu tư/Dự toán mua sắm
,
// ----- Tìm theo Quy trình áp dụng, mã quy trình "LDT" tức là Luật Đấu thầu/ Áp dụng Luật Đấu thầu
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-bidp-project-p"
                        ]
                    },
                    {
                        "fieldName": "processApply",
                        "searchType": "in",
                        "fieldValues": [
                            "LDT"
                        ]
                    }
                ]
            }
        ]
    }
]
// => "processApply": Quy trình áp dụng; "LDT": Luật Đấu thầu
,
// ----- Tìm theo Hình thức dự thầu có "Qua mạng" và "Không qua mạng", Vùng có "Trong nước" và "Quốc tế"
[
{
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
        {
            "index": "es-contractor-selection",
            "matchType": "all-1",
            "matchFields": [
                "notifyNo",
                "bidName"
            ],
            "filters": [
                {
                    "fieldName": "isDomestic",
                    "searchType": "in",
                    "fieldValues": [
                        1,
                        0
                    ]
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": [
                        "es-bidp-project-p"
                    ]
                },
                {
                    "fieldName": "isDomestic",
                    "searchType": "in",
                    "fieldValues": [
                        1,
                        0
                    ]
                },
                {
                    "fieldName": "isInternet",
                    "searchType": "in",
                    "fieldValues": [
                        1,
                        0
                    ]
                }
            ]
        }
    ]
}
]
// => "isInternet": Hình thức dự thầu; 1: Qua mạng, 0: Không qua mạng
// => "isDomestic": Vùng; 1: Trong nước, 0: Quốc tế
,
// ----- Tìm theo Kế hoạch lựa chọn nhà thầu
[
    {
        "pageSize": 10,
        "pageNumber": "0",
        "query": [
            {
                "index": "es-contractor-selection",
                "matchType": "all-1",
                "matchFields": [
                    "notifyNo",
                    "bidName"
                ],
                "filters": [
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-plan-project-p"
                        ]
                    },
                    {
                        "fieldName": "type",
                        "searchType": "in",
                        "fieldValues": [
                            "es-plan-project-p"
                        ]
                    }
                ]
            }
        ]
    }
]
// => Loại dữ liệu: "es-plan-project-p": Kế hoạch lựa chọn nhà thầu
// => "es-bidp-project-p": Dự án