fetch("https://muasamcong.mpi.gov.vn/o/egp-portal-contractors-approved/services/get-list", {
    "headers": {
        "accept": "application/json, text/plain, */*",
        "accept-language": "vi,zh-CN;q=0.9,zh;q=0.8",
        "cache-control": "no-cache",
        "content-type": "application/json",
        "pragma": "no-cache",
        "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "cookie": "COOKIE_SUPPORT=true; GUEST_LANGUAGE_ID=vi_VN; _ga=GA1.1.309655754.1764809909; _ga_19996Z37EE=deleted; _gtpk_testcookie..undefined=1; _gtpk_ref.6946.ea8d=%5B%22%22%2C%22%22%2C1767592966%2C%22https%3A%2F%2Fwww.google.com%2F%22%5D; _gtpk_ses.6946.ea8d=1; JSESSIONID=_L84Ro5F3gYQ5Y8DdbFdNuMHJiP2YAApXFGSEdgr.dc-app1-03; NSC_WT_QSE_QPSUBM_NTD_NQJ=ffffffffaf183e2545525d5f4f58455e445a4a4217de; _gtpk_id.6946.ea8d=2444cf35266a0787.1764809909.147.1767593776.1767592966.; _ga_19996Z37EE=GS2.1.s1767592966$o146$g1$t1767593776$j59$l0$h0; LFR_SESSION_STATE_20103=1767593776725",
        "Referer": "https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list"
    },
    "body": "{\"pageSize\":10,\"pageNumber\":0,\"queryParams\":{\"officePro\":{\"contains\":null},\"effRoleDate\":{\"greaterThanOrEqual\":null,\"lessThanOrEqual\":null},\"isForeignInvestor\":{\"equals\":null},\"roleType\":{\"in\":[\"NT\",\"NTPER\"]},\"decNo\":{\"contains\":null},\"orgName\":{\"contains\":null},\"taxCode\":{\"contains\":null},\"orgNameOrOrgCode\":{\"contains\":\"\"},\"agencyName\":{\"in\":null}}}",
    "method": "POST"
});