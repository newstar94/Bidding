fetch("https://muasamcong.mpi.gov.vn/o/egp-portal-contractors-approved/services/get-detail-approve-bidder", {
    "headers": {
        "accept": "application/json, text/plain, */*",
        "accept-language": "vi,zh-CN;q=0.9,zh;q=0.8",
        "cache-control": "no-cache",
        "content-type": "application/json",
        "pragma": "no-cache",
        "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "cookie": "COOKIE_SUPPORT=true; GUEST_LANGUAGE_ID=vi_VN; _ga=GA1.1.309655754.1764809909; _ga_19996Z37EE=deleted; _gtpk_testcookie..undefined=1; _gtpk_ref.6946.ea8d=%5B%22%22%2C%22%22%2C1767592966%2C%22https%3A%2F%2Fwww.google.com%2F%22%5D; _gtpk_ses.6946.ea8d=1; _gtpk_id.6946.ea8d=2444cf35266a0787.1764809909.147.1767593002.1767592966.; LFR_SESSION_STATE_20103=1767593003659; JSESSIONID=qfwE6DiXKZAbje7AZFSIXFAuI4MMmE9WvODjSspd.dc-app1-03; NSC_WT_QSE_QPSUBM_NTD_NQJ=ffffffffaf183e2545525d5f4f58455e445a4a4217de; _ga_19996Z37EE=GS2.1.s1767592966$o146$g1$t1767593150$j60$l0$h0",
        "Referer": "https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list?p_p_id=egpportalcontractorsapproved_WAR_egpportalcontractorsapproved&p_p_lifecycle=0&p_p_state=normal&p_p_mode=view&_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved_render=detail&orgCode=vn0601293738&effRoleDate=5/1/2026&role=NT"
    },
    "body": "{\"orgCode\":\"vn0601293738\",\"roleName\":\"NT\"}",
    "method": "POST"
});