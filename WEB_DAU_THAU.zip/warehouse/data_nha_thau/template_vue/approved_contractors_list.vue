

































	
		
			<!DOCTYPE html>


























































<html  TRANSLATE="no"  class="ltr" dir=" lang.dir" lang="vi-VN">

<head>
	<title>
		Nhà thầu được phê duyệt - EGP_v2.0 - EGP
	</title>
	<meta content="initial-scale=1.0, width=device-width" name="viewport" />

































<meta content="text/html; charset=UTF-8" http-equiv="content-type" />












<link data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list" rel="canonical" />
<link data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list" hreflang="vi-VN" rel="alternate" />
<link data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/en/web/guest/approved-contractors-list" hreflang="en-US" rel="alternate" />
<link data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list" hreflang="x-default" rel="alternate" />

<meta property="og:locale" content="vi_VN">
<meta property="og:locale:alternate" content="en_US">
<meta property="og:locale:alternate" content="vi_VN">
<meta property="og:site_name" content="EGP_v2.0">
<meta property="og:title" content="Nhà thầu được phê duyệt - EGP_v2.0 - EGP">
<meta property="og:type" content="website">
<meta property="og:url" content="https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list">


<link href="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/egp.ico" rel="icon" />



<link class="lfr-css-file" data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/css/clay.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1767127824000" id="liferayAUICSS" rel="stylesheet" type="text/css" />









	

	





	



	

		<link data-senna-track="temporary" href="/combo?browserId=chrome&amp;minifierType=&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;languageId=vi_VN&amp;b=7413&amp;com_liferay_analytics_reports_web_internal_portlet_AnalyticsReportsPortlet:%2Fcss%2Fmain.css&amp;com_liferay_portal_search_web_search_bar_portlet_SearchBarPortlet_INSTANCE_templateSearch:%2Fcss%2Fmain.css&amp;com_liferay_product_navigation_product_menu_web_portlet_ProductMenuPortlet:%2Fcss%2Fmain.css&amp;com_liferay_product_navigation_user_personal_bar_web_portlet_ProductNavigationUserPersonalBarPortlet:%2Fcss%2Fmain.css&amp;com_liferay_segments_experiment_web_internal_portlet_SegmentsExperimentPortlet:%2Fcss%2Fmain.css&amp;com_liferay_site_navigation_menu_web_portlet_SiteNavigationMenuPortlet:%2Fcss%2Fmain.css&amp;t=1767127824000" id="7f12770f" rel="stylesheet" type="text/css" />

	







<script data-senna-track="temporary" type="text/javascript">
	// <![CDATA[
		var Liferay = Liferay || {};

		Liferay.Browser = {
			acceptsGzip: function() {
				return true;
			},

			

			getMajorVersion: function() {
				return 143.0;
			},

			getRevision: function() {
				return '537.36';
			},
			getVersion: function() {
				return '143.0';
			},

			

			isAir: function() {
				return false;
			},
			isChrome: function() {
				return true;
			},
			isEdge: function() {
				return false;
			},
			isFirefox: function() {
				return false;
			},
			isGecko: function() {
				return true;
			},
			isIe: function() {
				return false;
			},
			isIphone: function() {
				return false;
			},
			isLinux: function() {
				return false;
			},
			isMac: function() {
				return false;
			},
			isMobile: function() {
				return false;
			},
			isMozilla: function() {
				return false;
			},
			isOpera: function() {
				return false;
			},
			isRtf: function() {
				return true;
			},
			isSafari: function() {
				return true;
			},
			isSun: function() {
				return false;
			},
			isWebKit: function() {
				return true;
			},
			isWindows: function() {
				return true;
			}
		};

		Liferay.Data = Liferay.Data || {};

		Liferay.Data.ICONS_INLINE_SVG = true;

		Liferay.Data.NAV_SELECTOR = '#navigation';

		Liferay.Data.NAV_SELECTOR_MOBILE = '#navigationCollapse';

		Liferay.Data.isCustomizationView = function() {
			return false;
		};

		Liferay.Data.notices = [
			
		];

		(function () {
			var available = {};

			var direction = {};

			

				available['en_US'] = 'Tiếng\x20Anh\x20\x28Hoa\x20Kỳ\x29';
				direction['en_US'] = 'ltr';

			

				available['vi_VN'] = 'Tiếng\x20Việt\x20\x28Việt\x20Nam\x29';
				direction['vi_VN'] = 'ltr';

			

			Liferay.Language = {
				available,
				direction,
				get: function(key) {
					return key;
				}
			};
		})();

		Liferay.PortletKeys = {
			DOCUMENT_LIBRARY: 'com_liferay_document_library_web_portlet_DLPortlet',
			DYNAMIC_DATA_MAPPING: 'com_liferay_dynamic_data_mapping_web_portlet_DDMPortlet',
			ITEM_SELECTOR: 'com_liferay_item_selector_web_portlet_ItemSelectorPortlet'
		};

		Liferay.PropsValues = {
			JAVASCRIPT_SINGLE_PAGE_APPLICATION_TIMEOUT: 0,
			UPLOAD_SERVLET_REQUEST_IMPL_MAX_SIZE: 104857600
		};

		Liferay.ThemeDisplay = {

			

			
				getLayoutId: function() {
					return '35';
				},

				

				getLayoutRelativeControlPanelURL: function() {
					return '/group/guest/~/control_panel/manage';
				},

				getLayoutRelativeURL: function() {
					return '/web/guest/approved-contractors-list';
				},
				getLayoutURL: function() {
					return 'https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list';
				},
				getParentLayoutId: function() {
					return '3';
				},
				isControlPanel: function() {
					return false;
				},
				isPrivateLayout: function() {
					return 'false';
				},
				isVirtualLayout: function() {
					return false;
				},
			

			getBCP47LanguageId: function() {
				return 'vi-VN';
			},
			getCanonicalURL: function() {

				

				return 'https\x3a\x2f\x2fmuasamcong\x2empi\x2egov\x2evn\x2fweb\x2fguest\x2fapproved-contractors-list';
			},
			getCDNBaseURL: function() {
				return 'https://muasamcong.mpi.gov.vn';
			},
			getCDNDynamicResourcesHost: function() {
				return '';
			},
			getCDNHost: function() {
				return '';
			},
			getCompanyGroupId: function() {
				return '20125';
			},
			getCompanyId: function() {
				return '20099';
			},
			getDefaultLanguageId: function() {
				return 'vi_VN';
			},
			getDoAsUserIdEncoded: function() {
				return '';
			},
			getLanguageId: function() {
				return 'vi_VN';
			},
			getParentGroupId: function() {
				return '3249151';
			},
			getPathContext: function() {
				return '';
			},
			getPathImage: function() {
				return '/image';
			},
			getPathJavaScript: function() {
				return '/o/frontend-js-web';
			},
			getPathMain: function() {
				return '/c';
			},
			getPathThemeImages: function() {
				return 'https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images';
			},
			getPathThemeRoot: function() {
				return '/o/egp-portal-theme';
			},
			getPlid: function() {
				return '141499';
			},
			getPortalURL: function() {
				return 'https://muasamcong.mpi.gov.vn';
			},
			getScopeGroupId: function() {
				return '3249151';
			},
			getScopeGroupIdOrLiveGroupId: function() {
				return '3249151';
			},
			getSessionId: function() {
				return '';
			},
			getSiteAdminURL: function() {
				return 'https://muasamcong.mpi.gov.vn/group/guest/~/control_panel/manage?p_p_lifecycle=0&p_p_state=maximized&p_p_mode=view';
			},
			getSiteGroupId: function() {
				return '3249151';
			},
			getURLControlPanel: function() {
				return '/group/control_panel?refererPlid=141499';
			},
			getURLHome: function() {
				return 'https\x3a\x2f\x2fmuasamcong\x2empi\x2egov\x2evn\x2fweb\x2fguest';
			},
			getUserEmailAddress: function() {
				return '';
			},
			getUserId: function() {
				return '20103';
			},
			getUserName: function() {
				return '';
			},
			isAddSessionIdToURL: function() {
				return false;
			},
			isImpersonated: function() {
				return false;
			},
			isSignedIn: function() {
				return false;
			},
			isStateExclusive: function() {
				return false;
			},
			isStateMaximized: function() {
				return false;
			},
			isStatePopUp: function() {
				return false;
			}
		};

		var themeDisplay = Liferay.ThemeDisplay;

		Liferay.AUI = {

			

			getCombine: function() {
				return true;
			},
			getComboPath: function() {
				return '/combo/?browserId=chrome&minifierType=&languageId=vi_VN&b=7413&t=1767131055652&';
			},
			getDateFormat: function() {
				return '%d/%m/%Y';
			},
			getEditorCKEditorPath: function() {
				return '/o/frontend-editor-ckeditor-web';
			},
			getFilter: function() {
				var filter = 'raw';

				
					
						filter = 'min';
					
					

				return filter;
			},
			getFilterConfig: function() {
				var instance = this;

				var filterConfig = null;

				if (!instance.getCombine()) {
					filterConfig = {
						replaceStr: '.js' + instance.getStaticResourceURLParams(),
						searchExp: '\\.js$'
					};
				}

				return filterConfig;
			},
			getJavaScriptRootPath: function() {
				return '/o/frontend-js-web';
			},
			getPortletRootPath: function() {
				return '/html/portlet';
			},
			getStaticResourceURLParams: function() {
				return '?browserId=chrome&minifierType=&languageId=vi_VN&b=7413&t=1767131055652';
			}
		};

		Liferay.authToken = 'G3TcFPKv';

		

		Liferay.currentURL = '\x2fweb\x2fguest\x2fapproved-contractors-list';
		Liferay.currentURLEncoded = '\x252Fweb\x252Fguest\x252Fapproved-contractors-list';
	// ]]>
</script>

<script data-senna-track="temporary" type="text/javascript">window.__CONFIG__= {basePath: '',combine: true, defaultURLParams: null, explainResolutions: false, exposeGlobal: false, logLevel: 'warn', namespace:'Liferay', reportMismatchedAnonymousModules: 'warn', resolvePath: '/o/js_resolve_modules', url: '/combo/?browserId=chrome&minifierType=&languageId=vi_VN&b=7413&t=1767131055652&', waitTimeout: 7000};</script><script data-senna-track="permanent" src="/o/frontend-js-loader-modules-extender/loader.js" type="text/javascript"></script><script data-senna-track="permanent" src="/combo?browserId=chrome&minifierType=js&languageId=vi_VN&b=7413&t=1767131055652&/o/frontend-js-aui-web/aui/aui/aui.js&/o/frontend-js-aui-web/liferay/modules.js&/o/frontend-js-aui-web/liferay/aui_sandbox.js&/o/frontend-js-aui-web/aui/attribute-base/attribute-base.js&/o/frontend-js-aui-web/aui/attribute-complex/attribute-complex.js&/o/frontend-js-aui-web/aui/attribute-core/attribute-core.js&/o/frontend-js-aui-web/aui/attribute-observable/attribute-observable.js&/o/frontend-js-aui-web/aui/attribute-extras/attribute-extras.js&/o/frontend-js-aui-web/aui/event-custom-base/event-custom-base.js&/o/frontend-js-aui-web/aui/event-custom-complex/event-custom-complex.js&/o/frontend-js-aui-web/aui/oop/oop.js&/o/frontend-js-aui-web/aui/aui-base-lang/aui-base-lang.js&/o/frontend-js-aui-web/liferay/dependency.js&/o/frontend-js-aui-web/liferay/util.js&/o/frontend-js-web/liferay/dom_task_runner.js&/o/frontend-js-web/liferay/events.js&/o/frontend-js-web/liferay/lazy_load.js&/o/frontend-js-web/liferay/liferay.js&/o/frontend-js-web/liferay/global.bundle.js&/o/frontend-js-web/liferay/portlet.js&/o/frontend-js-web/liferay/workflow.js&/o/frontend-js-module-launcher/webpack_federation.js" type="text/javascript"></script>
<script data-senna-track="temporary" type="text/javascript">try {var MODULE_MAIN='staging-processes-web@5.0.14/index';var MODULE_PATH='/o/staging-processes-web';AUI().applyConfig({groups:{stagingprocessesweb:{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-staging-processes-export-import":{path:"js/main.js",requires:["aui-datatype","aui-dialog-iframe-deprecated","aui-modal","aui-parse-content","aui-toggler","aui-tree-view","liferay-portlet-base","liferay-util-window"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='product-navigation-taglib@6.0.19/index';var MODULE_PATH='/o/product-navigation-taglib';AUI().applyConfig({groups:{controlmenu:{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-product-navigation-control-menu":{path:"control_menu/js/product_navigation_control_menu.js",requires:["aui-node","event-touch"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='invitation-invite-members-web@5.0.13/index';var MODULE_PATH='/o/invitation-invite-members-web';AUI().applyConfig({groups:{"invite-members":{base:MODULE_PATH+"/invite_members/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-portlet-invite-members":{path:"main.js",requires:["aui-base","autocomplete-base","datasource-io","datatype-number","liferay-portlet-base","liferay-util-window","node-core"]}},root:MODULE_PATH+"/invite_members/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='journal-web@5.0.48/index';var MODULE_PATH='/o/journal-web';AUI().applyConfig({groups:{journal:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-journal-navigation":{path:"navigation.js",requires:["aui-component","liferay-portlet-base","liferay-search-container"]},"liferay-portlet-journal":{path:"main.js",requires:["aui-base","aui-dialog-iframe-deprecated","liferay-portlet-base","liferay-util-window"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='staging-taglib@7.0.16/index';var MODULE_PATH='/o/staging-taglib';AUI().applyConfig({groups:{stagingTaglib:{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-export-import-management-bar-button":{path:"export_import_entity_management_bar_button/js/main.js",requires:["aui-component","liferay-search-container","liferay-search-container-select"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='layout-taglib@7.1.11/index';var MODULE_PATH='/o/layout-taglib';AUI().applyConfig({groups:{"layout-taglib":{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-layouts-tree":{path:"layouts_tree/js/layouts_tree.js",requires:["aui-tree-view"]},"liferay-layouts-tree-check-content-display-page":{path:"layouts_tree/js/layouts_tree_check_content_display_page.js",requires:["aui-component","plugin"]},"liferay-layouts-tree-node-radio":{path:"layouts_tree/js/layouts_tree_node_radio.js",requires:["aui-tree-node"]},"liferay-layouts-tree-node-task":{path:"layouts_tree/js/layouts_tree_node_task.js",requires:["aui-tree-node"]},"liferay-layouts-tree-radio":{path:"layouts_tree/js/layouts_tree_radio.js",requires:["aui-tree-node","liferay-layouts-tree-node-radio"]},"liferay-layouts-tree-selectable":{path:"layouts_tree/js/layouts_tree_selectable.js",requires:["liferay-layouts-tree-node-task"]},"liferay-layouts-tree-state":{path:"layouts_tree/js/layouts_tree_state.js",requires:["aui-base"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='@liferay/frontend-js-state-web@1.0.11/index';var MODULE_PATH='/o/frontend-js-state-web';AUI().applyConfig({groups:{state:{mainModule:MODULE_MAIN}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='@liferay/frontend-js-react-web@5.0.14/js/index';var MODULE_PATH='/o/frontend-js-react-web';AUI().applyConfig({groups:{react:{mainModule:MODULE_MAIN}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='document-library-web@6.0.58/index';var MODULE_PATH='/o/document-library-web';AUI().applyConfig({groups:{dl:{base:MODULE_PATH+"/document_library/js/legacy/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"document-library-upload":{path:"upload.js",requires:["aui-component","aui-data-set-deprecated","aui-overlay-manager-deprecated","aui-overlay-mask-deprecated","aui-parse-content","aui-progressbar","aui-template-deprecated","aui-tooltip","liferay-history-manager","liferay-search-container","querystring-parse-simple","uploader"]},"liferay-document-library":{path:"main.js",requires:["document-library-upload","liferay-portlet-base"]}},root:MODULE_PATH+"/document_library/js/legacy/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='frontend-js-components-web@2.0.17/index';var MODULE_PATH='/o/frontend-js-components-web';AUI().applyConfig({groups:{components:{mainModule:MODULE_MAIN}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='exportimport-web@5.0.23/index';var MODULE_PATH='/o/exportimport-web';AUI().applyConfig({groups:{exportimportweb:{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-export-import-export-import":{path:"js/main.js",requires:["aui-datatype","aui-dialog-iframe-deprecated","aui-modal","aui-parse-content","aui-toggler","aui-tree-view","liferay-portlet-base","liferay-util-window"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='item-selector-taglib@5.1.25/index.es';var MODULE_PATH='/o/item-selector-taglib';AUI().applyConfig({groups:{"item-selector-taglib":{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-image-selector":{path:"image_selector/js/image_selector.js",requires:["aui-base","liferay-item-selector-dialog","liferay-portlet-base","uploader"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='dynamic-data-mapping-web@5.0.32/index';var MODULE_PATH='/o/dynamic-data-mapping-web';!function(){var a=Liferay.AUI;AUI().applyConfig({groups:{ddm:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:a.getFilterConfig(),modules:{"liferay-ddm-form":{path:"ddm_form.js",requires:["aui-base","aui-datatable","aui-datatype","aui-image-viewer","aui-parse-content","aui-set","aui-sortable-list","json","liferay-form","liferay-layouts-tree","liferay-layouts-tree-radio","liferay-layouts-tree-selectable","liferay-map-base","liferay-translation-manager","liferay-util-window"]},"liferay-portlet-dynamic-data-mapping":{condition:{trigger:"liferay-document-library"},path:"main.js",requires:["arraysort","aui-form-builder-deprecated","aui-form-validator","aui-map","aui-text-unicode","json","liferay-menu","liferay-translation-manager","liferay-util-window","text"]},"liferay-portlet-dynamic-data-mapping-custom-fields":{condition:{trigger:"liferay-document-library"},path:"custom_fields.js",requires:["liferay-portlet-dynamic-data-mapping"]}},root:MODULE_PATH+"/js/"}}})}();
} catch(error) {console.error(error);}try {var MODULE_MAIN='portal-workflow-kaleo-designer-web@5.0.36/index';var MODULE_PATH='/o/portal-workflow-kaleo-designer-web';AUI().applyConfig({groups:{"kaleo-designer":{base:MODULE_PATH+"/designer/js/legacy/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-kaleo-designer-autocomplete-util":{path:"autocomplete_util.js",requires:["autocomplete","autocomplete-highlighters"]},"liferay-kaleo-designer-definition-diagram-controller":{path:"definition_diagram_controller.js",requires:["liferay-kaleo-designer-field-normalizer","liferay-kaleo-designer-utils"]},"liferay-kaleo-designer-dialogs":{path:"dialogs.js",requires:["liferay-util-window"]},"liferay-kaleo-designer-editors":{path:"editors.js",requires:["aui-ace-editor","aui-ace-editor-mode-xml","aui-base","aui-datatype","aui-node","liferay-kaleo-designer-autocomplete-util","liferay-kaleo-designer-utils"]},"liferay-kaleo-designer-field-normalizer":{path:"field_normalizer.js",requires:["liferay-kaleo-designer-remote-services"]},"liferay-kaleo-designer-nodes":{path:"nodes.js",requires:["aui-datatable","aui-datatype","aui-diagram-builder","liferay-kaleo-designer-editors","liferay-kaleo-designer-utils"]},"liferay-kaleo-designer-remote-services":{path:"remote_services.js",requires:["aui-io","liferay-portlet-url"]},"liferay-kaleo-designer-templates":{path:"templates.js",requires:["aui-tpl-snippets-deprecated"]},"liferay-kaleo-designer-utils":{path:"utils.js",requires:[]},"liferay-kaleo-designer-xml-definition":{path:"xml_definition.js",requires:["aui-base","aui-component","dataschema-xml","datatype-xml"]},"liferay-kaleo-designer-xml-definition-serializer":{path:"xml_definition_serializer.js",requires:["escape","liferay-kaleo-designer-xml-util"]},"liferay-kaleo-designer-xml-util":{path:"xml_util.js",requires:["aui-base"]},"liferay-portlet-kaleo-designer":{path:"main.js",requires:["aui-ace-editor","aui-ace-editor-mode-xml","aui-tpl-snippets-deprecated","dataschema-xml","datasource","datatype-xml","event-valuechange","io-form","liferay-kaleo-designer-autocomplete-util","liferay-kaleo-designer-editors","liferay-kaleo-designer-nodes","liferay-kaleo-designer-remote-services","liferay-kaleo-designer-utils","liferay-kaleo-designer-xml-util","liferay-util-window"]}},root:MODULE_PATH+"/designer/js/legacy/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='frontend-editor-alloyeditor-web@5.0.17/index';var MODULE_PATH='/o/frontend-editor-alloyeditor-web';AUI().applyConfig({groups:{alloyeditor:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-alloy-editor":{path:"alloyeditor.js",requires:["aui-component","liferay-portlet-base","timers"]},"liferay-alloy-editor-source":{path:"alloyeditor_source.js",requires:["aui-debounce","liferay-fullscreen-source-editor","liferay-source-editor","plugin"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='contacts-web@5.0.19/index';var MODULE_PATH='/o/contacts-web';AUI().applyConfig({groups:{contactscenter:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-contacts-center":{path:"main.js",requires:["aui-io-plugin-deprecated","aui-toolbar","autocomplete-base","datasource-io","json-parse","liferay-portlet-base","liferay-util-window"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='portal-workflow-task-web@5.0.20/index';var MODULE_PATH='/o/portal-workflow-task-web';AUI().applyConfig({groups:{workflowtasks:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-workflow-tasks":{path:"main.js",requires:["liferay-util-window"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='portal-search-web@6.0.29/index';var MODULE_PATH='/o/portal-search-web';AUI().applyConfig({groups:{search:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-search-bar":{path:"search_bar.js",requires:[]},"liferay-search-custom-filter":{path:"custom_filter.js",requires:[]},"liferay-search-facet-util":{path:"facet_util.js",requires:[]},"liferay-search-modified-facet":{path:"modified_facet.js",requires:["aui-form-validator","liferay-search-facet-util"]},"liferay-search-modified-facet-configuration":{path:"modified_facet_configuration.js",requires:["aui-node"]},"liferay-search-sort-configuration":{path:"sort_configuration.js",requires:["aui-node"]},"liferay-search-sort-util":{path:"sort_util.js",requires:[]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='commerce-product-content-web@4.0.26/index';var MODULE_PATH='/o/commerce-product-content-web';AUI().applyConfig({groups:{productcontent:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),modules:{"liferay-commerce-product-content":{path:"product_content.js",requires:["aui-base","aui-io-request","aui-parse-content","liferay-portlet-base","liferay-portlet-url"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='segments-simulation-web@3.0.8/index';var MODULE_PATH='/o/segments-simulation-web';AUI().applyConfig({groups:{segmentssimulation:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-portlet-segments-simulation":{path:"main.js",requires:["aui-base","liferay-portlet-base"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='commerce-frontend-impl@4.0.16/index';var MODULE_PATH='/o/commerce-frontend-impl';AUI().applyConfig({groups:{commercefrontend:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),modules:{"liferay-commerce-frontend-asset-categories-selector":{path:"liferay_commerce_frontend_asset_categories_selector.js",requires:["aui-tree","liferay-commerce-frontend-asset-tag-selector"]},"liferay-commerce-frontend-asset-tag-selector":{path:"liferay_commerce_frontend_asset_tag_selector.js",requires:["aui-io-plugin-deprecated","aui-live-search-deprecated","aui-template-deprecated","aui-textboxlist-deprecated","datasource-cache","liferay-service-datasource"]},"liferay-commerce-frontend-management-bar-state":{condition:{trigger:"liferay-management-bar"},path:"management_bar_state.js",requires:["liferay-management-bar"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='calendar-web@5.0.25/index';var MODULE_PATH='/o/calendar-web';AUI().applyConfig({groups:{calendar:{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-calendar-a11y":{path:"calendar_a11y.js",requires:["calendar"]},"liferay-calendar-container":{path:"calendar_container.js",requires:["aui-alert","aui-base","aui-component","liferay-portlet-base"]},"liferay-calendar-date-picker-sanitizer":{path:"date_picker_sanitizer.js",requires:["aui-base"]},"liferay-calendar-interval-selector":{path:"interval_selector.js",requires:["aui-base","liferay-portlet-base"]},"liferay-calendar-interval-selector-scheduler-event-link":{path:"interval_selector_scheduler_event_link.js",requires:["aui-base","liferay-portlet-base"]},"liferay-calendar-list":{path:"calendar_list.js",requires:["aui-template-deprecated","liferay-scheduler"]},"liferay-calendar-message-util":{path:"message_util.js",requires:["liferay-util-window"]},"liferay-calendar-recurrence-converter":{path:"recurrence_converter.js",requires:[]},"liferay-calendar-recurrence-dialog":{path:"recurrence.js",requires:["aui-base","liferay-calendar-recurrence-util"]},"liferay-calendar-recurrence-util":{path:"recurrence_util.js",requires:["aui-base","liferay-util-window"]},"liferay-calendar-reminders":{path:"calendar_reminders.js",requires:["aui-base"]},"liferay-calendar-remote-services":{path:"remote_services.js",requires:["aui-base","aui-component","liferay-calendar-util","liferay-portlet-base"]},"liferay-calendar-session-listener":{path:"session_listener.js",requires:["aui-base","liferay-scheduler"]},"liferay-calendar-simple-color-picker":{path:"simple_color_picker.js",requires:["aui-base","aui-template-deprecated"]},"liferay-calendar-simple-menu":{path:"simple_menu.js",requires:["aui-base","aui-template-deprecated","event-outside","event-touch","widget-modality","widget-position","widget-position-align","widget-position-constrain","widget-stack","widget-stdmod"]},"liferay-calendar-util":{path:"calendar_util.js",requires:["aui-datatype","aui-io","aui-scheduler","aui-toolbar","autocomplete","autocomplete-highlighters"]},"liferay-scheduler":{path:"scheduler.js",requires:["async-queue","aui-datatype","aui-scheduler","dd-plugin","liferay-calendar-a11y","liferay-calendar-message-util","liferay-calendar-recurrence-converter","liferay-calendar-recurrence-util","liferay-calendar-util","liferay-scheduler-event-recorder","liferay-scheduler-models","promise","resize-plugin"]},"liferay-scheduler-event-recorder":{path:"scheduler_event_recorder.js",requires:["dd-plugin","liferay-calendar-util","resize-plugin"]},"liferay-scheduler-models":{path:"scheduler_models.js",requires:["aui-datatype","dd-plugin","liferay-calendar-util"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='@liferay/frontend-taglib@6.2.11/index';var MODULE_PATH='/o/frontend-taglib';AUI().applyConfig({groups:{"frontend-taglib":{base:MODULE_PATH+"/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-management-bar":{path:"management_bar/js/management_bar.js",requires:["aui-component","liferay-portlet-base"]},"liferay-sidebar-panel":{path:"sidebar_panel/js/sidebar_panel.js",requires:["aui-base","aui-debounce","aui-parse-content","liferay-portlet-base"]}},root:MODULE_PATH+"/"}}});
} catch(error) {console.error(error);}try {var MODULE_MAIN='product-navigation-simulation-device@6.0.18/index';var MODULE_PATH='/o/product-navigation-simulation-device';AUI().applyConfig({groups:{"navigation-simulation-device":{base:MODULE_PATH+"/js/",combine:Liferay.AUI.getCombine(),filter:Liferay.AUI.getFilterConfig(),modules:{"liferay-product-navigation-simulation-device":{path:"product_navigation_simulation_device.js",requires:["aui-dialog-iframe-deprecated","aui-event-input","aui-modal","liferay-portlet-base","liferay-product-navigation-control-menu","liferay-util-window","liferay-widget-size-animation-plugin"]}},root:MODULE_PATH+"/js/"}}});
} catch(error) {console.error(error);}</script>


<script data-senna-track="temporary" type="text/javascript">
	// <![CDATA[
		
			
				
		

		

		
	// ]]>
</script>





	
		

			

			
		
		



	
		

			

			
		
	












	

	





	



	













	
	<link data-senna-track="temporary" href="/o/product-navigation-product-menu-web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1641394184000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/analytics-reports-web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1641241512000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/segments-experiment-web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1641242168000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/egp-portal-contractors-approved/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1767127554000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/portal-search-web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1639999628000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/com.liferay.product.navigation.user.personal.bar.web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1636413674000" rel="stylesheet" type="text/css" />
<link data-senna-track="temporary" href="/o/site-navigation-menu-web/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1639083398000" rel="stylesheet" type="text/css" />











<link class="lfr-css-file" data-senna-track="temporary" href="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/css/main.css?browserId=chrome&amp;themeId=egpportaltheme_WAR_egpportaltheme&amp;minifierType=css&amp;languageId=vi_VN&amp;b=7413&amp;t=1767127824000" id="liferayThemeCSS" rel="stylesheet" type="text/css" />








	<style data-senna-track="temporary" type="text/css">

		

			

		

			

		

			

		

			

		

			

		

			

		

	</style>


<link href="/o/commerce-frontend-js/styles/main.css" rel="stylesheet"type="text/css" /><style data-senna-track="temporary" type="text/css">
</style>
<script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('@liferay/frontend-js-state-web@1.0.11/State', function(_liferayFrontendJsStateWeb1011State) {
try {
(function() {
var FrontendJsState = _liferayFrontendJsStateWeb1011State;

})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-spa-web@5.0.18/init', function(frontendJsSpaWeb5018Init) {
try {
(function() {
var frontendJsSpaWebInit = frontendJsSpaWeb5018Init;
frontendJsSpaWebInit.default({"navigationExceptionSelectors":":not([target=\"_blank\"]):not([data-senna-off]):not([data-resource-href]):not([data-cke-saved-href]):not([data-cke-saved-href])","cacheExpirationTime":-1,"clearScreensCache":false,"portletsBlacklist":["com_liferay_account_admin_web_internal_portlet_AccountUsersAdminPortlet","com_liferay_account_admin_web_internal_portlet_AccountEntriesAdminPortlet","com_liferay_nested_portlets_web_portlet_NestedPortletsPortlet","com_liferay_site_navigation_directory_web_portlet_SitesDirectoryPortlet","com_liferay_questions_web_internal_portlet_QuestionsPortlet","com_liferay_account_admin_web_internal_portlet_AccountEntriesManagementPortlet","com_liferay_login_web_portlet_LoginPortlet","com_liferay_login_web_portlet_FastLoginPortlet"],"validStatusCodes":[221,490,494,499,491,492,493,495,220],"debugEnabled":false,"loginRedirect":"","excludedPaths":["/c/document_library","/documents","/image"],"userNotification":{"message":"Có vẻ như điều này mất nhiều thời gian hơn dự kiến.","title":"Rất tiếc","timeout":30000},"requestTimeout":0})
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script>





<script type="text/javascript">
// <![CDATA[
Liferay.on(
	'ddmFieldBlur', function(event) {
		if (window.Analytics) {
			Analytics.send(
				'fieldBlurred',
				'Form',
				{
					fieldName: event.fieldName,
					focusDuration: event.focusDuration,
					formId: event.formId,
					page: event.page
				}
			);
		}
	}
);

Liferay.on(
	'ddmFieldFocus', function(event) {
		if (window.Analytics) {
			Analytics.send(
				'fieldFocused',
				'Form',
				{
					fieldName: event.fieldName,
					formId: event.formId,
					page: event.page
				}
			);
		}
	}
);

Liferay.on(
	'ddmFormPageShow', function(event) {
		if (window.Analytics) {
			Analytics.send(
				'pageViewed',
				'Form',
				{
					formId: event.formId,
					page: event.page,
					title: event.title
				}
			);
		}
	}
);

Liferay.on(
	'ddmFormSubmit', function(event) {
		if (window.Analytics) {
			Analytics.send(
				'formSubmitted',
				'Form',
				{
					formId: event.formId
				}
			);
		}
	}
);

Liferay.on(
	'ddmFormView', function(event) {
		if (window.Analytics) {
			Analytics.send(
				'formViewed',
				'Form',
				{
					formId: event.formId,
					title: event.title
				}
			);
		}
	}
);
// ]]>
</script>













<script data-senna-track="temporary" type="text/javascript">
	if (window.Analytics) {
		window._com_liferay_document_library_analytics_isViewFileEntry = false;
	}
</script>















	<script src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/js/jquery/jquery-3.6.1.min.js"></script>
	<script src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/js/popper/popper.min.js"></script>
	<script src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/js/bootstrap/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-19996Z37EE"></script>
	<!-- Begin EMC Tracking Code -->
	<script type="text/javascript">
		var _govaq = window._govaq || [];
		_govaq.push(['trackPageView']);
		_govaq.push(['enableLinkTracking']);
		(function () {
			_govaq.push(['setTrackerUrl', 'https://f-emc.ngsp.gov.vn/tracking']);
			_govaq.push(['setSiteId', '6946']);
			var d = document,
					g = d.createElement('script'),
					s = d.getElementsByTagName('script')[0];
			g.type = 'text/javascript';
			g.async = true;
			g.defer = true;
			g.src = 'https://f-emc.ngsp.gov.vn/embed/gov-tracking.min.js';
			s.parentNode.insertBefore(g, s);
		})();
	</script>
	<style>
		.yhy-append-wrap {
			display: none;
		}
	</style>
	<!-- End EMC Tracking Code -->

	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'G-19996Z37EE');
	</script>



</head>
<style>
	[v-cloak] {
		display: none;
	}
</style>
<body class="chrome controls-visible  yui3-skin-sam signed-out public-page site">












































































<div class="container-fluid position-relative" id="wrapper">
<header id="egp-header" >

    <input type="text" style="display: none" id="server-time" :value="serverTime" ></input>
    <input type="text" style="display: none" id="server-time-cgtt">
    <div id="overlay" class="overlay-common" onclick="closeNav()"></div>
    <div id="mySidebar" class="sidebar">
        <div class="d-flex justify-content-between">
            <div
                    class="d-flex flex-column align-items-start justify-content-center px-2"
            >
                <p class="txt-hour" style="color: #262626" id="live-time-responsive"></p>
                <p class="txt-time" style="color: #262626" id="live-date-responsive"></p>
            </div>
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
        </div>
        <div id="accordion">
                    <div class="card">
                        <div class="card-header" id="heading0">
                            <h5 class="mb-0">
                                <button onclick="location.href = 'https://muasamcong.mpi.gov.vn/web/guest/home'"
                                        class="btn"
                                        data-toggle="collapse"
                                        data-target="#collapse0"
                                        aria-expanded="true"
                                        aria-controls="collapse0">
                                    Trang chủ
                                </button>
                            </h5>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading1">
                            <h5 class="mb-0">
                                <button
                                        class="btn collapsed"
                                        data-toggle="collapse"
                                        data-target="#collapse1"
                                        aria-expanded="false"
                                        aria-controls="collapse1">
                                    Tra cứu
                                </button>
                            </h5>
                        </div>
                        <div
                                id="collapse1"
                                class="collapse"
                                aria-labelledby="heading1"
                                data-parent="#accordion">
                            <div class="card-body">
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/legal-documents', '_self');">
                                            Văn bản pháp quy
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/student-list', '_self');">
                                            Chứng chỉ đấu thầu cơ bản
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list', '_self');">
                                            Nhà thầu được phê duyệt
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/investor-approved-list', '_self');">
                                            Nhà đầu tư được phê duyệt
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/foreign-contractor-winning-bid-vn', '_self');">
                                            Nhà thầu nước ngoài trúng thầu tại Việt Nam
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/organizations-violators', '_self');">
                                            Tổ chức, cá nhân vi phạm
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/annual-tender-form', '_self');">
                                            Biểu mẫu công tác đấu thầu hàng năm
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/bid-solicitor-approval', '_self');">
                                            Bên mời thầu được phê duyệt
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/investors-approval-v2', '_self');">
                                            Danh sách chủ đầu tư được phê duyệt
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/csdllist', '_self');">
                                            Cơ sở dữ liệu quốc gia về nhà thầu, chất lượng hàng hóa đã được sử dụng
                                        </a>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading2">
                            <h5 class="mb-0">
                                <button onclick="location.href = 'https://muasamcong.mpi.gov.vn/web/guest/tender-scenario'"
                                        class="btn"
                                        data-toggle="collapse"
                                        data-target="#collapse2"
                                        aria-expanded="true"
                                        aria-controls="collapse2">
                                    Tình huống đấu thầu
                                </button>
                            </h5>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading3">
                            <h5 class="mb-0">
                                <button onclick="location.href = 'https://muasamcong.mpi.gov.vn/web/guest/frequently-asked-questions'"
                                        class="btn"
                                        data-toggle="collapse"
                                        data-target="#collapse3"
                                        aria-expanded="true"
                                        aria-controls="collapse3">
                                    Câu hỏi thường gặp
                                </button>
                            </h5>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading4">
                            <h5 class="mb-0">
                                <button
                                        class="btn collapsed"
                                        data-toggle="collapse"
                                        data-target="#collapse4"
                                        aria-expanded="false"
                                        aria-controls="collapse4">
                                    Hướng dẫn sử dụng
                                </button>
                            </h5>
                        </div>
                        <div
                                id="collapse4"
                                class="collapse"
                                aria-labelledby="heading4"
                                data-parent="#accordion">
                            <div class="card-body">
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-contractors', '_self');">
                                            Nhà thầu
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-investor', '_self');">
                                            Chủ đầu tư
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-investor-bid-solicitor', '_self');">
                                            Bên mời thầu trong LCNT
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-expert-team', '_self');">
                                            Tổ chuyên gia
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-appraisal-team', '_self');">
                                            Tổ thẩm định
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-bid-solicitor-investor', '_self');">
                                            Bên mời thầu trong LCNĐT
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-manual-investors', '_self');">
                                            Nhà đầu tư
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-competent-authority', '_self');">
                                            Cơ quan có thẩm quyền
                                        </a>
                                        <a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/tender-management-unit', '_self');">
                                            Đơn vị quản lý đấu thầu
                                        </a>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading5">
                            <h5 class="mb-0">
                                <button onclick="location.href = 'https://muasamcong.mpi.gov.vn/web/guest/procurement-agreement'"
                                        class="btn"
                                        data-toggle="collapse"
                                        data-target="#collapse5"
                                        aria-expanded="true"
                                        aria-controls="collapse5">
                                    Mua sắm công theo hiệp định
                                </button>
                            </h5>
                        </div>
                    </div>
        </div>
            <div class="bottom-right-btn__wrapper">
                <a class="nav-link bottom-right-btn px-0 text-center" href="#">
                    <p>
Đăng ký                        <img
                                class="dropdown-img"
                                src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/down-arrow.svg"
                                alt="down-arrow" />
                    </p>
                </a>
                <a
                        class="nav-link bottom-right-btn text-center active bg-brown px-0"
                        href="https://muasamcong.mpi.gov.vn/c/portal/login?p_l_id=141499">
                    <p>Đăng nhập</p>
                </a>
            </div>
    </div>
    <button class="openbtn" onclick="openNav()" >☰</button>
    <div class="border-main">
        <div class="content__wrapper p-0">
            <div class="content mt-0">
                <div class="header-bg">
                    <div class="header-content">
                        <div class="header-content__left-header">
                            <img
                                    class="img"
                                    src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/custom/titleHeaderImg.png"
                                    alt="small-header" />
                            <div class="header-content__title-left-header">
                                <p class="header-content__title-left-header__top-content text-uppercase">
Bộ Tài chính                                </p>
                                <p
                                        class="header-content__title-left-header__bottom-content">
Hệ thống mạng đấu thầu quốc gia                                </p>
                            </div>
                        </div>
                        <div class="header-content__right-header">
                            <div class="row">

                                <button type="button" class="btn-change-display" style="margin-right: 15px; padding: 8px; border-radius: 10px">
                                    <img src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/phone.png" alt="recycle">
                                    <span style="font-size: 15px">Tổng đài hỗ trợ: 19006126</span>
                                </button>
                               <button
                                    class="btn-change-language"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false">
                                        <img
                                        style="padding-right: 8px"
                                        src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/vn_icon.png"
                                        alt="icon_vn" />
                                        Tiếng Việt
                                    <img
                                        src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/down-arrow.svg"
                                        alt="down-arrow"
                                        style="width: 12px; height: auto" />
                                </button>

                                                                <div
                                                                    class="dropdown-menu"
                                                                    aria-labelledby="dropdownMenuButton">
                                                                            <a class="dropdown-item"  onclick="window.open('/en/web/guest/approved-contractors-list', '_self')"
                                                                            >
                                                                               English</a>

                                                                            <a class="dropdown-item"
                                                                               onclick="window.open('/vi/web/guest/approved-contractors-list', '_self')"
                                                                           >
                                                                               Tiếng Việt</a>
                                                                </div>
                            </div>
                            <div class="header-content__title-right-header">
                                <a href="#"
                                   class="btn-change-language"
                                   type="button"
                                   id="dropdownMenuButton"
                                   data-toggle="dropdown"
                                   aria-haspopup="true"
                                   aria-expanded="false">
Giới thiệu                                    <img
                                            src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/down-arrow.svg"
                                            alt="down-arrow"
                                            g style="width: 8px; height: auto" />
                                </a>
                                <div
                                        class="dropdown-menu introduce-dropdown"
                                        aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/introduce-department', '_self');" >
Cục Quản lý đấu thầu                                    </a>
                                    <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/introduce-center', '_self');" >
Trung tâm Đấu thầu qua mạng quốc gia                                    </a>
                                    <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/introduce-idnes', '_self');" >
Doanh nghiệp dự án IDNES                                    </a>
                                    <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/introduce-system', '_self');" >
Hệ thống mạng đấu thầu quốc gia                                    </a>
                                </div>
                                <a onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/news', '_self');" >Tin tức</a>
                                <a onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/notification-system', '_self');" >Thông báo của bộ</a>
                                <a onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/contact', '_self');"  >Liên hệ - Góp ý</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<div class="bg-nav" id="egp-navigation">
	<div class="content__wrapper p-0">
		<div class="content mt-0">
			<nav class="navbar navbar-expand-lg navbar-light p-0">
				<div
					class="collapse navbar-collapse"
					id="navbarSupportedContent">
					<ul class="navbar-nav">
									<li class="nav-item">
										<a class="nav-link"  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/home', '_self');" >
											Trang chủ
										</a>
									</li>
								<li class="nav-item dropdown">
										<a class="nav-link active-nav" href="#">
											Tra cứu
										</a>
									<div class="dropdown-content">
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/legal-documents', '_self');">
														Văn bản pháp quy
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/student-list', '_self');">
														Chứng chỉ đấu thầu cơ bản
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/approved-contractors-list', '_self');">
														Nhà thầu được phê duyệt
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/investor-approved-list', '_self');">
														Nhà đầu tư được phê duyệt
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/foreign-contractor-winning-bid-vn', '_self');">
														Nhà thầu nước ngoài trúng thầu tại Việt Nam
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/organizations-violators', '_self');">
														Tổ chức, cá nhân vi phạm
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/annual-tender-form', '_self');">
														Biểu mẫu công tác đấu thầu hàng năm
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/bid-solicitor-approval', '_self');">
														Bên mời thầu được phê duyệt
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/investors-approval-v2', '_self');">
														Danh sách chủ đầu tư được phê duyệt
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/csdllist', '_self');">
														Cơ sở dữ liệu quốc gia về nhà thầu, chất lượng hàng hóa đã được sử dụng
													</a>
									</div>
								</li>
									<li class="nav-item">
										<a class="nav-link"  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/tender-scenario', '_self');" >
											Tình huống đấu thầu
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link"  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/frequently-asked-questions', '_self');" >
											Câu hỏi thường gặp
										</a>
									</li>
								<li class="nav-item dropdown">
										<a class="nav-link" href="#">
											Hướng dẫn sử dụng
										</a>
									<div class="dropdown-content">
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-contractors', '_self');">
														Nhà thầu
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-investor', '_self');">
														Chủ đầu tư
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-investor-bid-solicitor', '_self');">
														Bên mời thầu trong LCNT
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-expert-team', '_self');">
														Tổ chuyên gia
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-appraisal-team', '_self');">
														Tổ thẩm định
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-bid-solicitor-investor', '_self');">
														Bên mời thầu trong LCNĐT
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-manual-investors', '_self');">
														Nhà đầu tư
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/guideline-competent-authority', '_self');">
														Cơ quan có thẩm quyền
													</a>
													<a  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/tender-management-unit', '_self');">
														Đơn vị quản lý đấu thầu
													</a>
									</div>
								</li>
									<li class="nav-item">
										<a class="nav-link"  onclick="window.open('https://muasamcong.mpi.gov.vn/web/guest/procurement-agreement', '_self');" >
											Mua sắm công theo hiệp định
										</a>
									</li>
					</ul>
					<div
						class="collapse navbar-collapse bottom-right-content px-0">
						<div class="bottom-right-txt" >
							<p class="txt-hour" id="live-time"></p>
							<p class="txt-time" id="live-date"></p>
						</div>
							<div class="bottom-right-btn__wrapper">
								<a
									class="nav-link bottom-right-btn px-0 text-center"
									href="#" 
									type="button"
                                    id="dropdownRegisterButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
									>

Đăng ký										<img
											class="dropdown-img"
											src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/down-arrow.svg"
											alt="down-arrow" />
									
								</a>
								  <div
									class="dropdown-menu register-dropdown"
									aria-labelledby="dropdownRegisterButton">
									<a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/register')" >
Đăng ký tổ chức trong nước									</a>
									<a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/register/foreign')" >
Đăng ký nhà thầu, nhà đầu tư nước ngoài									</a>
									<a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/lookup-register')" >
Tra cứu thông tin đăng ký tổ chức									</a>
									  <hr style="margin-top: 0; margin-bottom: 0">
									  <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/register-personal')" >
Đăng ký nhà thầu cá nhân trong nước									  </a>
									  <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/register-personal/foreign')" >
Đăng ký nhà thầu cá nhân nước ngoài									  </a>
									  <a class="dropdown-item" onclick="window.open('https://muasamcong.mpi.gov.vn/egp/usermntfe/lookup-register/personal')" >
Tra cứu thông tin đăng ký cá nhân									  </a>
								</div>
								<a class="nav-link bottom-right-btn text-center active bg-brown px-0" data-redirect="false"
									href="https://muasamcong.mpi.gov.vn/c/portal/login?p_l_id=141499" id="login-element">
									<p>
Đăng nhập									</p>
								</a>
							</div>
					</div>
				</div>
			</nav>
		</div>
	</div>
</div>
    </div>
</header>

<script>

    function openNav() {
        document.getElementById('mySidebar').className += ' show';
        document.getElementById('overlay').className += ' show';
    }

    function closeNav() {
        document.getElementById('mySidebar').classList.remove('show');
        document.getElementById('overlay').classList.remove('show');
    }

    function openMegaDropdown() {
        $('div.item.mega-dropdown a').parent().parent().toggleClass('show');
        $('div.dropdown-menu.dropdown-menu-center').toggleClass('show');
    }

    $('html').on('click', function(e) {
        //console.log('run1');
        if (!$('div.item.mega-dropdown').has(e.target)) {
            return;
        }
        if (
            !$('div.dropdown-menu.dropdown-menu-center').is(e.target) &&
            $('div.dropdown-menu.dropdown-menu-center').has(e.target).length ===
            0 &&
            $('.show').has(e.target).length === 0
            &&
            !$('#closeTabNoti').is(e.target)
            &&
            !$('#notificationModal').is(e.target)

        ) {
            $('div.item.mega-dropdown a').parent().parent().removeClass('show');
            $('div.dropdown-menu.dropdown-menu-center').removeClass('show');
        }
    });

    function closeMegaDropDown() {
        $('div.item.mega-dropdown a').parent().parent().removeClass('show');
        $('div.dropdown-menu.dropdown-menu-center').removeClass('show');
    }

    var serverTime = new Date();

    function bindingServerTime(date){

        serverTime = date;

    }

    function checkIsEn() {
        if (window.location.href.includes("en/")) return true;
        return false;
    }
    function showLiveTime() {
        if($("#server-time-cgtt").val()){
            return;
        }
        //Time
        if($("#server-time").val()){
            var date = new Date($("#server-time").val());
        }else{
            var date = new Date();
        }

        var h = date.getHours(); // 0 - 23
        var m = date.getMinutes(); // 0 - 59
        var s = date.getSeconds(); // 0 - 59
        var session = "AM";


        if (h == 0) {
            h = 12;
        }
        if (h > 12) {
            h = h - 12;
            session = "PM";
        }
        h = (h < 10) ? "0" + h : h;
        m = (m < 10) ? "0" + m : m;
        s = (s < 10) ? "0" + s : s;
        var time = h + ":" + m + ":" + s + " " + session;
        //Date
        var options = {
            weekday: 'long',
            year: 'numeric',
            month: 'numeric',
            day: 'numeric'
        };

        var today = null;
        if(this.checkIsEn()){
            today= date.toLocaleDateString("en-EN", options);
        }else{
            today= date.toLocaleDateString("vi-VN", options);

        }
        $("#live-time").text(time);
        $("#live-date").text(today);
        $("#live-time-responsive").text(time);
        $("#live-date-responsive").text(today);



        if($("#server-time").val()){

            let date_time = $("#server-time").val();
            let newDate = new Date(new Date(date_time).setTime(new Date(date_time).getTime()+1000));
            // console.log("compare time : ", new Date() - newDate);
            if((new Date() - newDate) > 3000 || (new Date() - newDate) <  -3000){
                let startTime = new Date();
                Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-time-now', {
                    method: 'POST'
                }).then(data =>{
                    return data.json();
                }).then((res) => {
                    let compTime = new Date() - startTime;
                    // console.log("compTime : ",compTime);
                    $("#server-time").val(new Date(new Date(res.body).getTime() + compTime).toISOString());
                });
            }else{
                $("#server-time").val(newDate.toISOString());
            }


        }
        // setTimeout(showLiveTime, 1000);
    }



</script>

	<section id="content">
		<h2 class="hide-accessible sr-only" role="heading" aria-level="1">
			Nhà thầu được phê duyệt - EGP_v2.0
		</h2>































	

		


















	
	
		<div class="layout-content portlet-layout" id="main-content" role="main">
			



























<style data-senna-track="temporary" type="text/css">
.portlet-borderless .portlet-content {padding: 0;}</style>




	

		

		

		<div class=" d-lg-block mb-lg-0 ml-lg-0 mr-lg-0 mt-lg-0 pb-lg-0 pl-lg-0 pr-lg-0 pt-lg-0 text-lg-left" style="border-style: solid; border-width: 0px;">
 <div id="fragment-0-seut"> 
  <div class="portlet-boundary portlet-boundary_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved_  portlet-static portlet-static-end portlet-decorate  " id="p_p_id_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved_"> 
   <span id="p_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved"></span> 
   <section class="portlet" id="portlet_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved"> 
    <div class="portlet-content"> 
     <div class="autofit-float autofit-row portlet-header"> 
      <div class="autofit-col autofit-col-end"> 
       <div class="autofit-section"> 
       </div> 
      </div> 
     </div> 
     <div class=" portlet-content-container"> 
      <div class="portlet-body"> 
       <!--    <meta charset="UTF-8" />--> 
       <!--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />--> 
       <!--    <meta name="viewport" content="width=device-width, initial-scale=1.0" />--> 
       <!--    <title>nhà thầu được phê duyệt</title>--> 
       <!-- Bootstrap CSS --> 
       <!--    <link href="../../assets/vendors/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>--> 
       <!--  CSS --> 
       <!--    <link rel="stylesheet" href="../../assets/css/common.css" />--> 
       <link rel="stylesheet" href="https://muasamcong.mpi.gov.vn/content-provider/res/css/element-ui-them-idx.css"> 
       <link rel="stylesheet" href="https://muasamcong.mpi.gov.vn/content-provider/res/css/vue.antd.min.css"> 
       <script src="https://muasamcong.mpi.gov.vn/content-provider/res/js/vue-v2.6.14.js"></script> 
       <script src="https://muasamcong.mpi.gov.vn/content-provider/res/js/axios.min.js"></script> 
       <script src="https://muasamcong.mpi.gov.vn/content-provider/res/js/element-ui-idx.js"></script> 
       <script src="https://muasamcong.mpi.gov.vn/content-provider/res/js/moment.min.js"></script> 
       <script src="https://muasamcong.mpi.gov.vn/content-provider/res/js/antd-with-locales.min.js"></script> 
       <style>
    [v-cloak] {
        display: none;
    }
    .portlet-content{
        padding: 0 !important;
    }
    .portlet-layout {
        margin-bottom: 0 !important;
    }
    .portlet-header {
        margin-bottom: 0 !important;
    }
</style> 
       <div id="search-approved-contractor" v-cloak> 
        <a-spin :spinning="isLoadingLoadList || isLoading"> 
         <div id="egp-breadcrumb" class="content__wrapper p-0"> 
          <div class="content mt-0"> 
           <nav aria-label="breadcrumb"> 
            <ol class="breadcrumb mb-0 px-0"> 
             <li class="breadcrumb-item inactive"> <a @click="breadcrumbRedirect()">Tra cứu</a> </li> 
             <li class="breadcrumb-item active"> <a>Nhà thầu được phê duyệt</a> </li> 
            </ol> 
           </nav> 
          </div> 
         </div> 
         <!-- Content --> 
         <main class="app searchPage-header-search"> 
          <div class="content__wrapper" style="padding: 0"> 
           <div class="content__wrapper"> 
            <div class="content"> 
             <div class="content__title"> 
              <h4 class="content__title__heading">Danh sách nhà thầu được phê duyệt</h4> 
              <div class="content__title__searchbar"> 
               <div class="content__title__searchbar__left"> 
                <input type="text" @keyup.enter="search()" placeholder="Tìm kiếm nhà thầu" v-model="keySearch"> 
                <img src="/o/egp-portal-contractors-approved/icons/search.png" alt="" @click="search()" style="cursor: pointer"> 
               </div> 
               <template> 
                <!--                                <a-dropdown :trigger="['click']" :visible="check == 1 ? true : false"--> 
                <!--                                            style="text-align: center!important; margin-top: 5px">--> 
                <a-button class="content__title__searchbar__right" @click="showModal()"> 
                 <span class="w-max-content">Bộ lọc</span> 
                 <svg width="16" height="16" viewbox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"> 
                  <path d="M14.111 3.00016H8.55547V4.11127H14.111C14.4177 4.11127 14.6666 3.86238 14.6666 3.55572C14.6666 3.24905 14.4177 3.00016 14.111 3.00016Z" fill="white" /> 
                  <path d="M1.88881 4.11127H3.07881C3.32714 5.06683 4.18992 5.77794 5.22214 5.77794C6.4477 5.77794 7.44436 4.78127 7.44436 3.55572C7.44436 2.33016 6.4477 1.3335 5.22214 1.3335C4.18992 1.3335 3.32714 2.04461 3.07881 3.00016H1.88881C1.58214 3.00016 1.33325 3.24905 1.33325 3.55572C1.33325 3.86239 1.58214 4.11127 1.88881 4.11127Z" fill="white" /> 
                  <path d="M14.111 7.44461H12.9999V8.55572H14.111C14.4177 8.55572 14.6666 8.30683 14.6666 8.00016C14.6666 7.6935 14.4177 7.44461 14.111 7.44461Z" fill="white" /> 
                  <path d="M1.88881 8.55572H7.52325C7.77159 9.51127 8.63436 10.2224 9.66659 10.2224C10.8921 10.2224 11.8888 9.22572 11.8888 8.00016C11.8888 6.77461 10.8921 5.77794 9.66659 5.77794C8.63436 5.77794 7.77159 6.48905 7.52325 7.44461H1.88881C1.58214 7.44461 1.33325 7.6935 1.33325 8.00016C1.33325 8.30683 1.58214 8.55572 1.88881 8.55572Z" fill="white" /> 
                  <path d="M14.111 11.8891H8.55547V13.0002H14.111C14.4177 13.0002 14.6666 12.7513 14.6666 12.4446C14.6666 12.1379 14.4177 11.8891 14.111 11.8891Z" fill="white" /> 
                  <path d="M5.22214 10.2224C4.18992 10.2224 3.32714 10.9335 3.07881 11.8891H1.88881C1.58214 11.8891 1.33325 12.1379 1.33325 12.4446C1.33325 12.7513 1.58214 13.0002 1.88881 13.0002H3.07881C3.32714 13.9557 4.18992 14.6668 5.22214 14.6668C6.4477 14.6668 7.44436 13.6702 7.44436 12.4446C7.44436 11.2191 6.4477 10.2224 5.22214 10.2224Z" fill="white" /> 
                 </svg> 
                </a-button> 
                <!--                                    <template #overlay>--> 
                <!--                                        <a-menu>--> 
                <!--                                            <a-menu-item disabled>--> 
                <a-modal v-model:visible="visible" @ok="handleOk()"> 
                 <template #footer> 
                  <a-button key="back" type="primary" style="background-color: #0f4871; border-color: #0f4871;" @click="offFilter()">
                   Bỏ lọc
                  </a-button> 
                  <a-button key="submit" type="primary" style="background-color: #0f4871; border-color: #0f4871;" :loading="loading" @click="onFilter()">
                   Áp dụng
                  </a-button> 
                 </template> 
                 <label style="color: black">Tỉnh / thành phố</label> 
                 <select class="form-control" placeholder="Chọn tỉnh/ thành phố" v-model="filterSearch.provinceCity"> <option value="" disabled selected class="form-control"> Chọn tỉnh/ thành phố </option> <option v-for="item in listAreaPro" :value="item.code" class="form-control"> {{item.name}} </option> </select> 
                 <label style="margin-top: 16px;color: black;">Phân loại</label> 
                 <div class="row" style="margin-left: 5px;"> 
                  <div class="form-check"> 
                   <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" v-model="filterSearch.typeBidder" value="0"> 
                   <label class="form-check-label" for="flexRadioDefault1" style="color: black">Nhà thầu trong nước</label> 
                  </div> 
                  <div style="margin-left: 60px;" class="form-check"> 
                   <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" v-model="filterSearch.typeBidder" value="1"> 
                   <label class="form-check-label" for="flexRadioDefault2" style="color: black">Nhà thầu nước ngoài</label> 
                  </div> 
                 </div> 
                 <div>
                  <label style="margin-top: 18px;color: black;">Ngày phê duyệt</label>
                 </div> 
                 <div> 
                  <a-range-picker style="width: 100%;" @change="onChange" format="DD/MM/YYYY" :placeholder="rangePicker" v-model="filterSearch.range"></a-range-picker> 
                 </div> 
                 <label class="mt-3" style="color: black">Mã số thuế</label> 
                 <input class="form-control" placeholder="Nhập mã số thuế" v-model="filterSearch.taxCode"> 
                 <label class="mt-3" style="color: black">Số GCN đăng kí kinh doanh/ Số GCN đầu tư</label> 
                 <input class="form-control" placeholder="Nhập số GCN đăng kí kinh doanh/ số GCN đầu tư" v-model="filterSearch.numberGCN"> 
                 <!--                                                <div class="d-flex justify-content-end" style="margin-top: 20px;">--> 
                 <!--                                                    <button class="btn btn-primary mt-2" style="margin-right: 15px;" @click="offFilter()">Bỏ lọc</button>--> 
                 <!--                                                    <button class="btn btn-primary mt-2" @click="onFilter()">Áp dụng</button>--> 
                 <!--                                                </div>--> 
                </a-modal> 
                <!--                                            </a-menu-item>--> 
                <!--                                        </a-menu>--> 
                <!--                                    </template>--> 
                <!--                                </a-dropdown>--> 
               </template> 
               <!--                            <button class="content__title__searchbar__right" id="dropdownMenuLink"--> 
               <!--                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">--> 
               <!--                                <span class="w-max-content">Bộ lọc</span>--> 
               <!--                                <svg--> 
               <!--                                        width="16"--> 
               <!--                                        height="16"--> 
               <!--                                        viewBox="0 0 16 16"--> 
               <!--                                        fill="none"--> 
               <!--                                        xmlns="http://www.w3.org/2000/svg"--> 
               <!--                                >--> 
               <!--                                    <path--> 
               <!--                                            d="M14.111 3.00016H8.55547V4.11127H14.111C14.4177 4.11127 14.6666 3.86238 14.6666 3.55572C14.6666 3.24905 14.4177 3.00016 14.111 3.00016Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                    <path--> 
               <!--                                            d="M1.88881 4.11127H3.07881C3.32714 5.06683 4.18992 5.77794 5.22214 5.77794C6.4477 5.77794 7.44436 4.78127 7.44436 3.55572C7.44436 2.33016 6.4477 1.3335 5.22214 1.3335C4.18992 1.3335 3.32714 2.04461 3.07881 3.00016H1.88881C1.58214 3.00016 1.33325 3.24905 1.33325 3.55572C1.33325 3.86239 1.58214 4.11127 1.88881 4.11127Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                    <path--> 
               <!--                                            d="M14.111 7.44461H12.9999V8.55572H14.111C14.4177 8.55572 14.6666 8.30683 14.6666 8.00016C14.6666 7.6935 14.4177 7.44461 14.111 7.44461Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                    <path--> 
               <!--                                            d="M1.88881 8.55572H7.52325C7.77159 9.51127 8.63436 10.2224 9.66659 10.2224C10.8921 10.2224 11.8888 9.22572 11.8888 8.00016C11.8888 6.77461 10.8921 5.77794 9.66659 5.77794C8.63436 5.77794 7.77159 6.48905 7.52325 7.44461H1.88881C1.58214 7.44461 1.33325 7.6935 1.33325 8.00016C1.33325 8.30683 1.58214 8.55572 1.88881 8.55572Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                    <path--> 
               <!--                                            d="M14.111 11.8891H8.55547V13.0002H14.111C14.4177 13.0002 14.6666 12.7513 14.6666 12.4446C14.6666 12.1379 14.4177 11.8891 14.111 11.8891Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                    <path--> 
               <!--                                            d="M5.22214 10.2224C4.18992 10.2224 3.32714 10.9335 3.07881 11.8891H1.88881C1.58214 11.8891 1.33325 12.1379 1.33325 12.4446C1.33325 12.7513 1.58214 13.0002 1.88881 13.0002H3.07881C3.32714 13.9557 4.18992 14.6668 5.22214 14.6668C6.4477 14.6668 7.44436 13.6702 7.44436 12.4446C7.44436 11.2191 6.4477 10.2224 5.22214 10.2224Z"--> 
               <!--                                            fill="white"--> 
               <!--                                    />--> 
               <!--                                </svg>--> 
               <!--                            </button>--> 
               <!--                                                        <div class="dropdown-menu dropdown-menu-right p-3" onclick="event.stopPropagation()"--> 
               <!--                                                             aria-labelledby="dropdownMenuLink" style="min-width: 30rem;">--> 
               <!--                                                            <label>Tỉnh / thành phố</label>--> 
               <!--                                                            <select class="form-control" placeholder="Chọn tỉnh/ thành phố"--> 
               <!--                                                                    v-model="filterSearch.provinceCity">--> 
               <!--                                                                <option value="" disabled selected class="form-control">--> 
               <!--                                                                    <span>Chọn tỉnh/ thành phố</span>--> 
               <!--                                                                </option>--> 
               <!--                            &lt;!&ndash;                                    <option th:each="item:${provinces}" th:value="${item.code}" class="form-control">&ndash;&gt;--> 
               <!--                            &lt;!&ndash;                                        <span th:text="${item.name}"></span>&ndash;&gt;--> 
               <!--                            &lt;!&ndash;                                    </option>&ndash;&gt;--> 
               <!--                                                            </select>--> 
               <!--                                                            <label style="margin-top: 20px;">Phân loại</label>--> 
               <!--                                                            <div class="row" style="margin-left: 5px;">--> 
               <!--                                                                <div class="form-check">--> 
               <!--                                                                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">--> 
               <!--                                                                    <label class="form-check-label" for="flexRadioDefault1">--> 
               <!--                                                                        Nhà thầu trong nước--> 
               <!--                                                                    </label>--> 
               <!--                                                                </div>--> 
               <!--                                                                <div style="margin-left: 60px;" class="form-check">--> 
               <!--                                                                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">--> 
               <!--                                                                    <label class="form-check-label" for="flexRadioDefault2">--> 
               <!--                                                                        Nhà thầu nước ngoài--> 
               <!--                                                                    </label>--> 
               <!--                                                                </div>--> 
               <!--                                                            </div>--> 
               <!--                                                            <label style="margin-top: 18px;">Thời gian đăng kí</label>--> 
               <!--                                                            <a-range-picker style="width: 100%;" @change="onChange" format="DD/MM/YYYY" :placeholder="rangePicker" size="large"></a-range-picker>--> 
               <!--                                                            <label>Mã số thuế</label>--> 
               <!--                                                            <input class="form-control" placeholder="Nhập mã số thuế" v-model="filterSearch.taxCode">--> 
               <!--                                                            <label>Số GCN đăng kí kinh doanh/ Số GCN đầu tư</label>--> 
               <!--                                                            <input class="form-control" placeholder="Nhập số GCN đăng kí kinh doanh/ số GCN đầu tư" v-model="filterSearch.numberGCN">--> 
               <!--                                                            <a-range-picker :placeholder="rangePicker" format="DD/MM/YYYY"--> 
               <!--                                                                            valueFormat="YYYY-MM-DD">--> 
               <!--                                                            </a-range-picker>--> 
               <!--                                                            <div class="d-flex justify-content-end" style="margin-top: 20px;">--> 
               <!--                                                                <button type="button" class="blue-btn" data-toggle="dropdown" style="margin-right: 15px;" @click="offFilter()">Bỏ lọc</button>--> 
               <!--                                                                <button type="button" class="blue-btn" data-toggle="dropdown" @click="onFilter()">Áp dụng</button>--> 
               <!--                                                            </div>--> 
               <!--                                                        </div>--> 
              </div> 
             </div> 
             <div class="content__body"> 
              <div class="content__body__list"> 
               <!-- dang hoat dong --> 
               <div class="content__body__item" v-for="(item, index) in pageContent" @click="viewDetail(item?.orgCode,item?.effRoleDate,item?.parentName)" style="cursor: pointer"> 
                <div class="content__body__item__heading"> 
                 <h4 class="content__body__item__heading__text m-0"> {{item?.orgCode}} </h4> 
                 <span :class="{ 'content__body__item__heading__status--primary': (item?.status === 1), 'content__body__item__heading__status--warning': (item?.status === 2) , 'status--cancel': (item?.status === 3)}"> 
                  <template>
                   {{getRoleStatusNameByCode(item)}}
                  </template> </span> 
                </div> 
                <div class="d-flex flex-column align-items-start gap-16"> 
                 <h2 class="content__body__item__title m-0 content__long"> {{item?.orgFullname}} </h2> 
                 <div class="content__body__item__body" style="gap: 10%;"> 
                  <div class="content__body__item__body__address p-2" style="padding-left: 0 !important;min-width: 180px;"> 
                   <p class="content__body__item__body__title m-0">Mã số thuế</p> 
                   <p class="content__body__item__body__desc m-0 content__long"> {{item?.taxCode}} </p> 
                  </div> 
                  <div class="content__body__item__body__address p-2" style="padding-left: 0 !important;"> 
                   <p class="content__body__item__body__title m-0">Địa chỉ</p> 
                   <p class="content__body__item__body__desc m-0 content__long"> {{item?.officeAdd}} </p> 
                  </div> 
                  <div class="content__body__item__body__address p-2" style="padding-left: 0 !important;"> 
                   <p class="content__body__item__body__title m-0">Ngày phê duyệt</p> 
                   <p class="content__body__item__body__desc m-0 ml-auto content__long"> {{convertEffRoleDate(item?.effRoleDate)}} </p> 
                  </div> 
                  <div class="content__body__item__body__address p-2" style="padding-left: 0 !important;" v-if="item?.status === 2"> 
                   <p class="content__body__item__body__title m-0">Ngày tạm dừng</p> 
                   <p class="content__body__item__body__desc m-0 content__long"> {{item.startPendingDate|reverse}}</p> 
                  </div> 
                 </div> 
                </div> 
               </div> 
              </div> 
              <div class="pagination" v-if="!checkSearchTest()"> 
               <div class="pagination__list"> 
                <el-pagination background layout="prev, pager, next" :total="page.totalElements" :page-size="page.pageSize" :current-page="page.pageNumber" @current-change="changePage" :page-count="page.totalPages"> 
                </el-pagination> 
                <!--                            <span class="pagination__item"> << </span>--> 
                <!--                            <span class="pagination__item"> < </span>--> 
                <!--                            <div class="pagination__list-page">--> 
                <!--                                <span class="pagination__item active">1</span>--> 
                <!--                                <span class="pagination__item">2</span>--> 
                <!--                                <span class="pagination__item">3</span>--> 
                <!--                                <span class="pagination__item">...</span>--> 
                <!--                                <span class="pagination__item">50</span>--> 
                <!--                            </div>--> 
                <!--                            <span class="pagination__item">></span>--> 
                <!--                            <span class="pagination__item"> >> </span>--> 
               </div> 
               <div class="pagination--mobile"> 
                <!--                                <el-pagination--> 
                <!--                                        background--> 
                <!--                                        layout="prev, pager, next"--> 
                <!--                                        :total="page.totalElements"--> 
                <!--                                        :page-size="page.pageSize"--> 
                <!--                                        :current-page="page.pageNumber"--> 
                <!--                                        @current-change="changePage"--> 
                <!--                                        :page-count="page.totalPages">--> 
                <!--                                </el-pagination>--> 
                <select name="" id="" v-model="page.pageNumber" @change="changePageWithSelect()"> <option v-for="item in pages" :value="item + 1">{{item + 1}}</option> 
                 <!--                                    <option value="2">2</option>--> 
                 <!--                                    <option value="3">3</option>--> 
                 <!--                                    <option value="4">4</option>--> 
                 <!--                                    <option value="5">5</option>--> </select> 
               </div> 
              </div> 
              <div class="pagination" v-if="checkSearchTest()"> 
               <div class="pagination__list"> 
                <el-pagination background layout="prev, pager, next" :total="1" :page-size="page.pageSize" :current-page="1" @current-change="changePage" :page-count="1"> 
                </el-pagination> 
               </div> 
              </div> 
             </div> 
            </div> 
           </div> 
          </div> 
         </main> 
        </a-spin> 
       </div> 
       <script>
    new Vue({
        el: '#search-approved-contractor',
        data() {
            return {
                urlGetList: "\/o\/egp-portal-contractors-approved\/services\/get-list",
                urlLoadListRoleStatusByCAT: "\/o\/egp-portal-contractors-approved\/services\/role-status-cat",
                urlLoadAreasByType: "\/o\/egp-portal-contractors-approved\/services\/cat-areas",
                urlRenderDetail: "https:\/\/muasamcong.mpi.gov.vn\/web\/guest\/approved-contractors-list?p_p_id=egpportalcontractorsapproved_WAR_egpportalcontractorsapproved\u0026p_p_lifecycle=0\u0026p_p_state=normal\u0026p_p_mode=view\u0026_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved_render=detail",
                isBack: null,

                loading: false,
                dataPage: null,
                title: '',
                keySearch: '',
                isLoading: false,
                listRoleStatus: [],
                questType: 'GIAODIEN',
                checkActive: 'GIAODIEN',
                dataSearch: {
                    title: '',
                    questType: 'GIAODIEN'
                },
                page: {
                    pageSize: 10,
                    pageNumber: 0
                },
                isLoadingLoadList: false,
                addressList: [],
                listApproveBidder: [],
                queryParams: {
                    officePro:{
                        contains: null
                    },
                    effRoleDate: {
                        greaterThanOrEqual: null,
                        lessThanOrEqual: null
                    },
                    isForeignInvestor: {
                        equals: null
                    },
                    roleType: {
                        in: ['NT','NTPER']
                    },
                    decNo: {
                      contains: null
                    },
                    orgName: {
                        contains: null
                    },
                    taxCode: {
                        contains: null
                    },
                    orgNameOrOrgCode: {
                        contains: null
                    },
                    agencyName: {
                        in: null
                    }
                },
                filterSearch: {
                    provinceCity: null,
                    typeBidder: null,
                    fromRegisterTime: '',
                    toRegisterTime: '',
                    taxCode: null,
                    numberGCN: null,
                    range: [],
                },
                check: 0,
                rangePicker: ['dd/mm/yyyy', 'dd/mm/yyyy'],
                pages: [],
                siteURL: "https:\/\/muasamcong.mpi.gov.vn\/web\/guest",
                visible: false,
                range:[],
                listAreaPro: [],
            }
        },
        computed: {
            pageContent() {
                if (this.dataPage) {
                    return this.dataPage.content;
                }
                return [];
            },
        },
        methods: {
            loadPageApproveBidder() {
                this.isLoadingLoadList = true;
                this.addressList = [];
                const payload = {
                    pageSize: this.page.pageSize,
                    pageNumber: this.page.pageNumber,
                    queryParams: this.queryParams
                }
                axios.post(this.urlGetList,payload ).then(res => {
                    sessionStorage.setItem("payloadApprovedNT",JSON.stringify(payload))
                    this.isLoadingLoadList = false;
                    const data = res.data;
                    this.listApproveBidder = data.content;
                    this.dataPage = data;
                    this.page = {
                        pageSize: data.pageSize,
                        pageNumber: data.currentPage,
                        totalPages: data.totalPages,
                        totalElements: data.totalElements
                    };
                    this.pages = this.getPageList(data);

                }).catch(err => {
                    this.isLoadingLoadList = false;
                })
            },
            convertEffRoleDate(date){
                if(date && date.length > 0){
                    return `${date[2]}/${date[1]}/${date[0]}`
                }
                return '';
            },
            search() {
                this.queryParams.orgNameOrOrgCode.contains = this.keySearch;
                this.page.pageNumber = 0;
                this.loadPageApproveBidder();
            },
            loadRoleStatusListCAT() {
                this.isLoading = true;
                axios.get(
                    this.urlLoadListRoleStatusByCAT
                ).then(res => {
                    this.isLoading = false;
                    this.listRoleStatus = res.data;
                }).catch(err => {
                    this.isLoading = false;
                })
            },
            checkEnglishLanguage(){
                if (window.location.href.includes('/en/')){
                    return true;
                } else {
                    return false;
                }
            },
            getRoleStatusNameByCode(item) {
                if (item.status == 2 && item.lockRoleDate)
                    return this.checkEnglishLanguage() ? 'Lock' : 'Khóa';
                if (!this.listRoleStatus)
                    return item?.status;
                const temp = this.listRoleStatus.filter(el => el.code == item.status).pop();
                return temp ? (this.checkEnglishLanguage() ? temp.nameEn :  temp.name): item.status;
            },
            changePage(page) {
                console.log(page);
                this.page.pageNumber = page - 1;
                this.loadPageApproveBidder();
            },
            changePageWithSelect(){
                this.page.pageNumber = this.page.pageNumber -1;
                this.loadPageApproveBidder();
            },
            viewDetail(orgCode,effRoleDate,parentName) {
                effRoleDate = this.convertEffRoleDate(effRoleDate);
                window.open(`${this.urlRenderDetail}&orgCode=${orgCode}&effRoleDate=${effRoleDate}&role=${parentName}`, '_self');
            },
            //Download file public
            downloadFile(fileId, fileName) {
                axios.get('http://localhost:1234/api/download/file/browser/public', {
                    params: {
                        fileId: fileId
                    },
                    responseType: 'blob'
                }).then(response => {
                    var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                    var fileLink = document.createElement('a');
                    fileLink.href = fileURL;
                    fileLink.setAttribute('download', fileName);
                    document.body.appendChild(fileLink);
                    fileLink.click();
                })
            },
            onChange(date, dateString) {
                this.filterSearch.range = date;
                this.filterSearch.fromRegisterTime = dateString[0].split('/').reverse().join('-');
                this.filterSearch.toRegisterTime = dateString[1].split('/').reverse().join('-');
            },
            openSearch() {
                this.check = !this.check;
            },
            offFilter: function () {
                this.filterSearch.provinceCity = null;
                this.filterSearch.typeBidder = null;
                this.filterSearch.fromRegisterTime = '';
                this.filterSearch.toRegisterTime = '';
                this.filterSearch.taxCode = null;
                this.filterSearch.numberGCN = null;
                this.filterSearch.range= [];
                sessionStorage.removeItem('filterApprovedNT');

                // this.onSearch();
            },
            onFilter: function () {
                this.onSearch();
                sessionStorage.setItem('filterApprovedNT',JSON.stringify(this.filterSearch))
                this.visible = false;
            },
            onSearch: function () {
                this.queryParams.officePro.contains = this.filterSearch.provinceCity;
                this.queryParams.effRoleDate.greaterThanOrEqual = this.filterSearch.fromRegisterTime != '' ? new Date(new Date(this.filterSearch.fromRegisterTime).setUTCHours(0,0,0)).toISOString() : null;
                this.queryParams.effRoleDate.lessThanOrEqual = this.filterSearch.toRegisterTime != '' ? new Date (new Date (this.filterSearch.toRegisterTime).setUTCHours(23,59,59)).toISOString() : null;
                this.queryParams.isForeignInvestor.equals = this.filterSearch.typeBidder;
                this.queryParams.decNo.contains = this.filterSearch.numberGCN;
                this.queryParams.taxCode.contains = this.filterSearch.taxCode;
                // this.queryParams.agencyName.in = [this.filterSearch.provinceCity];
                this.page.pageSize = 10;
                this.page.pageNumber = 0;

                this.loadPageApproveBidder();
            },
            getListAreaPro() {
                this.isLoading = true;
                axios.post(this.urlLoadAreasByType, {
                    areaType: "1"
                }).then(res => {
                    this.isLoading = false;
                    const data = res.data;
                    this.listAreaPro = data;
                }).catch(err => {
                    this.isLoading = false;
                })
            },
            getPageList(pagination) {
                if (!pagination || pagination?.totalPages === 0) {
                    return [0];
                }
                const pages = [];
                for (let i = 0; i < pagination?.totalPages; i++) {
                    pages.push(i);
                }
                return pages;
            },
            breadcrumbRedirect(path) {
                let url = this.siteURL;
                if(path) url = `${url}/${path}`;
                window.location = url;
            },
            showModal() {
                this.visible = true;
            },
            handleOk() {
                this.visible = false;
            },
            checkSearchTest(){
                if (this.queryParams.orgNameOrOrgCode.contains && this.queryParams.orgNameOrOrgCode.contains.toLowerCase().includes('test')){
                    return true;
                }
                return  false;
            }
        },
        filters: {
            reverse(value) {
                if (!value)
                    return '';
                return value.split('-').reverse().join('/');
            }
        },
        mounted() {
            this.loadRoleStatusListCAT();
            this.getListAreaPro();
            if(this.isBack == '01' && sessionStorage.getItem('payloadApprovedNT')){
                let payload= JSON.parse(sessionStorage.getItem('payloadApprovedNT'));
                this.page.pageSize = payload.pageSize;
                this.page.pageNumber = payload.pageNumber;
                this.queryParams = payload.queryParams;
                if(payload?.queryParams?.orgNameOrOrgCode?.contains){
                    this.keySearch = payload?.queryParams?.orgNameOrOrgCode?.contains;
                }
                if(sessionStorage.getItem('filterApprovedNT')){
                    this.filterSearch = JSON.parse(sessionStorage.getItem('filterApprovedNT'));
                }
                this.loadPageApproveBidder();
            }
        }
    })
</script> 
      </div> 
     </div> 
    </div> 
   </section> 
  </div> 
 </div>
</div>

	




		</div>
	


<form action="#" aria-hidden="true" class="hide" id="hrefFm" method="post" name="hrefFm"><span></span><button hidden type="submit">Ẩn</button></form>



	
	</section>
<footer id="egp-footer" >
    <div class="img-container-footer1">
        <div class="content__wrapper p-0">
            <div class="content mt-0">
                <div class="row img-container-footer1__body-footer">
                    <div class="text-left" style="max-width: 450px">
                        <p class="img-container-footer1__body-footer__title">
                            Thông tin liên hệ                        </p>
                        <div
                            class="img-container-footer1__body-footer__content-contact d-flex flex-direction-row">
                            <p style="opacity: 0.7">
                                <img src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/phone.png" alt="phone" />
                                Tổng đài hỗ trợ người dùng:
                            </p>
                            &nbsp
                            <span>19006126</span>
                        </div>
                        <div
                            class="img-container-footer1__body-footer__content-contact d-flex flex-direction-row" style="">
                            <span style="opacity: 0.7; min-width: fit-content">
                                <img src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/location.png" alt="location" />
                                Địa chỉ:
                            </span>
                            &nbsp
                            <span>
                                <span>Cục Quản lý đấu thầu</span>:
                                <br/>
                                <span>Tầng 1, Tòa nhà Cục Quản lý đấu thầu, Số 4, Ngõ Hàng Chuối 1, phố Hàng Chuối, Phường Hai Bà Trưng, Hà Nội.</span>
                                <br/>
                                <br/>
                                 <span>Trung tâm Đấu thầu qua mạng quốc gia</span>:
                                <br/>
                                <span>Tầng 6, Tòa nhà Cục Quản lý đấu thầu, Số 4, Ngõ Hàng Chuối 1, phố Hàng Chuối, Phường Hai Bà Trưng, Hà Nội.</span>
                            </span>
                        </div>
                        <div
                            class="img-container-footer1__body-footer__content-contact d-flex flex-direction-row">
                            <p style="opacity: 0.7">
                                <img src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/mail.png" alt="mail" />
                                Email:
                            </p>
                            &nbsp
                            <span>hotro@muasamcong.gov.vn</span>
                        </div>
                    </div>
                    <div class="text-left">
                        <p class="img-container-footer1__body-footer__title">
Truy cập nhanh                        </p>
                        <a href="https://muasamcong.mpi.gov.vn/web/guest/introduce-system">
                            <p
                                class="img-container-footer1__body-footer__content-quick-access">
                                <img
                                    src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/right-arrow.png"
                                    alt="right-arrow" />
Giới thiệu                            </p>
                        </a>
                        <a href="https://muasamcong.mpi.gov.vn/web/guest/news">
                            <p
                                class="img-container-footer1__body-footer__content-quick-access">
                                <img
                                    src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/right-arrow.png"
                                    alt="right-arrow" />
Tin tức                            </p>
                        </a>
                        <a href="https://muasamcong.mpi.gov.vn/web/guest/notification-system">
                            <p
                                class="img-container-footer1__body-footer__content-quick-access">
                                <img
                                    src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/right-arrow.png"
                                    alt="right-arrow" />
Thông báo của bộ                            </p>
                        </a>
                        <a href="https://muasamcong.mpi.gov.vn/web/guest/contact">
                            <p
                                class="img-container-footer1__body-footer__content-quick-access">
                                <img
                                    src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/right-arrow.png"
                                    alt="right-arrow" />
Liên hệ - Góp ý                            </p>
                        </a>
                    </div>
                    <div class="content__body___footer">
                        <p class="img-container-footer1__body-footer__title">
                            Zalo Official Account
                        </p>
                        <img src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/custom/qr_zalo.png" alt="qr_zalo" />
                    </div>
                    <div class="content__body___footer">
                        <p class="img-container-footer1__body-footer__title">Fanpage</p>
                        <iframe
                            src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fmuasamcong&width=290&height=190&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId"
                            width="290"
                            height="190"
                            style="border: none; overflow: hidden"
                            scrolling="no"
                            frameborder="0"
                            allowfullscreen="true"
                            allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- bottom footer -->
    <div class="img-container-footer2">
        <div class="content__wrapper d-flex flex-direction-row p-0">
            <div class="content mt-0">
                <div class="img-container-footer2__bottom-footer">
                    <div class="text-center p-0 center-item" style="display: initial; !important;">
                        <div class="px-2">
                            <div class="img-container-footer2__right-bottom-footer-border dvc_class_btn"
                                 style="cursor: pointer" @click="loadAuthorizedUrl()">
                                <img
                                        src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/ic_btm_footer1.png"
                                        alt="btm-footer1"
                                        width="24"
                                        style="margin-right: 12px" />
                                <p>Cổng Dịch vụ công quốc gia</p>
                            </div>
                        </div>

                        <p
                            class="img-container-footer2__left-bottom-footer"
                            style="opacity: 0.7">
                            © 2022 Trung tâm Đấu thầu qua mạng quốc gia. Cục Quản lý đấu thầu. Bộ Tài chính.
                        </p>
                    </div>
                    <div class="px-2">
                        <div class="img-container-footer2__right-bottom-footer-border">
                            <img
                                src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/ic_btm_footer1.png"
                                alt="btm-footer1"
                                width="24"
                                style="margin-right: 12px" />
                            <p>Cổng thông tin điện tử Bộ Tài chính</p>
                        </div>
                    </div>
                    <div class="px-2">
                        <div class="img-container-footer2__right-bottom-footer-border">
                            <img
                                src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/ic_btm_footer2.png"
                                alt="btm-footer2"
                                width="32"
                                style="margin-right: 12px" />

                            <p>
Trang thông tin điện tử đầu tư theo hình thức đối tác công tư                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<script th:inline="javascript">
    var vm = new Vue({
        el: '#egp-footer',
        data() {
            return {

            }
        },
        directives: {},
        methods: {

            loadAuthorizedUrl(){



                console.log("hereeeeeeeeeee")

                Liferay.Util.fetch('/o/egp-portal-home/services/authorize-url', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(data => data.json())
                    .then((res) => {
                        console.log("res: ", res);
                        let url = res?.data?.authorizeUrl;
                        if(url){
                            console.log("url : ", url);
                            window.open(url,"_self");
                        }
                    }).catch(err => {
                    console.log("Errors in load root roles {} ", err);
                });

            },
        },
        created() {

        }
    })
</script>
</div>













































































































	

	





	



	









	

	





	



	









<script type="text/javascript">
// <![CDATA[

	
		

			

			
		
	

// ]]>
</script>













<script type="text/javascript">
	// <![CDATA[

		

		Liferay.currentURL = '\x2fweb\x2fguest\x2fapproved-contractors-list';
		Liferay.currentURLEncoded = '\x252Fweb\x252Fguest\x252Fapproved-contractors-list';

	// ]]>
</script>



	

	

	<script type="text/javascript">
		// <![CDATA[
			
				

				

				
			
		// ]]>
	</script>














	

	


<script type="text/javascript">
// <![CDATA[
(function() {var $ = AUI.$;var _ = AUI._;
	var onVote = function (event) {
		if (window.Analytics) {
			Analytics.send('VOTE', 'Ratings', {
				className: event.className,
				classPK: event.classPK,
				ratingType: event.ratingType,
				score: event.score,
			});
		}
	};

	var onDestroyPortlet = function () {
		Liferay.detach('ratings:vote', onVote);
		Liferay.detach('destroyPortlet', onDestroyPortlet);
	};

	Liferay.on('ratings:vote', onVote);
	Liferay.on('destroyPortlet', onDestroyPortlet);
})();(function() {var $ = AUI.$;var _ = AUI._;
	var onShare = function (data) {
		if (window.Analytics) {
			Analytics.send('shared', 'SocialBookmarks', {
				className: data.className,
				classPK: data.classPK,
				type: data.type,
				url: data.url,
			});
		}
	};

	var onDestroyPortlet = function () {
		Liferay.detach('socialBookmarks:share', onShare);
		Liferay.detach('destroyPortlet', onDestroyPortlet);
	};

	Liferay.on('socialBookmarks:share', onShare);
	Liferay.on('destroyPortlet', onDestroyPortlet);
})();(function() {var $ = AUI.$;var _ = AUI._;
	var pathnameRegexp = /\/documents\/(\d+)\/(\d+)\/(.+?)\/([^&]+)/;

	function handleDownloadClick(event) {
		if (event.target.nodeName.toLowerCase() === 'a' && window.Analytics) {
			var anchor = event.target;
			var match = pathnameRegexp.exec(anchor.pathname);

			var fileEntryId =
				anchor.dataset.analyticsFileEntryId ||
				(anchor.parentElement &&
					anchor.parentElement.dataset.analyticsFileEntryId);

			if (fileEntryId && match) {
				var getParameterValue = function (parameterName) {
					var result = null;

					anchor.search
						.substr(1)
						.split('&')
						.forEach((item) => {
							var tmp = item.split('=');

							if (tmp[0] === parameterName) {
								result = decodeURIComponent(tmp[1]);
							}
						});

					return result;
				};

				Analytics.send('documentDownloaded', 'Document', {
					groupId: match[1],
					fileEntryId: fileEntryId,
					preview: !!window._com_liferay_document_library_analytics_isViewFileEntry,
					title: decodeURIComponent(match[3].replace(/\+/gi, ' ')),
					version: getParameterValue('version'),
				});
			}
		}
	}

	Liferay.once('destroyPortlet', () => {
		document.body.removeEventListener('click', handleDownloadClick);
	});

	Liferay.once('portletReady', () => {
		document.body.addEventListener('click', handleDownloadClick);
	});
})();(function() {var $ = AUI.$;var _ = AUI._;
	var onDestroyPortlet = function () {
		Liferay.detach('messagePosted', onMessagePosted);
		Liferay.detach('destroyPortlet', onDestroyPortlet);
	};

	Liferay.on('destroyPortlet', onDestroyPortlet);

	var onMessagePosted = function (event) {
		if (window.Analytics) {
			Analytics.send('posted', 'Comment', {
				className: event.className,
				classPK: event.classPK,
				commentId: event.commentId,
				text: event.text,
			});
		}
	};

	Liferay.on('messagePosted', onMessagePosted);
})();
	if (window.svg4everybody && Liferay.Data.ICONS_INLINE_SVG) {
		svg4everybody(
			{
				polyfill: true,
				validate: function (src, svg, use) {
					return !src || !src.startsWith('#');
				}
			}
		);
	}

	
		Liferay.Portlet.register('egpportalcontractorsapproved_WAR_egpportalcontractorsapproved');
	

	Liferay.Portlet.onLoad(
		{
			canEditTitle: false,
			columnPos: 0,
			isStatic: 'end',
			namespacedId: 'p_p_id_egpportalcontractorsapproved_WAR_egpportalcontractorsapproved_',
			portletId: 'egpportalcontractorsapproved_WAR_egpportalcontractorsapproved',
			refreshURL: '\x2fc\x2fportal\x2frender_portlet\x3fp_l_id\x3d141499\x26p_p_id\x3degpportalcontractorsapproved_WAR_egpportalcontractorsapproved\x26p_p_lifecycle\x3d0\x26p_t_lifecycle\x3d0\x26p_p_state\x3dnormal\x26p_p_mode\x3dview\x26p_p_col_id\x3dnull\x26p_p_col_pos\x3dnull\x26p_p_col_count\x3dnull\x26p_p_static\x3d1\x26p_p_isolated\x3d1\x26currentURL\x3d\x252Fweb\x252Fguest\x252Fapproved-contractors-list\x26settingsScope\x3dportletInstance',
			refreshURLData: {}
		}
	);
Liferay.Loader.require('frontend-js-web/liferay/delegate/delegate.es', 'frontend-js-web/liferay/toast/commands/OpenToast.es', function(frontendJsWebLiferayDelegateDelegateEs, frontendJsWebLiferayToastCommandsOpenToastEs) {
try {
(function() {
var delegateModule = frontendJsWebLiferayDelegateDelegateEs;
var $ = AUI.$;var _ = AUI._;
	var delegate = delegateModule.default;

	delegate(
		document,
		'focusin',
		'.portlet',
		function(event) {
			event.delegateTarget.closest('.portlet').classList.add('open');
		}
	);

	delegate(
		document,
		'focusout',
		'.portlet',
		function(event) {
			event.delegateTarget.closest('.portlet').classList.remove('open');
		}
	);

})();
(function() {
var toastCommands = frontendJsWebLiferayToastCommandsOpenToastEs;
var $ = AUI.$;var _ = AUI._;
		AUI().use(
			'liferay-session',
			function() {
				Liferay.Session = new Liferay.SessionBase(
					{
						autoExtend: true,
						redirectOnExpire: true,
						redirectUrl: 'https\x3a\x2f\x2fmuasamcong\x2empi\x2egov\x2evn\x2fweb\x2fguest',
						sessionLength: 3600,
						sessionTimeoutOffset: 1,
						warningLength: 0
					}
				);

				
			}
		);
	
})();
} catch (err) {
	console.error(err);
}
});AUI().use('liferay-menu', 'aui-base', function(A) {(function() {var $ = AUI.$;var _ = AUI._;
	if (A.UA.mobile) {
		Liferay.Util.addInputCancel();
	}
})();(function() {var $ = AUI.$;var _ = AUI._;
	new Liferay.Menu();

	var liferayNotices = Liferay.Data.notices;

	for (var i = 0; i < liferayNotices.length; i++) {
		Liferay.Util.openToast(liferayNotices[i]);
	}

})();});
// ]]>
</script>







	
	






<script src="https://muasamcong.mpi.gov.vn/o/egp-portal-theme/js/main.js?browserId=chrome&amp;minifierType=js&amp;languageId=vi_VN&amp;b=7413&amp;t=1767127824000" type="text/javascript"></script>




<script type="text/javascript">
	// <![CDATA[
		AUI().use(
			'aui-base',
			function(A) {
				var frameElement = window.frameElement;

				if (frameElement && frameElement.getAttribute('id') === 'simulationDeviceIframe') {
					A.getBody().addClass('lfr-has-simulation-panel');
				}
			}
		);
	// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-tooltip-support-web@4.0.13/index', function(frontendJsTooltipSupportWeb4013Index) {
try {
(function() {
var TooltipSupport = frontendJsTooltipSupportWeb4013Index;
TooltipSupport.default()
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-dropdown-support-web@2.0.7/index', function(frontendJsDropdownSupportWeb207Index) {
try {
(function() {
var DropdownProvider = frontendJsDropdownSupportWeb207Index;
DropdownProvider.default()
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-tabs-support-web@2.0.8/index', function(frontendJsTabsSupportWeb208Index) {
try {
(function() {
var TabsProvider = frontendJsTabsSupportWeb208Index;
TabsProvider.default()
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-collapse-support-web@2.0.7/index', function(frontendJsCollapseSupportWeb207Index) {
try {
(function() {
var CollapseProvider = frontendJsCollapseSupportWeb207Index;
CollapseProvider.default()
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script><script type="text/javascript">
// <![CDATA[
Liferay.Loader.require('frontend-js-alert-support-web@2.0.7/index', function(frontendJsAlertSupportWeb207Index) {
try {
(function() {
var AlertProvider = frontendJsAlertSupportWeb207Index;
AlertProvider.default()
})();
} catch (err) {
	console.error(err);
}
});
// ]]>
</script></body>
<script type="text/javascript">
	$(document).ready(function () {
		var styleExpand = document.querySelector("#expand");
		var button__expand = document.querySelector("#button__expand");
		var button__small = document.querySelector("#button__small");
		var search__box = document.getElementById("search__box");
		var beforeCollapse = document.getElementById("beforeCollapse");
		var afterCollapse = document.getElementById("afterCollapse");
		var search__wrap = document.getElementById("search__wrap");

		$('.check-radio-group').click(function () {
			const name = $(this).find('input').eq(0).attr('name');
			$('.check-radio-group.active').each(function () {
				const input = $(this).find('input');
				if (input.attr('name') === name) {
					$(this).removeClass('active');
					input.attr('checked', false);
				}
			});

			$(this).addClass('active');
			$(this).find('input').attr('checked', true);
		});

		$('#search-home .button__expand').click(function () {
			handleExpand();
		});

		$('#search-home .button__small').click(function () {
			handleSmall();
		});

		$('.step__item').on('show.bs.collapse', function () {
			$(this).find('img.step__item__icon').attr('src', 'https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/minus-brown.svg').fadeIn(150);
		});

		$('.step__item').on('hide.bs.collapse', function () {
			$(this).find('img.step__item__icon').attr('src', 'https://muasamcong.mpi.gov.vn/o/egp-portal-theme/images/icons/add.svg').fadeIn(150);
		});

		$('.nav-tabs a').click(function () {
			const href = $(this).attr('href');
			$('.detail__children-2__view').addClass('disabled-block');
			const classShow = href.replace('#', '.');
			$(classShow).removeClass('disabled-block');
		});

		$('.btn-nav-right').click(function () {
			const scrollNow = $('.nav-scroll').scrollLeft();
			$('.nav-scroll').scrollLeft(scrollNow + 123);
			const scroll = $('.nav-scroll').scrollLeft();
			$('.btn-nav-left').removeClass('disabled-block');




			var maxScrollLeft =
					$('.nav-scroll')[0]?.scrollWidth - $('.nav-scroll')[0]?.clientWidth;
			if (maxScrollLeft == scroll) {
				$('.btn-nav-right').addClass('disabled-block');
			}
		});

		$('.btn-nav-left').click(function () {
			const scrollNow = $('.nav-scroll').scrollLeft();
			$('.nav-scroll').scrollLeft(scrollNow - 123);
			$('.btn-nav-right').removeClass('disabled-block');
			const scroll = $('.nav-scroll').scrollLeft();
			if (scroll == 0) {
				$('.btn-nav-left').addClass('disabled-block');
			}
		});
		// Add event listener to select size small or large
		if(beforeCollapse){
			beforeCollapse.classList.add('d-none');
		}
		if(afterCollapse){
			afterCollapse.classList.remove('d-none');
		}
		if(search__wrap){
			search__wrap.style['max-height'] = 'fit-content';
			search__wrap.classList.remove('blurText');
		}


		var height_search__wrap = $('#search-home .search__wrap').height();
		if(button__expand && button__small){
			if (height_search__wrap < 150) {
				button__expand.style.display = 'none';
				button__small.style.display = 'none';
			} else {
				button__expand.style.display = 'none';
				button__small.style.display = 'block';
			}
		}


		function handleExpand() {
			button__expand.style.display = "none";
			button__small.style.display = "block";
			beforeCollapse.classList.add("d-none");
			afterCollapse.classList.remove("d-none");
			search__wrap.style.height = "auto";
			search__wrap.classList.remove("blurText");
		}

		function handleSmall() {
			button__expand.style.display = "block";
			button__small.style.display = "none";
			beforeCollapse.classList.remove("d-none");
			afterCollapse.classList.add("d-none");
			search__wrap.style.height = "175px";
			search__wrap.classList.add("blurText");
		}

		$(window).resize(function () {
			handleBtnNavScroll();
		});

		function handleBtnNavScroll() {
			var maxScrollLeft =
					$('.nav-scroll')[0]?.scrollWidth - $('.nav-scroll')[0]?.clientWidth;
			if (maxScrollLeft > 0) {
				$('.btn-nav-right').removeClass('disabled-block');
			} else {
				$('.btn-nav-right').addClass('disabled-block');
			}
		}




	});


</script>
<script th:inline="javascript">
	var vm = new Vue({
		el: '#egp-header',
		data() {
			return {
				roles: [],
				rootRoles: [],
				roleDefault: '',
				favDropDown: [],
				listPathname: ['adbwbfe', 'plansfe', 'notificationsfe', 'bidsubmissionsfe', 'bidsubmissionsotherfe', 'bidopensfe', 'ebidresultsfe', 'ebidextensionsfe', 'bidonlinefe', 'contractorotherfe', 'econtractfe', 'epaymentfe'],
				isUpdate: null,
				checkLogin: null,
				userInfo: {},
				isEngLanguage: false,
				catUmPolicy: [],
				selectedrootRole: '',
				notificationList: [],
				modalData: null,
				modalVisible: false,
				totalNotification: 0,
				serverTime: null,
				checkTTCQCQ: false,
				classificationDependents: [],
				agencyCodePresent: null,
				agencyCodeNew: null,
				checkAgencyCodeNew: false,

				pro: null,
				checkPro: false,

				ward: null,
				checkWard: false,

				add: null,
				checkAdd: false,

				invoiceAddress: null,
				checkInvoiceAddress: false,

				listProvince : [],
				listWard : [],
				listRoles: [],

				orgCodeCurrent: '',
				isLoginReload: false,
				orgInfoCommon: null,
				userInfoV2: null,
				mergeUsers: [],
				modalVisibleChangeAccount: false,
			}
		},
		directives: {},
		methods: {
			handleLoadNotificationRealTime(){

			},
			readNotification(itemId){
				const payload = {
					id: itemId,
				};
				if (Liferay.ThemeDisplay.isSignedIn()) {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/change-status', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify(payload),
					}).then(data => data.json())
							.then((res) => {
							});
				}
			},

			customFilterOption(input, option){
				return option.componentOptions.children[0].text.toLowerCase().includes(input.toLowerCase());
			},
			loadProvince(){
				const payload =  {
					"areaType": 1,
					"parentCode": "VN",
					"isValid": true
				};
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/get/area-api', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(payload),
				}).then(data => data.json()).then((res) => {
					this.listProvince = res?.areas;
					if (!this.listProvince?.some(it => it.code == this.pro)){
						this.pro = null;
						this.ward = null
					}
					if (this.pro){
						this.loadWardList();
					}
				});
			},

			changeProvince(){
				this.ward = null;
				this.loadWardList();
			},
			loadWardList(){
				const payload =  {
					"areaType": 2,
					"parentCode": this.pro,
					"isValid": true
				};
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/get/area-api', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(payload),
				}).then(data => data.json()).then((res) => {
					this.listWard = res?.areas;
				});
			},

			openNotificationModal(id){
				this.notificationList.forEach(element => {
					if (id == element.id) {
						this.modalData = element;
						this.readNotification(id);
						this.loadNotification();
					}
				});
				this.modalVisible = true;
			},
			loadNotification() {
				const payload = {
					pageSize: 5,
					pageNumber: 0,
					queryParams: {
						status: {
							equals: 0
						},
					},
					sort: "createdDate desc",
				};
				if (Liferay.ThemeDisplay.isSignedIn()) {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/mail-inbox', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify(payload),
					}).then(data => data.json())
							.then((res) => {
								this.notificationList = res.page.content;
								this.totalNotification = res.page.totalElements;
							});
				}
			},
			loadMenuInfo() {
				const payLoad =  {
					langKey: "VI",
					keyModule: "PO"
				};
				if (Liferay.ThemeDisplay.isSignedIn()) {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/menus', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify(payLoad),
					}).then(data => data.json())
							.then((res) => {
								this.selectedrootRole = res.selectedrootRole;
								this.rootRoles = res.rootRoles;
								localStorage.setItem("currentRole", this.selectedrootRole);
								this.loadFavMenu(res.selectedrootRole);
							});
				} else {
					localStorage.setItem("currentRole", null);
				}
			},
			loadFavMenu(rootRole){
				const payLoadFavorite =  {
					langKey: "VI",
					keyModule: "EBID",
					rootRole: rootRole,
				};
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/menus', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(payLoadFavorite),
				}).then(data => data.json())
						.then((rs) =>{
							this.favDropDown = rs?.menus?.[0]?.menus?.filter(menu => menu.bookMarkIdx)
							this.favDropDown?.sort((a,b) => b.bookMarkIdx - a.bookMarkIdx);
						});
			},
			redirectMenu(root,menu){
				const targetProject = this.listPathname.find(item =>
						menu?.url?.includes(item)
				);
				const finalUrl = targetProject ? menu.url : ('/contractorfe' + menu.url);
				const url = root+ finalUrl;
				localStorage.setItem("process",menu?.menuKey)
				window.open(url, "_self");
			},
			loadUserInfo() {
				let prefixAva = "";
				const payLoad = {};
				if (Liferay.ThemeDisplay.isSignedIn()) {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-user-info', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify(payLoad),
					}).then(data => data.json())
							.then((res) => {
								// this.roleDefault = res.userDTO.roleDefault;
								this.userInfo = res.userDTO;
								this.orgCodeCurrent = this.userInfo.userName.split('-')[0];
								localStorage.setItem("userDTO", JSON.stringify(res.userDTO));

							});
				} else{
					localStorage.setItem("userDTO", null);
					localStorage.setItem("orgInfoCommon", null);

				}
			},
			loadCatList() {
				if (!Liferay.ThemeDisplay.isSignedIn()) {
					return;
				}
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-categories-by-code-lst', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify([{
						"categoryTypeCodeLst": ["UM_ROLE", "IDENTITY_TYPE", "USER_LANGUAGE", "BUSINESS_TYPE", "USER_STATUS", "CA_APPROVED_STATUS"]
					}])
				}).then(data => data.json())
						.then((res) => {
							this.catUmPolicy = res[0].categories.UM_ROLE;

						}).catch(err => {
					console.log("Error in load category roles {} ", err.text());
				});
			},
			// Danh sách cơ quan chủ quản
			loadCatListClassificationDependents(){
				if (!Liferay.ThemeDisplay.isSignedIn() || sessionStorage.getItem('classificationDependents')) {
					if (sessionStorage.getItem('classificationDependents')){
						this.classificationDependents =  JSON.parse(sessionStorage.getItem('classificationDependents'));
					}
					return;
				}
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-categories-by-code-lst', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify([{
						"categoryTypeCodeLst": ["classification_dependent"]
					}])
				}).then(data => data.json())
				.then((res) => {
					this.classificationDependents = res[0].categories.classification_dependent;
					sessionStorage.setItem("classificationDependents", JSON.stringify(this.classificationDependents));
				}).catch(err => {
						console.log("Error in load category roles {} ", err.text());
				});
			},
			// Check hiện popup cập nhật tt cơ quan chủ quản
			checkPopupTTCQCQ(){
				if (!Liferay.ThemeDisplay.isSignedIn()) {
					return;
				} else {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/check-confirm-agency', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify({boby: null})
					}).then(data => data.json())
					.then((res) => {
						if (res) {
							this.checkTTCQCQ = res.display;
							this.agencyCodePresent = res.agencyCurrent;
							this.agencyCodeNew = null;
							this.pro = res.pro;
							this.ward = res.ward;
							this.add = res.add;
							this.listRoles = res.roles;
							this.invoiceAddress = res.billingAdd;
							if (this.checkTTCQCQ){
								this.loadProvince();
							}
						} else {
							this.checkTTCQCQ = false;
						}
					});
				}
			},
			updateTTCQCQ(){
				console.log(this.agencyCodeNew);
				if (!this.agencyCodeNew && (this.listRoles?.includes('CDT') || this.listRoles?.includes('BMT'))){
					this.checkAgencyCodeNew = true;
					return;
				}
				this.checkPro = true;
				this.checkWard = true;
				this.checkAdd = true;
				this.checkInvoiceAddress = true;
				if (!this.pro){
					return;
				}
				if (!this.ward){
					return;
				}
				if (!this.add){
					return;
				}
				if (!this.invoiceAddress && (this.listRoles?.includes('NT') || this.listRoles?.includes('NDT') || this.listRoles?.includes('NTPER'))){
					return;
				}
				const dataImport = {
					[this.orgCodeCurrent]: {
						"pro": this.pro,
						"ward": this.ward,
						"add": this.add,
						"agencyName": this.agencyCodeNew
					}
				}
				console.log(dataImport);
				let payload = {
					dataUpdate: dataImport,
					type: 'dependent'
				};
				console.log(payload);
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/change-agency-name-in-theme', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
					body: JSON.stringify(payload)
				}).then(data => data.text())
				.then((res) => {
					console.log("res",res);
					if(res.includes('401 Unauthorized')){
						Swal.fire({
							icon: 'error',
							title: 'Thất bại',
							text: 'Phiên đăng nhập của bạn đã hết. Vui lòng đăng nhập lại. Trường hợp cần hỗ trợ, đơn vị vui lòng liên hệ Tổng đài 19006126'
							// confirmButtonText: 'Save'
						}).then(res => window.open('/c/portal/logout', '_self'))
						// setTimeout(() => {
						// 	window.open('/c/portal/logout', '_self');
						// }, 8000);
					} else if (JSON.parse(res)?.success == true) {
						this.checkTTCQCQ = false;
						if (this.listRoles?.includes('NT') || this.listRoles?.includes('NDT') || this.listRoles?.includes('NTPER')){
							const param = {
								billingInfo : {
									contractorCode : this.orgCodeCurrent,
									invoiceAddress: this.invoiceAddress
								}
							}
							Liferay.Util.fetch('/o/egp-portal-personal-page/services/update-billing-info', {
								method: 'POST',
								headers: {
									'Content-Type': 'application/json'
								},
								body: JSON.stringify(param)
							}).then(data => data.text())
						}
						// this.openNotificationWithIcon('success', 'Thành công', 'Lưu thông tin thành công');
						Swal.fire(
								'Thành công',
								'Lưu thông tin thành công',
								'success'
						);
					} else {
						Swal.fire({
							icon: 'error',
							title: 'Thất bại',
							text: 'Lưu thông tin thất bại'
							// confirmButtonText: 'Save'
						})
					}
					// alert("Lưu thông tin thành công");
				}).catch(err => {
					// this.openNotificationWithIcon('error', 'Thất bại', 'Lưu thông tin thất bại');
					Swal.fire({
						icon: 'error',
						title: 'Thất bại',
						text: 'Lưu thông tin thất bại'
						// confirmButtonText: 'Save'
					})
					if (err.response.data.includes('401 Unauthorized')) {
						setTimeout(() => {
							window.open('/c/portal/logout', '_self');
					}, 1500);
					}
				});
			},
			openNotificationWithIcon: function (type, message, description) {
				this.$notification[type]({
					message: message,
					description: description
				});
			},
			checkEnglishLanguage(){
				if (window.location.href.includes('/en/')){
					return true;
				} else {
					return false;
				}
			},
			loadRootRoles() {
				if (!Liferay.ThemeDisplay.isSignedIn()) {
					return;
				}
				const payLoad = {
					langKey: "VI",
					keyModule: "PO",
					rootRole: null
				}
				this.callChangeRoleOrMenu(payLoad);
			},
			onChangeRole(role) {
				if (!Liferay.ThemeDisplay.isSignedIn()) {
					return;
				}
				const payLoad = {
					langKey: "VI",
					keyModule: "PO",
					rootRole: role
				}
				this.callChangeRoleOrMenu(payLoad);
				var currentPath = "/approved-contractors-list";
				if(currentPath == '/profile-info'){
					window.open("https://muasamcong.mpi.gov.vn/web/guest/profile-info","_self");
				} else {
					window.open("https://muasamcong.mpi.gov.vn/web/guest/home","_self");
				}

			},
			callChangeRoleOrMenu(payLoad) {
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/menus', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: JSON.stringify(payLoad),
				}).then(data => data.json())
						.then((res) => {
							this.selectedrootRole = res.selectedrootRole;
							localStorage.setItem("currentRole", this.selectedrootRole);
						}).catch(err => {
					console.log("Errors in load root roles {} ", err);
				});
			},
			openChangeAccountModal(){
				this.modalVisibleChangeAccount = true;
			},
			onChangeAccount(account) {
				if (!Liferay.ThemeDisplay.isSignedIn()) {
					return;
				}
				const payLoad = account.username

				this.callChangeAccount(payLoad);

			},
			callChangeAccount(payLoad) {
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/um-login', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					},
					body: String(payLoad),
				}).then(data => data.json())
						.then((res) => {
							console.log("RES account change {} ", res);
							var currentPath = "/approved-contractors-list";
							if(currentPath == '/profile-info'){
								window.open("https://muasamcong.mpi.gov.vn/web/guest/profile-info","_self");
							} else {
								window.open("https://muasamcong.mpi.gov.vn/web/guest/home","_self");
							}
						}).catch(err => {
					console.log("Errors in load root roles {} ", err);
				});
			},
			loadUserInfoV2() {
				if (Liferay.ThemeDisplay.isSignedIn()) {
					Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-org-info', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify({})
					}).then(data => data.json())
							.then((res) => {
								this.orgInfoCommon = res?.orgInfoCommon;
								this.userInfoV2 = res?.userInfo;
								this.roleDefault = res.userInfo.roleDefault;
								if (this.orgInfoCommon?.mergeUsers){
									this.mergeUsers = Object.entries(this.orgInfoCommon?.mergeUsers).map(([username, value]) => ({ username, value }));
								}
							});
				} else {
				}
			},
			addEventReLogin(){
				window.addEventListener("storage", (ev) => {
					if (ev.key == "id_token") {
						this.reLogin();
					}
				});
			},
			reLogin(){
				if (!Liferay.ThemeDisplay.isSignedIn() && localStorage.getItem("id_token") && !this.isLoginReload){
					try {
						document.getElementById("login-element").click();
						this.isLoginReload = true;
					} catch (e){
						console.error(e)
					}
				}
			},

			clearStorage() {
				localStorage.clear();
			},

			redirectMailInbox(){
				window.open("https://muasamcong.mpi.gov.vn/web/guest/profile-info?render=personalUrl&menu=mail-inbox","_self");
			},
			loadServerTime(){
				Liferay.Util.fetch('/o/egp-portal-personal-page/services/get-time-now', {
					method: 'POST'
				}).then(data =>{
					return data.json();
				}).then((res) => {
					this.serverTime = res.body;
				});
			},
			loadAuthorizedUrl(){
				Liferay.Util.fetch('/o/egp-portal-home/services/authorize-url', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
					}
				}).then(data => data.json())
						.then((res) => {
							let url = res?.data?.data?.authorizeUrl;
							if(url){
								window.open(url,"_self");
							}
						}).catch(err => {
				});

			},// Hàm được gọi khi tab được đưa vào trạng thái "tạm dừng"
			// onVisibilityChange() {			console.log("tab hidden")
			//
			// 	// Kiểm tra xem tab hiện tại có đang hoạt động hay không
			// 	if (!document.hidden) {
			// 		// Tab hiện tại đang hoạt động
			// 		this.isPaused = false;
			// 	} else {
			// 		// Tab hiện tại không hoạt động
			// 		location.reload();
			//
			// 	}
			// },
			// // Hàm được gọi để chạy lại mã js của tab đồng hồ
			// runAgain() {
			// 	// Tải lại trang js của tab đồng hồ
			// 	location.reload();
			// },
		},
		created() {
			this.loadMenuInfo();
			this.checkPopupTTCQCQ();
			this.loadCatList();
			this.loadCatListClassificationDependents();
			// this.loadRootRoles();
			this.loadUserInfo();
			this.loadUserInfoV2();
			this.loadNotification();
			this.loadServerTime();
			this.isEngLanguage = this.checkEnglishLanguage();
			// this.reLogin();
			this.addEventReLogin();

			setInterval(showLiveTime, 1000);
		}
		// , mounted() {
		// 	// Tạo một trình lắng nghe sự kiện cho sự kiện "tabfocus"
		// 	console.log("tab focus")
		// 	document.addEventListener("visibilitychange", this.onVisibilityChange);
		// },
	})
</script>
</html>

		
	

