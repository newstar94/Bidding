function getCleanPlainData(vueInstance) {
    const raw = vueInstance._data || vueInstance;  // nếu mày lấy từ _data thì sạch hơn, còn không thì lấy cả instance
    const seen = new WeakSet();

    function clean(obj) {
        // Nếu không phải object hoặc null → trả nguyên
        if (obj === null || typeof obj !== 'object') return obj;

        // Xử lý circular
        if (seen.has(obj)) return "[Circular]";
        seen.add(obj);

        // Nếu là array → map recursive
        if (Array.isArray(obj)) {
            return obj.map(clean);
        }

        // Nếu là object → lọc key và value
        const cleaned = {};
        for (const key in obj) {
            if (Object.hasOwnProperty.call(obj, key)) {
                // Bỏ key bắt đầu bằng $ hoặc _
                if (key.startsWith('$') || key.startsWith('_')) continue;

                const value = obj[key];

                // Bỏ nếu value là function
                if (typeof value === 'function') continue;

                // Recursive clean value
                cleaned[key] = clean(value);
            }
        }
        return cleaned;
    }

    return clean(raw);
}

// Dùng luôn đây, mày thay id element nếu khác
const cleanData = getCleanPlainData(
    document.getElementById("search-advantage-haunt").__vue__
);

console.log(cleanData);
// Giờ mày có object thuần, sạch vl: không hàm, không $key, không _key, không circular
// Object.entries(cleanData).forEach(([key, value]) => {
//     console.log(key, value);
// });