let myPayload = 
  {
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
      {
        "index": "es-contractor-selection",
        "matchType": "all-1",
        "matchFields": [
          "notifyNo",
          "bidName"
        ],
        "filters": [
          {
            "fieldName": "publicDate",
            "searchType": "range",
            "from": "2026-01-03T00:00:00.000Z",
            "to": "2026-01-03T23:59:59.059Z"
          },
          {
            "fieldName": "type",
            "searchType": "in",
            "fieldValues": [
              "es-bidp-project-p"
            ]
          },
          {
            "fieldName": "type",
            "searchType": "in",
            "fieldValues": [
              "es-bidp-project-p"
            ]
          }
        ]
      }
    ]
  }


const VueComponent = document.getElementById("search-home").__vue__;
VueComponent.axiosSearch = function(payload) {
	console.dir("Chọc vào thành công");
	grecaptcha.ready(res => {
                    grecaptcha.execute(VueComponent.siteKey,
                        {action: 'submit'}).then(token => {

                        VueComponent.spinningSearch = true;
                        VueComponent.payloadSearch = payload;

                        // console.log("payload : ", VueComponent.formatPayloadSearchWidthNotify(payload))
                        axios.post(
                            VueComponent.elasticSearch+"?token="+token,VueComponent.formatPayloadSearchWidthNotify(payload)
                        ).then(response => {


                            if(typeof response.data == 'number'){
                                VueComponent.popupSpinning()
                            }else{
								console.log("Lấy được dữ liệu")
								console.log(response.data.page.content)
                                VueComponent.listResultSearch = response.data.page.content;
                                VueComponent.page = response.data.page;


                                VueComponent.textSearch = payload.query[0].keyWord;

                                if(VueComponent.activeTab == 'all'){
                                    VueComponent.aggOpen = response.data.agg;
                                    VueComponent.aggClose = response.data.agg;
                                }
                                // if(VueComponent.activeReOffer == 'all'){
                                //     VueComponent.aggOpenReOffer = response.data.agg;
                                // }
                                // if(Liferay.ThemeDisplay.isSignedIn() && VueComponent.checkIsReOfferPrice(payload)){
                                //     VueComponent.addSubmitNt(VueComponent.listResultSearch);
                                // }
                                // if(VueComponent.checkIsReOfferPrice(payload)){
                                //     VueComponent.loadMinPrice(VueComponent.listResultSearch);
                                // }

                                VueComponent.isHideTab = VueComponent.checkIsTbmt(payload);
                                VueComponent.isShowClosedStatus = VueComponent.IsSearchNotify(payload)



                            }
                            VueComponent.spinningSearch = false;

                            }
                        );

                    });
                });
}.bind(VueComponent)

VueComponent.axiosSearch(myPayload)