# Lược đồ quan hệ giữa các đối tượng - Hệ thống Mua sắm công

## 📋 Mục lục
1. [Tổng quan hệ thống](#1-tổng-quan-hệ-thống)
2. [Danh sách đối tượng](#2-danh-sách-đối-tượng)
3. [Lược đồ quan hệ (ERD)](#3-lược-đồ-quan-hệ-erd)
4. [Chi tiết từng đối tượng](#4-chi-tiết-từng-đối-tượng)
5. [Các chủ thể tham gia](#5-các-chủ-thể-tham-gia)
6. [Quy trình nghiệp vụ](#6-quy-trình-nghiệp-vụ)
7. [Mapping API](#7-mapping-api)

---

## 1. Tổng quan hệ thống

Hệ thống Mua sắm công quốc gia (muasamcong.mpi.gov.vn) quản lý toàn bộ quy trình đấu thầu từ lập kế hoạch đến ký hợp đồng. Các đối tượng được tổ chức theo luồng nghiệp vụ chính:

```
┌─────────────┐      ┌─────────────────────┐      ┌─────────────────┐      ┌──────────────┐     ┌─────────────┐
│   DỰ ÁN     │────▶│  KẾ HOẠCH LCNT       │────▶│  THÔNG BÁO MỜI  │────▶│  BIÊN BẢN    │────▶│  KẾT QUẢ    │
│             │      │  (KHLCNT)           │      │  THẦU (TBMT)    │      │  MỞ THẦU     │     │  LCNT       │
└─────────────┘      └─────────────────────┘      └─────────────────┘      └──────────────┘     └─────────────┘
                                                                                                     │
                                                                                                     ▼
                                                                                            ┌─────────────┐
                                                                                            │  HỢP ĐỒNG   │
                                                                                            └─────────────┘
```

---

## 2. Danh sách đối tượng

### 2.1 Đối tượng chính (Entities)

| STT | Đối tượng | Mã Type | Mô tả |
|-----|-----------|---------|-------|
| 1 | Dự án | `es-bidp-project-p` | Dự án đầu tư xây dựng/mua sắm |
| 2 | Kế hoạch LCNT | `es-plan-project-p` | Kế hoạch lựa chọn nhà thầu |
| 3 | Kế hoạch tổng thể LCNT | `es-plan-overall-p` | Kế hoạch tổng thể lựa chọn nhà thầu |
| 4 | Yêu cầu báo giá | `es-ycbg` | Yêu cầu báo giá (chỉ định thầu rút gọn) |
| 5 | Thông báo mời thầu | `es-notify-contractor` | TBMT thông thường |
| 6 | TBMT rút gọn | `es-notify-contractor` (bidForm=CGTTRG) | TBMT theo quy trình rút gọn |
| 7 | TBMT thuốc, dược liệu | `es-notify-contractor` (isMedicine=1) | TBMT thuốc, dược liệu, vị thuốc cổ truyền |
| 8 | Khảo sát quan tâm NT trong nước | `es-bido-interest-notify` | Khảo sát quan tâm nhà thầu |
| 9 | Thông báo mời sơ tuyển | `es-notify-prequalification` | TBMST cho gói thầu lớn/phức tạp |
| 10 | Thông báo mời quan tâm | `es-notify-interest` | TBMQT cho gói thầu đặc thù |
| 11 | Biên bản mở thầu | `es-bid-open` | BBMT - kết quả mở hồ sơ dự thầu |
| 12 | Biên bản mở sơ tuyển | `es-prequalification-open` | BBMST |
| 13 | Biên bản mở quan tâm | `es-interest-open` | BBMQT |
| 14 | Kết quả sơ tuyển | `es-prequalification-result` | KQST |
| 15 | Kết quả mời quan tâm | `es-interest-result` | KQMQT |
| 16 | Kết quả LCNT (không liên kết KHLCNT) | `es-bide-contractor-input-result-other` | KQLCNT độc lập |
| 17 | Kết quả mua sắm trực tuyến | `es-shopping-result` | KQMSTT |
| 18 | Thỏa thuận khung | `es-ct-publish-frame` | TTK - mua sắm tập trung |
| 19 | Hợp đồng | `es-ct-contract` | Thông tin chủ yếu của hợp đồng |

### 2.2 Chủ thể tham gia (Actors)

| STT | Chủ thể | Mã trường | Mô tả |
|-----|---------|-----------|-------|
| 1 | Chủ đầu tư | `investorCode`, `investorName` | Đơn vị sở hữu dự án |
| 2 | Bên mời thầu | `procuringEntityCode`, `procuringEntityName` | Đơn vị tổ chức đấu thầu |
| 3 | Nhà thầu | `orgCode`, `orgFullName` | Đơn vị dự thầu/trúng thầu |
| 4 | Nhà đầu tư | `investorCode` (cho PPP/XHH) | Nhà đầu tư dự án PPP |
| 5 | Tư vấn | - | Đơn vị tư vấn (TV lập HSMT, thẩm tra...) |

### 2.3 Đối tượng phụ (Sub-entities)

| STT | Đối tượng | Thuộc về | Mô tả |
|-----|-----------|----------|-------|
| 1 | Gói thầu | Kế hoạch LCNT | Các gói thầu trong kế hoạch |
| 2 | Lô thầu | Gói thầu | Các lô trong gói thầu (khi isMultiLot=1) |
| 3 | Hồ sơ dự thầu | Thông báo mời thầu | Hồ sơ của nhà thầu tham dự |

---

## 3. Lược đồ quan hệ (ERD)

### 3.1 Entity Relationship Diagram

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    CHỦ THỂ THAM GIA                                                  │
├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                      │
│   ┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐                       │
│   │   CHỦ ĐẦU TƯ    │         │  BÊN MỜI THẦU   │         │    NHÀ THẦU     │                       │
│   │   (Investor)    │         │(ProcuringEntity)│         │  (Contractor)   │                       │
│   ├─────────────────┤         ├─────────────────┤         ├─────────────────┤                       │
│   │ investorCode    │         │ procuringEntity │         │ orgCode         │                       │
│   │ investorName    │         │   Code          │         │ orgFullName     │                       │
│   │                 │         │ procuringEntity │         │ taxCode         │                       │
│   │                 │         │   Name          │         │ businessType    │                       │
│   └────────┬────────┘         └────────┬────────┘         └────────┬────────┘                       │
│            │ 1                         │ 1                         │ N                              │
│            │ sở hữu                    │ tổ chức                   │ trúng thầu                     │
│            ▼ N                         ▼ N                         ▼ N                              │
│                                                                                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    QUY TRÌNH ĐẤU THẦU CHÍNH                                          │
├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                      │
│   ┌─────────────────┐                                                                                │
│   │     DỰ ÁN       │                                                                                │
│   │   (Project)     │                                                                                │
│   ├─────────────────┤                                                                                │
│   │ id (UUID)       │                                                                                │
│   │ pno (PR...)     │───────────────┬───────────────────────────────────────┐                       │
│   │ name            │               │                                       │                       │
│   │ investTotal     │               │ 1                                     │ 1                     │
│   │ investorCode    │               ▼ N                                     ▼ N                     │
│   │ status          │   ┌───────────────────────┐           ┌───────────────────────┐               │
│   └─────────────────┘   │   KẾ HOẠCH LCNT       │           │  KẾ HOẠCH TỔNG THỂ    │               │
│                         │   (Plan)              │           │   LCNT (PlanOverall)  │               │
│                         ├───────────────────────┤           ├───────────────────────┤               │
│                         │ id (UUID)             │           │ id (UUID)             │               │
│                         │ planNo (PL...)        │           │ planNo (PL...)        │               │
│                         │ name                  │           │ name                  │               │
│                         │ projectId (FK)        │           │ projectId             │               │
│                         │ investTotal           │           │ investTotal           │               │
│                         │ bidPackages []        │◀─────┐   │ period                │               │
│                         └───────────┬───────────┘       │   └───────────────────────┘               │
│                                     │ 1                 │                                            │
│                                     │ chứa              │                                            │
│                                     ▼ N                 │                                            │
│                         ┌───────────────────────┐       │                                            │
│                         │     GÓI THẦU          │       │                                            │
│                         │   (BidPackage)        │       │                                            │
│                         ├───────────────────────┤       │                                            │
│                         │ bidNo (BP...)         │───────┘                                            │
│                         │ bidName               │                                                    │
│                         │ bidPrice              │                                                    │
│                         │ bidForm               │                                                    │
│                         │ bidField              │                                                    │
│                         │ isMultiLot            │                                                    │
│                         └───────────┬───────────┘                                                    │
│                                     │ 1 (nếu isMultiLot=1)                                           │
│                                     │ phân chia                                                      │
│                                     ▼ N                                                              │
│                         ┌───────────────────────┐                                                    │
│                         │     LÔ THẦU           │                                                    │
│                         │   (BidLot)            │                                                    │
│                         ├───────────────────────┤                                                    │
│                         │ lotNo                 │                                                    │
│                         │ lotName               │                                                    │
│                         │ lotPrice              │                                                    │
│                         └───────────────────────┘                                                    │
│                                                                                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    THÔNG BÁO VÀ KẾT QUẢ                                              │
├──────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                      │
│   Từ GÓI THẦU (BidPackage) phát sinh các thông báo:                                                  │
│                                                                                                      │
│   ┌───────────────────────────────────────────────────────────────────────────────────────────────┐ │
│   │                           LUỒNG ĐẤU THẦU THÔNG THƯỜNG                                         │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐ │ │
│   │   │ THÔNG BÁO MỜI   │────▶│ BIÊN BẢN MỞ    │────▶│ KẾT QUẢ LCNT   │────▶│   HỢP ĐỒNG      │ │ │
│   │   │   THẦU (TBMT)   │     │   THẦU (BBMT)   │     │                 │     │   (Contract)    │ │ │
│   │   ├─────────────────┤     ├─────────────────┤     ├─────────────────┤     ├─────────────────┤ │ │
│   │   │ notifyNo (IB..) │     │ bidOpenId       │     │ winningCode     │     │ contractCode    │ │ │
│   │   │ bidId (FK)      │     │ notifyId (FK)   │     │ winningName     │     │ (HD...)         │ │ │
│   │   │ bidName         │     │ bidRealityOpen  │     │ bidWinningPrice │     │ contractNo      │ │ │
│   │   │ bidPrice        │     │   Date          │     │                 │     │ contractSign    │ │ │
│   │   │ bidOpenDate     │     │ numBidderJoin   │     │                 │     │   Date          │ │ │
│   │   │ bidCloseDate    │     │                 │     │                 │     │ ctPriceAfter    │ │ │
│   │   └─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘ │ │
│   │          │                                                                                    │ │
│   │          │ stepCode progression:                                                              │ │
│   │          │ notify-contractor-step-1-tbmt → step-2-kqmt → step-3-dsntdkt → step-4-kqlcnt       │ │
│   │                                                                                               │ │
│   └───────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                     │
│   ┌───────────────────────────────────────────────────────────────────────────────────────────────┐ │
│   │                           LUỒNG SƠ TUYỂN                                                      │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐                         │ │
│   │   │ THÔNG BÁO MỜI   │────▶│ BIÊN BẢN MỞ    │────▶│ KẾT QUẢ        │                          │ │
│   │   │ SƠ TUYỂN(TBMST) │     │  SƠ TUYỂN(BBMST)│     │ SƠ TUYỂN(KQST) │                          │ │
│   │   └─────────────────┘     └─────────────────┘     └─────────────────┘                         │ │
│   │                                       │                    │                                  │ │
│   │                                       └────────────────────┼───────▶ TBMT ───▶ ...           │ │
│   │                                                                                               │ │
│   └───────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                     │
│   ┌───────────────────────────────────────────────────────────────────────────────────────────────┐ │
│   │                           LUỒNG QUAN TÂM                                                      │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐                         │ │
│   │   │ THÔNG BÁO MỜI   │────▶│ BIÊN BẢN MỞ    │────▶│ KẾT QUẢ MỜI    │                          │ │
│   │   │ QUAN TÂM(TBMQT) │     │ QUAN TÂM(BBMQT)│     │ QUAN TÂM(KQMQT)│                           │ │
│   │   └─────────────────┘     └─────────────────┘     └─────────────────┘                         │ │
│   │                                       │                    │                                  │ │
│   │                                       └────────────────────┼───────▶ TBMT ───▶ ...           │ │
│   │                                                                                               │ │
│   └───────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                     │
│   ┌───────────────────────────────────────────────────────────────────────────────────────────────┐ │
│   │                           LUỒNG ĐẶC BIỆT                                                      │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐                           ┌─────────────────┐                           │ │
│   │   │ YÊU CẦU BÁO GIÁ │─────────────────────────▶│   HỢP ĐỒNG      │                           │ │
│   │   │     (YCBG)      │  (chỉ định thầu rút gọn)  │                 │                          │ │
│   │   └─────────────────┘                           └─────────────────┘                           │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐                           ┌─────────────────┐                           │ │
│   │   │ KẾT QUẢ LCNT    │─────────────────────────▶│   HỢP ĐỒNG      │                           │ │
│   │   │ (KHÔNG LK KHLCNT)│  (nhập kết quả thủ công) │                 │                           │ │
│   │   └─────────────────┘                           └─────────────────┘                           │ │
│   │                                                                                               │ │
│   │   ┌─────────────────┐                                                                         │ │
│   │   │ THỎA THUẬN KHUNG│  (mua sắm tập trung - nhiều đơn vị sử dụng)                             │ │
│   │   │      (TTK)      │                                                                         │ │
│   │   └─────────────────┘                                                                         │ │
│   │                                                                                               │ │
│   └───────────────────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Mối quan hệ chi tiết

```
┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                    QUAN HỆ GIỮA CÁC ĐỐI TƯỢNG                                          │
├────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                        │
│  1. DỰ ÁN (Project) ──────────────────────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:N ────▶ KẾ HOẠCH LCNT (Plan)                                                              │
│     │               Liên kết: Plan.projectId = Project.id                                              │
│     │               Liên kết: Plan.projectNo = Project.pno                                             │
│     │                                                                                                  │
│     ├──── 1:N ────▶ KẾ HOẠCH TỔNG THỂ LCNT (PlanOverall)                                              │
│     │               Liên kết: PlanOverall.pid = Project.id                                             │
│     │               Liên kết: PlanOverall.pno = Project.pno                                            │
│     │                                                                                                  │
│     └──── 1:1 ────▶ CHỦ ĐẦU TƯ (Investor)                                                             │
│                     Liên kết: Project.investorCode = Investor.code                                     │
│                                                                                                        │
│  2. KẾ HOẠCH LCNT (Plan) ─────────────────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:N ────▶ GÓI THẦU (BidPackage) - trong bidpPlanDetailToProjectList[]                       │
│     │               Liên kết: BidPackage.planNo = Plan.planNo                                          │
│     │                                                                                                  │
│     └──── N:1 ────▶ DỰ ÁN (Project)                                                                   │
│                     Liên kết: Plan.projectId = Project.id                                              │
│                                                                                                        │
│  3. GÓI THẦU (BidPackage) ────────────────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:N ────▶ THÔNG BÁO MỜI THẦU (Notification)                                                 │
│     │               Liên kết: Notification.bidNo = BidPackage.bidNo                                    │
│     │               Liên kết: Notification.bidId = BidPackage.id                                       │
│     │               Liên kết: Notification.planNo = BidPackage.planNo                                  │
│     │                                                                                                  │
│     ├──── 1:N ────▶ LÔ THẦU (BidLot) - khi isMultiLot = 1                                             │
│     │               Gói thầu có thể chia thành nhiều lô                                                │
│     │                                                                                                  │
│     └──── N:1 ────▶ KẾ HOẠCH LCNT (Plan)                                                              │
│                     Liên kết: BidPackage.planNo = Plan.planNo                                          │
│                                                                                                        │
│  4. THÔNG BÁO MỜI THẦU (Notification) ────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:1 ────▶ BIÊN BẢN MỞ THẦU (BidOpen)                                                        │
│     │               Liên kết: BidOpen.notifyId = Notification.id                                       │
│     │               Phát sinh khi stepCode chuyển sang step-2-kqmt                                     │
│     │                                                                                                  │
│     ├──── 1:N ────▶ HỒ SƠ DỰ THẦU (BidSubmission)                                                     │
│     │               Các nhà thầu nộp hồ sơ tham dự                                                     │
│     │               Tracked bởi: numBidderJoin, numBidderTech                                          │
│     │                                                                                                  │
│     ├──── 1:1 ────▶ KẾT QUẢ LCNT (BidResult)                                                          │
│     │               Liên kết qua notifyNo                                                              │
│     │               Phát sinh khi stepCode = step-4-kqlcnt                                             │
│     │                                                                                                  │
│     └──── N:1 ────▶ GÓI THẦU (BidPackage)                                                             │
│                     Liên kết: Notification.bidNo = BidPackage.bidNo                                    │
│                                                                                                        │
│  5. KẾT QUẢ LCNT ─────────────────────────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:N ────▶ NHÀ THẦU TRÚNG (WinningContractor)                                                │
│     │               Liên kết: winningCode[], winningContractorName[]                                   │
│     │                                                                                                  │
│     └──── 1:1 ────▶ HỢP ĐỒNG (Contract)                                                               │
│                     Liên kết: Contract.notifyNo = Notification.notifyNo                                │
│                                                                                                        │
│  6. HỢP ĐỒNG (Contract) ──────────────────────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── N:1 ────▶ THÔNG BÁO MỜI THẦU (Notification)                                                 │
│     │               Liên kết: Contract.notifyNo = Notification.notifyNo                                │
│     │                                                                                                  │
│     ├──── N:N ────▶ NHÀ THẦU (Contractor)                                                             │
│     │               Liên kết: Contract.winningCodes[] contains Contractor.orgCode                      │
│     │                                                                                                  │
│     └──── N:1 ────▶ CHỦ ĐẦU TƯ (Investor)                                                             │
│                     Liên kết: Contract.investorCode = Investor.code                                    │
│                                                                                                        │
│  7. THỎA THUẬN KHUNG (FrameworkAgreement) ────────────────────────────────────────────────────────────│
│     │                                                                                                  │
│     ├──── 1:N ────▶ NHÀ THẦU TRÚNG (WinningContractor) - nhiều nhà thầu trong liên danh              │
│     │               Liên kết: winningCodes contains multiple codes (PC...; vn...; vn...)               │
│     │                                                                                                  │
│     └──── N:1 ────▶ THÔNG BÁO MỜI THẦU (Notification)                                                 │
│                     Liên kết: FrameworkAgreement.notifyNo = Notification.notifyNo                      │
│                                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Chi tiết từng đối tượng

### 4.1 Dự án (Project)
```json
{
  "id": "UUID",
  "pno": "PR2500xxxxx",        // Mã dự án
  "pversion": "00",            // Phiên bản
  "name": "Tên dự án",
  "investorCode": "vnxxxxxxxxxx",
  "investorName": "Tên chủ đầu tư",
  "investTotal": 148152899000,  // Tổng mức đầu tư (VND)
  "investTotalUnit": "VND",
  "pgroup": "NB",               // Nhóm: NC (nhóm C), NB (nhóm B), NA (nhóm A)
  "pperiod": 3,                 // Thời gian thực hiện
  "pperiodUnit": 1,             // 1: năm, 2: tháng, 3: ngày
  "isOda": false,               // Có sử dụng vốn ODA
  "decisionNo": "229",          // Số quyết định phê duyệt
  "decisionDate": "2024-11-21",
  "decisionAgency": "Cơ quan phê duyệt",
  "status": "01",               // 01: đã đăng
  "publicDate": "2025-12-31T16:58:38",
  "locations": [{"provCode": "38", "provName": "Tỉnh Thanh Hóa"}]
}
```

### 4.2 Kế hoạch LCNT (Plan)
```json
{
  "id": "UUID",
  "planNo": "PL2500xxxxx",
  "planVersion": "00",
  "name": "Tên kế hoạch",
  "planType": "TX",             // TX: thường xuyên, DTPT: dự án đầu tư phát triển
  "investTotal": 68166000,
  "investorName": "Tên chủ đầu tư",
  "projectId": "UUID",          // Liên kết dự án (nếu có)
  "projectNo": "PR2500xxxxx",
  "bidPack": 1,                 // Số lượng gói thầu
  "decisionNo": "720/QĐ-xxx",
  "decisionDate": "2025-12-29",
  "publicDate": "2025-12-31",
  "bidpPlanDetailToProjectList": [
    {
      "bidNo": "BP2500912711",
      "bidName": "Tên gói thầu",
      "bidPrice": 68166000,
      "bidForm": "CDTRG",       // Hình thức lựa chọn
      "bidField": "PTV",        // Lĩnh vực
      "bidMode": "1_MTHS",      // Phương thức
      "isMultiLot": 0,          // Có chia lô không
      "processApply": "LDT"     // Quy trình áp dụng
    }
  ]
}
```

### 4.3 Thông báo mời thầu (Notification)
```json
{
  "id": "UUID",
  "notifyNo": "IB2500638660",
  "notifyVersion": "00",
  "bidName": ["Tên gói thầu"],
  "bidNo": "BP2500900370",
  "bidId": "UUID",
  "bidPrice": [546924600],
  "bidForm": "CGTTRG",          // DTRR, CDT, CHCT, CGTTRG...
  "bidMode": "1_MTHS",          // 1_MTHS, 1_2THS, 2THS
  "bidField": "HH",             // HH, XL, TV, PTV
  "investField": ["HH"],
  "processApply": "LDT",        // LDT, ADB, WB, KHAC
  "planNo": "PL2500370498",
  "planType": "TX",
  "investorCode": "vnz000021136",
  "investorName": "Tên chủ đầu tư",
  "bidOpenDate": "2026-01-02T09:00:00",
  "bidCloseDate": "2026-01-05T09:00:00",
  "publicDate": "2025-12-28T22:54:35",
  "status": "01",
  "stepCode": "reoffer-price-step-1",
  "isInternet": 1,              // 1: đấu thầu qua mạng
  "isDomestic": 1,              // 1: trong nước
  "isMultiLot": 0,              // 1: chia lô
  "priceInit": 546924600,       // Giá khởi điểm (CGTTRG)
  "priceStep": 1500000,         // Bước giá (CGTTRG)
  "locations": [{"provCode": "80", "provName": "Tỉnh Tây Ninh"}]
}
```

### 4.4 Hợp đồng (Contract)
```json
{
  "id": "UUID",
  "contractCode": "HD2500229968",
  "contractNo": "12/2025/HD-XD",
  "contractVersion": "00",
  "contractSignDate": "2025-12-28",
  "ctPriceAfter": 24683527858,   // Giá trị hợp đồng sau đàm phán
  "notifyNo": "IB2500568881",
  "bidName": ["Tên gói thầu"],
  "bidForm": "DTRR",
  "bidMode": "1_MTHS",
  "investField": ["XL"],
  "investorCode": "vnz000040031",
  "investorName": "Tên chủ đầu tư",
  "winningCode": ["vn5300240354"],
  "winningContractorName": ["CÔNG TY CỔ PHẦN ABC"],
  "status": "IS_PUBLISH",
  "isDomestic": 1,
  "isInternet": 1
}
```

### 4.5 Nhà thầu (Contractor)
```json
{
  "orgCode": "vn0601293738",
  "orgFullName": "Tên công ty/tổ chức",
  "orgEnName": "English name",
  "businessType": "NON_BUSINESS_UNIT",  // ENTERPRISE, NON_BUSINESS_UNIT...
  "taxCode": "0601293738",
  "idTypes": "TAX_CODE",
  "taxNation": "VN",
  "officePro": "37",               // Mã tỉnh
  "officeDis": "13741",            // Mã quận/huyện
  "officeAdd": "Địa chỉ",
  "repName": "Tên người đại diện",
  "repPosition": "Chức vụ",
  "agencyName": "42",
  "budgetCode": "1159864",
  "isForeignInvestor": false,
  "businesses": [],                // Danh sách ngành nghề
  "roleContractorHis": []          // Lịch sử vai trò
}
```

---

## 5. Các chủ thể tham gia

### 5.1 Chủ đầu tư (Investor)
- **Vai trò**: Đơn vị sở hữu dự án, quyết định đầu tư
- **Trường nhận dạng**: `investorCode`, `investorName`
- **Xuất hiện trong**: Dự án, Kế hoạch LCNT, TBMT, Hợp đồng
- **Ví dụ**: Ban quản lý dự án, Sở/ngành, UBND

### 5.2 Bên mời thầu (Procuring Entity)
- **Vai trò**: Đơn vị tổ chức đấu thầu, có thể khác chủ đầu tư
- **Trường nhận dạng**: `procuringEntityCode`, `procuringEntityName`
- **Xuất hiện trong**: Kế hoạch LCNT, TBMT
- **Ghi chú**: Nếu không có, mặc định = Chủ đầu tư

### 5.3 Nhà thầu (Contractor)
- **Vai trò**: Doanh nghiệp/tổ chức tham dự thầu
- **Trường nhận dạng**: `orgCode`, `orgFullName`, `taxCode`
- **Xuất hiện trong**: Biên bản mở thầu, Kết quả LCNT, Hợp đồng
- **Trạng thái**: Đã đăng ký (status=1), Đang chờ, Bị khóa

### 5.4 Nhà đầu tư (cho dự án PPP/XHH)
- **Vai trò**: Đơn vị đầu tư vào dự án đối tác công-tư
- **Trường nhận dạng**: Giống Chủ đầu tư nhưng trong context khác
- **Xuất hiện trong**: Các dự án thuộc phạm vi "Lựa chọn nhà đầu tư"

### 5.5 Tư vấn (Consultant)
- **Vai trò**: Đơn vị tư vấn (lập HSMT, thẩm tra, giám sát...)
- **Trường nhận dạng**: Thường trong `bidField = "TV"`
- **Quan hệ**: Là một loại nhà thầu cung cấp dịch vụ tư vấn

---

## 6. Quy trình nghiệp vụ

### 6.1 Quy trình đấu thầu thông thường

```
┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│  Lập dự án  │──▶│  Lập KHLCNT │──▶│ Đăng TBMT   │──▶│  Mở thầu    │──▶│ Đánh giá    │
│             │   │             │   │             │   │  (BBMT)     │   │  HSDT       │
└─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘
                                                                               │
       ┌───────────────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│ Công bố     │──▶│ Thương thảo │──▶│  Ký hợp đồng│
│ KQLCNT      │   │  hợp đồng   │   │             │
└─────────────┘   └─────────────┘   └─────────────┘
```

### 6.2 Step Codes theo quy trình

| Step Code | Mô tả | Giai đoạn |
|-----------|-------|-----------|
| `project-step-1` | Dự án đã đăng | Dự án |
| `plan-step-1` | KHLCNT đã đăng | Kế hoạch |
| `plan-overall-step-1` | KH tổng thể đã đăng | Kế hoạch |
| `notify-contractor-step-1-tbmt` | TBMT đã đăng | Mời thầu |
| `reoffer-price-step-1` | Đang chào giá | Rút gọn |
| `notify-contractor-step-2-kqmt` | Đã mở thầu | Mở thầu |
| `notify-contractor-step-3-dsntdkt` | DS nhà thầu đạt KT | Đánh giá |
| `notify-contractor-step-4-kqlcnt` | Đã có KQLCNT | Kết quả |
| `ct-step-1-ttcy` | Hợp đồng đã đăng | Hợp đồng |

### 6.3 Quy trình sơ tuyển

```
TBMST ──▶ BBMST ──▶ KQST ──▶ TBMT (chỉ NT đạt ST) ──▶ BBMT ──▶ KQLCNT ──▶ Hợp đồng
```

### 6.4 Quy trình quan tâm

```
TBMQT ──▶ BBMQT ──▶ KQMQT ──▶ TBMT (chỉ NT quan tâm) ──▶ BBMT ──▶ KQLCNT ──▶ Hợp đồng
```

---

## 7. Mapping API

### 7.1 API Endpoints

| Đối tượng | Detail API Endpoint |
|-----------|---------------------|
| Dự án | `/expose/lcnt/bid-po-bidp-project-view/get-by-id` |
| Kế hoạch LCNT | `/expose/lcnt/bid-po-bidp-plan-project/get-by-id` |
| KH tổng thể | `/expose/lcnt/bid-plan-project-manage-overall/get-by-id` |
| TBMT | `/expose/lcnt/bid-notify-contractor/get-by-id` |
| YCBG | `/expose/lcnt/bid-request-quote/get-by-id` |
| TBMST | `/expose/lcnt/bid-notify-prequalification/get-by-id` |
| TBMQT | `/expose/lcnt/bid-notify-interest/get-by-id` |
| Hợp đồng | `/expose/lcnt/bid-ct-contract/get-by-id` |
| TTK | `/expose/lcnt/bid-ct-publish-frame/get-by-id` |

### 7.2 Các mã định danh

| Prefix | Đối tượng | Ví dụ |
|--------|-----------|-------|
| PR | Dự án | PR2500074001 |
| PL | Kế hoạch | PL2500376493 |
| BP | Gói thầu | BP2500912711 |
| IB | Thông báo mời thầu | IB2500638660 |
| RQ | Yêu cầu báo giá | RQ2500026510 |
| HD | Hợp đồng | HD2500229968 |
| FC | Thỏa thuận khung | FC2500000950 |
| vn | Mã tổ chức (nhà thầu/CĐT) | vn0601293738 |
| vnz | Mã tổ chức (cũ) | vnz000021136 |
| PC | Liên danh | PC2500046439 |

---

## 8. Mô hình dữ liệu Database

### 8.1 Bảng chính

```sql
-- Quan hệ chính
projects (id) ──────────────────┬──▶ plans (project_id)
                                └──▶ plans_overall (project_id)

plans (plan_no) ────────────────────▶ notifications (plan_no)

notifications (notify_no) ──────┬──▶ contracts (notify_no)
                                └──▶ framework_agreements (notify_no)

contractors (code) ─────────────────▶ contracts (winning_codes[])
```

### 8.2 Các khóa ngoại quan trọng

| Bảng nguồn | Trường | Bảng đích | Trường |
|------------|--------|-----------|--------|
| plans | project_id | projects | id |
| plans | project_no | projects | pno |
| notifications | plan_no | plans | plan_no |
| notifications | bid_id | bid_packages | id |
| contracts | notify_no | notifications | notify_no |
| contracts | investor_code | investors | code |
| contracts | winning_codes | contractors | code |

---

## 9. Lưu ý khi crawl

### 9.1 Thứ tự crawl đề xuất

1. **Dự án** (`es-bidp-project-p`) - Độc lập
2. **Kế hoạch LCNT** (`es-plan-project-p`) - Liên kết dự án
3. **Kế hoạch tổng thể** (`es-plan-overall-p`) - Liên kết dự án
4. **TBMT các loại** (`es-notify-contractor`) - Liên kết kế hoạch
5. **Kết quả & Hợp đồng** - Liên kết TBMT
6. **Nhà thầu** - Extract từ kết quả/hợp đồng

### 9.2 Xử lý phiên bản

- Mỗi đối tượng có thể có nhiều phiên bản (`version: 00, 01, 02...`)
- Cần crawl phiên bản mới nhất hoặc tất cả phiên bản
- Unique constraint: `(record_no, version)`

### 9.3 Xử lý trạng thái

| Status | Ý nghĩa |
|--------|---------|
| `01` | Đã đăng tải |
| `OPEN_BID` | Đang mở thầu |
| `IS_PUBLISH` | Đã công bố |
| `DXT` | Đang xét thầu |
| `CANCEL_BID` | Đã hủy |
| `CNTTT` | Có nhà thầu trúng thầu |

---

*Tài liệu được tạo tự động từ dữ liệu crawl thực tế*
*Cập nhật: 2026-01-05*
