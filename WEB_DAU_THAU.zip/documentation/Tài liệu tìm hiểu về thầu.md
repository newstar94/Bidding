# Tài Liệu Hệ Thống Đấu Thầu Quốc Gia

## Mục Lục
1. [Tổng Quan](#1-tổng-quan)
2. [Phân Loại Dự Án](#2-phân-loại-dự-án)
3. [Các Loại Bản Ghi (Record Types)](#3-các-loại-bản-ghi-record-types)
4. [Danh Mục Hệ Thống](#4-danh-mục-hệ-thống)
5. [Cấu Trúc API](#5-cấu-trúc-api)
6. [Cấu Trúc Dữ Liệu](#6-cấu-trúc-dữ-liệu)
7. [Quy Trình Crawl Data](#7-quy-trình-crawl-data)
8. [Schema Database (Supabase)](#8-schema-database-supabase)

---

## 1. Tổng Quan

### 1.1. Giới Thiệu
Hệ thống Mạng Đấu Thầu Quốc Gia (muasamcong.mpi.gov.vn) là nền tảng điện tử do Bộ Tài Chính quản lý, phục vụ công tác đấu thầu mua sắm công trên toàn quốc.

### 1.2. Mục Tiêu Crawl Data
- Thu thập dữ liệu thông tin đấu thầu công khai
- Lưu trữ vào database Supabase để phân tích
- Tự động hóa việc theo dõi cơ hội đấu thầu

### 1.3. Nguồn Dữ Liệu
- **Website**: https://muasamcong.mpi.gov.vn
- **Trang tìm kiếm**: `/web/guest/contractor-selection?render=index`
- **API Search**: `/o/egp-portal-contractor-selection-v2/services/smart-search/search/advance-search`
- **Index Elasticsearch**: `es-contractor-selection`

---

## 2. Phân Loại Dự Án

### 2.1. Lựa Chọn Nhà Thầu (Contractor Selection)
Đây là phần chính của hệ thống, bao gồm các gói thầu mua sắm hàng hóa, xây lắp, tư vấn...

### 2.2. Lựa Chọn Nhà Đầu Tư (Investor Selection)
Gồm 4 loại dự án đầu tư:

| Mã | Tên Tiếng Việt | Tên Tiếng Anh |
|----|---------------|---------------|
| `es-ppp` | Dự án PPP | PPP Project |
| `es-sdd` | Dự án đầu tư có sử dụng đất | Investment project involving land use |
| `es-xhh` | Dự án đầu tư kinh doanh (Dự án chuyên ngành/XHH) | Investment project (specialized and socialized project) |
| `es-nldt` | Dự án ngoài phạm vi điều chỉnh | Projects are not within the scope of regulations |

---

## 3. Các Loại Bản Ghi (Record Types)

### 3.1. Bảng Tổng Hợp 17 Loại Bản Ghi

| STT | Mã Type | Tên Tiếng Việt | Mô Tả |
|-----|---------|----------------|-------|
| 1 | `es-bidp-project-p` | Dự án | Thông tin dự án đầu tư phát triển |
| 2 | `es-plan-project-p` | Kế hoạch lựa chọn nhà thầu | KHLCNT được phê duyệt |
| 3 | `es-plan-overall-p` | Kế hoạch tổng thể lựa chọn nhà thầu | KHLCNT tổng thể cho dự án lớn |
| 4 | `es-ycbg` | Yêu cầu báo giá | Yêu cầu nhà thầu báo giá |
| 5 | `es-notify-contractor` | Thông báo mời thầu (TBMT) | Thông báo mời nhà thầu tham gia |
| 6 | `es-notify-contractor-cgttrg` | TBMT theo quy trình rút gọn | TBMT cho gói thầu giá trị nhỏ |
| 7 | `es-notify-contractor-medicine` | TBMT thuốc, dược liệu | TBMT cho ngành y tế |
| 8 | `es-bido-interest-notify` | Khảo sát quan tâm nhà thầu | Khảo sát sự quan tâm của nhà thầu trong nước |
| 9 | `es-notify-prequalification` | Thông báo mời sơ tuyển (TBMST) | Mời sơ tuyển năng lực |
| 10 | `es-notify-interest` | Thông báo mời quan tâm (TBMQT) | Mời quan tâm dự án |
| 11 | `es-bid-open` | Biên bản mở thầu (BBMT) | Kết quả mở thầu |
| 12 | `es-prequalification-open` | Biên bản mở sơ tuyển (BBMST) | Kết quả mở hồ sơ sơ tuyển |
| 13 | `es-interest-open` | Biên bản mở quan tâm (BBMHSQT) | Kết quả mở hồ sơ quan tâm |
| 14 | `es-prequalification-result` | Kết quả sơ tuyển (KQST) | Danh sách nhà thầu đạt sơ tuyển |
| 15 | `es-interest-result` | Kết quả mời quan tâm (KQMQT) | Kết quả quan tâm |
| 16 | `es-bide-contractor-input-result-other` | Kết quả LCNT (không liên kết KHLCNT) | KQLCNT độc lập |
| 17 | `es-shopping-result` | Kết quả mua sắm trực tuyến | Kết quả e-shopping |
| 18 | `es-ct-publish-frame` | Thỏa thuận khung | Framework agreement |
| 19 | `es-ct-contract` | Hợp đồng | Thông tin hợp đồng đã ký |

### 3.2. Mapping Type và Filter Value

```json
{
    "da": "es-bidp-project-p",
    "khlcnt": "es-plan-project-p", 
    "khlcnt-tt": "es-plan-overall-p",
    "es-ycbg": "es-ycbg",
    "tbmt": "es-notify-contractor",
    "tbmt-cgttrg": "es-notify-contractor (stepCode: reoffer-price)",
    "tbmt-medicine": "es-notify-contractor (isMedicine: 1)",
    "tbmst": "es-notify-prequalification",
    "tbmqt": "es-notify-interest",
    "bbmt": "es-notify-contractor (stepCode: notify-contractor-step-2-kqmt)",
    "bbmst": "es-prequalification-open",
    "bbmhsqt": "es-interest-open",
    "kqst": "es-prequalification-result",
    "kqmqt": "es-interest-result",
    "es-bide-contractor-input-result-other": "es-bide-contractor-input-result-other",
    "es-shopping-result": "es-shopping-result",
    "es-ct-publish-frame": "es-ct-publish-frame",
    "es-ct-contract": "es-ct-contract"
}
```

---

## 4. Danh Mục Hệ Thống

### 4.1. Lĩnh Vực Lựa Chọn Nhà Thầu (investField)

| Mã | Tên Tiếng Việt | Tên Tiếng Anh |
|----|---------------|---------------|
| `HH` | Hàng hóa | Goods |
| `XL` | Xây lắp | Construction |
| `PTV` | Phi tư vấn | Non-consulting |
| `TV` | Tư vấn | Consulting |
| `HON_HOP` | Hỗn hợp | Mixed |

### 4.2. Hình Thức Lựa Chọn Nhà Thầu (bidForm)

| Mã | Tên Tiếng Việt | Mô Tả |
|----|---------------|-------|
| `DTRR` | Đấu thầu rộng rãi | Open bidding - phổ biến nhất |
| `DTHC` | Đấu thầu hạn chế | Limited bidding |
| `CDT` | Chỉ định thầu | Direct contracting |
| `CDTRG` | Chỉ định thầu rút gọn | Shortened direct contracting |
| `CHCT` | Chào hàng cạnh tranh | Competitive bidding |
| `CHCTRG` | Chào hàng cạnh tranh rút gọn | Short competitive bidding |
| `MSTT` | Mua sắm trực tiếp | Direct procurement |
| `CGTT` | Chào giá trực tuyến | Online quotation |
| `CGTTRG` | Chào giá trực tuyến rút gọn | Online bidding simplified |
| `ESHOP` | Mua sắm trực tuyến | Online shopping (e-marketplace) |
| `DPCT` | Đàm phán cạnh tranh | Competitive negotiation |
| `DPG` | Đàm phán giá | Price negotiation |
| `TTH` | Tự thực hiện | Self-implementation |
| `TVCN` | Tư vấn cá nhân | Individual consultant |
| `KHAC` | Khác | Other |

### 4.3. Quy Trình Áp Dụng (processApply)

| Mã | Tên | Mô Tả |
|----|-----|-------|
| `LDT` | Luật Đấu thầu | Áp dụng Luật Đấu thầu Việt Nam |
| `ADB` | ADB (Qua mạng) | Asian Development Bank procedures |
| `WB` | WB (Qua mạng) | World Bank procedures |
| `CPTPP` | CPTPP | Hiệp định CPTPP |
| `EVFTA` | EVFTA/UKVFTA | Hiệp định thương mại EU/UK |
| `KHAC` | Khác | Các quy trình khác |

### 4.4. Phương Thức Lựa Chọn (bidMode)

| Mã | Tên |
|----|-----|
| `1_MTHS` | Một giai đoạn một túi hồ sơ |
| `1_2THS` | Một giai đoạn hai túi hồ sơ |
| `2_1THS` | Hai giai đoạn một túi hồ sơ |
| `2_2THS` | Hai giai đoạn hai túi hồ sơ |

### 4.5. Loại Kế Hoạch (planType)

| Mã | Tên | Mô Tả |
|----|-----|-------|
| `DTPT` | Chi đầu tư phát triển | Investment expenditures |
| `TX` | Chi thường xuyên | Recurrent expenditures |
| `DTMS` | Dự toán mua sắm | Purchasing estimates |
| `KHAC` | Khác | Other |

### 4.6. Loại Hợp Đồng (contractType)

| Mã | Tên |
|----|-----|
| `1` | Trọn gói |
| `11` | Theo đơn giá cố định |
| `12` | Theo đơn giá điều chỉnh |
| `3` | Theo thời gian |
| `13` | Trọn gói + Đơn giá cố định |
| `14` | Trọn gói + Đơn giá điều chỉnh |

---

## 5. Cấu Trúc API

### 5.1. API Search (Danh Sách)

**Endpoint**: `POST /o/egp-portal-contractor-selection-v2/services/smart-search/search/advance-search?token={recaptcha_token}`

**Request Payload**:
```json
{
    "pageSize": 10,
    "pageNumber": "0",
    "query": [
        {
            "index": "es-contractor-selection",
            "matchType": "all-1",
            "matchFields": ["notifyNo", "bidName"],
            "filters": [
                {
                    "fieldName": "publicDate",
                    "searchType": "range",
                    "from": "2026-01-03T00:00:00.000Z",
                    "to": "2026-01-03T23:59:59.059Z"
                },
                {
                    "fieldName": "type",
                    "searchType": "in",
                    "fieldValues": ["es-notify-contractor"]
                }
            ]
        }
    ]
}
```

**Response Structure**:
```json
{
    "page": {
        "content": [...],
        "totalElements": 1234,
        "totalPages": 124,
        "number": 0,
        "size": 10
    },
    "agg": {...}
}
```

### 5.2. API Detail (Chi Tiết)

Mỗi loại bản ghi có endpoint detail riêng:

| Type | Detail API Endpoint |
|------|---------------------|
| `es-bidp-project-p` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-po-bidp-project-view/get-by-id` |
| `es-plan-project-p` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-po-bidp-plan-project/get-by-id` |
| `es-plan-overall-p` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-plan-project-manage-overall/get-by-id` |
| `es-notify-contractor` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-notify-contractor/get-by-id` |
| `es-ycbg` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-request-quote/get-by-id` |
| `es-ct-contract` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-ct-contract/get-by-id` |
| `es-ct-publish-frame` | `/o/egp-portal-contractor-selection-v2/services/expose/lcnt/bid-ct-publish-frame/get-by-id` |

**Request**: `GET {endpoint}?id={record_id}`

### 5.3. Tham Số URL Chi Tiết

Khi navigate đến trang detail, URL có các tham số:
- `type`: Loại bản ghi
- `stepCode`: Bước trong quy trình
- `id`: ID của record
- `notifyId`: ID thông báo mời thầu (nếu có)
- `pno`: Mã dự án
- `planNo`: Mã kế hoạch

---

## 6. Cấu Trúc Dữ Liệu

### 6.1. Dự Án (es-bidp-project-p)

```typescript
interface Project {
    id: string;                    // UUID
    pno: string;                   // Mã dự án (PR2500xxxxx)
    pversion: string;              // Phiên bản (00, 01...)
    pnoStand: string;              // Mã chuẩn (PR2500xxxxx-00)
    name: string;                  // Tên dự án
    investorCode: string;          // Mã chủ đầu tư
    investorName: string;          // Tên chủ đầu tư
    investTotal: number;           // Tổng vốn đầu tư (VND)
    investTotalUnit: string;       // Đơn vị (VND)
    pgroup: string;                // Nhóm dự án (NC, NB...)
    pperiod: number;               // Thời gian thực hiện
    pperiodUnit: number;           // Đơn vị (1: năm, 2: tháng, 3: ngày)
    decisionNo: string;            // Số quyết định phê duyệt
    decisionDate: string;          // Ngày quyết định
    decisionAgency: string;        // Cơ quan quyết định
    decisionFileId: string;        // ID file quyết định
    publicDate: string;            // Ngày đăng tải
    status: string;                // Trạng thái (01: đã đăng)
    type: "es-bidp-project-p";     // Loại bản ghi
    stepCode: string;              // project-step-1
    locations: Location[];         // Địa điểm
}

interface Location {
    provCode: string;              // Mã tỉnh
    provName: string;              // Tên tỉnh
    districtCode: string;          // Mã quận/huyện
    districtName: string;          // Tên quận/huyện
}
```

### 6.2. Kế Hoạch Lựa Chọn Nhà Thầu (es-plan-project-p)

```typescript
interface Plan {
    id: string;
    planNo: string;                // Mã KHLCNT (PL2500xxxxx)
    planVersion: string;
    planNoStand: string;
    name: string;                  // Tên kế hoạch
    planType: string;              // Loại (DTPT, TX...)
    investTotal: number;           // Tổng mức đầu tư
    procuringEntityCode: string;   // Mã bên mời thầu
    procuringEntityName: string;   // Tên bên mời thầu
    decisionDate: string;
    publicDate: string;
    status: string;
    type: "es-plan-project-p";
    bidNamePlanNew: BidPackage[];  // Danh sách gói thầu
    locations: Location[];
    // Liên kết dự án
    pname?: string;
    pid?: string;
    pno?: string;
}

interface BidPackage {
    name: string;                  // Tên gói thầu
    bidPrice?: number;             // Giá gói thầu
    bidField?: string;             // Lĩnh vực
}
```

### 6.3. Thông Báo Mời Thầu (es-notify-contractor)

```typescript
interface Notification {
    id: string;
    notifyId: string;
    notifyNo: string;              // Mã TBMT (IB2500xxxxx)
    notifyVersion: string;
    notifyNoStand: string;
    bidName: string[];             // Tên gói thầu
    bidId: string;                 // ID gói thầu
    bidNo: string;                 // Mã gói thầu (BP2500xxxxx)
    bidPrice: number[];            // Giá gói thầu
    bidForm: string;               // Hình thức (DTRR, CDT...)
    bidMode: string;               // Phương thức (1_MTHS...)
    bidField: string;              // Lĩnh vực
    investField: string[];         // Lĩnh vực đầu tư
    processApply: string;          // Quy trình (LDT, ADB...)
    investorCode: string;
    investorName: string;
    bidOpenDate: string;           // Ngày mở thầu
    bidCloseDate: string;          // Ngày đóng thầu
    publicDate: string;
    originalPublicDate: string;
    status: string;
    statusForNotify: string;
    stepCode: string;              // notify-contractor-step-1-tbmt
    type: "es-notify-contractor";
    isInternet: number;            // 1: qua mạng
    isDomestic: number;            // 1: trong nước
    isMultiLot: number;            // 1: nhiều phần
    isMedicine: number;            // 1: thuốc
    planNo: string;                // Mã KHLCNT liên kết
    planType: string;
    locations: Location[];
    // Số liệu petition/clarify
    numPetition?: number;
    numClarifyReq?: number;
    numBidderTech?: number;
    // Chào giá online
    priceInit?: number;            // Giá khởi điểm
    priceStep?: number;            // Bước giá
}
```

### 6.4. Hợp Đồng (es-ct-contract)

```typescript
interface Contract {
    id: string;
    contractCode: string;          // Mã hợp đồng (HD2500xxxxx)
    contractNo: string;            // Số hợp đồng
    contractVersion: string;
    contractSignDate: string;      // Ngày ký
    ctPriceAfter: number;          // Giá trị hợp đồng
    bidName: string[];
    notifyNo: string;
    bidForm: string;
    bidMode: string;
    investField: string[];
    investorCode: string;
    investorName: string;
    winningCode: string[];         // Mã nhà thầu trúng
    winningContractorName: string[]; // Tên nhà thầu trúng
    publicDate: string;
    status: string;
    type: "es-ct-contract";
    stepCode: string;              // ct-step-1-ttcy
    isDomestic: number;
    isInternet: number;
}
```

---

## 7. Quy Trình Crawl Data

### 7.1. Kiến Trúc Hệ Thống

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────┐
│   Puppeteer     │────>│  muasamcong.mpi  │────>│  Supabase   │
│   (Headless)    │<────│  .gov.vn API     │     │  Database   │
└─────────────────┘     └──────────────────┘     └─────────────┘
        │                        │
        │                        │
        v                        v
  ┌───────────┐          ┌─────────────┐
  │ Intercept │          │  reCAPTCHA  │
  │ Requests  │          │  v3 Token   │
  └───────────┘          └─────────────┘
```

### 7.2. Flow Crawl Data

```
1. Khởi tạo Puppeteer (headless: true, stealth mode)
        │
        v
2. Navigate đến /contractor-selection?render=index
        │
        v
3. Đợi Vue component load (__vue__)
        │
        v
4. Inject code lấy Vue instance
        │
        v
5. Loop theo ngày (from/to trong publicDate)
   │
   ├──> 5.1. Gọi axiosSearch() với payload
   │         │
   │         v
   │    5.2. reCAPTCHA execute (tự động)
   │         │
   │         v
   │    5.3. API Search response
   │         │
   │         v
   │    5.4. Loop pagination (pageNumber: 0 -> totalPages)
   │         │
   │         └──> Delay 10 giây giữa mỗi page
   │
   └──> 5.5. Với mỗi record:
              │
              ├──> Lưu list data vào Supabase
              │
              └──> Gọi Detail API (intercept hoặc navigate)
                    │
                    v
                   Lưu detail data vào Supabase
```

### 7.3. Xử Lý reCAPTCHA

Website sử dụng reCAPTCHA v3 với flow:
1. `grecaptcha.ready()` - Đợi reCAPTCHA sẵn sàng
2. `grecaptcha.execute(siteKey, {action: 'submit'})` - Lấy token
3. Token được gửi kèm query string: `?token={token}`

**Chiến lược**: Sử dụng browser context thực để reCAPTCHA v3 không detect bot.

### 7.4. Request Interception

```javascript
// Enable request interception
await page.setRequestInterception(true);

page.on('request', request => {
    // Log hoặc modify requests
    request.continue();
});

page.on('response', async response => {
    const url = response.url();
    if (url.includes('/advance-search')) {
        const data = await response.json();
        // Process search results
    }
    if (url.includes('/get-by-id')) {
        const data = await response.json();
        // Process detail data
    }
});
```

### 7.5. Chiến Lược Lấy Detail

**Option A: Navigate Detail Page**
- Navigate đến URL detail
- Intercept response từ get-by-id API
- Chậm nhưng chắc chắn có token mới

**Option B: Direct API Call**
- Sử dụng token từ search request
- Gọi trực tiếp detail API
- Nhanh nhưng token có thể expire

**Option C: Hybrid**
- Batch lấy list trước
- Sau đó navigate lấy detail theo schedule riêng

---

## 8. Schema Database (Supabase)

### 8.1. Bảng `projects` (Dự án)

```sql
CREATE TABLE projects (
    id UUID PRIMARY KEY,
    pno VARCHAR(20) UNIQUE,
    pversion VARCHAR(5),
    pno_stand VARCHAR(25),
    name TEXT,
    investor_code VARCHAR(20),
    investor_name TEXT,
    invest_total BIGINT,
    invest_total_unit VARCHAR(10) DEFAULT 'VND',
    pgroup VARCHAR(10),
    pperiod INTEGER,
    pperiod_unit INTEGER,
    decision_no VARCHAR(100),
    decision_date TIMESTAMP,
    decision_agency TEXT,
    decision_file_id UUID,
    public_date TIMESTAMP,
    status VARCHAR(10),
    step_code VARCHAR(50),
    locations JSONB,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_projects_public_date ON projects(public_date);
CREATE INDEX idx_projects_investor_code ON projects(investor_code);
```

### 8.2. Bảng `plans` (Kế hoạch LCNT)

```sql
CREATE TABLE plans (
    id UUID PRIMARY KEY,
    plan_no VARCHAR(20) UNIQUE,
    plan_version VARCHAR(5),
    plan_no_stand VARCHAR(25),
    name TEXT,
    plan_type VARCHAR(10),
    invest_total BIGINT,
    procuring_entity_code VARCHAR(20),
    procuring_entity_name TEXT,
    decision_date TIMESTAMP,
    public_date TIMESTAMP,
    status VARCHAR(10),
    step_code VARCHAR(50),
    -- Liên kết dự án
    project_id UUID REFERENCES projects(id),
    project_no VARCHAR(20),
    locations JSONB,
    bid_packages JSONB,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_plans_public_date ON plans(public_date);
CREATE INDEX idx_plans_project_id ON plans(project_id);
```

### 8.3. Bảng `notifications` (TBMT)

```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY,
    notify_id UUID,
    notify_no VARCHAR(20) UNIQUE,
    notify_version VARCHAR(5),
    notify_no_stand VARCHAR(25),
    bid_name TEXT[],
    bid_id UUID,
    bid_no VARCHAR(20),
    bid_price BIGINT[],
    bid_form VARCHAR(20),
    bid_mode VARCHAR(20),
    bid_field VARCHAR(10),
    invest_field VARCHAR(10)[],
    process_apply VARCHAR(20),
    investor_code VARCHAR(20),
    investor_name TEXT,
    bid_open_date TIMESTAMP,
    bid_close_date TIMESTAMP,
    public_date TIMESTAMP,
    original_public_date TIMESTAMP,
    status VARCHAR(10),
    status_for_notify VARCHAR(50),
    step_code VARCHAR(50),
    is_internet INTEGER,
    is_domestic INTEGER,
    is_multi_lot INTEGER,
    is_medicine INTEGER,
    -- Liên kết
    plan_no VARCHAR(20),
    plan_type VARCHAR(10),
    locations JSONB,
    -- Số liệu
    num_petition INTEGER,
    num_clarify_req INTEGER,
    num_bidder_tech INTEGER,
    -- Chào giá
    price_init BIGINT,
    price_step BIGINT,
    raw_data JSONB,
    detail_data JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_public_date ON notifications(public_date);
CREATE INDEX idx_notifications_bid_close_date ON notifications(bid_close_date);
CREATE INDEX idx_notifications_investor_code ON notifications(investor_code);
CREATE INDEX idx_notifications_bid_form ON notifications(bid_form);
CREATE INDEX idx_notifications_status ON notifications(status);
```

### 8.4. Bảng `contracts` (Hợp đồng)

```sql
CREATE TABLE contracts (
    id UUID PRIMARY KEY,
    contract_code VARCHAR(20) UNIQUE,
    contract_no VARCHAR(100),
    contract_version VARCHAR(5),
    contract_sign_date TIMESTAMP,
    contract_price BIGINT,
    bid_name TEXT[],
    notify_no VARCHAR(20),
    bid_form VARCHAR(20),
    bid_mode VARCHAR(20),
    invest_field VARCHAR(10)[],
    investor_code VARCHAR(20),
    investor_name TEXT,
    winning_codes VARCHAR(50)[],
    winning_names TEXT[],
    public_date TIMESTAMP,
    status VARCHAR(20),
    step_code VARCHAR(50),
    is_domestic INTEGER,
    is_internet INTEGER,
    raw_data JSONB,
    detail_data JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_contracts_public_date ON contracts(public_date);
CREATE INDEX idx_contracts_sign_date ON contracts(contract_sign_date);
CREATE INDEX idx_contracts_investor_code ON contracts(investor_code);
```

### 8.5. Bảng `crawl_logs` (Log crawl)

```sql
CREATE TABLE crawl_logs (
    id SERIAL PRIMARY KEY,
    crawl_date DATE,
    record_type VARCHAR(50),
    total_records INTEGER,
    success_count INTEGER,
    error_count INTEGER,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    duration_seconds INTEGER,
    errors JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_crawl_logs_date ON crawl_logs(crawl_date);
CREATE INDEX idx_crawl_logs_type ON crawl_logs(record_type);
```

### 8.6. Bảng `raw_records` (Dữ liệu thô tất cả types)

```sql
CREATE TABLE raw_records (
    id UUID PRIMARY KEY,
    record_type VARCHAR(50),
    record_no VARCHAR(30),
    public_date TIMESTAMP,
    list_data JSONB,
    detail_data JSONB,
    crawled_at TIMESTAMP DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_raw_records_type ON raw_records(record_type);
CREATE INDEX idx_raw_records_date ON raw_records(public_date);
CREATE INDEX idx_raw_records_processed ON raw_records(processed);
```

---

## Phụ Lục

### A. Danh Sách Tỉnh/Thành Phố (63 tỉnh)

Tham khảo file: `warehouse/catalog_search/catalog_vue_search.json` → `listProvince`

### B. Step Codes

| Loại | Step Code | Mô Tả |
|------|-----------|-------|
| Dự án | `project-step-1` | Dự án đã đăng |
| KHLCNT | `plan-step-1` | KHLCNT đã đăng |
| TBMT | `notify-contractor-step-1-tbmt` | TBMT mới đăng |
| TBMT | `reoffer-price-step-1` | Chào giá online |
| BBMT | `notify-contractor-step-2-kqmt` | Đã mở thầu |
| KQLCNT | `notify-contractor-step-3-dsntdkt` | Có DS nhà thầu đạt KT |
| KQLCNT | `notify-contractor-step-4-kqlcnt` | Có kết quả LCNT |
| Hợp đồng | `ct-step-1-ttcy` | Hợp đồng đã ký |

### C. Tài Liệu Tham Khảo

- Source code Vue component: `code_test/template_vue/`
- Sample data: `warehouse/data_example_by_type/`
- Payload mẫu: `warehouse/code_devtool/code_get_data_on_devtools.js`
