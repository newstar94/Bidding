-- ═══════════════════════════════════════════════════════════════════════════════
-- SCHEMA RIÊNG CHO THÔNG BÁO MỜI THẦU (TBMT)
-- Tiền tố bảng: bidding_
-- Nghiệp vụ: Thông báo mời thầu (es-notify-contractor)
-- API: /services/smart/search (muasamcong.mpi.gov.vn)
-- Date: 2026-02-27
-- ═══════════════════════════════════════════════════════════════════════════════

-- ───────────────────────────────────────────────────────────────────────────────
-- 1. BẢNG CHÍNH: bidding_tbmt
--    Lưu dữ liệu từng thông báo mời thầu
--    Mảng đơn giản (bidName, investField...) lưu dưới dạng JSONB
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bidding_tbmt (
    -- Khóa chính
    id                      UUID            PRIMARY KEY,
    notify_id               UUID,                                       -- notifyId (thường = id)
    bid_id                  UUID,                                       -- bidId (gói thầu)
    input_result_id         UUID,                                       -- inputResultId (KQLCNT)
    bid_open_id             UUID,                                       -- bidOpenId

    -- Mã hiệu
    notify_no               VARCHAR(30),                                -- IB22xxxxx
    notify_version          VARCHAR(5)      DEFAULT '00',               -- 00, 01...
    notify_no_stand         VARCHAR(40),                                -- IB22xxxxx-00
    plan_no                 VARCHAR(30),                                -- PL22xxxxx
    type                    VARCHAR(50)     DEFAULT 'es-notify-contractor',

    -- Tên gói thầu (mảng → JSONB)
    bid_name                JSONB,                                      -- ["Thi công xây dựng..."]

    -- Phân loại
    bid_form                VARCHAR(20),                                -- DTRR, DTQT...
    bid_mode                VARCHAR(20),                                -- 1_MTHS...
    bid_field               VARCHAR(20),                                -- XL, HH, DV...
    invest_field            JSONB,                                      -- ["XL","HH"]
    plan_type               VARCHAR(20),                                -- DTPT, KHAC...
    work_type               VARCHAR(20),                                -- KHAC...
    process_apply           VARCHAR(20),                                -- LDT, QKT...
    step_code               VARCHAR(80),                                -- notify-contractor-step-X-xxx

    -- Chủ đầu tư / Bên mời thầu
    investor_code           VARCHAR(20),
    investor_name           TEXT,
    procuring_entity_code   VARCHAR(20),
    procuring_entity_name   TEXT,
    created_by              VARCHAR(20),

    -- Thời gian
    public_date             TIMESTAMPTZ,                                -- Ngày đăng
    public_date_kqmt        TIMESTAMPTZ,                                -- Ngày đăng KQMT
    public_date_kqlcnt      TIMESTAMPTZ,                                -- Ngày đăng KQLCNT
    bid_open_date           TIMESTAMPTZ,                                -- Ngày mở thầu dự kiến
    bid_reality_open_date   TIMESTAMPTZ,                                -- Ngày mở thầu thực tế
    bid_close_date          TIMESTAMPTZ,                                -- Ngày đóng thầu
    decision_date           TIMESTAMPTZ,                                -- Ngày quyết định KQLCNT

    -- Trạng thái
    status                  VARCHAR(30),                                -- IS_PUBLISH, 03...
    status_for_notify       VARCHAR(30),                                -- DHTBMT, CNTTT...
    is_internet             SMALLINT        DEFAULT 1,
    is_pass                 SMALLINT,
    is_domestic             SMALLINT        DEFAULT 1,

    -- Giá trị gói thầu (mảng → JSONB, đơn vị VNĐ)
    bid_price               JSONB,                                      -- [12981910000]
    bid_winning_price       JSONB,                                      -- [13366124000]

    -- Nhà thầu trúng (mảng → JSONB)
    winning_code            JSONB,                                      -- ["vn5500412547"]
    contractor_name         JSONB,                                      -- ["CÔNG TY TNHH..."]
    winning_contractor_name JSONB,                                      -- same as contractorName khi đã trúng

    -- Số liệu thống kê
    num_petition            INTEGER         DEFAULT 0,
    num_clarify_req         INTEGER         DEFAULT 0,
    num_bidder_tech         INTEGER         DEFAULT 0,
    num_bidder_join         INTEGER         DEFAULT 0,
    num_petition_hsmt       INTEGER         DEFAULT 0,
    num_petition_lcnt       INTEGER         DEFAULT 0,
    num_petition_kqlcnt     INTEGER         DEFAULT 0,
    score                   VARCHAR(20),

    -- Metadata crawl
    crawled_at              TIMESTAMPTZ     DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     DEFAULT NOW()
);

-- Indexes để query nhanh
CREATE INDEX IF NOT EXISTS idx_btbmt_public_date     ON bidding_tbmt (public_date);
CREATE INDEX IF NOT EXISTS idx_btbmt_status          ON bidding_tbmt (status);
CREATE INDEX IF NOT EXISTS idx_btbmt_status_notify   ON bidding_tbmt (status_for_notify);
CREATE INDEX IF NOT EXISTS idx_btbmt_notify_no       ON bidding_tbmt (notify_no);
CREATE INDEX IF NOT EXISTS idx_btbmt_investor_code   ON bidding_tbmt (investor_code);
CREATE INDEX IF NOT EXISTS idx_btbmt_procuring_code  ON bidding_tbmt (procuring_entity_code);
CREATE INDEX IF NOT EXISTS idx_btbmt_bid_form        ON bidding_tbmt (bid_form);
CREATE INDEX IF NOT EXISTS idx_btbmt_bid_field       ON bidding_tbmt (bid_field);
CREATE INDEX IF NOT EXISTS idx_btbmt_plan_type       ON bidding_tbmt (plan_type);
CREATE INDEX IF NOT EXISTS idx_btbmt_crawled_at      ON bidding_tbmt (crawled_at);
CREATE INDEX IF NOT EXISTS idx_btbmt_step_code       ON bidding_tbmt (step_code);
-- GIN index cho JSONB full-text search
CREATE INDEX IF NOT EXISTS idx_btbmt_bid_name_gin    ON bidding_tbmt USING GIN (bid_name);
CREATE INDEX IF NOT EXISTS idx_btbmt_winning_code_gin ON bidding_tbmt USING GIN (winning_code);


-- ───────────────────────────────────────────────────────────────────────────────
-- 2. BẢNG PHỤ: bidding_tbmt_location
--    Lưu địa điểm thực hiện gói thầu (quan hệ 1-N với bidding_tbmt)
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bidding_tbmt_location (
    id              BIGSERIAL       PRIMARY KEY,
    tbmt_id         UUID            NOT NULL REFERENCES bidding_tbmt(id) ON DELETE CASCADE,
    prov_code       VARCHAR(10),
    prov_name       TEXT,
    district_code   VARCHAR(10),
    district_name   TEXT,
    ward_code       VARCHAR(15),
    ward_name       TEXT
);

CREATE INDEX IF NOT EXISTS idx_btbmt_loc_tbmt_id   ON bidding_tbmt_location (tbmt_id);
CREATE INDEX IF NOT EXISTS idx_btbmt_loc_prov_code ON bidding_tbmt_location (prov_code);


-- ───────────────────────────────────────────────────────────────────────────────
-- 3. BẢNG TRẠNG THÁI CRAWL: bidding_crawl_progress
--    Lưu trạng thái vòng lặp crawl để resume khi restart
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bidding_crawl_progress (
    id              SERIAL          PRIMARY KEY,
    job_name        VARCHAR(50)     UNIQUE NOT NULL,    -- tên job, vd: 'tbmt_backward'
    crawl_date    DATE            NOT NULL,           -- ngày đang crawl
    last_page       INTEGER         DEFAULT 0,          -- pageNumber đã crawl xong
    total_pages     INTEGER         DEFAULT 1,
    records_saved   INTEGER         DEFAULT 0,          -- tổng bản ghi đã lưu
    status          VARCHAR(20)     DEFAULT 'running',  -- running | paused | done
    last_run_at     TIMESTAMPTZ     DEFAULT NOW(),
    created_at      TIMESTAMPTZ     DEFAULT NOW()
);

-- Khởi tạo bản ghi job mặc định nếu chưa có
INSERT INTO bidding_crawl_progress (job_name, crawl_date, status)
VALUES ('tbmt_backward', CURRENT_DATE, 'running')
ON CONFLICT (job_name) DO NOTHING;


-- ───────────────────────────────────────────────────────────────────────────────
-- 4. BẢNG LOG CRAWL: bidding_crawl_log
--    Ghi lại lịch sử từng phiên crawl
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bidding_crawl_log (
    id              BIGSERIAL       PRIMARY KEY,
    job_name        VARCHAR(50),
    crawl_date      DATE,
    page_number     INTEGER,
    records_fetched INTEGER         DEFAULT 0,
    records_new     INTEGER         DEFAULT 0,
    records_dup     INTEGER         DEFAULT 0,
    http_status     INTEGER,
    error_msg       TEXT,
    duration_ms     INTEGER,
    created_at      TIMESTAMPTZ     DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bclog_job_name  ON bidding_crawl_log (job_name);
CREATE INDEX IF NOT EXISTS idx_bclog_date      ON bidding_crawl_log (crawl_date);
CREATE INDEX IF NOT EXISTS idx_bclog_created   ON bidding_crawl_log (created_at DESC);


-- ───────────────────────────────────────────────────────────────────────────────
-- 5. VIEW TIỆN ÍCH
-- ───────────────────────────────────────────────────────────────────────────────

-- View kết hợp TBMT + provinces (dùng cho filter theo tỉnh)
CREATE OR REPLACE VIEW bidding_tbmt_with_province AS
SELECT
    t.*,
    -- Ghép danh sách tỉnh thành string để dễ hiển thị
    COALESCE(
        (SELECT STRING_AGG(DISTINCT l.prov_name, ', ')
         FROM bidding_tbmt_location l
         WHERE l.tbmt_id = t.id),
        ''
    ) AS province_names,
    COALESCE(
        (SELECT ARRAY_AGG(DISTINCT l.prov_code)
         FROM bidding_tbmt_location l
         WHERE l.tbmt_id = t.id),
        '{}'::VARCHAR[]
    ) AS province_codes
FROM bidding_tbmt t;


-- View thống kê theo ngày
CREATE OR REPLACE VIEW bidding_tbmt_daily_stats AS
SELECT
    DATE(public_date)           AS pub_date,
    COUNT(*)                    AS total_records,
    COUNT(*) FILTER (WHERE status_for_notify = 'DHTBMT')    AS cnt_dhtbmt,
    COUNT(*) FILTER (WHERE status_for_notify = 'CNTTT')     AS cnt_cnttt,
    COUNT(*) FILTER (WHERE status_for_notify = 'DHTBMT' OR status_for_notify IS NULL) AS cnt_pending,
    SUM((bid_price->0)::BIGINT) FILTER (WHERE bid_price IS NOT NULL AND jsonb_array_length(bid_price) > 0) AS total_bid_price
FROM bidding_tbmt
GROUP BY DATE(public_date)
ORDER BY pub_date DESC;


-- ───────────────────────────────────────────────────────────────────────────────
-- 6. ROW LEVEL SECURITY (RLS) - bật để an toàn, cho phép đọc công khai
-- ───────────────────────────────────────────────────────────────────────────────
ALTER TABLE bidding_tbmt          ENABLE ROW LEVEL SECURITY;
ALTER TABLE bidding_tbmt_location ENABLE ROW LEVEL SECURITY;
ALTER TABLE bidding_crawl_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE bidding_crawl_log     ENABLE ROW LEVEL SECURITY;

-- Policy: cho phép anon đọc tbmt và location
CREATE POLICY "anon_read_tbmt" ON bidding_tbmt
    FOR SELECT TO anon USING (true);

CREATE POLICY "anon_read_tbmt_location" ON bidding_tbmt_location
    FOR SELECT TO anon USING (true);

-- Policy: chỉ service_role mới được ghi
CREATE POLICY "service_write_tbmt" ON bidding_tbmt
    FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "service_write_tbmt_location" ON bidding_tbmt_location
    FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "service_rw_crawl_progress" ON bidding_crawl_progress
    FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "service_rw_crawl_log" ON bidding_crawl_log
    FOR ALL TO service_role USING (true) WITH CHECK (true);

-- anon đọc progress và log (để theo dõi từ giao diện)
CREATE POLICY "anon_read_crawl_progress" ON bidding_crawl_progress
    FOR SELECT TO anon USING (true);

CREATE POLICY "anon_read_crawl_log" ON bidding_crawl_log
    FOR SELECT TO anon USING (true);
