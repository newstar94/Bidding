-- ═══════════════════════════════════════════════════════════════════════════════
-- SUPABASE SCHEMA - HỆ THỐNG CRAWL DATA ĐẤU THẦU QUỐC GIA
-- Database: PostgreSQL (Supabase)
-- Version: 1.0
-- Date: 2026-01-04
-- ═══════════════════════════════════════════════════════════════════════════════

-- ───────────────────────────────────────────────────────────────────────────────
-- 1. BẢNG RAW_RECORDS - Lưu trữ dữ liệu thô tất cả các loại
-- Bảng chính để lưu data crawl, sau đó có thể xử lý ra các bảng cụ thể
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS raw_records (
    id UUID PRIMARY KEY,
    record_type VARCHAR(50) NOT NULL,           -- es-bidp-project-p, es-notify-contractor...
    record_no VARCHAR(30),                       -- Mã bản ghi (IB..., PL..., PR...)
    public_date TIMESTAMP WITH TIME ZONE,        -- Ngày đăng tải
    list_data JSONB,                             -- Data từ search API
    detail_data JSONB,                           -- Data từ detail API
    crawled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE,             -- Đã xử lý sang bảng cụ thể chưa
    
    CONSTRAINT unique_raw_record UNIQUE (id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_raw_records_type ON raw_records(record_type);
CREATE INDEX IF NOT EXISTS idx_raw_records_date ON raw_records(public_date);
CREATE INDEX IF NOT EXISTS idx_raw_records_processed ON raw_records(processed);
CREATE INDEX IF NOT EXISTS idx_raw_records_record_no ON raw_records(record_no);

-- ───────────────────────────────────────────────────────────────────────────────
-- 2. BẢNG PROJECTS - Dự án đầu tư
-- Type: es-bidp-project-p
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY,
    pno VARCHAR(20),                             -- Mã dự án (PR2500xxxxx)
    pversion VARCHAR(5),                         -- Phiên bản (00, 01...)
    pno_stand VARCHAR(25),                       -- Mã chuẩn (PR2500xxxxx-00)
    name TEXT,                                   -- Tên dự án
    
    -- Chủ đầu tư
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    -- Thông tin tài chính
    invest_total BIGINT,                         -- Tổng vốn đầu tư (VND)
    invest_total_unit VARCHAR(10) DEFAULT 'VND',
    invest_total_ex BIGINT,                      -- Vốn ngoại tệ (nếu có)
    
    -- Thông tin dự án
    pgroup VARCHAR(10),                          -- Nhóm dự án (NC, NB, NA...)
    pperiod INTEGER,                             -- Thời gian thực hiện
    pperiod_unit INTEGER,                        -- Đơn vị (1: năm, 2: tháng, 3: ngày)
    pform VARCHAR(20),                           -- Hình thức quản lý dự án
    is_oda BOOLEAN DEFAULT FALSE,                -- Có sử dụng vốn ODA
    invest_target TEXT,                          -- Mục tiêu đầu tư
    invest_scale TEXT,                           -- Quy mô đầu tư
    competent_persons TEXT,                      -- Người có thẩm quyền (JSON string)
    
    -- Quyết định phê duyệt
    decision_no VARCHAR(100),
    decision_date TIMESTAMP WITH TIME ZONE,
    decision_agency TEXT,
    decision_file_id UUID,
    decision_file_name TEXT,
    
    -- Địa điểm
    locations JSONB,                             -- [{provCode, provName, districtCode, districtName}]
    
    -- Meta
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(10),                          -- 01: đã đăng
    step_code VARCHAR(50),
    
    -- Raw data backup
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_project_pno_version UNIQUE (pno, pversion)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_projects_public_date ON projects(public_date);
CREATE INDEX IF NOT EXISTS idx_projects_investor_code ON projects(investor_code);
CREATE INDEX IF NOT EXISTS idx_projects_pno ON projects(pno);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);

-- ───────────────────────────────────────────────────────────────────────────────
-- 3. BẢNG PLANS - Kế hoạch lựa chọn nhà thầu
-- Type: es-plan-project-p
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plans (
    id UUID PRIMARY KEY,
    plan_no VARCHAR(20),                         -- Mã KHLCNT (PL2500xxxxx)
    plan_version VARCHAR(5),
    plan_no_stand VARCHAR(25),
    name TEXT,                                   -- Tên kế hoạch
    plan_type VARCHAR(10),                       -- DTPT, TX, DTMS, KHAC
    
    -- Tài chính
    invest_total BIGINT,
    invest_total_unit VARCHAR(10) DEFAULT 'VND',
    
    -- Bên mời thầu
    procuring_entity_code VARCHAR(20),
    procuring_entity_name TEXT,
    
    -- Quyết định
    decision_no VARCHAR(100),
    decision_date TIMESTAMP WITH TIME ZONE,
    decision_agency TEXT,
    decision_file_id UUID,
    decision_file_name TEXT,
    
    -- Liên kết dự án
    project_id UUID REFERENCES projects(id),
    project_name TEXT,
    project_no VARCHAR(20),
    
    -- Địa điểm
    locations JSONB,
    
    -- Danh sách gói thầu trong kế hoạch
    bid_packages JSONB,                          -- [{name, bidPrice, bidField, bidForm...}]
    bid_pack_count INTEGER,                      -- Số lượng gói thầu
    
    -- Meta
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(10),
    step_code VARCHAR(50),
    approval_status VARCHAR(10),
    
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_plan_no_version UNIQUE (plan_no, plan_version)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_plans_public_date ON plans(public_date);
CREATE INDEX IF NOT EXISTS idx_plans_project_id ON plans(project_id);
CREATE INDEX IF NOT EXISTS idx_plans_plan_no ON plans(plan_no);
CREATE INDEX IF NOT EXISTS idx_plans_plan_type ON plans(plan_type);

-- ───────────────────────────────────────────────────────────────────────────────
-- 4. BẢNG PLANS_OVERALL - Kế hoạch tổng thể LCNT
-- Type: es-plan-overall-p
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plans_overall (
    id UUID PRIMARY KEY,
    plan_no VARCHAR(20),
    plan_version VARCHAR(5),
    name TEXT,
    plan_type VARCHAR(10),
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    invest_total BIGINT,
    invest_total_unit VARCHAR(10) DEFAULT 'VND',
    
    period INTEGER,
    period_unit INTEGER,
    
    decision_no VARCHAR(100),
    decision_date TIMESTAMP WITH TIME ZONE,
    decision_agency TEXT,
    decision_file_id UUID,
    decision_file_name TEXT,
    
    -- Liên kết dự án
    project_id UUID,
    project_name TEXT,
    project_no VARCHAR(20),
    
    is_oda BOOLEAN DEFAULT FALSE,
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(10),
    
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 5. BẢNG NOTIFICATIONS - Thông báo mời thầu
-- Type: es-notify-contractor (bao gồm TBMT, BBMT, KQLCNT theo stepCode)
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY,
    notify_id UUID,
    notify_no VARCHAR(20),                       -- Mã TBMT (IB2500xxxxx)
    notify_version VARCHAR(5),
    notify_no_stand VARCHAR(25),
    
    -- Thông tin gói thầu
    bid_name TEXT[],                             -- Tên gói thầu (có thể nhiều)
    bid_id UUID,
    bid_no VARCHAR(20),                          -- Mã gói thầu (BP2500xxxxx)
    bid_price BIGINT[],                          -- Giá gói thầu
    bid_form VARCHAR(20),                        -- Hình thức (DTRR, CDT, CHCT...)
    bid_mode VARCHAR(20),                        -- Phương thức (1_MTHS, 1_2THS...)
    bid_field VARCHAR(10),                       -- Lĩnh vực chính
    invest_field VARCHAR(10)[],                  -- Lĩnh vực (HH, XL, TV, PTV)
    process_apply VARCHAR(20),                   -- Quy trình (LDT, ADB, WB...)
    
    -- Chủ đầu tư
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    -- Thời gian
    bid_open_date TIMESTAMP WITH TIME ZONE,      -- Ngày mở thầu
    bid_close_date TIMESTAMP WITH TIME ZONE,     -- Ngày đóng thầu
    public_date TIMESTAMP WITH TIME ZONE,        -- Ngày đăng tải
    original_public_date TIMESTAMP WITH TIME ZONE,
    
    -- Trạng thái
    status VARCHAR(10),
    status_for_notify VARCHAR(50),
    step_code VARCHAR(50),                       -- notify-contractor-step-1-tbmt, step-2-kqmt...
    
    -- Flags
    is_internet INTEGER,                         -- 1: đấu thầu qua mạng
    is_domestic INTEGER,                         -- 1: trong nước
    is_multi_lot INTEGER,                        -- 1: nhiều phần/lô
    is_medicine INTEGER,                         -- 1: thuốc/dược liệu
    
    -- Liên kết
    plan_no VARCHAR(20),
    plan_type VARCHAR(10),
    
    -- Địa điểm
    locations JSONB,
    
    -- Số liệu (petition, clarify)
    num_petition INTEGER DEFAULT 0,
    num_petition_hsmt INTEGER DEFAULT 0,
    num_petition_lcnt INTEGER DEFAULT 0,
    num_petition_kqlcnt INTEGER DEFAULT 0,
    num_clarify_req INTEGER DEFAULT 0,
    num_bidder_tech INTEGER DEFAULT 0,
    num_bidder_join INTEGER DEFAULT 0,
    
    -- Chào giá online (cho CGTTRG)
    price_init BIGINT,                           -- Giá khởi điểm
    price_step BIGINT,                           -- Bước giá
    
    -- Data chi tiết từ detail API
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_notify_no_version UNIQUE (notify_no, notify_version)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_notifications_public_date ON notifications(public_date);
CREATE INDEX IF NOT EXISTS idx_notifications_bid_close_date ON notifications(bid_close_date);
CREATE INDEX IF NOT EXISTS idx_notifications_investor_code ON notifications(investor_code);
CREATE INDEX IF NOT EXISTS idx_notifications_bid_form ON notifications(bid_form);
CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status);
CREATE INDEX IF NOT EXISTS idx_notifications_step_code ON notifications(step_code);
CREATE INDEX IF NOT EXISTS idx_notifications_notify_no ON notifications(notify_no);
CREATE INDEX IF NOT EXISTS idx_notifications_plan_no ON notifications(plan_no);

-- Full-text search index on bid_name
CREATE INDEX IF NOT EXISTS idx_notifications_bid_name_gin ON notifications USING GIN (bid_name);

-- ───────────────────────────────────────────────────────────────────────────────
-- 6. BẢNG CONTRACTS - Hợp đồng
-- Type: es-ct-contract
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contracts (
    id UUID PRIMARY KEY,
    contract_code VARCHAR(20),                   -- Mã hợp đồng (HD2500xxxxx)
    contract_no VARCHAR(100),                    -- Số hợp đồng
    contract_version VARCHAR(5),
    contract_sign_date TIMESTAMP WITH TIME ZONE, -- Ngày ký
    contract_price BIGINT,                       -- Giá trị hợp đồng
    
    bid_name TEXT[],
    notify_no VARCHAR(20),
    bid_form VARCHAR(20),
    bid_mode VARCHAR(20),
    invest_field VARCHAR(10)[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    -- Nhà thầu trúng
    winning_codes VARCHAR(50)[],                 -- Mã nhà thầu trúng
    winning_names TEXT[],                        -- Tên nhà thầu trúng
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20),
    step_code VARCHAR(50),
    is_domestic INTEGER,
    is_internet INTEGER,
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT unique_contract_code_version UNIQUE (contract_code, contract_version)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_contracts_public_date ON contracts(public_date);
CREATE INDEX IF NOT EXISTS idx_contracts_sign_date ON contracts(contract_sign_date);
CREATE INDEX IF NOT EXISTS idx_contracts_investor_code ON contracts(investor_code);
CREATE INDEX IF NOT EXISTS idx_contracts_notify_no ON contracts(notify_no);
CREATE INDEX IF NOT EXISTS idx_contracts_winning_codes ON contracts USING GIN (winning_codes);

-- ───────────────────────────────────────────────────────────────────────────────
-- 7. BẢNG FRAMEWORK_AGREEMENTS - Thỏa thuận khung
-- Type: es-ct-publish-frame
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS framework_agreements (
    id UUID PRIMARY KEY,
    contract_code VARCHAR(20),
    contract_no VARCHAR(100),
    contract_version VARCHAR(5),
    contract_sign_date TIMESTAMP WITH TIME ZONE,
    
    bid_name TEXT[],
    notify_no VARCHAR(20),
    bid_form VARCHAR(20),
    bid_mode VARCHAR(20),
    invest_field VARCHAR(10)[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    winning_codes VARCHAR(50)[],
    winning_names TEXT[],
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20),
    step_code VARCHAR(50),
    is_domestic INTEGER,
    is_internet INTEGER,
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 8. BẢNG REQUEST_QUOTES - Yêu cầu báo giá
-- Type: es-ycbg
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS request_quotes (
    id UUID PRIMARY KEY,
    notify_no VARCHAR(20),                       -- Mã YCBG (RQ2500xxxxx)
    notify_version VARCHAR(5),
    name TEXT,
    
    bid_name TEXT[],
    bid_open_date TIMESTAMP WITH TIME ZONE,
    bid_close_date TIMESTAMP WITH TIME ZONE,
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    decision_date TIMESTAMP WITH TIME ZONE,
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(10),
    step_code VARCHAR(50),
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 9. BẢNG PREQUALIFICATIONS - Thông báo mời sơ tuyển
-- Type: es-notify-prequalification
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS prequalifications (
    id UUID PRIMARY KEY,
    notify_no VARCHAR(20),
    notify_version VARCHAR(5),
    bid_name TEXT[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    bid_open_date TIMESTAMP WITH TIME ZONE,
    bid_close_date TIMESTAMP WITH TIME ZONE,
    public_date TIMESTAMP WITH TIME ZONE,
    
    status VARCHAR(10),
    step_code VARCHAR(50),
    
    locations JSONB,
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 10. BẢNG INTERESTS - Thông báo mời quan tâm
-- Type: es-notify-interest
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS interests (
    id UUID PRIMARY KEY,
    notify_no VARCHAR(20),
    notify_version VARCHAR(5),
    bid_name TEXT[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    bid_open_date TIMESTAMP WITH TIME ZONE,
    bid_close_date TIMESTAMP WITH TIME ZONE,
    public_date TIMESTAMP WITH TIME ZONE,
    
    status VARCHAR(10),
    step_code VARCHAR(50),
    
    locations JSONB,
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 11. BẢNG CRAWL_LOGS - Log quá trình crawl
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS crawl_logs (
    id SERIAL PRIMARY KEY,
    crawl_date DATE NOT NULL,
    record_type VARCHAR(50) NOT NULL,
    total_records INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    error_count INTEGER DEFAULT 0,
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    errors JSONB,                                -- [{message, recordId, timestamp}]
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_crawl_logs_date ON crawl_logs(crawl_date);
CREATE INDEX IF NOT EXISTS idx_crawl_logs_type ON crawl_logs(record_type);

-- ───────────────────────────────────────────────────────────────────────────────
-- 12. BẢNG INVESTORS - Danh sách chủ đầu tư (denormalized)
-- Lưu thông tin chủ đầu tư unique để dễ tra cứu
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS investors (
    code VARCHAR(20) PRIMARY KEY,
    name TEXT,
    first_seen_date TIMESTAMP WITH TIME ZONE,
    last_seen_date TIMESTAMP WITH TIME ZONE,
    total_projects INTEGER DEFAULT 0,
    total_plans INTEGER DEFAULT 0,
    total_notifications INTEGER DEFAULT 0,
    total_contracts INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 13. BẢNG CONTRACTORS - Danh sách nhà thầu
-- Lưu thông tin nhà thầu từ các hợp đồng và từ API approved_contractors
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contractors (
    org_code VARCHAR(50) PRIMARY KEY,            -- Mã nhà thầu (vn0601293738)
    org_full_name TEXT,                          -- Tên đầy đủ
    org_en_name TEXT,                            -- Tên tiếng Anh (nếu có)
    business_type VARCHAR(50),                   -- Loại hình: ENTERPRISE, NON_BUSINESS_UNIT...
    tax_code VARCHAR(20),                        -- Mã số thuế
    id_types VARCHAR(20),                        -- Loại ID: TAX_CODE, CCCD...
    tax_nation VARCHAR(10) DEFAULT 'VN',         -- Quốc gia thuế
    tax_date TIMESTAMP WITH TIME ZONE,           -- Ngày cấp
    
    -- Thông tin văn phòng
    office_prov VARCHAR(10),                     -- Mã tỉnh
    office_dis VARCHAR(10),                      -- Mã quận/huyện
    office_war VARCHAR(10),                      -- Mã phường/xã
    office_add TEXT,                             -- Địa chỉ chi tiết
    office_phone VARCHAR(20),
    office_web TEXT,
    office_zipcode VARCHAR(10),
    
    -- Người đại diện
    rep_name TEXT,                               -- Tên người đại diện
    rep_position TEXT,                           -- Chức vụ
    
    -- Thông tin khác
    agency_name VARCHAR(50),
    budget_code VARCHAR(50),
    is_foreign_investor BOOLEAN DEFAULT FALSE,
    
    -- Danh sách ngành nghề kinh doanh (JSON)
    businesses JSONB,
    
    -- Lịch sử vai trò nhà thầu (JSON)
    role_contractor_his JSONB,
    
    -- Trạng thái
    status INTEGER DEFAULT 1,                    -- 1: active, 0: inactive
    eff_role_date TIMESTAMP WITH TIME ZONE,      -- Ngày hiệu lực vai trò
    start_pending_date TIMESTAMP WITH TIME ZONE,
    lock_role_date TIMESTAMP WITH TIME ZONE,
    parent_name VARCHAR(10),                     -- NT: Nhà thầu
    
    -- Thống kê
    total_contracts INTEGER DEFAULT 0,
    total_contract_value BIGINT DEFAULT 0,
    first_seen_date TIMESTAMP WITH TIME ZONE,
    last_seen_date TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho contractors
CREATE INDEX IF NOT EXISTS idx_contractors_tax_code ON contractors(tax_code);
CREATE INDEX IF NOT EXISTS idx_contractors_status ON contractors(status);
CREATE INDEX IF NOT EXISTS idx_contractors_office_prov ON contractors(office_prov);
CREATE INDEX IF NOT EXISTS idx_contractors_business_type ON contractors(business_type);

-- ───────────────────────────────────────────────────────────────────────────────
-- 14. BẢNG BID_PACKAGES - Gói thầu
-- Thông tin chi tiết các gói thầu trong kế hoạch
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bid_packages (
    id UUID PRIMARY KEY,
    bid_no VARCHAR(20),                          -- Mã gói thầu (BP2500xxxxx)
    bid_name TEXT,                               -- Tên gói thầu
    
    -- Liên kết kế hoạch
    plan_id UUID REFERENCES plans(id),
    plan_no VARCHAR(20),
    
    -- Thông tin gói thầu
    bid_price BIGINT,                            -- Giá gói thầu
    bid_price_unit VARCHAR(10) DEFAULT 'VND',
    bid_estimate_price BIGINT,                   -- Giá dự toán
    bid_form VARCHAR(20),                        -- Hình thức: DTRR, CDT, CHCT, CGTTRG
    bid_field VARCHAR(10),                       -- Lĩnh vực: HH, XL, TV, PTV
    bid_mode VARCHAR(20),                        -- Phương thức: 1_MTHS, 1_2THS, 2THS
    process_apply VARCHAR(20),                   -- Quy trình: LDT, ADB, WB, KHAC
    ctype VARCHAR(10),                           -- TG: tự thực hiện, khác...
    
    -- Thời gian
    bid_time VARCHAR(50),                        -- Thời gian thực hiện: "15 ngày"
    bid_start_year INTEGER,
    bid_start_month INTEGER,
    bid_start_quarter VARCHAR(5),
    bid_start_unit VARCHAR(5),                   -- M: tháng, Q: quý
    
    -- Thời gian hợp đồng
    cperiod INTEGER,                             -- Thời gian hợp đồng
    cperiod_unit VARCHAR(5),                     -- M: tháng, D: ngày
    
    -- Flags
    is_internet INTEGER DEFAULT 1,               -- 1: đấu thầu qua mạng
    is_domestic INTEGER DEFAULT 1,               -- 1: trong nước
    is_multi_lot INTEGER DEFAULT 0,              -- 1: có chia lô
    is_prequalification INTEGER DEFAULT 0,       -- 1: có sơ tuyển
    is_concentrate_shopping INTEGER DEFAULT 0,   -- 1: mua sắm tập trung
    
    -- Thông tin bổ sung
    capital_detail TEXT,                         -- Nguồn vốn: "Ngân sách nhà nước"
    general_tasks TEXT,                          -- Nhiệm vụ tổng quát
    supervisor TEXT,                             -- Giám sát
    additional_choice TEXT,
    additional_choice_value TEXT,
    
    -- Chủ đầu tư
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    -- Bên mời thầu
    procuring_entity_code VARCHAR(20),
    procuring_entity_name TEXT,
    
    -- Meta
    status VARCHAR(10),
    created_by VARCHAR(20),
    created_date TIMESTAMP WITH TIME ZONE,
    
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho bid_packages
CREATE INDEX IF NOT EXISTS idx_bid_packages_plan_no ON bid_packages(plan_no);
CREATE INDEX IF NOT EXISTS idx_bid_packages_bid_no ON bid_packages(bid_no);
CREATE INDEX IF NOT EXISTS idx_bid_packages_bid_field ON bid_packages(bid_field);
CREATE INDEX IF NOT EXISTS idx_bid_packages_bid_form ON bid_packages(bid_form);

-- ───────────────────────────────────────────────────────────────────────────────
-- 15. BẢNG BID_LOTS - Lô thầu (trong gói thầu phân lô)
-- Khi gói thầu có isMultiLot = 1
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bid_lots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lot_no VARCHAR(20),                          -- Số lô
    lot_name TEXT,                               -- Tên lô
    lot_price BIGINT,                            -- Giá trị lô
    lot_price_unit VARCHAR(10) DEFAULT 'VND',
    
    -- Liên kết gói thầu
    bid_package_id UUID REFERENCES bid_packages(id),
    bid_no VARCHAR(20),
    
    -- Thông tin lô
    lot_field VARCHAR(10),                       -- Lĩnh vực của lô
    lot_description TEXT,
    
    -- Meta
    status VARCHAR(10),
    
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho bid_lots
CREATE INDEX IF NOT EXISTS idx_bid_lots_bid_package_id ON bid_lots(bid_package_id);
CREATE INDEX IF NOT EXISTS idx_bid_lots_bid_no ON bid_lots(bid_no);

-- ───────────────────────────────────────────────────────────────────────────────
-- 16. BẢNG BID_OPENS - Biên bản mở thầu
-- Thông tin chi tiết về buổi mở thầu
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bid_opens (
    id UUID PRIMARY KEY,
    bid_open_id UUID,                            -- ID biên bản mở thầu
    notify_id UUID REFERENCES notifications(id),
    notify_no VARCHAR(20),
    
    -- Thời gian
    bid_reality_open_date TIMESTAMP WITH TIME ZONE,  -- Thời gian thực tế mở thầu
    
    -- Số liệu
    num_bidder_join INTEGER DEFAULT 0,           -- Số nhà thầu tham gia
    num_bidder_tech INTEGER DEFAULT 0,           -- Số nhà thầu đạt kỹ thuật
    num_petition INTEGER DEFAULT 0,              -- Số kiến nghị
    num_clarify_req INTEGER DEFAULT 0,           -- Số yêu cầu làm rõ
    
    -- Danh sách nhà thầu tham dự (JSON)
    bidders JSONB,
    
    -- Meta
    status VARCHAR(20),
    step_code VARCHAR(50),
    public_date TIMESTAMP WITH TIME ZONE,
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho bid_opens
CREATE INDEX IF NOT EXISTS idx_bid_opens_notify_id ON bid_opens(notify_id);
CREATE INDEX IF NOT EXISTS idx_bid_opens_notify_no ON bid_opens(notify_no);
CREATE INDEX IF NOT EXISTS idx_bid_opens_public_date ON bid_opens(public_date);

-- ───────────────────────────────────────────────────────────────────────────────
-- 17. BẢNG BID_RESULTS - Kết quả lựa chọn nhà thầu
-- Lưu kết quả đấu thầu
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bid_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notify_id UUID REFERENCES notifications(id),
    notify_no VARCHAR(20),
    
    -- Quyết định phê duyệt
    approval_date TIMESTAMP WITH TIME ZONE,
    decision_date TIMESTAMP WITH TIME ZONE,
    decision_no VARCHAR(100),
    
    -- Nhà thầu trúng
    winning_codes VARCHAR(50)[],                 -- Mã nhà thầu trúng
    winning_names TEXT[],                        -- Tên nhà thầu trúng
    bid_winning_price BIGINT[],                  -- Giá trúng thầu
    
    -- Trạng thái
    status VARCHAR(20),
    status_for_notify VARCHAR(50),               -- CNTTT: có nhà thầu trúng thầu
    step_code VARCHAR(50),
    
    -- Meta
    public_date TIMESTAMP WITH TIME ZONE,
    is_domestic INTEGER,
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho bid_results
CREATE INDEX IF NOT EXISTS idx_bid_results_notify_id ON bid_results(notify_id);
CREATE INDEX IF NOT EXISTS idx_bid_results_notify_no ON bid_results(notify_no);
CREATE INDEX IF NOT EXISTS idx_bid_results_winning_codes ON bid_results USING GIN (winning_codes);

-- ───────────────────────────────────────────────────────────────────────────────
-- 18. BẢNG PREQUALIFICATION_RESULTS - Kết quả sơ tuyển
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS prequalification_results (
    id UUID PRIMARY KEY,
    bid_pre_notify_result_id UUID,
    notify_id UUID,
    notify_no VARCHAR(20),
    
    bid_name TEXT[],
    invest_field VARCHAR(10)[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    procuring_entity_code VARCHAR(20),
    procuring_entity_name TEXT,
    
    bid_open_date TIMESTAMP WITH TIME ZONE,
    bid_close_date TIMESTAMP WITH TIME ZONE,
    public_date TIMESTAMP WITH TIME ZONE,
    public_date_kqst TIMESTAMP WITH TIME ZONE,
    
    decision_date TIMESTAMP WITH TIME ZONE,
    is_pass INTEGER,                             -- 1: đạt
    
    locations JSONB,
    status VARCHAR(20),
    step_code VARCHAR(50),
    plan_type VARCHAR(10),
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 19. BẢNG INTEREST_RESULTS - Kết quả mời quan tâm
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS interest_results (
    id UUID PRIMARY KEY,
    notify_id UUID,
    notify_no VARCHAR(20),
    
    bid_name TEXT[],
    invest_field VARCHAR(10)[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    bid_open_date TIMESTAMP WITH TIME ZONE,
    bid_close_date TIMESTAMP WITH TIME ZONE,
    public_date TIMESTAMP WITH TIME ZONE,
    public_date_kqmqt TIMESTAMP WITH TIME ZONE,
    
    locations JSONB,
    status VARCHAR(20),
    step_code VARCHAR(50),
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 20. BẢNG INTEREST_SURVEYS - Khảo sát quan tâm nhà thầu trong nước
-- Type: es-bido-interest-notify
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS interest_surveys (
    id UUID PRIMARY KEY,
    notify_no VARCHAR(20),
    notify_version VARCHAR(5),
    name TEXT,
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(10),
    step_code VARCHAR(50),
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 21. BẢNG STANDALONE_RESULTS - Kết quả LCNT không liên kết KHLCNT
-- Type: es-bide-contractor-input-result-other
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS standalone_results (
    id UUID PRIMARY KEY,
    input_result_id UUID,
    notify_no VARCHAR(20),
    notify_version VARCHAR(5),
    
    bid_name TEXT[],
    bid_id UUID,
    bid_price BIGINT[],
    bid_form VARCHAR(20),
    bid_mode VARCHAR(20),
    bid_field VARCHAR(10),
    invest_field VARCHAR(10)[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    winning_codes VARCHAR(50)[],
    winning_names TEXT[],
    bid_winning_price BIGINT[],
    
    approval_date TIMESTAMP WITH TIME ZONE,
    decision_date TIMESTAMP WITH TIME ZONE,
    public_date TIMESTAMP WITH TIME ZONE,
    
    status VARCHAR(20),
    status_for_notify VARCHAR(50),
    step_code VARCHAR(50),
    is_domestic INTEGER,
    is_internet INTEGER,
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes cho standalone_results
CREATE INDEX IF NOT EXISTS idx_standalone_results_notify_no ON standalone_results(notify_no);
CREATE INDEX IF NOT EXISTS idx_standalone_results_winning_codes ON standalone_results USING GIN (winning_codes);

-- ───────────────────────────────────────────────────────────────────────────────
-- 22. BẢNG SHOPPING_RESULTS - Kết quả mua sắm trực tuyến
-- Type: es-shopping-result
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS shopping_results (
    id UUID PRIMARY KEY,
    notify_no VARCHAR(20),
    
    bid_name TEXT[],
    
    investor_code VARCHAR(20),
    investor_name TEXT,
    
    winning_codes VARCHAR(50)[],
    winning_names TEXT[],
    
    public_date TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20),
    step_code VARCHAR(50),
    
    detail_data JSONB,
    raw_data JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ───────────────────────────────────────────────────────────────────────────────
-- 23. BẢNG CONTRACT_CONTRACTORS - Liên kết nhiều-nhiều Hợp đồng - Nhà thầu
-- Cho trường hợp liên danh nhà thầu
-- ───────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contract_contractors (
    id SERIAL PRIMARY KEY,
    contract_id UUID REFERENCES contracts(id),
    contractor_code VARCHAR(50) REFERENCES contractors(org_code),
    role VARCHAR(50),                            -- LEAD: đứng đầu liên danh, MEMBER: thành viên
    share_percentage DECIMAL(5,2),               -- Phần trăm tham gia
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_contract_contractors_contract ON contract_contractors(contract_id);
CREATE INDEX IF NOT EXISTS idx_contract_contractors_contractor ON contract_contractors(contractor_code);

-- ═══════════════════════════════════════════════════════════════════════════════
-- FUNCTIONS & TRIGGERS
-- ═══════════════════════════════════════════════════════════════════════════════

-- Function: Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables with updated_at
DO $$
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.columns 
        WHERE column_name = 'updated_at' 
        AND table_schema = 'public'
    LOOP
        EXECUTE format('
            DROP TRIGGER IF EXISTS update_%s_updated_at ON %s;
            CREATE TRIGGER update_%s_updated_at
            BEFORE UPDATE ON %s
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
        ', t, t, t, t);
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- ═══════════════════════════════════════════════════════════════════════════════
-- VIEWS
-- ═══════════════════════════════════════════════════════════════════════════════

-- View: Thống kê crawl theo ngày
CREATE OR REPLACE VIEW crawl_daily_stats AS
SELECT 
    crawl_date,
    SUM(total_records) AS total_records,
    SUM(success_count) AS total_success,
    SUM(error_count) AS total_errors,
    COUNT(DISTINCT record_type) AS types_crawled,
    array_agg(DISTINCT record_type) AS record_types
FROM crawl_logs
GROUP BY crawl_date
ORDER BY crawl_date DESC;

-- View: Thống kê TBMT theo tháng
CREATE OR REPLACE VIEW notifications_monthly_stats AS
SELECT 
    DATE_TRUNC('month', public_date) AS month,
    bid_form,
    COUNT(*) AS count,
    SUM(COALESCE(bid_price[1], 0)) AS total_value
FROM notifications
WHERE public_date IS NOT NULL
GROUP BY DATE_TRUNC('month', public_date), bid_form
ORDER BY month DESC, count DESC;

-- View: Top chủ đầu tư
CREATE OR REPLACE VIEW top_investors AS
SELECT 
    investor_code,
    investor_name,
    COUNT(*) AS total_notifications,
    SUM(COALESCE(bid_price[1], 0)) AS total_value
FROM notifications
WHERE investor_code IS NOT NULL
GROUP BY investor_code, investor_name
ORDER BY total_notifications DESC
LIMIT 100;

-- View: Top nhà thầu trúng thầu
CREATE OR REPLACE VIEW top_winning_contractors AS
SELECT 
    c.org_code,
    c.org_full_name,
    c.business_type,
    c.office_prov,
    COUNT(cc.id) AS total_contracts,
    SUM(ct.contract_price) AS total_contract_value
FROM contractors c
LEFT JOIN contract_contractors cc ON c.org_code = cc.contractor_code
LEFT JOIN contracts ct ON cc.contract_id = ct.id
GROUP BY c.org_code, c.org_full_name, c.business_type, c.office_prov
ORDER BY total_contracts DESC
LIMIT 100;

-- View: Thống kê theo lĩnh vực
CREATE OR REPLACE VIEW notifications_by_field AS
SELECT 
    bid_field,
    COUNT(*) AS count,
    SUM(COALESCE(bid_price[1], 0)) AS total_value,
    COUNT(CASE WHEN is_internet = 1 THEN 1 END) AS internet_count,
    COUNT(CASE WHEN is_domestic = 1 THEN 1 END) AS domestic_count
FROM notifications
WHERE public_date IS NOT NULL
GROUP BY bid_field
ORDER BY count DESC;

-- View: Dự án với các kế hoạch
CREATE OR REPLACE VIEW projects_with_plans AS
SELECT 
    p.id,
    p.pno,
    p.name AS project_name,
    p.invest_total,
    p.investor_name,
    p.public_date AS project_public_date,
    COUNT(DISTINCT pl.id) AS plan_count,
    COUNT(DISTINCT po.id) AS plan_overall_count,
    array_agg(DISTINCT pl.plan_no) AS plan_nos
FROM projects p
LEFT JOIN plans pl ON p.id = pl.project_id
LEFT JOIN plans_overall po ON p.id = po.project_id
GROUP BY p.id, p.pno, p.name, p.invest_total, p.investor_name, p.public_date
ORDER BY p.public_date DESC;

-- View: Quy trình đấu thầu hoàn chỉnh
CREATE OR REPLACE VIEW bidding_process_full AS
SELECT 
    n.notify_no,
    n.bid_name,
    n.bid_price,
    n.bid_form,
    n.bid_field,
    n.investor_name,
    n.public_date AS notify_date,
    n.bid_open_date,
    n.bid_close_date,
    n.step_code,
    n.status,
    bo.bid_reality_open_date,
    bo.num_bidder_join,
    br.winning_names,
    br.bid_winning_price,
    c.contract_code,
    c.contract_sign_date,
    c.contract_price
FROM notifications n
LEFT JOIN bid_opens bo ON n.id = bo.notify_id
LEFT JOIN bid_results br ON n.id = br.notify_id
LEFT JOIN contracts c ON n.notify_no = c.notify_no
ORDER BY n.public_date DESC;

-- ═══════════════════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (Optional - enable if needed)
-- ═══════════════════════════════════════════════════════════════════════════════

-- Enable RLS on tables
-- ALTER TABLE raw_records ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
-- ... etc

-- ═══════════════════════════════════════════════════════════════════════════════
-- COMMENTS
-- ═══════════════════════════════════════════════════════════════════════════════

COMMENT ON TABLE raw_records IS 'Bảng lưu trữ dữ liệu thô từ crawler, trước khi xử lý sang các bảng cụ thể';
COMMENT ON TABLE projects IS 'Thông tin dự án đầu tư (type: es-bidp-project-p)';
COMMENT ON TABLE plans IS 'Kế hoạch lựa chọn nhà thầu (type: es-plan-project-p)';
COMMENT ON TABLE plans_overall IS 'Kế hoạch tổng thể lựa chọn nhà thầu (type: es-plan-overall-p)';
COMMENT ON TABLE notifications IS 'Thông báo mời thầu và các bước tiếp theo (type: es-notify-contractor)';
COMMENT ON TABLE contracts IS 'Thông tin hợp đồng đã ký (type: es-ct-contract)';
COMMENT ON TABLE framework_agreements IS 'Thỏa thuận khung - mua sắm tập trung (type: es-ct-publish-frame)';
COMMENT ON TABLE request_quotes IS 'Yêu cầu báo giá - chỉ định thầu rút gọn (type: es-ycbg)';
COMMENT ON TABLE prequalifications IS 'Thông báo mời sơ tuyển (type: es-notify-prequalification)';
COMMENT ON TABLE interests IS 'Thông báo mời quan tâm (type: es-notify-interest)';
COMMENT ON TABLE crawl_logs IS 'Log quá trình crawl để theo dõi và debug';
COMMENT ON TABLE investors IS 'Danh sách chủ đầu tư (denormalized)';
COMMENT ON TABLE contractors IS 'Danh sách nhà thầu với đầy đủ thông tin';
COMMENT ON TABLE bid_packages IS 'Gói thầu trong kế hoạch LCNT';
COMMENT ON TABLE bid_lots IS 'Lô thầu trong gói thầu phân lô';
COMMENT ON TABLE bid_opens IS 'Biên bản mở thầu';
COMMENT ON TABLE bid_results IS 'Kết quả lựa chọn nhà thầu';
COMMENT ON TABLE prequalification_results IS 'Kết quả sơ tuyển';
COMMENT ON TABLE interest_results IS 'Kết quả mời quan tâm';
COMMENT ON TABLE interest_surveys IS 'Khảo sát quan tâm nhà thầu trong nước';
COMMENT ON TABLE standalone_results IS 'Kết quả LCNT không liên kết KHLCNT';
COMMENT ON TABLE shopping_results IS 'Kết quả mua sắm trực tuyến';
COMMENT ON TABLE contract_contractors IS 'Liên kết nhiều-nhiều giữa Hợp đồng và Nhà thầu (liên danh)';

-- ═══════════════════════════════════════════════════════════════════════════════
-- ENUMS & REFERENCE DATA
-- ═══════════════════════════════════════════════════════════════════════════════

-- Bảng danh mục hình thức đấu thầu
CREATE TABLE IF NOT EXISTS ref_bid_forms (
    code VARCHAR(20) PRIMARY KEY,
    name TEXT,
    description TEXT
);

INSERT INTO ref_bid_forms (code, name, description) VALUES
('DTRR', 'Đấu thầu rộng rãi', 'Hình thức lựa chọn nhà thầu phổ biến nhất'),
('CDT', 'Chỉ định thầu', 'Chỉ định trực tiếp nhà thầu'),
('CHCT', 'Chào hàng cạnh tranh', 'Yêu cầu ít nhất 3 báo giá'),
('CGTTRG', 'Chào giá trực tuyến (Rút gọn)', 'Đấu thầu qua mạng theo quy trình rút gọn'),
('CDTRG', 'Chỉ định thầu rút gọn', 'Chỉ định thầu theo quy trình rút gọn'),
('MSTT', 'Mua sắm trực tuyến', 'Mua sắm qua hệ thống điện tử'),
('TTD', 'Tự thực hiện', 'Chủ đầu tư tự thực hiện'),
('LCCTCHQ', 'Lựa chọn cộng đồng/hợp quản', 'Lựa chọn theo hình thức cộng đồng')
ON CONFLICT (code) DO NOTHING;

-- Bảng danh mục lĩnh vực
CREATE TABLE IF NOT EXISTS ref_bid_fields (
    code VARCHAR(10) PRIMARY KEY,
    name TEXT,
    description TEXT
);

INSERT INTO ref_bid_fields (code, name, description) VALUES
('HH', 'Hàng hóa', 'Mua sắm hàng hóa, vật tư, thiết bị'),
('XL', 'Xây lắp', 'Thi công xây dựng, lắp đặt'),
('TV', 'Tư vấn', 'Dịch vụ tư vấn'),
('PTV', 'Phi tư vấn', 'Dịch vụ phi tư vấn'),
('HON_HOP', 'Hỗn hợp', 'Kết hợp nhiều lĩnh vực')
ON CONFLICT (code) DO NOTHING;

-- Bảng danh mục phương thức
CREATE TABLE IF NOT EXISTS ref_bid_modes (
    code VARCHAR(20) PRIMARY KEY,
    name TEXT,
    description TEXT
);

INSERT INTO ref_bid_modes (code, name, description) VALUES
('1_MTHS', 'Một giai đoạn một túi hồ sơ', 'Phương thức phổ biến nhất'),
('1_2THS', 'Một giai đoạn hai túi hồ sơ', 'Tách riêng kỹ thuật và tài chính'),
('2THS', 'Hai giai đoạn hai túi hồ sơ', 'Gói thầu phức tạp')
ON CONFLICT (code) DO NOTHING;

-- Bảng danh mục quy trình
CREATE TABLE IF NOT EXISTS ref_process_applies (
    code VARCHAR(20) PRIMARY KEY,
    name TEXT,
    description TEXT
);

INSERT INTO ref_process_applies (code, name, description) VALUES
('LDT', 'Luật Đấu thầu', 'Theo Luật Đấu thầu Việt Nam'),
('ADB', 'Ngân hàng ADB', 'Theo quy trình của ADB'),
('WB', 'Ngân hàng Thế giới', 'Theo quy trình của World Bank'),
('JICA', 'JICA', 'Theo quy trình của JICA'),
('KHAC', 'Quy trình khác', 'Các quy trình đặc thù khác')
ON CONFLICT (code) DO NOTHING;

-- Bảng danh mục loại kế hoạch
CREATE TABLE IF NOT EXISTS ref_plan_types (
    code VARCHAR(20) PRIMARY KEY,
    name TEXT,
    description TEXT
);

INSERT INTO ref_plan_types (code, name, description) VALUES
('DTPT', 'Dự án đầu tư phát triển', 'Kế hoạch thuộc dự án đầu tư'),
('TX', 'Thường xuyên', 'Kế hoạch mua sắm thường xuyên'),
('DTMS', 'Dự toán mua sắm', 'Kế hoạch theo dự toán'),
('KHAC', 'Khác', 'Các loại khác')
ON CONFLICT (code) DO NOTHING;

-- Done!
SELECT 'Schema created successfully with all tables!' AS status;
