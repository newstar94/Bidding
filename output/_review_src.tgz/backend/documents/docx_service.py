import json
import re
from datetime import date, datetime
from backend.shared.helpers import database
from backend.documents.docx_context_policy import (
    REPORT_DOCUMENT_TYPES,
    project_docx_context,
)
from backend.documents.detailed_evaluation_context import (
    build_detailed_evaluation_context,
)
from backend.sync.mapper import attach_child_rows, attach_child_rows_to_items, _enrich_opening_bid_contractor_versions
from backend.shared.date_utils import vietnam_now
from backend.versioning.relation_policy import load_contracts_for_package_lineage
from backend.documents.plan_basis_context import (
    materialize_plan_basis_items,
    resolve_plan_basis_rows,
)


def _date_only(value):
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    raw = str(value or '').strip()
    if not raw:
        return ''
    iso = re.match(r'^(\d{4})-(\d{2})-(\d{2})', raw)
    if iso:
        return f'{iso.group(1)}-{iso.group(2)}-{iso.group(3)}'
    dmy = re.match(r'^(\d{2})/(\d{2})/(\d{4})', raw)
    if dmy:
        return f'{dmy.group(3)}-{dmy.group(2)}-{dmy.group(1)}'
    return ''


def select_effective_partner_version(records, partner_version_id, business_date):
    """Select the version effective on a document's business date."""
    selected = next(
        (
            item for item in records or []
            if str(item.get('id') or '') == str(partner_version_id or '')
        ),
        None,
    )
    if not selected:
        return None
    root_id = selected.get('id_goc') or selected.get('rootId') or selected['id']
    family = [
        item for item in records or []
        if str(item.get('id_goc') or item.get('rootId') or item.get('id') or '')
        == str(root_id)
    ]
    if not family:
        return selected
    target = _date_only(business_date)
    if not target:
        return selected

    def rank(item):
        effective_date = _date_only(
            item.get('ngay_ap_dung')
            or item.get('ngayApDung')
            or item.get('created_at')
            or item.get('createdAt')
            or item.get('updated_at')
            or item.get('updatedAt')
        )
        try:
            version = int(item.get('phien_ban') or item.get('phienBan') or 0)
        except (TypeError, ValueError):
            version = 0
        return effective_date, version

    applicable = [item for item in family if rank(item)[0] and rank(item)[0] <= target]
    if applicable:
        return max(applicable, key=rank)
    return min(family, key=lambda item: (rank(item)[1], rank(item)[0]))


def _metadata_object(value):
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(value or '{}')
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _collect_metadata_dates(value, field_names):
    dates = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key in field_names and _date_only(child):
                dates.append(_date_only(child))
            elif isinstance(child, (dict, list)):
                dates.extend(_collect_metadata_dates(child, field_names))
    elif isinstance(value, list):
        for child in value:
            dates.extend(_collect_metadata_dates(child, field_names))
    return dates


def resolve_report_business_date(document_type, package):
    """Return the milestone date that governs partner data for a Word report."""
    pkg = package or {}
    if document_type == 'hsmt':
        return pkg.get('ngay_quyet_dinh') or pkg.get('ngayQuyetDinh') or ''
    if document_type == 'opening':
        return (
            pkg.get('thoi_gian_mo_thau')
            or pkg.get('thoiGianMoThau')
            or pkg.get('thoi_gian_mo_ehsdxtc')
            or pkg.get('thoiGianMoEhsdxtc')
            or ''
        )
    metadata = _metadata_object(
        pkg.get('danh_gia_hsdt_metadata') or pkg.get('danhGiaHsdtMetadata')
    )
    if document_type == 'evaluation':
        report_dates = _collect_metadata_dates(
            metadata,
            {
                'ngayBaoCao',
                'ngay_bao_cao',
                'ngayBaoCaoDanhGiaNhaThau',
                'ngay_bao_cao_danh_gia_nha_thau',
            },
        )
        return max(report_dates) if report_dates else ''
    if document_type == 'result':
        decision_date = (
            pkg.get('ngay_quyet_dinh_ket_qua')
            or pkg.get('ngayQuyetDinhKetQua')
        )
        if decision_date:
            return decision_date
        result_dates = _collect_metadata_dates(
            metadata,
            {'ngayQuyetDinhKetQua', 'ngay_quyet_dinh_ket_qua'},
        )
        return max(result_dates) if result_dates else ''
    return ''


def load_effective_investor(cursor, investor_id, organization_id, business_date):
    """Load the investor lineage and return the version effective for the document."""
    if not investor_id:
        return {}
    cursor.execute(
        """SELECT * FROM chu_dau_tu
           WHERE id = ? AND organization_id = ? AND archived_at IS NULL""",
        (investor_id, organization_id),
    )
    row = cursor.fetchone()
    if not row:
        return {}
    anchor = parse_json_fields(dict(row))
    root_id = str(anchor.get('id_goc') or anchor['id']).strip()
    cursor.execute(
        """SELECT * FROM chu_dau_tu
           WHERE organization_id = ? AND archived_at IS NULL
             AND (id_goc = ? OR id = ?)""",
        (organization_id, root_id, root_id),
    )
    versions = [parse_json_fields(dict(item)) for item in cursor.fetchall()]
    return select_effective_partner_version(
        versions or [anchor],
        anchor['id'],
        business_date,
    ) or anchor

def to_snake_case(s):
    import re
    return re.sub(r'(?<!^)(?=[A-Z])', '_', s).lower()

def normalize_dict_keys(data):
    if isinstance(data, dict):
        return {to_snake_case(k): normalize_dict_keys(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [normalize_dict_keys(x) for x in data]
    return data

def parse_json_fields(row_dict):
    if not row_dict:
        return row_dict
    for col, val in list(row_dict.items()):
        if val and isinstance(val, str):
            is_json = (
                col.endswith("_list")
                or col.startswith("cv_")
                or col in ("thanh_vien_lien_danh", "goi_thau_ids", "thong_tin_thiet_bi_cuoi")
            )
            if is_json:
                try:
                    parsed = json.loads(val)
                    row_dict[col] = normalize_dict_keys(parsed)
                except (json.JSONDecodeError, TypeError):
                    row_dict[col] = [] if col != "thong_tin_thiet_bi_cuoi" else {}
        elif val is None and (
            col.endswith("_list")
            or col.startswith("cv_")
            or col in ("thanh_vien_lien_danh", "goi_thau_ids", "thong_tin_thiet_bi_cuoi")
        ):
            row_dict[col] = [] if col != "thong_tin_thiet_bi_cuoi" else {}
    return row_dict

def enrich_bids_with_contractor_fields(cursor, bids, organization_id):
    contractor_ids = sorted({
        str(bid.get('nha_thau_id')).strip()
        for bid in bids
        if isinstance(bid, dict) and bid.get('nha_thau_id')
    })
    if not contractor_ids:
        return bids

    placeholders = ','.join(['?'] * len(contractor_ids))
    cursor.execute(
        f"""
            SELECT id, ten_nha_thau, ten_viet_tat, ma_nha_thau, ma_so_thue,
                   nguoi_dai_dien, chuc_vu_dai_dien, danh_xung, dia_chi,
                   dia_chi_goc, so_dien_thoai, email, so_tai_khoan,
                   noi_mo_tai_khoan, ma_ngan_hang
            FROM nha_thau
            WHERE organization_id = ? AND id IN ({placeholders})
        """,
        (organization_id, *contractor_ids),
    )
    contractors = {row['id']: dict(row) for row in cursor.fetchall()}
    for bid in bids:
        if not isinstance(bid, dict):
            continue
        contractor = contractors.get(str(bid.get('nha_thau_id') or '').strip())
        if not contractor:
            continue
        is_joint_venture = str(bid.get('loai_nha_thau') or '').strip().lower() == 'liên danh'
        if not is_joint_venture:
            bid['ten_nha_thau'] = contractor.get('ten_nha_thau') or bid.get('ten_nha_thau') or ''
        for field in (
            'ten_viet_tat', 'ma_nha_thau', 'ma_so_thue', 'nguoi_dai_dien',
            'chuc_vu_dai_dien', 'danh_xung', 'dia_chi', 'dia_chi_goc',
            'so_dien_thoai', 'email', 'so_tai_khoan', 'noi_mo_tai_khoan',
            'ma_ngan_hang',
        ):
            bid[field] = contractor.get(field) or ''
    return bids


def load_current_contracts_for_package(cursor, organization_id, package_id):
    """Return every current contract linked to the selected package lineage."""

    related = load_contracts_for_package_lineage(
        cursor,
        organization_id,
        package_id,
    )
    current = [
        parse_json_fields(dict(item))
        for item in related
        if item.get('is_latest') in (1, True, '1')
    ]
    if current:
        return current
    # Legacy rows may predate ``is_latest``. Preserve export compatibility while
    # the relation loader still supplies deterministic ordering.
    return [parse_json_fields(dict(item)) for item in related]

def extract_evaluation_dates(pkg):
    if not pkg:
        return pkg
    metadata_str = pkg.get('danh_gia_hsdt_metadata')
    if metadata_str and isinstance(metadata_str, str):
        try:
            meta = json.loads(metadata_str)
            if meta:

                if meta.get('is1G2T') or 'financial' in meta:
                    fin = meta.get('financial', {}) or {}
                    ngay_moi_doichieu = fin.get('ngayMoiDoiChieu')
                    ngay_doichieu = fin.get('ngayDoiChieu')
                else:
                    ngay_moi_doichieu = meta.get('ngayMoiDoiChieu')
                    ngay_doichieu = meta.get('ngayDoiChieu')


                def format_date(d_str):
                    if d_str and '-' in d_str:
                        parts = d_str.split('-')
                        if len(parts) == 3:
                            return f"{parts[2]}/{parts[1]}/{parts[0]}"
                    return d_str or ''

                pkg['ngay_moi_doi_chieu'] = format_date(ngay_moi_doichieu)
                pkg['ngay_doi_chieu'] = format_date(ngay_doichieu)
        except (TypeError, ValueError, OverflowError):
            pass
    return pkg

def is_competitive_quotation_package(pkg):
    return str((pkg or {}).get('hinh_thuc_lua_chon') or (pkg or {}).get('hinhThucLuaChon') or '').strip().lower() == 'chào hàng cạnh tranh'

def clear_competitive_quotation_appraisal(pkg):
    if not pkg or not is_competitive_quotation_package(pkg):
        return pkg
    pkg['yeu_cau_tham_dinh_hsmt'] = 'Không'
    pkg['yeuCauThamDinhHsmt'] = 'Không'
    pkg['yeu_cau_tham_dinh_hsmt_code'] = 'NOT_REQUIRED'
    pkg['yeuCauThamDinhHsmtCode'] = 'NOT_REQUIRED'
    # Retain appraisal evidence so a later fact change can restore it.
    return pkg


def load_plan_versions(cursor, plan, organization_id):
    """Load every persisted version in the current plan lineage."""
    if not isinstance(plan, dict) or not plan.get("id"):
        return []
    root_id = str(plan.get("id_goc") or plan["id"]).strip()
    cursor.execute(
        """SELECT * FROM ke_hoach_lcnt
           WHERE organization_id = ? AND (id_goc = ? OR id = ?)
           ORDER BY CAST(phien_ban AS INTEGER) ASC""",
        (organization_id, root_id, root_id),
    )
    versions = [parse_json_fields(dict(row)) for row in cursor.fetchall()]
    attach_child_rows_to_items(
        cursor,
        "ke_hoach_lcnt",
        versions,
        organization_id=organization_id,
        naming="snake",
    )
    return versions

def _build_plan_context_snapshot(
    plan_id,
    user_id,
    org_name,
    capabilities=None,
    selected_plan_basis_ids=None,
):
    """Truy vấn CSDL để xây dựng ngữ cảnh đầy đủ phục vụ xuất file Word Kế hoạch LCNT."""
    conn = database.get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM ke_hoach_lcnt WHERE id = ? AND organization_id = ?", (plan_id, org_name))
    row_plan = cursor.fetchone()
    if not row_plan:
        conn.close()
        raise ValueError(f"Plan with id {plan_id} not found")
    plan = parse_json_fields(dict(row_plan))
    attach_child_rows(cursor, "ke_hoach_lcnt", plan, organization_id=org_name, naming="snake")
    plan_versions = load_plan_versions(cursor, plan, org_name)
    selected_basis_rows, _selection_mode = resolve_plan_basis_rows(
        cursor, org_name, plan_id, selected_plan_basis_ids
    )
    selected_plan_bases = materialize_plan_basis_items(selected_basis_rows)

    investor_name = '--'
    investor_address = ''
    inv_data = {}
    if plan.get('chu_dau_tu_id'):
        inv_data = load_effective_investor(
            cursor,
            plan['chu_dau_tu_id'],
            org_name,
            plan.get('ngay_phe_duyet'),
        )
        if inv_data:
            investor_name = inv_data.get('ten_chu_dau_tu', '--')
            investor_address = inv_data.get('dia_chi', '')

    cursor.execute(
        """SELECT ten_dang_nhap, ho_ten, vai_tro, email, anh_dai_dien,
                  da_xac_minh
           FROM tai_khoan WHERE id = ?""",
        (user_id,),
    )
    row_user = cursor.fetchone()
    user_data = parse_json_fields(dict(row_user)) if row_user else {}

    cursor.execute("SELECT ten_to_chuc FROM to_chuc WHERE id = ?", (org_name,))
    row_org = cursor.fetchone()
    org_data = parse_json_fields(dict(row_org)) if row_org else {}

    gdv_data = {}
    cursor.execute(
        """SELECT pkg.ten_goi, pkg.gia_ca, pkg.han_muc_nhan_su, pkg.mo_ta
           FROM organization_subscriptions sub
           JOIN goi_dich_vu pkg ON pkg.id = sub.package_id
           WHERE sub.organization_id = ?
           LIMIT 1""",
        (org_name,),
    )
    row_gdv = cursor.fetchone()
    if row_gdv:
        gdv_data = parse_json_fields(dict(row_gdv))

    cursor.execute(
        """SELECT * FROM goi_thau
           WHERE ke_hoach_id = ? AND organization_id = ?
             AND archived_at IS NULL AND is_latest = 1""",
        (plan_id, org_name),
    )
    goi_thau_list = [parse_json_fields(dict(r)) for r in cursor.fetchall()]
    attach_child_rows_to_items(cursor, "goi_thau", goi_thau_list, organization_id=org_name, naming="snake")
    for gt in goi_thau_list:
        extract_evaluation_dates(gt)
        clear_competitive_quotation_appraisal(gt)
    conn.close()

    now = vietnam_now()
    unified_context = {
        'ke_hoach': plan,
        'ke_hoach_versions': plan_versions,
        'user': user_data,
        'to_chuc': org_data,
        'goi_dich_vu': gdv_data,
        'goi_thau': goi_thau_list,
        'goi_thau_trong_ke_hoach': goi_thau_list,
        'ke_hoach_can_cu': selected_plan_bases,
        'investor_name': investor_name,
        'investor_address': investor_address,
        'chu_dau_tu': inv_data,
        'current_time': now.isoformat(timespec='seconds'),
        'today': now.date().isoformat()
    }
    projected_context = project_docx_context(
            "plan",
            unified_context,
            capabilities,
            organization_id=org_name,
        )
    # Keep the selected-only source available until custom mappings create the
    # template-visible alias. seal_docx_context removes this internal key.
    projected_context["ke_hoach_can_cu"] = selected_plan_bases
    return projected_context, int(plan.get("row_version") or 1)


def build_plan_context_snapshot(
    plan_id, user_id, org_name, capabilities=None, selected_plan_basis_ids=None
):
    """Return the projected plan DTO and its internal authoritative revision."""
    return _build_plan_context_snapshot(
        plan_id, user_id, org_name, capabilities, selected_plan_basis_ids
    )


def _build_report_context_snapshot(
    package_id,
    user_id,
    org_name,
    type_param,
    capabilities=None,
):
    """Truy vấn CSDL để xây dựng ngữ cảnh phục vụ xuất file Word HSMT/Mở thầu/Đánh giá/Hợp đồng."""
    if type_param not in REPORT_DOCUMENT_TYPES:
        raise ValueError("Loại báo cáo Word không được hỗ trợ")
    conn = database.get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM goi_thau WHERE id = ? AND organization_id = ?", (package_id, org_name))
    row_pkg = cursor.fetchone()
    if not row_pkg:
        conn.close()
        raise ValueError(f"Package with id {package_id} not found")
    pkg = parse_json_fields(dict(row_pkg))
    attach_child_rows(cursor, "goi_thau", pkg, organization_id=org_name, naming="snake")
    extract_evaluation_dates(pkg)
    clear_competitive_quotation_appraisal(pkg)

    plan = {}
    plan_versions = []
    investor_name = '--'
    investor_address = ''
    inv_data = {}
    if pkg.get('ke_hoach_id'):
        cursor.execute(
            "SELECT * FROM ke_hoach_lcnt WHERE id = ? AND organization_id = ? AND archived_at IS NULL",
            (pkg['ke_hoach_id'], org_name),
        )
        row_plan = cursor.fetchone()
        if row_plan:
            plan = parse_json_fields(dict(row_plan))
            attach_child_rows(cursor, "ke_hoach_lcnt", plan, organization_id=org_name, naming="snake")
            plan_versions = load_plan_versions(cursor, plan, org_name)
            if plan.get('chu_dau_tu_id'):
                inv_data = load_effective_investor(
                    cursor,
                    plan['chu_dau_tu_id'],
                    org_name,
                    resolve_report_business_date(type_param, pkg),
                )
                if inv_data:
                    investor_name = inv_data.get('ten_chu_dau_tu', '--')
                    investor_address = inv_data.get('dia_chi', '')

    cursor.execute(
        """SELECT ten_dang_nhap, ho_ten, vai_tro, email, anh_dai_dien,
                  da_xac_minh
           FROM tai_khoan WHERE id = ?""",
        (user_id,),
    )
    row_user = cursor.fetchone()
    user_data = parse_json_fields(dict(row_user)) if row_user else {}

    cursor.execute("SELECT ten_to_chuc FROM to_chuc WHERE id = ?", (org_name,))
    row_org = cursor.fetchone()
    org_data = parse_json_fields(dict(row_org)) if row_org else {}

    gdv_data = {}
    cursor.execute(
        """SELECT pkg.ten_goi, pkg.gia_ca, pkg.han_muc_nhan_su, pkg.mo_ta
           FROM organization_subscriptions sub
           JOIN goi_dich_vu pkg ON pkg.id = sub.package_id
           WHERE sub.organization_id = ?
           LIMIT 1""",
        (org_name,),
    )
    row_gdv = cursor.fetchone()
    if row_gdv:
        gdv_data = parse_json_fields(dict(row_gdv))

    cursor.execute("SELECT * FROM thong_tin_mo_thau WHERE goi_thau_id = ? AND organization_id = ?", (package_id, org_name))
    bids = [parse_json_fields(dict(r)) for r in cursor.fetchall()]
    attach_child_rows_to_items(cursor, "thong_tin_mo_thau", bids, organization_id=org_name, naming="snake")
    if type_param == 'result':
        try:
            result_meta = json.loads(pkg.get('danh_gia_hsdt_metadata') or '{}').get('result', {})
        except (TypeError, ValueError, json.JSONDecodeError):
            result_meta = {}
        bindings = {
            str(item.get('bidId') or ''): item
            for item in result_meta.get('contractorBindings', [])
            if isinstance(item, dict)
        }
        for bid in bids:
            binding = bindings.get(str(bid.get('id') or ''))
            if binding and binding.get('contractorVersionId'):
                bid['nha_thau_id'] = binding['contractorVersionId']
                for member, member_id in zip(
                    bid.get('thanh_vien_lien_danh') or [],
                    binding.get('memberVersionIds') or [],
                ):
                    member['thanh_vien_nha_thau_id'] = member_id
        if pkg.get('nha_thau_trung_thau_id'):
            winning_ids = {str(pkg['nha_thau_trung_thau_id'])}
            winning_ids.update(str(item.get('nha_thau_trung_thau_id')) for item in pkg.get('phan_lo_list', []) if item.get('nha_thau_trung_thau_id'))
            bids = [bid for bid in bids if str(bid.get('nha_thau_id')) in winning_ids or str(bindings.get(str(bid.get('id') or ''), {}).get('contractorVersionId')) in winning_ids]
        _enrich_opening_bid_contractor_versions(cursor, {str(bid.get('id')): bid for bid in bids}, org_name, 'snake')
    enrich_bids_with_contractor_fields(cursor, bids, org_name)
    opening_bids = bids


    id_goc = pkg.get('id_goc')
    root_id = id_goc if (id_goc and id_goc.strip()) else package_id
    cursor.execute("SELECT * FROM goi_thau WHERE organization_id = ? AND (id_goc = ? OR id = ?) ORDER BY CAST(phien_ban AS INTEGER) ASC", (org_name, root_id, root_id))
    goi_thau_versions = [parse_json_fields(dict(r)) for r in cursor.fetchall()]
    attach_child_rows_to_items(cursor, "goi_thau", goi_thau_versions, organization_id=org_name, naming="snake")
    for v in goi_thau_versions:
        extract_evaluation_dates(v)
        clear_competitive_quotation_appraisal(v)

    contract_data = {}
    # Linked contracts are package-level data used by composite templates.
    # Keep them available for every package report context; only the dedicated
    # contract/liquidation contexts may replace the primary investor and bidder
    # with parties from one selected contract.
    contract_list = load_current_contracts_for_package(
        cursor,
        org_name,
        package_id,
    )
    if type_param in ('contract', 'liquidation'):
        if contract_list:
            contract_data = dict(contract_list[0])
            cursor.execute(
                "SELECT goi_thau_id FROM hop_dong_goi_thau WHERE organization_id = ? AND hop_dong_id = ?",
                (org_name, contract_data.get('id'))
            )
            contract_data['goi_thau_ids'] = [r[0] for r in cursor.fetchall()]
            investor_id = contract_data.get('chu_dau_tu_thanh_ly_id') if type_param == 'liquidation' else contract_data.get('chu_dau_tu_id')
            contractor_id = contract_data.get('nha_thau_thanh_ly_id') if type_param == 'liquidation' else contract_data.get('nha_thau_id')
            if investor_id:
                cursor.execute("SELECT * FROM chu_dau_tu WHERE id = ? AND organization_id = ?", (investor_id, org_name))
                row_inv = cursor.fetchone()
                if row_inv:
                    inv_data = parse_json_fields(dict(row_inv))
                    investor_name = inv_data.get('ten_chu_dau_tu', '--')
                    investor_address = inv_data.get('dia_chi', '')
            if contractor_id:
                cursor.execute("SELECT * FROM nha_thau WHERE id = ? AND organization_id = ?", (contractor_id, org_name))
                row_contractor = cursor.fetchone()
                if row_contractor:
                    bids = [parse_json_fields(dict(row_contractor))]
                    attach_child_rows_to_items(cursor, "nha_thau", bids, organization_id=org_name, naming="snake")


    cursor.execute("""
        SELECT cg.*, gtcg.chuc_vu, gtcg.cong_viec
        FROM goi_thau_chuyen_gia gtcg
        JOIN chuyen_gia cg ON gtcg.chuyen_gia_id = cg.id
        WHERE gtcg.organization_id = ? AND cg.organization_id = ? AND gtcg.goi_thau_id = ? AND gtcg.loai = 'chuyen_gia'
    """, (org_name, org_name, package_id))
    to_chuyen_gia = [parse_json_fields(dict(r)) for r in cursor.fetchall()]


    cursor.execute("""
        SELECT cg.*, gtcg.chuc_vu, gtcg.cong_viec
        FROM goi_thau_chuyen_gia gtcg
        JOIN chuyen_gia cg ON gtcg.chuyen_gia_id = cg.id
        WHERE gtcg.organization_id = ? AND cg.organization_id = ? AND gtcg.goi_thau_id = ? AND gtcg.loai = 'tham_dinh'
    """, (org_name, org_name, package_id))
    to_tham_dinh = [parse_json_fields(dict(r)) for r in cursor.fetchall()]
    if is_competitive_quotation_package(pkg):
        to_tham_dinh = []

    conn.close()

    now = vietnam_now()
    unified_context = {
        'goi_thau': pkg,
        'goi_thau_versions': goi_thau_versions,
        'ke_hoach': plan,
        'ke_hoach_versions': plan_versions if plan else [],
        'user': user_data,
        'to_chuc': org_data,
        'goi_dich_vu': gdv_data,
        'nha_thau': bids,
        # Contract documents use ``nha_thau`` for the linked contractor. Keep
        # the opening rows separately so an explicitly configured composite
        # template can still render ``ds_mo_thau`` from its declared source.
        'thong_tin_mo_thau': opening_bids,
        'to_chuyen_gia': to_chuyen_gia,
        'to_tham_dinh': to_tham_dinh,
        'hop_dong': contract_data,
        'hop_dong_list': contract_list,
        'investor_name': investor_name,
        'investor_address': investor_address,
        'chu_dau_tu': inv_data,
        'current_time': now.isoformat(timespec='seconds'),
        'today': now.date().isoformat()
    }
    unified_context.update(build_detailed_evaluation_context(pkg, bids))
    return (
        project_docx_context(
            type_param,
            unified_context,
            capabilities,
            organization_id=org_name,
        ),
        int(pkg.get("row_version") or 1),
    )


def build_report_context(
    package_id,
    user_id,
    org_name,
    type_param,
    capabilities=None,
):
    context, _record_revision = _build_report_context_snapshot(
        package_id,
        user_id,
        org_name,
        type_param,
        capabilities,
    )
    return context


def build_report_context_snapshot(
    package_id,
    user_id,
    org_name,
    type_param,
    capabilities=None,
):
    """Return the projected report DTO and its internal authoritative revision."""
    return _build_report_context_snapshot(
        package_id,
        user_id,
        org_name,
        type_param,
        capabilities,
    )
