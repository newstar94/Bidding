"""HTTP routes for the package detail document tab."""

from __future__ import annotations

import asyncio
import json
import re
import time

from starlette.responses import FileResponse, JSONResponse

from backend.documents.document_worker import (
    DocumentWorkerError,
    DocumentWorkerInputError,
    run_document_job_async,
)
from backend.documents.package_document_policy import (
    allowed_upload_types,
    compose_document_sections,
    document_type_definition,
    is_evaluation_document_type,
    package_status_code,
)
from backend.documents.package_document_service import (
    MAX_PACKAGE_DOCUMENT_BYTES,
    PackageDocumentError,
    PackageDocumentNotFoundError,
    clean_original_filename,
    create_storage_key,
    delete_package_document,
    get_evaluation_batch,
    get_evaluation_batch_for_document_mutation,
    get_package_document,
    list_package_evaluation_batches,
    list_package_documents,
    load_package,
    load_package_for_document_mutation,
    media_for_filename,
    persist_upload_path,
    remove_storage_key,
    resolve_storage_key,
    upsert_package_document,
    validate_pdf_path,
)
from backend.documents.upload_spooling import spooled_upload
from backend.auth.auth_helper import verify_session_in_transaction
from backend.shared.access_policy import authorize_record_write, can_read_record
from backend.shared.async_io import (
    BlockingIOBusyError, BlockingIOTimeoutError, finish_submitted_task, run_blocking_io,
)
from backend.shared.database_io import run_database_read, run_database_write
from backend.shared.domain_enums import enum_label
from backend.shared.helpers import (
    OrgPermissionError,
    database,
    get_active_org,
    log_audit,
    log_error,
    verify_session,
)
from backend.shared.logging_utils import log_and_error
from backend.shared.logging_utils import get_request_id
from backend.shared.date_utils import vietnam_now_sql
from backend.shared.idempotency import acquire_idempotency_lock
from backend.activity.service import (
    document_activity_event,
    insert_activity_events,
)
from backend.sync.websocket import enqueue_websocket_event
from backend.sync.aggregate_mutability import package_mutability_error
from backend.sync.repository import next_sync_version


_IDEMPOTENCY_KEY_RE = re.compile(r"^[A-Za-z0-9._:-]{8,128}$")


class PackageDocumentHistoricalError(PackageDocumentError):
    code = "HISTORICAL_PARENT_IMMUTABLE"


class PackageDocumentAuthorizationError(PackageDocumentError):
    code = "AUTHENTICATION_REQUIRED"
    status_code = 401


class PackageDocumentIdempotencyConflict(PackageDocumentError):
    code = "IDEMPOTENCY_KEY_REUSED"
    status_code = 409


def _document_error(message, code, status_code):
    return JSONResponse({"error": message, "code": code}, status_code=status_code)


def _document_idempotency_key(request):
    key = str(request.headers.get("Idempotency-Key") or "").strip()
    if key and not _IDEMPOTENCY_KEY_RE.fullmatch(key):
        return None, _document_error(
            "Idempotency-Key không hợp lệ.",
            "INVALID_IDEMPOTENCY_KEY",
            400,
        )
    return key or None, None


def _document_operation(
    organization_id,
    package_id,
    document_type,
    evaluation_batch_id,
    action,
):
    return ":".join((
        "package_document",
        str(organization_id),
        str(package_id),
        str(document_type),
        str(evaluation_batch_id or "general"),
        str(action),
    ))


def _document_idempotency_replay(
    cursor,
    *,
    actor_user_id,
    operation,
    idempotency_key,
    request_hash=None,
):
    if not idempotency_key:
        return None
    acquire_idempotency_lock(
        cursor,
        "package_document",
        actor_user_id,
        operation,
        idempotency_key,
    )
    row = cursor.execute(
        """SELECT response_json FROM api_idempotency
           WHERE actor_user_id = ? AND operation = ? AND idempotency_key = ?""",
        (actor_user_id, operation, idempotency_key),
    ).fetchone()
    if not row:
        return None
    payload = json.loads(row[0] or "{}")
    stored_request_hash = payload.pop("_requestHash", None)
    if request_hash is not None and stored_request_hash != str(request_hash):
        raise PackageDocumentIdempotencyConflict(
            "Idempotency-Key đã được dùng cho một tệp khác."
        )
    status_code = int(payload.pop("_statusCode", 200))
    return payload, status_code


def _store_document_idempotency(
    cursor,
    *,
    actor_user_id,
    operation,
    idempotency_key,
    payload,
    status_code,
    request_hash=None,
):
    if not idempotency_key:
        return
    stored_payload = {**payload, "_statusCode": int(status_code)}
    if request_hash is not None:
        stored_payload["_requestHash"] = str(request_hash)
    cursor.execute(
        """INSERT INTO api_idempotency (
               actor_user_id, operation, idempotency_key, response_json, created_at
           ) VALUES (?, ?, ?, ?, ?)""",
        (
            actor_user_id,
            operation,
            idempotency_key,
            json.dumps(stored_payload, ensure_ascii=False),
            int(time.time()),
        ),
    )


def _package_read_allowed(cursor, session, organization_id, package_id):
    return can_read_record(
        cursor,
        session,
        session.user_id,
        organization_id,
        "goithau",
        "goi_thau",
        package_id,
    )


def _package_write_decision(cursor, session, organization_id, package_id):
    immutability = package_mutability_error(
        cursor, organization_id, package_id, lock=True
    )
    if immutability:
        raise PackageDocumentHistoricalError(immutability["message"])
    return authorize_record_write(
        cursor,
        session,
        session.user_id,
        organization_id,
        "goithau",
        "goi_thau",
        {"id": package_id},
    )


def _package_document_write_allowed(cursor, session, organization_id, package_id):
    """Return UI write eligibility without turning historical reads into errors."""

    immutability = package_mutability_error(
        cursor, organization_id, package_id, lock=False
    )
    if immutability:
        return False
    return authorize_record_write(
        cursor,
        session,
        session.user_id,
        organization_id,
        "goithau",
        "goi_thau",
        {"id": package_id},
    ).allowed


def _request_evaluation_batch_id(request):
    return str(
        request.query_params.get("evaluationBatchId") or ""
    ).strip() or None


def _bump_package_projection_revision(cursor, organization_id, package_id):
    sync_version = next_sync_version(cursor, organization_id)
    row = cursor.execute(
        """UPDATE goi_thau
              SET sync_version = ?, row_version = row_version + 1,
                  updated_at = CURRENT_TIMESTAMP
            WHERE organization_id = ? AND id = ? AND archived_at IS NULL
            RETURNING row_version""",
        (sync_version, organization_id, package_id),
    ).fetchone()
    if not row:
        raise PackageDocumentNotFoundError("Không tìm thấy gói thầu.")
    return sync_version, int(row[0])


def _validate_mutation_scope(
    cursor,
    organization_id,
    package,
    document_type,
    evaluation_batch_id,
    *,
    lock_for_mutation=False,
):
    is_evaluation = is_evaluation_document_type(document_type)
    has_lots = str(package.get("phan_lo") or "").strip() == "Có"
    if not is_evaluation:
        if evaluation_batch_id:
            raise PackageDocumentError(
                "Tài liệu chung của gói thầu không được gắn với đợt đánh giá."
            )
        return None
    if not has_lots:
        if evaluation_batch_id:
            raise PackageDocumentError(
                "Gói thầu không phân lô không có phạm vi đợt đánh giá phần lô."
            )
        return None
    if not evaluation_batch_id:
        raise PackageDocumentError(
            "Phải chọn đúng đợt đánh giá khi tải BCĐG hoặc BCTĐ."
        )
    batch_loader = (
        get_evaluation_batch_for_document_mutation
        if lock_for_mutation
        else get_evaluation_batch
    )
    batch = batch_loader(
        cursor,
        organization_id,
        package["id"],
        evaluation_batch_id,
    )
    if not batch:
        raise PackageDocumentError(
            "Không tìm thấy đợt đánh giá thuộc gói thầu này."
        )
    if str(batch.get("status") or "").upper() != "ACTIVE":
        raise PackageDocumentError(
            "Đợt đánh giá đã kết thúc; tài liệu của đợt được chuyển sang chỉ đọc."
        )
    return batch


async def list_package_documents_api(request):
    try:
        return await run_database_read(_list_package_documents, request)
    except (BlockingIOBusyError, BlockingIOTimeoutError) as exc:
        return log_and_error(
            request,
            exc,
            "list_package_documents_api",
            "PACKAGE_DOCUMENT_LIST_FAILED",
            "Không thể tải danh sách tài liệu.",
            status_code=503,
        )


def _list_package_documents(request):
    try:
        valid, session = verify_session(request)
        if not valid:
            return _document_error(str(session), "SESSION_REQUIRED", 403)
        package_id = str(request.path_params.get("package_id") or "").strip()
        organization_id = get_active_org(request, session.user_id)
        with database.get_connection() as connection:
            cursor = connection.cursor()
            package = load_package(cursor, organization_id, package_id)
            if not _package_read_allowed(
                cursor,
                session,
                organization_id,
                package_id,
            ):
                return _document_error(
                    "Không có quyền xem tài liệu của gói thầu.",
                    "PACKAGE_DOCUMENT_ACCESS_DENIED",
                    403,
                )
            documents = list_package_documents(
                cursor,
                organization_id,
                package_id,
            )
            batches = list_package_evaluation_batches(
                cursor,
                organization_id,
                package_id,
            )
            write_allowed = _package_document_write_allowed(
                cursor,
                session,
                organization_id,
                package_id,
            )
            sections = compose_document_sections(
                package,
                documents,
                batches,
                write_allowed=write_allowed,
            )
            return JSONResponse(
                {
                    "packageId": package_id,
                    "packageStatus": enum_label(
                        "goi_thau",
                        "trang_thai",
                        package_status_code(package),
                    ),
                    "sections": sections,
                    "slots": [
                        slot
                        for section in sections
                        for slot in section["slots"]
                    ],
                },
                headers={"Cache-Control": "private, no-store"},
            )
    except PackageDocumentNotFoundError as exc:
        return _document_error(str(exc), exc.code, 404)
    except OrgPermissionError as scope_error:
        return _document_error(
            "Không có quyền truy cập tổ chức.",
            scope_error.code,
            scope_error.status_code,
        )
    except Exception as exc:
        return log_and_error(
            request,
            exc,
            "list_package_documents_api",
            "PACKAGE_DOCUMENT_LIST_FAILED",
            "Không thể tải danh sách tài liệu.",
        )


def _prepare_package_document_upload(request):
    valid, session = verify_session(request)
    if not valid:
        return _document_error(str(session), "SESSION_REQUIRED", 403)
    package_id = str(request.path_params.get("package_id") or "").strip()
    document_type = str(
        request.path_params.get("document_type") or ""
    ).strip()
    evaluation_batch_id = _request_evaluation_batch_id(request)
    idempotency_key, idempotency_error = _document_idempotency_key(request)
    if idempotency_error:
        return idempotency_error
    if document_type_definition(document_type) is None:
        return _document_error(
            "Loại tài liệu không hợp lệ.",
            "PACKAGE_DOCUMENT_TYPE_INVALID",
            400,
        )
    organization_id = get_active_org(request, session.user_id)
    operation = _document_operation(
        organization_id,
        package_id,
        document_type,
        evaluation_batch_id,
        "upload",
    )

    with database.get_connection() as read_connection:
        cursor = read_connection.cursor()
        package = load_package(cursor, organization_id, package_id)
        decision = _package_write_decision(
            cursor,
            session,
            organization_id,
            package_id,
        )
        if not decision.allowed:
            return _document_error(
                decision.message or "Không có quyền sửa gói thầu.",
                "PACKAGE_DOCUMENT_ACCESS_DENIED",
                403,
            )
        if document_type not in allowed_upload_types(package):
            return _document_error(
                "Loại tài liệu này không được tải lên ở bước hiện tại.",
                "PACKAGE_DOCUMENT_STEP_LOCKED",
                409,
            )
        _validate_mutation_scope(
            cursor,
            organization_id,
            package,
            document_type,
            evaluation_batch_id,
        )

    return (session, package_id, document_type, evaluation_batch_id,
            idempotency_key, organization_id, operation)


def _commit_package_document_upload(
    request, session, package_id, document_type, evaluation_batch_id,
    idempotency_key, organization_id, operation, new_storage_key,
    original_filename, content_type, stored_size, checksum,
):
    # This worker owns the transaction and newly staged file until commit.
    # Caller cancellation cannot delete a file whose transaction may commit.
    connection = None
    accepted = False
    try:
        connection = database.get_connection()
        connection.execute("BEGIN")
        cursor = connection.cursor()
        authority_valid, current_session = verify_session_in_transaction(
            cursor,
            request,
        )
        if (
            not authority_valid
            or str(current_session.user_id) != str(session.user_id)
        ):
            raise PackageDocumentAuthorizationError(
                current_session
                if not authority_valid
                else "Phiên đăng nhập đã thay đổi. Vui lòng đăng nhập lại."
            )
        session = current_session
        package = load_package_for_document_mutation(
            cursor, organization_id, package_id
        )
        decision = _package_write_decision(
            cursor,
            session,
            organization_id,
            package_id,
        )
        if not decision.allowed:
            raise PackageDocumentError(
                decision.message or "Không còn quyền sửa gói thầu."
            )
        replay = _document_idempotency_replay(
            cursor,
            actor_user_id=session.user_id,
            operation=operation,
            idempotency_key=idempotency_key,
            request_hash=checksum,
        )
        if replay:
            connection.commit()
            connection.close()
            connection = None
            replay_payload, replay_status = replay
            return JSONResponse(replay_payload, status_code=replay_status)
        if document_type not in allowed_upload_types(package):
            raise PackageDocumentError(
                "Gói thầu đã chuyển bước; không thể tải loại tài liệu này."
            )
        _validate_mutation_scope(
            cursor,
            organization_id,
            package,
            document_type,
            evaluation_batch_id,
            lock_for_mutation=True,
        )
        document, previous = upsert_package_document(
            cursor,
            organization_id=organization_id,
            package=package,
            document_type=document_type,
            original_filename=original_filename,
            storage_key=new_storage_key,
            content_type=content_type,
            size_bytes=stored_size,
            sha256=checksum,
            uploaded_by_id=session.user_id,
            evaluation_batch_id=evaluation_batch_id,
        )
        projection_revision, package_row_version = _bump_package_projection_revision(
            cursor, organization_id, package_id
        )
        document["projectionRevision"] = projection_revision
        document["packageRowVersion"] = package_row_version
        old_storage_key = previous.get("storage_key") if previous else None
        insert_activity_events(
            cursor,
            organization_id=organization_id,
            owner_type=package["owner_type"],
            actor_user_id=session.user_id,
            occurred_at=vietnam_now_sql(),
            events=[document_activity_event(
                action=(
                    "package_document.replaced"
                    if previous else "package_document.uploaded"
                ),
                package=package,
                document_id=document["id"],
                filename=document["originalFilename"],
                document_type=document_type,
                size_bytes=stored_size,
                client_mutation_id=idempotency_key,
                request_id=get_request_id(request),
            )],
        )
        log_audit(
            "package_document.replaced" if previous else "package_document.uploaded",
            actor_user_id=session.user_id,
            organization_id=organization_id,
            target_type="package_document",
            target_id=document["id"],
            request=request,
            metadata={
                "packageId": package_id,
                "documentType": document_type,
                "evaluationBatchId": evaluation_batch_id,
                "sizeBytes": stored_size,
            },
            cursor=cursor,
            required=True,
        )
        response_payload = {"success": True, "document": document}
        response_status = 200 if previous else 201
        _store_document_idempotency(
            cursor,
            actor_user_id=session.user_id,
            operation=operation,
            idempotency_key=idempotency_key,
            payload=response_payload,
            status_code=response_status,
            request_hash=checksum,
        )
        enqueue_websocket_event(
            cursor,
            "broadcast",
            organization_id=organization_id,
            payload={
                "event": "package_documents_changed",
                "packageId": package_id,
                "revision": projection_revision,
            },
        )
        connection.commit()
        connection.close()
        connection = None
        accepted = True
        if old_storage_key and old_storage_key != new_storage_key:
            try:
                remove_storage_key(old_storage_key)
            except Exception as cleanup_error:
                log_error(cleanup_error, "package_document_old_file_cleanup")
        return JSONResponse(response_payload, status_code=response_status)
    except BaseException:
        if connection:
            connection.rollback()
        raise
    finally:
        if connection:
            connection.close()
        if not accepted:
            try:
                remove_storage_key(new_storage_key)
            except OSError as cleanup_error:
                log_error(cleanup_error, "package_document_failed_upload_cleanup")


async def _remove_staged_package_document_upload(storage_key):
    while True:
        try:
            await run_blocking_io(
                remove_storage_key, storage_key, timeout_seconds=None,
                lane="package_document_cleanup",
            )
            return
        except BlockingIOBusyError:
            # Cleanup retains ownership while the bounded lane is saturated.
            await asyncio.sleep(0.01)
        except OSError as cleanup_error:
            log_error(cleanup_error, "package_document_staging_cleanup")
            return


async def _stage_package_document_upload(upload_path, storage_key, *, timeout_seconds=15):
    worker_started = False

    def persist():
        nonlocal worker_started
        worker_started = True
        return persist_upload_path(upload_path, storage_key)

    staging = asyncio.create_task(run_blocking_io(persist, timeout_seconds=None))
    try:
        return await asyncio.wait_for(asyncio.shield(staging), timeout=timeout_seconds)
    except BaseException:
        async def finish_and_remove():
            # The copy may still own the source and rename its destination.
            # Keep the spool alive, then remove only after that worker finishes.
            await asyncio.gather(staging, return_exceptions=True)
            if worker_started:
                await _remove_staged_package_document_upload(storage_key)

        cleanup = asyncio.create_task(finish_and_remove())
        try:
            await finish_submitted_task(cleanup)
        except asyncio.CancelledError:
            pass  # Cleanup finished; preserve the original cancellation/deadline.
        raise


async def _submit_staged_package_document_upload(storage_key, *args):
    worker_started = False

    def commit():
        nonlocal worker_started
        worker_started = True
        return _commit_package_document_upload(*args)

    try:
        return await run_database_write(commit)
    except Exception:
        if not worker_started:
            # Admission/submission failed before a worker could own the file.
            await _remove_staged_package_document_upload(storage_key)
        raise


async def upload_package_document_api(request):
    new_storage_key = None
    handed_to_commit = False
    try:
        prepared = await run_database_read(_prepare_package_document_upload, request)
        if isinstance(prepared, JSONResponse):
            return prepared
        (session, package_id, document_type, evaluation_batch_id,
         idempotency_key, organization_id, operation) = prepared

        form = await request.form()
        upload = form.get("file")
        if upload is None or not getattr(upload, "filename", None):
            return _document_error(
                "Vui lòng chọn tệp cần tải lên.",
                "PACKAGE_DOCUMENT_FILE_REQUIRED",
                400,
            )
        original_filename = clean_original_filename(upload.filename)
        extension, archive_kind, content_type = media_for_filename(
            original_filename
        )
        async with spooled_upload(
            upload,
            max_bytes=MAX_PACKAGE_DOCUMENT_BYTES,
            suffix=extension,
        ) as (upload_path, upload_size, head):
            if upload_size <= 0:
                raise PackageDocumentError("Tệp tải lên đang trống.")
            if archive_kind == "pdf":
                if not head.startswith(b"%PDF-"):
                    raise PackageDocumentError("Cấu trúc tệp PDF không hợp lệ.")
                await run_blocking_io(
                    validate_pdf_path,
                    upload_path,
                    timeout_seconds=10,
                )
            else:
                if not head.startswith(b"PK"):
                    raise PackageDocumentError(
                        "Cấu trúc tệp Office không hợp lệ."
                    )
                await run_document_job_async(
                    "validate_ooxml",
                    {
                        "content_path": str(upload_path),
                        "kind": archive_kind,
                    },
                    timeout_seconds=20,
                )

            staging_key = create_storage_key(
                organization_id,
                package_id,
                extension,
            )
            stored_size, checksum = await _stage_package_document_upload(
                upload_path, staging_key,
            )
            new_storage_key = staging_key

        commit = asyncio.create_task(_submit_staged_package_document_upload(
            new_storage_key,
            request, session, package_id, document_type, evaluation_batch_id,
            idempotency_key, organization_id, operation, new_storage_key,
            original_filename, content_type, stored_size, checksum,
        ))
        handed_to_commit = True
        # Retrieve failures even when the client stops waiting for its mutation.
        commit.add_done_callback(lambda task: None if task.cancelled() else task.exception())
        return await asyncio.shield(commit)
    except (PackageDocumentError, DocumentWorkerInputError) as exc:
        return _document_error(
            str(exc),
            getattr(exc, "code", "PACKAGE_DOCUMENT_FILE_INVALID"),
            int(getattr(exc, "status_code", 400)),
        )
    except DocumentWorkerError as exc:
        return log_and_error(
            request,
            exc,
            "upload_package_document_api",
            "PACKAGE_DOCUMENT_VALIDATION_UNAVAILABLE",
            "Dịch vụ kiểm tra tài liệu tạm thời không khả dụng.",
            status_code=503,
        )
    except OrgPermissionError as scope_error:
        return _document_error(
            "Không có quyền truy cập tổ chức.",
            scope_error.code,
            scope_error.status_code,
        )
    except (BlockingIOBusyError, TimeoutError) as exc:
        return log_and_error(
            request, exc, "upload_package_document_api",
            "PACKAGE_DOCUMENT_UPLOAD_FAILED",
            "Dịch vụ tài liệu tạm thời không khả dụng.", status_code=503,
        )
    except Exception as exc:
        return log_and_error(
            request,
            exc,
            "upload_package_document_api",
            "PACKAGE_DOCUMENT_UPLOAD_FAILED",
            "Không thể tải tài liệu lên.",
        )
    finally:
        if new_storage_key and not handed_to_commit:
            await finish_submitted_task(asyncio.create_task(
                _remove_staged_package_document_upload(new_storage_key),
            ))


def package_document_routes(Route):
    return [
        Route(
            "/api/packages/{package_id}/documents",
            list_package_documents_api,
            methods=["GET"],
        ),
        Route(
            "/api/packages/{package_id}/documents/{document_type}",
            upload_package_document_api,
            methods=["PUT"],
        ),
        Route(
            "/api/packages/{package_id}/documents/{document_type}",
            delete_package_document_api,
            methods=["DELETE"],
        ),
        Route(
            "/api/packages/{package_id}/documents/{document_type}/download",
            download_package_document_api,
            methods=["GET"],
        ),
    ]


async def download_package_document_api(request):
    try:
        return await run_database_write(_download_package_document, request)
    except BlockingIOBusyError as exc:
        return log_and_error(
            request, exc, "download_package_document_api",
            "PACKAGE_DOCUMENT_DOWNLOAD_FAILED",
            "Dịch vụ tài liệu tạm thời không khả dụng.", status_code=503,
        )


def _download_package_document(request):
    connection = None
    try:
        valid, session = verify_session(request)
        if not valid:
            return _document_error(str(session), "SESSION_REQUIRED", 403)
        package_id = str(request.path_params.get("package_id") or "").strip()
        document_type = str(
            request.path_params.get("document_type") or ""
        ).strip()
        evaluation_batch_id = _request_evaluation_batch_id(request)
        organization_id = get_active_org(request, session.user_id)
        connection = database.get_connection()
        connection.execute("BEGIN")
        cursor = connection.cursor()
        load_package(cursor, organization_id, package_id)
        if not _package_read_allowed(
            cursor,
            session,
            organization_id,
            package_id,
        ):
            connection.rollback()
            return _document_error(
                "Không có quyền tải tài liệu của gói thầu.",
                "PACKAGE_DOCUMENT_ACCESS_DENIED",
                403,
            )
        document = get_package_document(
            cursor,
            organization_id,
            package_id,
            document_type,
            evaluation_batch_id,
        )
        if not document:
            raise PackageDocumentNotFoundError("Không tìm thấy tài liệu.")
        path = resolve_storage_key(document["storage_key"])
        if not path.is_file():
            raise PackageDocumentNotFoundError("Tệp tài liệu không còn tồn tại.")
        log_audit(
            "package_document.downloaded",
            actor_user_id=session.user_id,
            organization_id=organization_id,
            target_type="package_document",
            target_id=document["id"],
            request=request,
            metadata={
                "packageId": package_id,
                "documentType": document_type,
                "evaluationBatchId": evaluation_batch_id,
                "sizeBytes": document["size_bytes"],
            },
            cursor=cursor,
            required=True,
        )
        connection.commit()
        connection.close()
        connection = None
        return FileResponse(
            path,
            filename=document["original_filename"],
            media_type=document["content_type"],
            headers={
                "Cache-Control": "private, no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )
    except PackageDocumentNotFoundError as exc:
        if connection:
            connection.rollback()
        return _document_error(str(exc), exc.code, 404)
    except PackageDocumentError as exc:
        if connection:
            connection.rollback()
        return _document_error(str(exc), exc.code, 409)
    except OrgPermissionError as scope_error:
        if connection:
            connection.rollback()
        return _document_error(
            "Không có quyền truy cập tổ chức.",
            scope_error.code,
            scope_error.status_code,
        )
    except Exception as exc:
        if connection:
            connection.rollback()
        return log_and_error(
            request,
            exc,
            "download_package_document_api",
            "PACKAGE_DOCUMENT_DOWNLOAD_FAILED",
            "Không thể tải tài liệu.",
        )
    finally:
        if connection:
            connection.close()


async def delete_package_document_api(request):
    try:
        return await run_database_write(_delete_package_document, request)
    except BlockingIOBusyError as exc:
        return log_and_error(
            request, exc, "delete_package_document_api",
            "PACKAGE_DOCUMENT_DELETE_FAILED",
            "Dịch vụ tài liệu tạm thời không khả dụng.", status_code=503,
        )


def _delete_package_document(request):
    connection = None
    deleted = None
    try:
        valid, session = verify_session(request)
        if not valid:
            return _document_error(str(session), "SESSION_REQUIRED", 403)
        package_id = str(request.path_params.get("package_id") or "").strip()
        document_type = str(
            request.path_params.get("document_type") or ""
        ).strip()
        evaluation_batch_id = _request_evaluation_batch_id(request)
        idempotency_key, idempotency_error = _document_idempotency_key(request)
        if idempotency_error:
            return idempotency_error
        organization_id = get_active_org(request, session.user_id)
        operation = _document_operation(
            organization_id,
            package_id,
            document_type,
            evaluation_batch_id,
            "delete",
        )
        connection = database.get_connection()
        connection.execute("BEGIN")
        cursor = connection.cursor()
        package = load_package_for_document_mutation(
            cursor, organization_id, package_id
        )
        decision = _package_write_decision(
            cursor,
            session,
            organization_id,
            package_id,
        )
        if not decision.allowed:
            connection.rollback()
            return _document_error(
                decision.message or "Không có quyền sửa gói thầu.",
                "PACKAGE_DOCUMENT_ACCESS_DENIED",
                403,
            )
        replay = _document_idempotency_replay(
            cursor,
            actor_user_id=session.user_id,
            operation=operation,
            idempotency_key=idempotency_key,
        )
        if replay:
            connection.commit()
            connection.close()
            connection = None
            replay_payload, replay_status = replay
            return JSONResponse(replay_payload, status_code=replay_status)
        if document_type not in allowed_upload_types(package):
            connection.rollback()
            return _document_error(
                "Không thể xóa tài liệu của bước đã hoàn thành.",
                "PACKAGE_DOCUMENT_STEP_LOCKED",
                409,
            )
        _validate_mutation_scope(
            cursor,
            organization_id,
            package,
            document_type,
            evaluation_batch_id,
            lock_for_mutation=True,
        )
        deleted = delete_package_document(
            cursor,
            organization_id,
            package_id,
            document_type,
            evaluation_batch_id,
        )
        projection_revision, package_row_version = _bump_package_projection_revision(
            cursor, organization_id, package_id
        )
        insert_activity_events(
            cursor,
            organization_id=organization_id,
            owner_type=package["owner_type"],
            actor_user_id=session.user_id,
            occurred_at=vietnam_now_sql(),
            events=[document_activity_event(
                action="package_document.deleted",
                package=package,
                document_id=deleted["id"],
                filename=deleted["original_filename"],
                document_type=document_type,
                size_bytes=None,
                client_mutation_id=idempotency_key,
                request_id=get_request_id(request),
            )],
        )
        log_audit(
            "package_document.deleted",
            actor_user_id=session.user_id,
            organization_id=organization_id,
            target_type="package_document",
            target_id=deleted["id"],
            request=request,
            metadata={
                "packageId": package_id,
                "documentType": document_type,
                "evaluationBatchId": evaluation_batch_id,
            },
            cursor=cursor,
            required=True,
        )
        response_payload = {
            "success": True,
            "projectionRevision": projection_revision,
            "packageRowVersion": package_row_version,
        }
        _store_document_idempotency(
            cursor,
            actor_user_id=session.user_id,
            operation=operation,
            idempotency_key=idempotency_key,
            payload=response_payload,
            status_code=200,
        )
        enqueue_websocket_event(
            cursor,
            "broadcast",
            organization_id=organization_id,
            payload={
                "event": "package_documents_changed",
                "packageId": package_id,
                "revision": projection_revision,
            },
        )
        connection.commit()
        connection.close()
        connection = None
        try:
            remove_storage_key(deleted["storage_key"])
        except Exception as cleanup_error:
            log_error(cleanup_error, "package_document_deleted_file_cleanup")
        return JSONResponse(response_payload)
    except PackageDocumentNotFoundError as exc:
        if connection:
            connection.rollback()
        return _document_error(str(exc), exc.code, 404)
    except PackageDocumentError as exc:
        if connection:
            connection.rollback()
        return _document_error(str(exc), exc.code, 409)
    except OrgPermissionError as scope_error:
        if connection:
            connection.rollback()
        return _document_error(
            "Không có quyền truy cập tổ chức.",
            scope_error.code,
            scope_error.status_code,
        )
    except Exception as exc:
        if connection:
            connection.rollback()
        return log_and_error(
            request,
            exc,
            "delete_package_document_api",
            "PACKAGE_DOCUMENT_DELETE_FAILED",
            "Không thể xóa tài liệu.",
        )
    finally:
        if connection:
            connection.close()
