"""Shared domain rules."""
