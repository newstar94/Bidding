"""One-time password reset token persistence and redemption."""

import hashlib
import secrets
import time
import uuid

from backend.auth.auth_helper import hash_password
from backend.auth.identity import normalize_email, normalize_username
from backend.auth.session_store import revoke_user_sessions
from backend.shared.logging_utils import log_audit


RESET_TOKEN_TTL_SECONDS = 30 * 60
PASSWORD_SETUP_TOKEN_TTL_SECONDS = 2 * 60 * 60


class InvalidResetToken(ValueError):
    """Raised for missing, expired, already-used or unknown reset tokens."""


def _token_hash(token):
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()


def invalidate_password_reset_tokens(cursor, user_id, *, now=None):
    """Invalidate unused recovery links while the caller holds the account lock."""

    current_time = int(time.time() if now is None else now)
    cursor.execute(
        "UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL",
        (current_time, user_id),
    )


def create_password_reset(database, username, email, requested_ip, now=None):
    """Create a reset token when the identity matches, otherwise return None.

    The caller must always return the same public response for both outcomes.
    The raw token exists only in the returned email payload and is never stored.
    """
    normalized_username = normalize_username(username)
    normalized_email = normalize_email(email)
    current_time = int(time.time() if now is None else now)
    conn = database.get_connection()
    try:
        # Housekeeping must release token locks before identity/account locking.
        # Keeping it separate preserves cleanup even for mismatched identities.
        conn.execute("BEGIN")
        conn.execute(
            "DELETE FROM password_reset_tokens WHERE expires_at <= ? OR used_at IS NOT NULL",
            (current_time,),
        )
        conn.commit()
        conn.execute("BEGIN")
        row = conn.execute(
            """
            SELECT id, ho_ten, ten_dang_nhap, email
            FROM tai_khoan
            WHERE username_norm = ? AND email_norm = ?
              AND trang_thai = 'active'
            LIMIT 1
            FOR UPDATE
            """,
            (normalized_username, normalized_email),
        ).fetchone()
        if row is None:
            conn.commit()
            return None

        user = dict(row)
        current_time = int(time.time() if now is None else now)
        invalidate_password_reset_tokens(conn, user["id"], now=current_time)
        raw_token = secrets.token_urlsafe(32)
        conn.execute(
            """
            INSERT INTO password_reset_tokens (
                id, user_id, token_hash, expires_at, used_at, requested_ip, created_at
            ) VALUES (?, ?, ?, ?, NULL, ?, ?)
            """,
            (
                str(uuid.uuid4()),
                user["id"],
                _token_hash(raw_token),
                current_time + RESET_TOKEN_TTL_SECONDS,
                str(requested_ip or "")[:128],
                current_time,
            ),
        )
        conn.commit()
        return {
            "token": raw_token,
            "email": user["email"],
            "name": user["ho_ten"],
            "username": user["ten_dang_nhap"],
        }
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def create_password_setup_token(
    cursor,
    user_id,
    *,
    requested_ip="",
    now=None,
    ttl_seconds=PASSWORD_SETUP_TOKEN_TTL_SECONDS,
):
    """Create one password-setup token inside the caller's transaction."""

    current_time = int(time.time() if now is None else now)
    account = cursor.execute(
        "SELECT id FROM tai_khoan WHERE id = ? FOR UPDATE",
        (user_id,),
    ).fetchone()
    if account is None:
        raise InvalidResetToken("Reset token user no longer exists.")
    current_time = int(time.time() if now is None else now)
    invalidate_password_reset_tokens(cursor, user_id, now=current_time)
    raw_token = secrets.token_urlsafe(32)
    expires_at = current_time + int(ttl_seconds)
    cursor.execute(
        """INSERT INTO password_reset_tokens (
               id, user_id, token_hash, expires_at, used_at, requested_ip, created_at
           ) VALUES (?, ?, ?, ?, NULL, ?, ?)""",
        (
            str(uuid.uuid4()),
            user_id,
            _token_hash(raw_token),
            expires_at,
            str(requested_ip or "")[:128],
            current_time,
        ),
    )
    return {"token": raw_token, "expiresAt": expires_at}


def redeem_password_reset(
    database,
    token,
    new_password,
    now=None,
    *,
    password_hash=None,
    audit=log_audit,
    request=None,
):
    """Atomically consume a token, change the password and revoke sessions."""
    raw_token = str(token or "")
    if not raw_token or len(raw_token) > 512:
        raise InvalidResetToken("Reset token is invalid.")

    current_time = int(time.time() if now is None else now)
    conn = database.get_connection()
    try:
        conn.execute("BEGIN")
        row = conn.execute(
            """
            SELECT id, user_id, expires_at, used_at
            FROM password_reset_tokens
            WHERE token_hash = ?
            LIMIT 1
            """,
            (_token_hash(raw_token),),
        ).fetchone()
        if row is None or row["used_at"] is not None or int(row["expires_at"]) <= current_time:
            raise InvalidResetToken("Reset token is invalid or expired.")

        user_id = row["user_id"]
        account = conn.execute(
            """SELECT id FROM tai_khoan
               WHERE id = ? AND trang_thai = 'active' FOR UPDATE""",
            (user_id,),
        ).fetchone()
        if account is None:
            raise InvalidResetToken("Reset token user no longer exists.")
        # Every recovery writer locks the account before touching its tokens.
        # Reload after waiting so a completed credential rotation wins.
        row = conn.execute(
            """SELECT id, user_id, expires_at, used_at
               FROM password_reset_tokens
               WHERE token_hash = ? AND user_id = ?
               LIMIT 1 FOR UPDATE""",
            (_token_hash(raw_token), user_id),
        ).fetchone()
        current_time = int(time.time() if now is None else now)
        if row is None or row["used_at"] is not None or int(row["expires_at"]) <= current_time:
            raise InvalidResetToken("Reset token is invalid or expired.")

        consumed = conn.execute(
            """
            UPDATE password_reset_tokens
            SET used_at = ?
            WHERE id = ? AND used_at IS NULL AND expires_at > ?
            """,
            (current_time, row["id"], current_time),
        )
        if consumed.rowcount != 1:
            raise InvalidResetToken("Reset token has already been used.")

        replacement_password_hash = password_hash or hash_password(new_password)
        updated = conn.execute(
            """UPDATE tai_khoan SET mat_khau = ?
               WHERE id = ? AND trang_thai = 'active'""",
            (replacement_password_hash, user_id),
        )
        if updated.rowcount != 1:
            raise InvalidResetToken("Reset token user no longer exists.")
        revoke_user_sessions(conn, user_id, now=current_time)

        invalidate_password_reset_tokens(conn, user_id, now=current_time)
        audit(
            "auth.password_reset",
            actor_user_id=user_id,
            target_type="tai_khoan",
            target_id=user_id,
            request=request,
            metadata={"sessions_revoked": True},
            cursor=conn,
            required=True,
        )
        conn.commit()
        return user_id
    except InvalidResetToken:
        conn.rollback()
        raise
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
