"""Bounded webhook inbox: verify first, persist, ACK quickly."""

from __future__ import annotations

from hashlib import sha256
import json
import time

from starlette.responses import JSONResponse

from backend.db.db_helper import database
from backend.shared.async_io import BlockingIOBusyError
from backend.shared.database_io import run_database_write
from backend.shared.logging_utils import log_error

from .providers.base import PaymentProviderError
from .runtime import payment_provider_registry


MAX_WEBHOOK_BYTES = 262_144


def webhook_event_id(profile_id, payload_hash):
    identity = f"{profile_id}|{payload_hash}".encode("utf-8")
    return f"payment-event-{sha256(identity).hexdigest()[:32]}"


def _payment_webhook_sync(request, profile_id, envelope, raw):
    connection = None
    try:
        connection = database.get_connection()
        connection.execute("BEGIN")
        profile = connection.execute(
            """SELECT id, provider, environment, mode, readiness_status,
                      credential_reference, timeout_ms, max_attempts
                 FROM payment_provider_profiles WHERE id = ?""",
            (profile_id,),
        ).fetchone()
        if not profile:
            connection.rollback()
            return JSONResponse({"error": "Provider profile không tồn tại.", "code": "NOT_FOUND"}, status_code=404)
        if str(profile["provider"] or "").strip().casefold() == "fake":
            connection.rollback()
            return JSONResponse(
                {
                    "error": "Provider giả lập không tiếp nhận webhook công khai.",
                    "code": "PROVIDER_EVENT_UNVERIFIED",
                },
                status_code=400,
            )
        try:
            provider = payment_provider_registry().resolve(profile)
            signed_data = provider.verify_webhook(envelope)
        except PaymentProviderError as error:
            connection.rollback()
            status_code = (
                503 if error.code == "PROVIDER_CREDENTIAL_UNAVAILABLE" else 400
            )
            return JSONResponse(
                {"error": str(error), "code": error.code}, status_code=status_code
            )
        payload_hash = sha256(raw).hexdigest()
        order_code = str(signed_data.get("orderCode") or "")
        payment_link_id = str(signed_data.get("paymentLinkId") or "")
        reference = str(signed_data.get("reference") or "")
        dedupe_key = "|".join((order_code, payment_link_id, reference))[:500]
        if not dedupe_key.strip("|"):
            connection.rollback()
            return JSONResponse({"error": "Webhook thiếu identity.", "code": "WEBHOOK_INVALID"}, status_code=400)
        event_id = webhook_event_id(profile_id, payload_hash)
        conflicting_event = connection.execute(
            """SELECT id FROM payment_webhook_events
                WHERE provider_profile_id = ? AND dedupe_key = ?
                  AND payload_hash <> ?
                LIMIT 1 FOR UPDATE""",
            (profile_id, dedupe_key, payload_hash),
        ).fetchone()
        initial_status = "review" if conflicting_event else "pending"
        initial_error = "WEBHOOK_DEDUPE_PAYLOAD_MISMATCH" if conflicting_event else None
        inserted = connection.execute(
            """INSERT INTO payment_webhook_events
                   (id, provider_profile_id, dedupe_key, payload_hash,
                    signed_fields_json, status, available_at, last_error_code)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(provider_profile_id, dedupe_key, payload_hash) DO NOTHING""",
            (
                event_id, profile_id, dedupe_key, payload_hash,
                json.dumps(signed_data, ensure_ascii=False, separators=(",", ":")),
                initial_status,
                int(time.time()),
                initial_error,
            ),
        )
        connection.commit()
        return JSONResponse(
            {
                "received": True,
                "duplicate": inserted.rowcount == 0,
                "reviewRequired": bool(conflicting_event),
            },
            status_code=202,
        )
    except Exception as error:  # noqa: BLE001 - webhook returns bounded public error
        if connection:
            connection.rollback()
        log_error(error, "payment_webhook_api")
        return JSONResponse({"error": "Không thể tiếp nhận webhook.", "code": "WEBHOOK_FAILED"}, status_code=500)
    finally:
        if connection:
            connection.close()


async def payment_webhook_api(request):
    try:
        profile_id = str(request.path_params["profile_id"] or "").strip()
        raw = await request.body()
        if len(raw) > MAX_WEBHOOK_BYTES:
            return JSONResponse({"error": "Webhook quá lớn.", "code": "WEBHOOK_TOO_LARGE"}, status_code=413)
        try:
            envelope = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return JSONResponse({"error": "Webhook không phải JSON hợp lệ.", "code": "WEBHOOK_INVALID"}, status_code=400)
        return await run_database_write(
            _payment_webhook_sync,
            request,
            profile_id,
            envelope,
            raw,
        )
    except BlockingIOBusyError:
        response = JSONResponse(
            {"error": "Hệ thống đang bận tiếp nhận webhook.", "code": "WEBHOOK_BUSY"},
            status_code=503,
        )
        response.headers["Retry-After"] = "1"
        return response
    except Exception as error:  # noqa: BLE001 - webhook returns bounded public error
        log_error(error, "payment_webhook_api")
        return JSONResponse({"error": "Không thể tiếp nhận webhook.", "code": "WEBHOOK_FAILED"}, status_code=500)
