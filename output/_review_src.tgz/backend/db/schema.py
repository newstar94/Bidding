import re


MONEY_COLUMNS = frozenset({
    ("goi_dich_vu", "gia_ca"),
    ("billing_prices", "subtotal_amount"),
    ("billing_prices", "tax_amount"),
    ("billing_prices", "total_amount"),
    ("billing_quotes", "subtotal_amount"),
    ("billing_quotes", "tax_amount"),
    ("billing_quotes", "total_amount"),
    ("billing_orders", "subtotal_amount"),
    ("billing_orders", "tax_amount"),
    ("billing_orders", "total_amount"),
    ("payment_transactions", "verified_paid_amount"),
    ("payment_transactions", "fee_amount"),
    ("payment_transactions", "net_settled_amount"),
    ("billing_refund_intents", "amount"),
    ("ke_hoach_lcnt", "tong_muc_dau_tu"),
    ("ke_hoach_cong_viec", "gia_tri"),
    ("goi_thau", "gia_goi_thau"),
    ("goi_thau", "gia_trung_thau"),
    ("goi_thau", "gia_tri_dam_bao_du_thau"),
    ("goi_thau_phan_lo", "gia_tri_phan_lo"),
    ("goi_thau_phan_lo", "bao_dam_du_thau"),
    ("goi_thau_phan_lo", "gia_trung_thau"),
    ("goi_thau_hang_hoa", "don_gia_du_toan"),
    ("goi_thau_hang_hoa", "thanh_tien_du_toan"),
    ("hang_hoa_du_thau_nha_thau", "don_gia_du_thau"),
    ("hang_hoa_du_thau_nha_thau", "thanh_tien_du_thau"),
    ("hang_hoa_du_thau_nha_thau", "gia_tri_co_so_sau_giam_gia"),
    ("hang_hoa_du_thau_nha_thau", "gia_tri_cong_uu_dai"),
    ("hang_hoa_du_thau_nha_thau", "thanh_tien_sau_uu_dai"),
    ("goi_thau_tuy_chon_mua_them", "gia_tri_uoc_tinh"),
    ("hop_dong", "gia_tri"),
    ("thong_tin_mo_thau", "gia_du_thau"),
    ("thong_tin_mo_thau", "gia_sau_giam_gia"),
    ("thong_tin_mo_thau", "tong_gia_tri_cong_uu_dai"),
    ("thong_tin_mo_thau", "gia_so_sanh_sau_uu_dai"),
    ("thong_tin_mo_thau", "gia_danh_gia_sau_uu_dai"),
    ("thong_tin_mo_thau", "gia_tri_dam_bao"),
    ("ket_qua_danh_gia_nha_thau", "gia_xep_hang"),
    ("ket_qua_danh_gia_nha_thau", "gia_de_nghi_trung_thau"),
})


SCHEMA_DINH_NGHIA = {
    "procurement_monitor_state": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "package_root_id": "TEXT NOT NULL CHECK(package_root_id != '')",
            "notice_no": "TEXT NOT NULL CHECK(length(notice_no) = 12)",
            "seen_json": "TEXT NOT NULL DEFAULT '{}'",
            "completed_slot": "BIGINT NOT NULL DEFAULT 0",
            "attempt_slot": "BIGINT NOT NULL DEFAULT 0",
            "attempts": "INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0)",
            "lease_token": "TEXT",
            "lease_until": "BIGINT NOT NULL DEFAULT 0",
            "retry_after": "BIGINT NOT NULL DEFAULT 0",
            "last_checked_at": "BIGINT",
            "last_error": "TEXT"
        },
        "primary_keys": ["organization_id", "package_root_id", "notice_no"]
    },
    "database_metadata": {
        "columns": {
            "id": "INTEGER PRIMARY KEY CHECK(id = 1)",
            "schema_version": "INTEGER NOT NULL CHECK(schema_version > 0)",
            "baseline": "TEXT NOT NULL CHECK(baseline != '')",
            "installation_id": "TEXT NOT NULL CHECK(installation_id != '')",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "goi_dich_vu": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "ten_goi": "TEXT",
            "gia_ca": "INTEGER NOT NULL CHECK(typeof(gia_ca) = 'integer' AND gia_ca >= 0)",
            "han_muc_nhan_su": "INTEGER NOT NULL CHECK(han_muc_nhan_su > 0)",
            "document_export_word": "INTEGER NOT NULL DEFAULT 1 CHECK(document_export_word IN (0,1))",
            "document_export_excel": "INTEGER NOT NULL DEFAULT 1 CHECK(document_export_excel IN (0,1))",
            "document_export_award_result_excel": "INTEGER NOT NULL DEFAULT 1 CHECK(document_export_award_result_excel IN (0,1))",
            "trang_thai": "TEXT NOT NULL DEFAULT 'active' CHECK(trang_thai IN ('active', 'inactive'))",
            "mo_ta": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        }
    },
    "tai_khoan": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "ten_dang_nhap": "TEXT",
            "username_norm": "TEXT UNIQUE",
            "mat_khau": "TEXT NOT NULL",
            "ho_ten": "TEXT",
            "vai_tro": "TEXT NOT NULL DEFAULT 'user' CHECK(vai_tro IN ('super_admin', 'user'))",
            "trang_thai": "TEXT NOT NULL DEFAULT 'active' CHECK(trang_thai IN ('active', 'inactive'))",
            "email": "TEXT NOT NULL",
            "email_norm": "TEXT NOT NULL UNIQUE CHECK(email_norm != '')",
            "anh_dai_dien": "TEXT",
            "da_xac_minh": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(da_xac_minh) = 'integer' AND da_xac_minh IN (0,1))",
            "registration_verified_at": "INTEGER CHECK(registration_verified_at IS NULL OR registration_verified_at > 0)",
            "ma_xac_minh": "TEXT",
            "han_xac_minh": "INTEGER",
            "username_da_dat": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(username_da_dat) = 'integer' AND username_da_dat IN (0,1))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "auth_sessions": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "user_id": "TEXT NOT NULL",
            "token_hash": "TEXT NOT NULL UNIQUE CHECK(token_hash != '')",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "last_seen_at": "INTEGER NOT NULL CHECK(last_seen_at > 0)",
            "idle_expires_at": "INTEGER NOT NULL CHECK(idle_expires_at > 0)",
            "absolute_expires_at": "INTEGER NOT NULL CHECK(absolute_expires_at > 0)",
            "revoked_at": "INTEGER",
            "remember_me": "INTEGER NOT NULL DEFAULT 0 CHECK(remember_me IN (0,1))",
            "device_info": "TEXT",
            "privileged_reauth_at": "INTEGER",
            "active_role": "TEXT CHECK(active_role IS NULL OR active_role IN ('super_admin', 'manager', 'employee'))",
            "active_role_organization_id": "TEXT CHECK(active_role_organization_id IS NULL OR (active_role IS NOT NULL AND TRIM(active_role_organization_id) != ''))"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "dinh_danh_ngoai": {
        "columns": {
            "issuer": "TEXT NOT NULL",
            "subject": "TEXT NOT NULL",
            "user_id": "TEXT NOT NULL",
            "email_norm": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["issuer", "subject"],
        "unique_constraints": ["UNIQUE (user_id, issuer)"],
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "password_reset_tokens": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "user_id": "TEXT NOT NULL",
            "token_hash": "TEXT NOT NULL UNIQUE",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "used_at": "INTEGER",
            "requested_ip": "TEXT",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "email_delivery_status": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "user_id": "TEXT NOT NULL",
            "purpose": "TEXT NOT NULL CHECK(purpose IN ('google_temporary_password', 'google_password_setup', 'user_notification'))",
            "recipient_hash": "TEXT NOT NULL CHECK(recipient_hash != '')",
            "recipient_ciphertext": "TEXT",
            "subject_ciphertext": "TEXT",
            "body_ciphertext": "TEXT",
            "sensitive_content": "INTEGER NOT NULL DEFAULT 1 CHECK(sensitive_content IN (0,1))",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'sending', 'retry', 'sent', 'failed'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "last_error_code": "TEXT",
            "next_attempt_at": "INTEGER",
            "locked_at": "INTEGER",
            "locked_by": "TEXT",
            "accepted_at": "INTEGER",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "user_notifications": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "user_id": "TEXT NOT NULL",
            "organization_id": "TEXT",
            "kind": "TEXT NOT NULL CHECK(kind IN ('assignment_added', 'assignment_removed', 'organization_added', 'organization_removed', 'procurement_update'))",
            "severity": "TEXT NOT NULL DEFAULT 'info' CHECK(severity IN ('info', 'warning'))",
            "title": "TEXT NOT NULL CHECK(trim(title) != '')",
            "message": "TEXT NOT NULL CHECK(trim(message) != '')",
            "target_type": "TEXT CHECK(target_type IS NULL OR target_type IN ('goithau', 'hopdong'))",
            "target_id": "TEXT",
            "route": "TEXT",
            "read_at": "INTEGER",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "rate_limit_buckets": {
        "columns": {
            "bucket_key": "TEXT PRIMARY KEY",
            "window_started_at": "INTEGER NOT NULL",
            "attempt_count": "INTEGER NOT NULL CHECK(attempt_count >= 0)",
            "expires_at": "INTEGER NOT NULL"
        },
    },
    "ai_conversations": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "user_id": "TEXT NOT NULL",
            "mode": "TEXT NOT NULL CHECK(mode IN ('data', 'procurement_advice', 'app_help'))",
            "title": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'deleted'))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "deleted_at": "TEXT"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "CHECK((status = 'active' AND deleted_at IS NULL) OR (status = 'deleted' AND deleted_at IS NOT NULL))"
        ]
    },
    "ai_messages": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "conversation_id": "TEXT NOT NULL",
            "role": "TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system'))",
            "content": "TEXT NOT NULL",
            "status": "TEXT NOT NULL DEFAULT 'completed' CHECK(status IN ('pending', 'completed', 'failed'))",
            "model": "TEXT",
            "input_tokens": "INTEGER CHECK(input_tokens IS NULL OR input_tokens >= 0)",
            "output_tokens": "INTEGER CHECK(output_tokens IS NULL OR output_tokens >= 0)",
            "error_code": "TEXT",
            "client_request_id": "TEXT CHECK(client_request_id IS NULL OR (length(client_request_id) BETWEEN 8 AND 80))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, conversation_id) REFERENCES ai_conversations(organization_id, id) ON DELETE CASCADE"
        ]
    },
    "ai_tool_executions": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "conversation_id": "TEXT NOT NULL",
            "message_id": "TEXT",
            "user_id": "TEXT NOT NULL",
            "tool_name": "TEXT NOT NULL",
            "arguments_redacted": "TEXT NOT NULL DEFAULT '{}'",
            "result_summary": "TEXT",
            "record_count": "INTEGER NOT NULL DEFAULT 0 CHECK(record_count >= 0)",
            "duration_ms": "INTEGER NOT NULL DEFAULT 0 CHECK(duration_ms >= 0)",
            "status": "TEXT NOT NULL CHECK(status IN ('completed', 'denied', 'failed', 'timeout'))",
            "error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, conversation_id) REFERENCES ai_conversations(organization_id, id) ON DELETE CASCADE",
            "FOREIGN KEY (organization_id, message_id) REFERENCES ai_messages(organization_id, id) ON DELETE SET NULL",
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "ai_feedback": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "message_id": "TEXT NOT NULL",
            "user_id": "TEXT NOT NULL",
            "rating": "TEXT NOT NULL CHECK(rating IN ('up', 'down'))",
            "category": "TEXT NOT NULL CHECK(category IN ('correct', 'incorrect_data', 'missing_source', 'permission_issue', 'not_helpful', 'too_slow', 'other'))",
            "comment": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, message_id) REFERENCES ai_messages(organization_id, id) ON DELETE CASCADE",
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, message_id, user_id)"
        ]
    },
    "ai_usage_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "user_id": "TEXT NOT NULL",
            "request_count": "INTEGER NOT NULL DEFAULT 0 CHECK(request_count >= 0)",
            "input_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(input_tokens >= 0)",
            "output_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(output_tokens >= 0)",
            "reserved_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(reserved_tokens >= 0)",
            "tool_call_count": "INTEGER NOT NULL DEFAULT 0 CHECK(tool_call_count >= 0)",
            "estimated_cost": "REAL NOT NULL DEFAULT 0 CHECK(estimated_cost >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "organization_id", "user_id"],
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "ai_token_reservations": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "user_id": "TEXT NOT NULL",
            "reserved_tokens": "INTEGER NOT NULL CHECK(reserved_tokens >= 0)",
            "actual_input_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(actual_input_tokens >= 0)",
            "actual_output_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(actual_output_tokens >= 0)",
            "status": "TEXT NOT NULL CHECK(status IN ('reserved', 'settled', 'released'))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "settled_at": "TEXT"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "ai_knowledge_documents": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT",
            "title": "TEXT NOT NULL CHECK(trim(title) != '')",
            "document_number": "TEXT NOT NULL CHECK(trim(document_number) != '')",
            "issuing_authority": "TEXT NOT NULL CHECK(trim(issuing_authority) != '')",
            "document_type": "TEXT NOT NULL CHECK(document_type IN ('LEGAL_DOCUMENT', 'INTERNAL_POLICY', 'PROCESS_GUIDE', 'BIDDINGFLOW_HELP', 'TEMPLATE_GUIDE', 'APPROVED_QA'))",
            "issued_date": "TEXT NOT NULL CHECK(date(issued_date) IS NOT NULL)",
            "effective_from": "TEXT NOT NULL CHECK(date(effective_from) IS NOT NULL)",
            "effective_to": "TEXT CHECK(effective_to IS NULL OR (length(effective_to) = 10 AND date(effective_to) IS NOT NULL))",
            "version": "TEXT NOT NULL CHECK(trim(version) != '')",
            "status": "TEXT NOT NULL CHECK(status IN ('active', 'retired'))",
            "confidentiality": "TEXT NOT NULL CHECK(confidentiality IN ('public', 'internal', 'confidential'))",
            "approved_by": "TEXT NOT NULL",
            "approved_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "source_url": "TEXT NOT NULL DEFAULT ''",
            "source_filename": "TEXT NOT NULL",
            "content_hash": "TEXT NOT NULL CHECK(length(content_hash) = 64)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (approved_by) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "CHECK(effective_to IS NULL OR effective_to >= effective_from)",
            "CHECK(organization_id IS NOT NULL OR confidentiality != 'confidential')"
        ]
    },
    "ai_knowledge_chunks": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "document_id": "TEXT NOT NULL",
            "chunk_index": "INTEGER NOT NULL CHECK(chunk_index >= 0)",
            "section": "TEXT NOT NULL DEFAULT ''",
            "page_number": "INTEGER CHECK(page_number IS NULL OR page_number > 0)",
            "content": "TEXT NOT NULL CHECK(trim(content) != '')",
            "char_count": "INTEGER NOT NULL CHECK(char_count > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (document_id) REFERENCES ai_knowledge_documents(id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "UNIQUE(document_id, chunk_index)"
        ]
    },
    "partner_lookup_cache": {
        "columns": {
            "cache_key": "TEXT PRIMARY KEY",
            "result_json": "TEXT",
            "found": "INTEGER NOT NULL CHECK(found IN (0,1))",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        }
    },
    "partner_upstream_health": {
        "columns": {
            "upstream": "TEXT PRIMARY KEY CHECK(upstream IN ('muasamcong', 'vietqr', 'escodata'))",
            "failure_count": "INTEGER NOT NULL DEFAULT 0 CHECK(failure_count >= 0)",
            "opened_until": "INTEGER NOT NULL DEFAULT 0 CHECK(opened_until >= 0)",
            "probe_locked_until": "INTEGER NOT NULL DEFAULT 0 CHECK(probe_locked_until >= 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        }
    },
    "contractor_violation_cache": {
        "columns": {
            "cache_key": "TEXT PRIMARY KEY",
            "provider": "TEXT NOT NULL CHECK(trim(provider) != '')",
            "contractor_identifier": "TEXT NOT NULL CHECK(trim(contractor_identifier) != '')",
            "tax_code": "TEXT",
            "response_schema_version": "TEXT NOT NULL CHECK(trim(response_schema_version) != '')",
            "records_json": "TEXT NOT NULL DEFAULT '[]'",
            "payload_hash": "TEXT NOT NULL DEFAULT '' CHECK(length(payload_hash) IN (0, 64))",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "partner_enrichment_jobs": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "contractor_id": "TEXT NOT NULL CHECK(contractor_id != '')",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'retry', 'completed', 'failed'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL CHECK(available_at > 0)",
            "locked_at": "INTEGER",
            "locked_by": "TEXT",
            "last_error_code": "TEXT",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, contractor_id)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (organization_id, contractor_id) REFERENCES nha_thau(organization_id, id) ON DELETE CASCADE"
        ]
    },
    "websocket_events": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "event_type": "TEXT NOT NULL CHECK(event_type IN ('broadcast', 'revoke_user'))",
            "organization_id": "TEXT",
            "user_id": "TEXT",
            "payload_json": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'retry', 'dispatched', 'dead_letter'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL DEFAULT 0 CHECK(available_at >= 0)",
            "delivered_at": "INTEGER",
            "dispatched_at": "INTEGER",
            "last_error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "websocket_connection_leases": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "user_id": "TEXT",
            "organization_id": "TEXT",
            "client_ip_hash": "TEXT NOT NULL CHECK(client_ip_hash != '')",
            "worker_id": "TEXT NOT NULL CHECK(worker_id != '')",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "product_usage_hourly": {
        "columns": {
            "window_started_at": "INTEGER NOT NULL CHECK(window_started_at > 0)",
            "user_id": "TEXT NOT NULL CHECK(user_id != '')",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL CHECK(owner_type IN ('organization', 'personal'))",
            "metric_key": "TEXT NOT NULL CHECK(metric_key IN ('presence.heartbeat', 'feature.used', 'word_export.completed'))",
            "feature_key": "TEXT NOT NULL DEFAULT '' CHECK(length(feature_key) <= 64)",
            "event_count": "INTEGER NOT NULL DEFAULT 1 CHECK(event_count BETWEEN 1 AND 2147483647)",
            "first_seen_at": "INTEGER NOT NULL CHECK(first_seen_at > 0)",
            "last_seen_at": "INTEGER NOT NULL CHECK(last_seen_at >= first_seen_at)"
        },
        "primary_keys": [
            "window_started_at",
            "user_id",
            "organization_id",
            "metric_key",
            "feature_key"
        ],
        "unique_constraints": [
            "CHECK((metric_key = 'feature.used' AND feature_key != '') OR (metric_key != 'feature.used' AND feature_key = ''))"
        ],
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "commercial_analytics_events": {
        "columns": {
            "event_id": "TEXT PRIMARY KEY CHECK(trim(event_id) != '')",
            "event_name": "TEXT NOT NULL CHECK(event_name IN ('pricing.viewed', 'pricing.size_selected', 'pricing.variant_compared', 'pricing.offer_selected', 'upgrade.prompt_shown', 'upgrade.prompt_clicked', 'quota.warning_shown', 'quota.topup_clicked', 'checkout.started', 'checkout.cancelled', 'subscription.cancel_intent', 'downgrade.started'))",
            "analytics_user_id": "TEXT NOT NULL CHECK(length(analytics_user_id) = 64)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "sku_code": "TEXT CHECK(sku_code IS NULL OR length(sku_code) <= 200)",
            "commercial_release_id": "TEXT NOT NULL",
            "source": "TEXT NOT NULL CHECK(source IN ('pricing_page', 'commercial_storefront', 'upgrade_prompt', 'quota_warning', 'checkout', 'subscription_settings'))",
            "occurred_at": "INTEGER NOT NULL CHECK(occurred_at > 0)",
            "received_at": "INTEGER NOT NULL CHECK(received_at >= occurred_at)"
        },
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_feedback": {
        "columns": {
            "feedback_id": "TEXT PRIMARY KEY CHECK(trim(feedback_id) != '')",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "moment": "TEXT NOT NULL CHECK(moment IN ('checkout_abandoned', 'second_topup', 'upgrade_completed', 'cancel_or_downgrade_intent', 'paid_day_45_60'))",
            "reason": "TEXT NOT NULL CHECK(reason IN ('too_expensive', 'not_needed_yet', 'benefits_unclear', 'payment_method', 'need_internal_approval', 'technical_issue', 'missing_feature', 'usage_too_low', 'other'))",
            "commercial_release_id": "TEXT NOT NULL",
            "occurred_at": "INTEGER NOT NULL CHECK(occurred_at > 0)",
            "received_at": "INTEGER NOT NULL CHECK(received_at >= occurred_at)"
        },
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "workspace_usage_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "commercial_release_id": "TEXT",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "registered_seats": "INTEGER NOT NULL DEFAULT 0 CHECK(registered_seats >= 0)",
            "active_seats": "INTEGER NOT NULL DEFAULT 0 CHECK(active_seats >= 0)",
            "power_seats": "INTEGER NOT NULL DEFAULT 0 CHECK(power_seats >= 0)",
            "meaningful_actions": "INTEGER NOT NULL DEFAULT 0 CHECK(meaningful_actions >= 0)",
            "procurement_actions": "INTEGER NOT NULL DEFAULT 0 CHECK(procurement_actions >= 0)",
            "fetch_attempted": "INTEGER NOT NULL DEFAULT 0 CHECK(fetch_attempted >= 0)",
            "fetch_failures": "INTEGER NOT NULL DEFAULT 0 CHECK(fetch_failures >= 0)",
            "fetch_cancelled": "INTEGER NOT NULL DEFAULT 0 CHECK(fetch_cancelled >= 0)",
            "cache_hits": "INTEGER NOT NULL DEFAULT 0 CHECK(cache_hits >= 0)",
            "credits_reserved": "INTEGER NOT NULL DEFAULT 0 CHECK(credits_reserved >= 0)",
            "credits_released": "INTEGER NOT NULL DEFAULT 0 CHECK(credits_released >= 0)",
            "successful_fetches": "INTEGER NOT NULL DEFAULT 0 CHECK(successful_fetches >= 0)",
            "feature_uses": "INTEGER NOT NULL DEFAULT 0 CHECK(feature_uses >= 0)",
            "word_exports": "INTEGER NOT NULL DEFAULT 0 CHECK(word_exports >= 0)",
            "included_credits_granted": "INTEGER NOT NULL DEFAULT 0 CHECK(included_credits_granted >= 0)",
            "included_credits_consumed": "INTEGER NOT NULL DEFAULT 0 CHECK(included_credits_consumed >= 0)",
            "purchased_credits": "INTEGER NOT NULL DEFAULT 0 CHECK(purchased_credits >= 0)",
            "purchased_credits_unused": "INTEGER NOT NULL DEFAULT 0 CHECK(purchased_credits_unused >= 0)",
            "expired_unused_credits": "INTEGER NOT NULL DEFAULT 0 CHECK(expired_unused_credits >= 0)",
            "topup_spend_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(topup_spend_vnd >= 0)",
            "workflow_volume": "INTEGER NOT NULL DEFAULT 0 CHECK(workflow_volume >= 0)",
            "workflow_depth": "INTEGER NOT NULL DEFAULT 0 CHECK(workflow_depth >= 0)",
            "ai_requests": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_requests >= 0)",
            "ai_input_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_input_tokens >= 0)",
            "ai_output_tokens": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_output_tokens >= 0)",
            "ai_tool_calls": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_tool_calls >= 0)",
            "ai_feedback_up": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_feedback_up >= 0)",
            "ai_feedback_down": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_feedback_down >= 0)",
            "ai_feedback_too_slow": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_feedback_too_slow >= 0)",
            "ai_feedback_incorrect_source": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_feedback_incorrect_source >= 0)",
            "ai_estimated_cost_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_estimated_cost_vnd >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "analytics_workspace_id"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "workspace_feature_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "feature_key": "TEXT NOT NULL CHECK(trim(feature_key) != '')",
            "active_users": "INTEGER NOT NULL DEFAULT 0 CHECK(active_users >= 0)",
            "event_count": "INTEGER NOT NULL DEFAULT 0 CHECK(event_count >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "analytics_workspace_id", "feature_key"]
    },
    "workspace_seat_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "analytics_user_id": "TEXT NOT NULL CHECK(length(analytics_user_id) = 64)",
            "meaningful_actions": "INTEGER NOT NULL DEFAULT 0 CHECK(meaningful_actions >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "analytics_workspace_id", "analytics_user_id"]
    },
    "commercial_funnel_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "commercial_release_id": "TEXT NOT NULL",
            "event_name": "TEXT NOT NULL",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "sku_code": "TEXT NOT NULL DEFAULT ''",
            "event_count": "INTEGER NOT NULL DEFAULT 0 CHECK(event_count >= 0)",
            "unique_workspaces": "INTEGER NOT NULL DEFAULT 0 CHECK(unique_workspaces >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "commercial_release_id", "event_name", "owner_kind", "size_bucket", "sku_code"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_funnel_workspace_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "commercial_release_id": "TEXT NOT NULL",
            "event_name": "TEXT NOT NULL CHECK(trim(event_name) != '')",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "sku_code": "TEXT NOT NULL DEFAULT ''",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "event_count": "INTEGER NOT NULL DEFAULT 0 CHECK(event_count >= 0)",
            "first_occurred_at": "INTEGER CHECK(first_occurred_at IS NULL OR first_occurred_at > 0)",
            "last_occurred_at": "INTEGER CHECK((first_occurred_at IS NULL AND last_occurred_at IS NULL) OR (first_occurred_at IS NOT NULL AND last_occurred_at >= first_occurred_at))"
        },
        "primary_keys": [
            "usage_date", "commercial_release_id", "event_name", "owner_kind",
            "size_bucket", "sku_code", "analytics_workspace_id"
        ],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "subscription_snapshot_daily": {
        "columns": {
            "snapshot_date": "TEXT NOT NULL CHECK(date(snapshot_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "commercial_release_id": "TEXT",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "member_quota": "INTEGER NOT NULL DEFAULT 0 CHECK(member_quota >= 0)",
            "status": "TEXT NOT NULL CHECK(status IN ('active', 'suspended', 'expired', 'cancelled'))",
            "activated_today": "INTEGER NOT NULL DEFAULT 0 CHECK(activated_today IN (0,1))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["snapshot_date", "analytics_workspace_id"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "revenue_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "commercial_release_id": "TEXT NOT NULL",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "sku_code": "TEXT NOT NULL DEFAULT ''",
            "gross_revenue_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(gross_revenue_vnd >= 0)",
            "net_settled_revenue_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(net_settled_revenue_vnd >= 0)",
            "refund_amount_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(refund_amount_vnd >= 0)",
            "payment_fee_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(payment_fee_vnd >= 0)",
            "paid_orders": "INTEGER NOT NULL DEFAULT 0 CHECK(paid_orders >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "commercial_release_id", "owner_kind", "plan_code", "variant", "sku_code"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "cost_usage_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "commercial_release_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "analytics_workspace_id": "TEXT NOT NULL DEFAULT '' CHECK(analytics_workspace_id = '' OR length(analytics_workspace_id) = 64)",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "cost_type": "TEXT NOT NULL CHECK(cost_type IN ('procurement_fetch', 'ai', 'document_worker', 'storage', 'bandwidth', 'payment_fee', 'email', 'other_external_provider'))",
            "quantity": "INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0)",
            "estimated_cost_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(estimated_cost_vnd >= 0)",
            "cost_status": "TEXT NOT NULL DEFAULT 'available' CHECK(cost_status IN ('available', 'not_configured'))",
            "source": "TEXT NOT NULL DEFAULT 'aggregate' CHECK(trim(source) != '')",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "owner_kind", "analytics_workspace_id", "plan_code", "variant", "cost_type", "source"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "retention_cohort_weekly": {
        "columns": {
            "cohort_week": "TEXT NOT NULL CHECK(date(cohort_week) IS NOT NULL)",
            "cohort_kind": "TEXT NOT NULL CHECK(cohort_kind IN ('signup', 'first_value', 'paid_activation'))",
            "segment_key": "TEXT NOT NULL DEFAULT 'all'",
            "commercial_release_id": "TEXT NOT NULL DEFAULT ''",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "workspace_count": "INTEGER NOT NULL CHECK(workspace_count >= 0)",
            "week_number": "INTEGER NOT NULL CHECK(week_number BETWEEN 0 AND 12)",
            "retained_workspaces": "INTEGER NOT NULL CHECK(retained_workspaces >= 0 AND retained_workspaces <= workspace_count)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["cohort_week", "cohort_kind", "segment_key", "commercial_release_id", "owner_kind", "week_number"],
        "foreign_keys": []
    },
    "plan_fit_monthly": {
        "columns": {
            "snapshot_month": "TEXT NOT NULL CHECK(date(snapshot_month) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "commercial_release_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "active_seats": "INTEGER NOT NULL DEFAULT 0 CHECK(active_seats >= 0)",
            "seat_utilization": "REAL NOT NULL DEFAULT 0 CHECK(seat_utilization >= 0)",
            "procurement_usage": "INTEGER NOT NULL DEFAULT 0 CHECK(procurement_usage >= 0)",
            "quota_utilization": "REAL NOT NULL DEFAULT 0 CHECK(quota_utilization >= 0)",
            "topup_spend_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(topup_spend_vnd >= 0)",
            "repeat_topups": "INTEGER NOT NULL DEFAULT 0 CHECK(repeat_topups >= 0)",
            "connected_feature_days": "INTEGER NOT NULL DEFAULT 0 CHECK(connected_feature_days >= 0)",
            "workflow_volume": "INTEGER NOT NULL DEFAULT 0 CHECK(workflow_volume >= 0)",
            "workflow_depth": "INTEGER NOT NULL DEFAULT 0 CHECK(workflow_depth >= 0)",
            "export_intensity": "INTEGER NOT NULL DEFAULT 0 CHECK(export_intensity >= 0)",
            "ai_intensity": "INTEGER NOT NULL DEFAULT 0 CHECK(ai_intensity >= 0)",
            "estimated_cost_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(estimated_cost_vnd >= 0)",
            "cost_status": "TEXT NOT NULL DEFAULT 'not_configured' CHECK(cost_status IN ('available', 'not_configured'))",
            "revenue_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(revenue_vnd >= 0)",
            "revenue_status": "TEXT NOT NULL DEFAULT 'not_available' CHECK(revenue_status IN ('available', 'not_available'))",
            "price_gap_to_connected_vnd": "INTEGER CHECK(price_gap_to_connected_vnd IS NULL OR price_gap_to_connected_vnd >= 0)",
            "days_to_break_even": "INTEGER CHECK(days_to_break_even IS NULL OR days_to_break_even >= 0)",
            "classification": "TEXT NOT NULL CHECK(classification IN ('UNDER_SIZED', 'GOOD_FIT', 'OVER_SIZED', 'CONNECTED_CANDIDATE', 'TOPUP_HEAVY', 'ENTERPRISE_CANDIDATE'))",
            "rule_version": "TEXT NOT NULL CHECK(trim(rule_version) != '')",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["snapshot_month", "analytics_workspace_id"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "workspace_activation_facts": {
        "columns": {
            "analytics_workspace_id": "TEXT PRIMARY KEY CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "signup_at": "INTEGER NOT NULL CHECK(signup_at > 0)",
            "verification_at": "INTEGER",
            "verification_observation": "TEXT NOT NULL CHECK(verification_observation IN ('observed', 'not_verified', 'historical_timestamp_unavailable'))",
            "first_login_at": "INTEGER",
            "first_value_at": "INTEGER",
            "first_feature_key": "TEXT NOT NULL DEFAULT ''",
            "first_plan_at": "INTEGER",
            "first_procurement_or_export_at": "INTEGER",
            "subscription_activated_at": "INTEGER",
            "first_paid_value_at": "INTEGER",
            "commercial_release_id": "TEXT",
            "plan_code": "TEXT NOT NULL DEFAULT ''",
            "variant": "TEXT NOT NULL DEFAULT '' CHECK(variant IN ('', 'internal', 'connected'))",
            "size_bucket": "TEXT NOT NULL DEFAULT 'unknown' CHECK(size_bucket IN ('1', '2_5', '6_15', '16_50', 'over_50', 'unknown'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "CHECK(verification_at IS NULL OR verification_at >= signup_at)",
            "CHECK(first_login_at IS NULL OR first_login_at >= signup_at)",
            "CHECK(first_value_at IS NULL OR first_value_at >= signup_at)",
            "CHECK(subscription_activated_at IS NULL OR subscription_activated_at >= signup_at)",
            "CHECK(first_paid_value_at IS NULL OR subscription_activated_at IS NOT NULL)"
        ]
    },
    "credit_pack_purchase_daily": {
        "columns": {
            "purchase_date": "TEXT NOT NULL CHECK(date(purchase_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "commercial_release_id": "TEXT NOT NULL",
            "sku_code": "TEXT NOT NULL CHECK(trim(sku_code) != '')",
            "pack_size": "INTEGER NOT NULL CHECK(pack_size > 0)",
            "purchase_count": "INTEGER NOT NULL DEFAULT 0 CHECK(purchase_count >= 0)",
            "credits_purchased": "INTEGER NOT NULL DEFAULT 0 CHECK(credits_purchased >= 0)",
            "gross_revenue_vnd": "INTEGER NOT NULL DEFAULT 0 CHECK(gross_revenue_vnd >= 0)",
            "unused_credits": "INTEGER NOT NULL DEFAULT 0 CHECK(unused_credits >= 0 AND unused_credits <= credits_purchased)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["purchase_date", "analytics_workspace_id", "commercial_release_id", "sku_code", "pack_size"],
        "foreign_keys": [
            "FOREIGN KEY (commercial_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "workspace_feature_user_daily": {
        "columns": {
            "usage_date": "TEXT NOT NULL CHECK(date(usage_date) IS NOT NULL)",
            "analytics_workspace_id": "TEXT NOT NULL CHECK(length(analytics_workspace_id) = 64)",
            "feature_key": "TEXT NOT NULL CHECK(trim(feature_key) != '')",
            "analytics_user_id": "TEXT NOT NULL CHECK(length(analytics_user_id) = 64)",
            "event_count": "INTEGER NOT NULL DEFAULT 0 CHECK(event_count >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["usage_date", "analytics_workspace_id", "feature_key", "analytics_user_id"]
    },
    "document_jobs": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "operation": "TEXT NOT NULL CHECK(operation != '')",
            "organization_id": "TEXT",
            "user_id": "TEXT",
            "package_id": "TEXT",
            "record_type": "TEXT CHECK(record_type IS NULL OR record_type IN ('goi_thau', 'ke_hoach_lcnt'))",
            "record_id": "TEXT CHECK(record_id IS NULL OR record_id != '')",
            "filename": "TEXT",
            "content_type": "TEXT",
            "policy_json": "TEXT NOT NULL DEFAULT '' CHECK(length(policy_json) <= 65536)",
            "policy_hash": "TEXT NOT NULL DEFAULT '' CHECK(length(policy_hash) IN (0, 64))",
            "cancelled_at": "INTEGER",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'retry', 'completed', 'failed'))",
            "progress_phase": "TEXT NOT NULL DEFAULT 'queued' CHECK(progress_phase != '' AND length(progress_phase) <= 64)",
            "progress_completed_items": "INTEGER NOT NULL DEFAULT 0 CHECK(progress_completed_items >= 0)",
            "progress_total_items": "INTEGER NOT NULL DEFAULT 1 CHECK(progress_total_items >= 1)",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL CHECK(available_at > 0)",
            "locked_at": "INTEGER",
            "locked_by": "TEXT",
            "last_error_code": "TEXT",
            "last_error_message": "TEXT",
            "completed_at": "INTEGER",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)"
        }
    },
    "asset_journal": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "client_mutation_id": "TEXT NOT NULL CHECK(client_mutation_id != '')",
            "staging_path": "TEXT NOT NULL CHECK(staging_path != '')",
            "managed_path": "TEXT NOT NULL CHECK(managed_path != '')",
            "sha256": "TEXT NOT NULL CHECK(length(sha256) = 64)",
            "size_bytes": "INTEGER NOT NULL CHECK(size_bytes > 0)",
            "status": "TEXT NOT NULL DEFAULT 'staged' CHECK(status IN ('staged', 'promoted', 'failed'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "last_error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, client_mutation_id, managed_path)"
        ]
    },
    "chu_dau_tu": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ngay_ap_dung": "TEXT NOT NULL DEFAULT (date('now'))",
            "ma_chu_dau_tu": "TEXT",
            "ten_chu_dau_tu": "TEXT NOT NULL",
            "ten_viet_tat": "TEXT",
            "ma_so_thue": "TEXT",
            "chuc_vu_nguoi_dung_dau": "TEXT",
            "dai_dien_cdt": "TEXT",
            "chuc_vu_dai_dien": "TEXT",
            "danh_xung": "TEXT DEFAULT 'Ông'",
            "dia_chi": "TEXT",
            "dia_chi_goc": "TEXT",
            "so_dien_thoai": "TEXT",
            "so_tai_khoan": "TEXT",
            "noi_mo_tai_khoan": "TEXT",
            "email": "TEXT",
            "ma_qhns": "TEXT",
            "co_quan_chu_quan": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "field_map": {
            "ma_qhns": "maQHNS"
        }
    },
    "ke_hoach_lcnt": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "ma_ke_hoach": "TEXT",
            "ma_du_an": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ten_ke_hoach": "TEXT NOT NULL",
            "ten_du_an_du_toan": "TEXT",
            "loai_hinh_mua_sam": "TEXT NOT NULL CHECK(trim(loai_hinh_mua_sam) != '')",
            "chu_dau_tu_id": "TEXT NOT NULL CHECK(trim(chu_dau_tu_id) != '')",
            "don_vi_trinh_cdt": "TEXT",
            "ten_viet_tat_don_vi_trinh": "TEXT",
            "tong_muc_dau_tu": "INTEGER CHECK(tong_muc_dau_tu IS NULL OR (typeof(tong_muc_dau_tu) = 'integer' AND tong_muc_dau_tu >= 0))",
            "is_tong_muc_tu_dong": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(is_tong_muc_tu_dong) = 'integer' AND is_tong_muc_tu_dong IN (0,1))",
            "ngay_phe_duyet": "TEXT NOT NULL CHECK(date(ngay_phe_duyet) IS NOT NULL)",
            "quyet_dinh_phe_duyet": "TEXT NOT NULL CHECK(trim(quyet_dinh_phe_duyet) != '')",
            "thoi_gian_dang_tai": "TEXT",
            "nguon_von": "TEXT",
            "thoi_gian_du_an": "TEXT",
            "dia_diem_quy_mo": "TEXT",
            "thong_tin_khac": "TEXT",
            "can_cu_gia_goi_thau": "TEXT NOT NULL DEFAULT ''",
            "so_qd_phe_duyet_du_an": "TEXT",
            "ngay_qd_phe_duyet_du_an": "TEXT",
            "co_quan_phe_duyet_du_an": "TEXT",
            "phe_duyet": "TEXT",
            "so_to_trinh_du_toan": "TEXT",
            "ngay_trinh_du_toan": "TEXT",
            "ngay_phe_duyet_du_toan": "TEXT",
            "so_qd_phe_duyet_du_toan": "TEXT",
            "so_to_trinh_ke_hoach": "TEXT",
            "so_to_trinh_du_toan_ke_hoach": "TEXT",
            "ngay_trinh_ke_hoach": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "foreign_keys": ["FOREIGN KEY (chu_dau_tu_id) REFERENCES chu_dau_tu(id) ON DELETE RESTRICT"],
        "unique_constraints": [
            "CONSTRAINT ke_hoach_lcnt_budget_name_check "
            "CHECK(loai_hinh_mua_sam != 'Dự toán mua sắm' OR "
            "trim(COALESCE(ten_du_an_du_toan, '')) != '')"
        ],
        "field_map": {
            "ma_du_an": "maDuan",
            "thoi_gian_dang_tai": "thoiGianDangMa",
            "don_vi_trinh_cdt": "donViTrinhCdt",
            "ten_viet_tat_don_vi_trinh": "tenVietTatDonViTrinh",
            "phe_duyet": "pheDuyet",
            "so_to_trinh_du_toan": "soToTrinhDuToan",
            "ngay_trinh_du_toan": "ngayTrinhDuToan",
            "ngay_phe_duyet_du_toan": "ngayPheDuyetDuToan",
            "so_qd_phe_duyet_du_toan": "soQdPheDuyetDuToan",
            "so_to_trinh_ke_hoach": "soToTrinhKeHoach",
            "so_to_trinh_du_toan_ke_hoach": "soToTrinhDuToanKeHoach",
            "ngay_trinh_ke_hoach": "ngayTrinhKeHoach"
        }
    },
    "ke_hoach_cong_viec": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "ke_hoach_id": "TEXT NOT NULL",
            "loai": "TEXT NOT NULL CHECK(loai IN ('da_thuc_hien', 'khong_ap_dung', 'chua_du_dieu_kien'))",
            "ten_cong_viec": "TEXT",
            "gia_tri": "INTEGER CHECK(gia_tri IS NULL OR (typeof(gia_tri) = 'integer' AND gia_tri >= 0))",
            "don_vi_thuc_hien": "TEXT",
            "van_ban_phe_duyet": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (ke_hoach_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT"
        ]
    },
    "ke_hoach_can_cu": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "id_goc": "TEXT NOT NULL CHECK(trim(id_goc) != '')",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "ke_hoach_id": "TEXT NOT NULL",
            "noi_dung_goc": "TEXT NOT NULL CHECK(trim(noi_dung_goc) != '')",
            "ten_van_ban": "TEXT",
            "so_van_ban": "TEXT",
            "ngay_ban_hanh": "TEXT CHECK(ngay_ban_hanh IS NULL OR date(ngay_ban_hanh) IS NOT NULL)",
            "don_vi_ban_hanh": "TEXT",
            "trich_yeu": "TEXT",
            "parse_status": "TEXT NOT NULL CHECK(parse_status IN ('PARSED', 'PARTIAL', 'UNPARSED'))",
            "parse_version": "TEXT NOT NULL CHECK(trim(parse_version) != '')",
            "parse_reasons": "TEXT NOT NULL DEFAULT '[]'",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(sort_order >= 0)",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (ke_hoach_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, ke_hoach_id, sort_order)"
        ]
    },
    "nha_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ngay_ap_dung": "TEXT NOT NULL DEFAULT (date('now'))",
            "ma_nha_thau": "TEXT",
            "ten_nha_thau": "TEXT NOT NULL",
            "ten_viet_tat": "TEXT",
            "loai_nha_thau": "TEXT",
            "ma_so_thue": "TEXT",
            "nguoi_dai_dien": "TEXT",
            "chuc_vu_dai_dien": "TEXT",
            "danh_xung": "TEXT DEFAULT 'Ông'",
            "so_dien_thoai": "TEXT",
            "email": "TEXT",
            "dia_chi": "TEXT",
            "dia_chi_goc": "TEXT",
            "so_tai_khoan": "TEXT",
            "noi_mo_tai_khoan": "TEXT",
            "ma_ngan_hang": "TEXT",
            "anh_dau": "TEXT",
            "ten_anh_dau": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        }
    },
    "nha_thau_lien_danh_thanh_vien": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "nha_thau_id": "TEXT NOT NULL",
            "thanh_vien_nha_thau_id": "TEXT NOT NULL",
            "ten_nha_thau": "TEXT",
            "ma_nha_thau": "TEXT",
            "ma_so_thue": "TEXT",
            "vai_tro": "TEXT NOT NULL CHECK(vai_tro IN ('Đứng đầu liên danh', 'Thành viên liên danh'))",
            "nguoi_dai_dien": "TEXT",
            "danh_xung": "TEXT",
            "so_dien_thoai": "TEXT",
            "email": "TEXT",
            "dia_chi": "TEXT",
            "dia_chi_goc": "TEXT",
            "so_tai_khoan": "TEXT",
            "noi_mo_tai_khoan": "TEXT",
            "ma_ngan_hang": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (nha_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (thanh_vien_nha_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, nha_thau_id, thanh_vien_nha_thau_id)"
        ]
    },
    "goi_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "ma_goi_thau": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ke_hoach_id": "TEXT NOT NULL CHECK(trim(ke_hoach_id) != '')",
            "ten_goi_thau": "TEXT NOT NULL",
            "gia_goi_thau": "INTEGER NOT NULL CHECK(typeof(gia_goi_thau) = 'integer' AND gia_goi_thau >= 0)",
            "loai_hop_dong": "TEXT",
            "hinh_thuc_lua_chon": "TEXT",
            "phuong_thuc_lua_chon": "TEXT",
            "qua_mang": "TEXT NOT NULL DEFAULT 'Qua mạng' CHECK(qua_mang IN ('Qua mạng', 'Không qua mạng'))",
            "trong_nuoc_quoc_te": "TEXT NOT NULL DEFAULT 'Trong nước' CHECK(trong_nuoc_quoc_te IN ('Trong nước', 'Quốc tế'))",
            "thoi_gian_thuc_hien": "TEXT NOT NULL CHECK(trim(thoi_gian_thuc_hien) != '')",
            "nguon_von": "TEXT NOT NULL CHECK(trim(nguon_von) != '')",
            "nha_thau_trung_thau_id": "TEXT",
            "gia_trung_thau": "INTEGER CHECK(gia_trung_thau IS NULL OR (typeof(gia_trung_thau) = 'integer' AND gia_trung_thau >= 0))",
            "linh_vuc": "TEXT",
            "tuy_chon_mua_them": "TEXT DEFAULT 'Không' CHECK(tuy_chon_mua_them IN ('Có', 'Không') OR tuy_chon_mua_them IS NULL)",
            "thoi_gian_to_chuc": "TEXT NOT NULL CHECK(trim(thoi_gian_to_chuc) != '')",
            "thoi_gian_bat_dau_to_chuc": "TEXT NOT NULL CHECK(trim(thoi_gian_bat_dau_to_chuc) != '')",
            "phan_lo": "TEXT DEFAULT 'Không' CHECK(phan_lo IN ('Có', 'Không') OR phan_lo IS NULL)",
            "thoi_gian_dang_tai": "TEXT",
            "thoi_gian_dong_thau": "TEXT",
            "thoi_gian_mo_thau": "TEXT",
            "thoi_gian_mo_ehsdxtc": "TEXT",
            "so_quyet_dinh": "TEXT",
            "ngay_quyet_dinh": "TEXT",
            "so_quyet_dinh_ket_qua": "TEXT",
            "ngay_quyet_dinh_ket_qua": "TEXT",
            "thoi_gian_goi_thau": "TEXT",
            "thoi_gian_hop_dong": "TEXT",
            "gia_tri_dam_bao_du_thau": "INTEGER CHECK(gia_tri_dam_bao_du_thau IS NULL OR (typeof(gia_tri_dam_bao_du_thau) = 'integer' AND gia_tri_dam_bao_du_thau >= 0))",
            "hieu_luc_hsdt": "INTEGER CHECK(hieu_luc_hsdt IS NULL OR hieu_luc_hsdt >= 0)",
            "hieu_luc_dam_bao_du_thau": "INTEGER CHECK(hieu_luc_dam_bao_du_thau IS NULL OR hieu_luc_dam_bao_du_thau >= 0)",
            "phuong_phap_danh_gia": "TEXT",
            "trong_so_ky_thuat": "INTEGER CHECK(trong_so_ky_thuat IS NULL OR (typeof(trong_so_ky_thuat) = 'integer' AND trong_so_ky_thuat BETWEEN 0 AND 100))",
            "ty_le_bao_dam_hop_dong": "REAL CHECK(ty_le_bao_dam_hop_dong IS NULL OR (typeof(ty_le_bao_dam_hop_dong) IN ('integer', 'real') AND ty_le_bao_dam_hop_dong BETWEEN 0 AND 100 AND ty_le_bao_dam_hop_dong = round(ty_le_bao_dam_hop_dong, 4)))",
            "is_thuoc": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(is_thuoc) = 'integer' AND is_thuoc IN (0,1))",
            "is_rebid": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(is_rebid) = 'integer' AND is_rebid IN (0,1))",
            "rebid_from_package_id": "TEXT",
            "trang_thai": "TEXT NOT NULL DEFAULT 'PREPARING' CHECK(trang_thai IN ('UNKNOWN', 'PREPARING', 'INVITED', 'OPENED', 'EVALUATING', 'PARTIALLY_AWARDED', 'AWARDED', 'CANCELLED'))",
            "yeu_cau_tham_dinh_hsmt": "TEXT DEFAULT 'Không' CHECK(yeu_cau_tham_dinh_hsmt IN ('Có', 'Không') OR yeu_cau_tham_dinh_hsmt IS NULL)",
            "yeu_cau_tham_dinh_hsmt_code": "TEXT NOT NULL DEFAULT 'UNDETERMINED' CHECK(yeu_cau_tham_dinh_hsmt_code IN ('UNDETERMINED', 'REQUIRED', 'NOT_REQUIRED'))",
            "so_bao_cao_tham_dinh_hsmt": "TEXT",
            "ngay_bao_cao_tham_dinh_hsmt": "TEXT",
            "so_to_trinh_hsmt": "TEXT",
            "ngay_trinh_hsmt": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (ke_hoach_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_trung_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (rebid_from_package_id) REFERENCES goi_thau(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "CHECK(NULLIF(thoi_gian_dang_tai, '') IS NULL OR NULLIF(thoi_gian_dong_thau, '') IS NULL OR (datetime(thoi_gian_dang_tai) IS NOT NULL AND datetime(thoi_gian_dong_thau) IS NOT NULL AND datetime(thoi_gian_dong_thau) > datetime(thoi_gian_dang_tai)))",
            "CHECK(NULLIF(thoi_gian_dong_thau, '') IS NULL OR NULLIF(thoi_gian_mo_thau, '') IS NULL OR (datetime(thoi_gian_dong_thau) IS NOT NULL AND datetime(thoi_gian_mo_thau) IS NOT NULL AND datetime(thoi_gian_mo_thau) >= datetime(thoi_gian_dong_thau)))",
            "CHECK((is_rebid = 0 AND rebid_from_package_id IS NULL) OR (is_rebid = 1 AND rebid_from_package_id IS NOT NULL AND rebid_from_package_id != id))",
            "CHECK(trang_thai != 'AWARDED' OR (gia_trung_thau IS NOT NULL AND so_quyet_dinh_ket_qua IS NOT NULL AND trim(so_quyet_dinh_ket_qua) != '' AND ngay_quyet_dinh_ket_qua IS NOT NULL AND date(ngay_quyet_dinh_ket_qua) IS NOT NULL AND (phan_lo = 'Có' OR (nha_thau_trung_thau_id IS NOT NULL AND trim(nha_thau_trung_thau_id) != ''))))"
        ],
        "field_map": {
            "nha_thau_trung_thau_id": "nhaThauTrungThauId",
            "thoi_gian_dang_tai": "thoiGianDangTai",
            "thoi_gian_dong_thau": "thoiGianDongThau",
            "thoi_gian_mo_thau": "thoiGianMoThau",
            "thoi_gian_mo_ehsdxtc": "thoiGianMoEhsdxtc",
            "so_quyet_dinh": "soQuyetDinh",
            "ngay_quyet_dinh": "ngayQuyetDinh",
            "so_quyet_dinh_ket_qua": "soQuyetDinhKetQua",
            "ngay_quyet_dinh_ket_qua": "ngayQuyetDinhKetQua",
            "gia_tri_dam_bao_du_thau": "giaTriDamBaoDuThau",
            "hieu_luc_hsdt": "hieuLucHsdt",
            "hieu_luc_dam_bao_du_thau": "hieuLucDamBaoDuThau",
            "ty_le_bao_dam_hop_dong": "tyLeBaoDamHopDong",
            "phuong_phap_danh_gia": "phuongPhapDanhGia",
            "trong_so_ky_thuat": "trongSoKyThuat",
            "is_thuoc": "isThuoc",
            "yeu_cau_tham_dinh_hsmt": "yeuCauThamDinhHsmt",
            "yeu_cau_tham_dinh_hsmt_code": "yeuCauThamDinhHsmtCode",
            "so_bao_cao_tham_dinh_hsmt": "soBaoCaoThamDinhHsmt",
            "ngay_bao_cao_tham_dinh_hsmt": "ngayBaoCaoThamDinhHsmt",
            "so_to_trinh_hsmt": "soToTrinhHsmt",
            "ngay_trinh_hsmt": "ngayTrinhHsmt"
        }
    },
    "tai_lieu_goi_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "evaluation_batch_id": "TEXT",
            "document_type": "TEXT NOT NULL CHECK(document_type IN ('HSMT', 'HSMT_APPRAISAL_REPORT', 'BID_EVALUATION_REPORT', 'TECHNICAL_EVALUATION_REPORT', 'TECHNICAL_APPRAISAL_REPORT', 'FINANCIAL_EVALUATION_REPORT', 'RESULT_APPRAISAL_REPORT'))",
            "original_filename": "TEXT NOT NULL CHECK(trim(original_filename) != '')",
            "storage_key": "TEXT NOT NULL CHECK(trim(storage_key) != '')",
            "content_type": "TEXT NOT NULL CHECK(trim(content_type) != '')",
            "size_bytes": "INTEGER NOT NULL CHECK(typeof(size_bytes) = 'integer' AND size_bytes > 0)",
            "sha256": "TEXT NOT NULL CHECK(length(sha256) = 64)",
            "uploaded_by_id": "TEXT",
            "uploaded_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (evaluation_batch_id) REFERENCES dot_xu_ly_phan_lo(id) ON DELETE RESTRICT",
            "FOREIGN KEY (uploaded_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": []
    },
    "goi_thau_phan_lo": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "ma_phan_lo": "TEXT",
            "ma_phan_lo_normalized": "TEXT NOT NULL DEFAULT ''",
            "ten_phan_lo": "TEXT",
            "gia_tri_phan_lo": "INTEGER CHECK(gia_tri_phan_lo IS NULL OR (typeof(gia_tri_phan_lo) = 'integer' AND gia_tri_phan_lo >= 0))",
            "bao_dam_du_thau": "INTEGER CHECK(bao_dam_du_thau IS NULL OR (typeof(bao_dam_du_thau) = 'integer' AND bao_dam_du_thau >= 0))",
            "thoi_gian_thuc_hien": "TEXT",
            "nha_thau_trung_thau_id": "TEXT",
            "gia_trung_thau": "INTEGER CHECK(gia_trung_thau IS NULL OR (typeof(gia_trung_thau) = 'integer' AND gia_trung_thau >= 0))",
            "thoi_gian_goi_thau": "TEXT",
            "thoi_gian_hop_dong": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "archived_at": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_trung_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT"
        ]
    },
    "goi_thau_hang_hoa": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL CHECK(trim(goi_thau_id) != '')",
            "phan_lo_id": "TEXT",
            "ma_hang_hoa": "TEXT NOT NULL CHECK(trim(ma_hang_hoa) != '')",
            "ten_hang_hoa": "TEXT NOT NULL CHECK(trim(ten_hang_hoa) != '')",
            "nhom_hang_hoa": "TEXT",
            "don_vi_tinh": "TEXT NOT NULL CHECK(trim(don_vi_tinh) != '')",
            "so_luong": "REAL NOT NULL CHECK(typeof(so_luong) IN ('integer', 'real') AND so_luong > 0)",
            "yeu_cau_ky_thuat": "TEXT",
            "ky_ma_hieu_tham_chieu": "TEXT",
            "xuat_xu_yeu_cau": "TEXT",
            "dia_diem_giao_hang": "TEXT",
            "thoi_gian_giao_hang": "TEXT",
            "don_gia_du_toan": "INTEGER CHECK(don_gia_du_toan IS NULL OR (typeof(don_gia_du_toan) = 'integer' AND don_gia_du_toan >= 0))",
            "thanh_tien_du_toan": "INTEGER CHECK(thanh_tien_du_toan IS NULL OR (typeof(thanh_tien_du_toan) = 'integer' AND thanh_tien_du_toan >= 0))",
            "ghi_chu": "TEXT",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(sort_order) = 'integer' AND sort_order >= 0)",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (phan_lo_id) REFERENCES goi_thau_phan_lo(id) ON DELETE RESTRICT"
        ]
    },
    "hang_hoa_du_thau_nha_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL CHECK(trim(goi_thau_id) != '')",
            "thong_tin_mo_thau_id": "TEXT NOT NULL CHECK(trim(thong_tin_mo_thau_id) != '')",
            "phan_lo_id": "TEXT",
            "goi_thau_hang_hoa_id": "TEXT",
            "stt_nguon": "TEXT NOT NULL DEFAULT '' CHECK(length(stt_nguon) <= 80)",
            "ma_phan_lo_nguon": "TEXT NOT NULL DEFAULT '' CHECK(length(ma_phan_lo_nguon) <= 200)",
            "ten_phan_lo_nguon": "TEXT NOT NULL DEFAULT '' CHECK(length(ten_phan_lo_nguon) <= 1000)",
            "danh_muc_hang_hoa": "TEXT NOT NULL CHECK(length(trim(danh_muc_hang_hoa)) BETWEEN 1 AND 4000)",
            "ky_ma_hieu": "TEXT NOT NULL DEFAULT '' CHECK(length(ky_ma_hieu) <= 10000)",
            "nhan_hieu": "TEXT NOT NULL DEFAULT '' CHECK(length(nhan_hieu) <= 4000)",
            "nam_san_xuat": "TEXT NOT NULL DEFAULT '' CHECK(length(nam_san_xuat) <= 500)",
            "xuat_xu": "TEXT NOT NULL DEFAULT '' CHECK(length(xuat_xu) <= 2000)",
            "hang_san_xuat": "TEXT NOT NULL DEFAULT '' CHECK(length(hang_san_xuat) <= 2000)",
            "cau_hinh_tinh_nang_ky_thuat": "TEXT NOT NULL DEFAULT '' CHECK(length(cau_hinh_tinh_nang_ky_thuat) <= 100000)",
            "don_vi_tinh": "TEXT NOT NULL DEFAULT '' CHECK(length(don_vi_tinh) <= 200)",
            "khoi_luong": "REAL CHECK(khoi_luong IS NULL OR (typeof(khoi_luong) IN ('integer', 'real') AND khoi_luong > 0))",
            "ma_hs": "TEXT NOT NULL DEFAULT '' CHECK(length(ma_hs) <= 2000)",
            "don_gia_du_thau": "INTEGER CHECK(don_gia_du_thau IS NULL OR (typeof(don_gia_du_thau) = 'integer' AND don_gia_du_thau >= 0))",
            "thanh_tien_du_thau": "INTEGER CHECK(thanh_tien_du_thau IS NULL OR (typeof(thanh_tien_du_thau) = 'integer' AND thanh_tien_du_thau >= 0))",
            "ma_uu_dai": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(ma_uu_dai) = 'integer' AND ma_uu_dai BETWEEN 0 AND 5)",
            "he_so_uu_dai_goc_bp": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(he_so_uu_dai_goc_bp) = 'integer' AND he_so_uu_dai_goc_bp BETWEEN 0 AND 1500)",
            "he_so_cong_uu_dai_bp": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(he_so_cong_uu_dai_bp) = 'integer' AND he_so_cong_uu_dai_bp BETWEEN 0 AND 1500)",
            "gia_tri_co_so_sau_giam_gia": "INTEGER CHECK(gia_tri_co_so_sau_giam_gia IS NULL OR (typeof(gia_tri_co_so_sau_giam_gia) = 'integer' AND gia_tri_co_so_sau_giam_gia >= 0))",
            "gia_tri_cong_uu_dai": "INTEGER CHECK(gia_tri_cong_uu_dai IS NULL OR (typeof(gia_tri_cong_uu_dai) = 'integer' AND gia_tri_cong_uu_dai >= 0))",
            "thanh_tien_sau_uu_dai": "INTEGER CHECK(thanh_tien_sau_uu_dai IS NULL OR (typeof(thanh_tien_sau_uu_dai) = 'integer' AND thanh_tien_sau_uu_dai >= 0))",
            "uu_dai_source_sheet": "TEXT NOT NULL DEFAULT '' CHECK(length(uu_dai_source_sheet) <= 500)",
            "uu_dai_source_row": "INTEGER CHECK(uu_dai_source_row IS NULL OR uu_dai_source_row > 0)",
            "uu_dai_match_method": "TEXT NOT NULL DEFAULT 'no_15a' CHECK(uu_dai_match_method IN ('no_15a', 'normalized_name_occurrence', 'position', 'manual', 'unmatched'))",
            "uu_dai_match_status": "TEXT NOT NULL DEFAULT 'matched' CHECK(uu_dai_match_status IN ('matched', 'ambiguous', 'conflict'))",
            "uu_dai_source_payload": "TEXT NOT NULL DEFAULT '' CHECK(length(uu_dai_source_payload) <= 20000)",
            "uu_dai_manual_override": "INTEGER NOT NULL DEFAULT 0 CHECK(uu_dai_manual_override IN (0, 1))",
            "uu_dai_manual_actor_id": "TEXT",
            "uu_dai_manual_updated_at": "TEXT",
            "uu_dai_manual_reason": "TEXT NOT NULL DEFAULT '' CHECK(length(uu_dai_manual_reason) <= 1000)",
            "trang_thai_uu_dai": "TEXT NOT NULL DEFAULT 'empty' CHECK(trang_thai_uu_dai IN ('empty', 'draft', 'ready', 'stale'))",
            "mapping_method": "TEXT NOT NULL DEFAULT 'unmatched' CHECK(mapping_method IN ('unmatched', 'auto', 'manual'))",
            "mapping_status": "TEXT NOT NULL DEFAULT 'unmatched' CHECK(mapping_status IN ('matched', 'unmatched', 'duplicate', 'wrong_lot', 'lot_not_found'))",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(sort_order) = 'integer' AND sort_order >= 0)",
            "import_batch_id": "TEXT NOT NULL DEFAULT '' CHECK(length(import_batch_id) <= 160)",
            "is_draft": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_draft) = 'integer' AND is_draft IN (0, 1))",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (phan_lo_id) REFERENCES goi_thau_phan_lo(id) ON DELETE RESTRICT",
            "FOREIGN KEY (goi_thau_hang_hoa_id) REFERENCES goi_thau_hang_hoa(id) ON DELETE RESTRICT",
            "FOREIGN KEY (uu_dai_manual_actor_id) REFERENCES tai_khoan(id) ON DELETE SET NULL",
            "FOREIGN KEY (organization_id, goi_thau_id, thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(organization_id, goi_thau_id, id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, thong_tin_mo_thau_id, goi_thau_hang_hoa_id)"
        ]
    },
    "dot_xu_ly_phan_lo": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "sequence_no": "INTEGER NOT NULL CHECK(sequence_no > 0)",
            "procedure_kind": "TEXT NOT NULL CHECK(procedure_kind IN ('1G1T', '1G2T'))",
            "approval_mode": "TEXT NOT NULL DEFAULT 'CONSOLIDATED_APPROVAL' CHECK(approval_mode IN ('CONSOLIDATED_APPROVAL', 'STAGED_APPROVAL'))",
            "status": "TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT', 'ACTIVE', 'CLOSED', 'VOID'))",
            "policy_version": "INTEGER NOT NULL DEFAULT 1 CHECK(policy_version > 0)",
            "staged_approval_authorized": "INTEGER NOT NULL DEFAULT 0 CHECK(staged_approval_authorized IN (0,1))",
            "authorization_basis": "TEXT",
            "created_by_id": "TEXT",
            "closed_at": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, goi_thau_id, sequence_no)"
        ]
    },
    "dot_xu_ly_phan_lo_chi_tiet": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "batch_id": "TEXT NOT NULL",
            "lot_id": "TEXT NOT NULL",
            "current_stage": "TEXT NOT NULL DEFAULT 'NOT_STARTED' CHECK(current_stage IN ('NOT_STARTED', 'EVALUATION_DRAFT', 'EVALUATION_FINALIZED', 'TECHNICAL_DRAFT', 'TECHNICAL_EVALUATED', 'TECHNICAL_APPRAISED', 'TECHNICAL_APPROVED', 'FINANCIAL_OPENED', 'FINANCIAL_EVALUATED', 'RESULT_APPRAISED', 'RESULT_APPROVED'))",
            "lifecycle_revision": "INTEGER NOT NULL DEFAULT 1 CHECK(lifecycle_revision > 0)",
            "outcome": "TEXT CHECK(outcome IS NULL OR outcome IN ('AWARDED', 'NO_BID', 'NO_TECHNICAL_QUALIFIER', 'NO_FINANCIAL_QUALIFIER', 'NO_RESPONSIVE_BID', 'CANCELLED_LOT', 'REPROCUREMENT_REQUIRED', 'OTHER_APPROVED_OUTCOME'))",
            "is_active": "INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1))",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (batch_id) REFERENCES dot_xu_ly_phan_lo(id) ON DELETE RESTRICT",
            "FOREIGN KEY (lot_id) REFERENCES goi_thau_phan_lo(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, batch_id, lot_id)",
            "CHECK((current_stage = 'RESULT_APPROVED' AND outcome IS NOT NULL) OR (current_stage != 'RESULT_APPROVED' AND outcome IS NULL))"
        ]
    },
    "nhom_phu_thuoc_phan_lo": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "dependency_kind": "TEXT NOT NULL CHECK(dependency_kind IN ('HSMT_GROUP_EVALUATION', 'CROSS_LOT_DISCOUNT', 'AGGREGATE_CAPACITY', 'AWARD_OPTIMIZATION', 'FINANCIAL_DISCLOSURE'))",
            "reason": "TEXT NOT NULL CHECK(trim(reason) != '')",
            "must_move_together": "INTEGER NOT NULL DEFAULT 1 CHECK(must_move_together IN (0,1))",
            "policy_version": "INTEGER NOT NULL DEFAULT 1 CHECK(policy_version > 0)",
            "is_active": "INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1))",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT"
        ]
    },
    "nhom_phu_thuoc_phan_lo_thanh_vien": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "dependency_group_id": "TEXT NOT NULL",
            "lot_id": "TEXT NOT NULL",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (dependency_group_id) REFERENCES nhom_phu_thuoc_phan_lo(id) ON DELETE CASCADE",
            "FOREIGN KEY (lot_id) REFERENCES goi_thau_phan_lo(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, dependency_group_id, lot_id)"
        ]
    },
    "ho_so_nghiep_vu_lcnt": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "batch_id": "TEXT NOT NULL",
            "artifact_type": "TEXT NOT NULL CHECK(artifact_type IN ('SINGLE_STAGE_EVALUATION_REPORT', 'TECHNICAL_EVALUATION_REPORT', 'TECHNICAL_APPRAISAL_REPORT', 'TECHNICAL_APPROVAL_DECISION', 'FINANCIAL_OPENING_MINUTES', 'FINANCIAL_EVALUATION_REPORT', 'RESULT_APPRAISAL_REPORT', 'RESULT_APPROVAL_DECISION'))",
            "status": "TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT', 'FINAL', 'VOID', 'SUPERSEDED'))",
            "document_number": "TEXT",
            "document_date": "TEXT",
            "revision": "INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)",
            "snapshot_schema_version": "INTEGER NOT NULL DEFAULT 1 CHECK(snapshot_schema_version > 0)",
            "snapshot_json": "TEXT NOT NULL DEFAULT '{}'",
            "scope_hash": "TEXT NOT NULL CHECK(trim(scope_hash) != '')",
            "content_digest": "TEXT",
            "finalized_by_id": "TEXT",
            "finalized_at": "TEXT",
            "voided_by_id": "TEXT",
            "voided_at": "TEXT",
            "void_reason": "TEXT",
            "supersedes_id": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (batch_id) REFERENCES dot_xu_ly_phan_lo(id) ON DELETE RESTRICT",
            "FOREIGN KEY (finalized_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL",
            "FOREIGN KEY (voided_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL",
            "FOREIGN KEY (supersedes_id) REFERENCES ho_so_nghiep_vu_lcnt(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, batch_id, artifact_type, revision)",
            "CHECK((status != 'FINAL') OR (document_number IS NOT NULL AND trim(document_number) != '' AND document_date IS NOT NULL))",
            "CHECK((status != 'VOID') OR (void_reason IS NOT NULL AND trim(void_reason) != ''))"
        ]
    },
    "ho_so_nghiep_vu_lcnt_phan_lo": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "artifact_id": "TEXT NOT NULL",
            "lot_id": "TEXT NOT NULL",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (artifact_id) REFERENCES ho_so_nghiep_vu_lcnt(id) ON DELETE RESTRICT",
            "FOREIGN KEY (lot_id) REFERENCES goi_thau_phan_lo(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, artifact_id, lot_id)"
        ]
    },
    "goi_thau_tuy_chon_mua_them": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "hang_muc": "TEXT",
            "don_vi": "TEXT",
            "so_luong": "REAL CHECK(so_luong IS NULL OR (typeof(so_luong) IN ('integer', 'real') AND so_luong >= 0))",
            "ty_le": "REAL CHECK(ty_le IS NULL OR (typeof(ty_le) IN ('integer', 'real') AND ty_le BETWEEN 0 AND 100 AND ty_le = round(ty_le, 4)))",
            "gia_tri_uoc_tinh": "INTEGER CHECK(gia_tri_uoc_tinh IS NULL OR (typeof(gia_tri_uoc_tinh) = 'integer' AND gia_tri_uoc_tinh >= 0))",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE"
        ]
    },
    "goi_thau_gia_han": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "thoi_gian_dong_thau": "TEXT",
            "ly_do_gia_han": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT"
        ]
    },
    "goi_thau_lam_ro": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "loai": "TEXT NOT NULL CHECK(loai IN ('yeu_cau', 'tra_loi'))",
            "thoi_gian": "TEXT",
            "noi_dung": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT"
        ]
    },
    "chuyen_gia": {
        "json_fields": [],
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ho_ten": "TEXT NOT NULL",
            "so_chung_chi": "TEXT",
            "ngay_cap_chung_chi": "TEXT",
            "don_vi_cap_chung_chi": "TEXT",
            "so_cccd": "TEXT",
            "ngay_cap_cccd": "TEXT",
            "noi_cap_cccd": "TEXT",
            "anh_chung_chi": "TEXT",
            "ten_anh_chung_chi": "TEXT",
            "anh_chu_ky": "TEXT",
            "ten_anh_chu_ky": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "field_map": {
            "so_cccd": "soCCCD",
            "ngay_cap_cccd": "ngayCapCCCD",
            "noi_cap_cccd": "noiCapCCCD"
        }
    },
    "hop_dong": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_goc": "TEXT",
            "phien_ban": "TEXT NOT NULL DEFAULT '00'",
            "is_latest": "INTEGER NOT NULL DEFAULT 1 CHECK(typeof(is_latest) = 'integer' AND is_latest IN (0,1))",
            "archived_at": "TEXT",
            "ten_hop_dong": "TEXT NOT NULL CHECK(trim(ten_hop_dong) != '')",
            "so_hop_dong": "TEXT NOT NULL CHECK(trim(so_hop_dong) != '')",
            "ngay_ky": "TEXT NOT NULL CHECK(date(ngay_ky) IS NOT NULL)",
            "chu_dau_tu_id": "TEXT NOT NULL CHECK(trim(chu_dau_tu_id) != '')",
            "nha_thau_id": "TEXT NOT NULL CHECK(trim(nha_thau_id) != '')",
            "ngay_thanh_ly": "TEXT",
            "chu_dau_tu_thanh_ly_id": "TEXT",
            "nha_thau_thanh_ly_id": "TEXT",
            "ke_hoach_id": "TEXT NOT NULL CHECK(trim(ke_hoach_id) != '')",
            "gia_tri": "INTEGER NOT NULL CHECK(typeof(gia_tri) = 'integer' AND gia_tri >= 0)",
            "loai_hop_dong": "TEXT NOT NULL CHECK(trim(loai_hop_dong) != '')",
            "thoi_gian_thuc_hien": "TEXT NOT NULL CHECK(trim(thoi_gian_thuc_hien) != '')",
            "trang_thai_hop_dong": "TEXT NOT NULL DEFAULT 'Đang thực hiện' CHECK(trim(trang_thai_hop_dong) != '')",
            "phan_loai": "TEXT",
            "co_qd_chi_dinh": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(co_qd_chi_dinh) = 'integer' AND co_qd_chi_dinh IN (0,1))",
            "so_qd_chi_dinh": "TEXT",
            "ngay_qd_chi_dinh": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (chu_dau_tu_id) REFERENCES chu_dau_tu(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (chu_dau_tu_thanh_ly_id) REFERENCES chu_dau_tu(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_thanh_ly_id) REFERENCES nha_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (ke_hoach_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, trang_thai_hop_dong) REFERENCES danh_muc_trang_thai_hop_dong(organization_id, name) ON UPDATE CASCADE ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "CHECK(NULLIF(ngay_ky, '') IS NULL OR NULLIF(ngay_thanh_ly, '') IS NULL OR (date(ngay_ky) IS NOT NULL AND date(ngay_thanh_ly) IS NOT NULL AND date(ngay_thanh_ly) >= date(ngay_ky)))",
            "CHECK((co_qd_chi_dinh = 0 AND COALESCE(trim(so_qd_chi_dinh), '') = '' AND COALESCE(trim(ngay_qd_chi_dinh), '') = '') OR (co_qd_chi_dinh = 1 AND COALESCE(trim(so_qd_chi_dinh), '') != '' AND date(ngay_qd_chi_dinh) IS NOT NULL AND date(ngay_qd_chi_dinh) <= date(ngay_ky)))"
        ],
        "field_map": {
            "thoi_gian_thuc_hien": "soNgayThucHien",
            "ke_hoach_id": "keHoachId"
        }
    },
    "hop_dong_goi_thau": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "hop_dong_id": "TEXT NOT NULL",
            "goi_thau_id": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "primary_keys": ["organization_id", "hop_dong_id", "goi_thau_id"],
        "foreign_keys": [
            "FOREIGN KEY (hop_dong_id) REFERENCES hop_dong(id) ON DELETE RESTRICT",
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT"
        ]
    },
    "phan_cong_nhan_su": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "id_nhan_vien": "TEXT NOT NULL",
            "id_muc_tieu": "TEXT NOT NULL",
            "loai_doi_tuong": "TEXT NOT NULL CHECK(loai_doi_tuong IN ('kehoach', 'goithau', 'hopdong'))",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, id_nhan_vien, id_muc_tieu, loai_doi_tuong)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (id_nhan_vien) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ],
        "field_map": {
            "id_nhan_vien": "empId",
            "id_muc_tieu": "targetId",
            "loai_doi_tuong": "type"
        }
    },



    "danh_muc_trang_thai_hop_dong": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "name": "TEXT NOT NULL",
            "color": "TEXT NOT NULL DEFAULT '#64748b'",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "unique_constraints": ["UNIQUE(organization_id, name)"]
    },






    "thong_tin_mo_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "archived_at": "TEXT",
            "goi_thau_id": "TEXT NOT NULL",
            "nha_thau_id": "TEXT NOT NULL",
            "ma_phan_lo": "TEXT NOT NULL DEFAULT ''",
            "ma_phan_lo_normalized": "TEXT NOT NULL DEFAULT ''",
            "ten_phan_lo": "TEXT",
            "ma_dinh_danh": "TEXT",
            "gia_du_thau": "INTEGER CHECK(gia_du_thau IS NULL OR (typeof(gia_du_thau) = 'integer' AND gia_du_thau >= 0))",
            "ty_le_giam_gia": "REAL CHECK(ty_le_giam_gia IS NULL OR (typeof(ty_le_giam_gia) IN ('integer', 'real') AND ty_le_giam_gia BETWEEN 0 AND 100 AND ty_le_giam_gia = round(ty_le_giam_gia, 4)))",
            "gia_sau_giam_gia": "INTEGER CHECK(gia_sau_giam_gia IS NULL OR (typeof(gia_sau_giam_gia) = 'integer' AND gia_sau_giam_gia >= 0))",
            "tong_gia_tri_cong_uu_dai": "INTEGER CHECK(tong_gia_tri_cong_uu_dai IS NULL OR (typeof(tong_gia_tri_cong_uu_dai) = 'integer' AND tong_gia_tri_cong_uu_dai >= 0))",
            "gia_so_sanh_sau_uu_dai": "INTEGER CHECK(gia_so_sanh_sau_uu_dai IS NULL OR (typeof(gia_so_sanh_sau_uu_dai) = 'integer' AND gia_so_sanh_sau_uu_dai >= 0))",
            "gia_danh_gia_sau_uu_dai": "INTEGER CHECK(gia_danh_gia_sau_uu_dai IS NULL OR (typeof(gia_danh_gia_sau_uu_dai) = 'integer' AND gia_danh_gia_sau_uu_dai >= 0))",
            "trang_thai_tinh_uu_dai": "TEXT NOT NULL DEFAULT 'empty' CHECK(trang_thai_tinh_uu_dai IN ('empty', 'draft', 'ready', 'stale'))",
            "uu_dai_tinh_luc": "TEXT",
            "uu_dai_input_hash": "TEXT NOT NULL DEFAULT '' CHECK(length(uu_dai_input_hash) <= 128)",
            "hieu_luc_hsdt": "INTEGER CHECK(hieu_luc_hsdt IS NULL OR hieu_luc_hsdt >= 0)",
            "gia_tri_dam_bao": "INTEGER CHECK(gia_tri_dam_bao IS NULL OR (typeof(gia_tri_dam_bao) = 'integer' AND gia_tri_dam_bao >= 0))",
            "hieu_luc_bao_dam_ngay": "INTEGER CHECK(hieu_luc_bao_dam_ngay IS NULL OR hieu_luc_bao_dam_ngay >= 0)",
            "thoi_gian_thuc_hien": "TEXT",
            "ten_nha_thau": "TEXT",
            "loai_nha_thau": "TEXT",
            "violation_status": "TEXT NOT NULL DEFAULT 'NOT_CHECKED' CHECK(violation_status IN ('VIOLATION_CONFIRMED', 'NO_ACTIVE_VIOLATION', 'REVIEW_REQUIRED', 'LOOKUP_FAILED', 'NOT_CHECKED', 'IDENTITY_CONFLICT'))",
            "violation_bid_closing_at": "TEXT",
            "violation_checked_at": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT"
        ],
        "field_map": {
            "goi_thau_id": "goiThauId",
            "nha_thau_id": "nhaThauId",
            "ma_phan_lo": "maPhanLo",
            "ten_phan_lo": "tenPhanLo",
            "ma_dinh_danh": "maDinhDanh",
            "gia_du_thau": "giaDuThau",
            "ty_le_giam_gia": "tyLeGiamGia",
            "gia_sau_giam_gia": "giaSauGiamGia",
            "hieu_luc_hsdt": "hieuLucHsdt",
            "gia_tri_dam_bao": "giaTriDamBao",
            "hieu_luc_bao_dam_ngay": "hieuLucBaoDamNgay",
            "thoi_gian_thuc_hien": "thoiGianThucHien",
            "ten_nha_thau": "tenNhaThau",
            "loai_nha_thau": "loaiNhaThau",
            "violation_status": "violationStatus",
            "violation_bid_closing_at": "violationBidClosingAt",
            "violation_checked_at": "violationCheckedAt",
        },
        "unique_constraints": [
            "UNIQUE(organization_id, goi_thau_id, id)"
        ]
    },
    "thong_tin_mo_thau_lien_danh_thanh_vien": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "thong_tin_mo_thau_id": "TEXT NOT NULL",
            "thanh_vien_nha_thau_id": "TEXT NOT NULL",
            "ten_nha_thau": "TEXT",
            "ma_nha_thau": "TEXT",
            "ma_so_thue": "TEXT",
            "vai_tro": "TEXT NOT NULL CHECK(vai_tro IN ('Đứng đầu liên danh', 'Thành viên liên danh'))",
            "nguoi_dai_dien": "TEXT",
            "danh_xung": "TEXT",
            "so_dien_thoai": "TEXT",
            "email": "TEXT",
            "dia_chi": "TEXT",
            "dia_chi_goc": "TEXT",
            "so_tai_khoan": "TEXT",
            "noi_mo_tai_khoan": "TEXT",
            "ma_ngan_hang": "TEXT",
            "violation_status": "TEXT NOT NULL DEFAULT 'NOT_CHECKED' CHECK(violation_status IN ('VIOLATION_CONFIRMED', 'NO_ACTIVE_VIOLATION', 'REVIEW_REQUIRED', 'LOOKUP_FAILED', 'NOT_CHECKED', 'IDENTITY_CONFLICT'))",
            "violation_bid_closing_at": "TEXT",
            "violation_checked_at": "TEXT",
            "sort_order": "INTEGER DEFAULT 0",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (thanh_vien_nha_thau_id) REFERENCES nha_thau(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, thong_tin_mo_thau_id, thanh_vien_nha_thau_id)"
        ]
    },
    "nha_thau_tham_du_mo_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "thong_tin_mo_thau_id": "TEXT NOT NULL",
            "goi_thau_id": "TEXT NOT NULL",
            "lot_scope": "TEXT NOT NULL CHECK(trim(lot_scope) != '')",
            "nha_thau_goc_id": "TEXT NOT NULL",
            "nha_thau_phien_ban_id": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, thong_tin_mo_thau_id, nha_thau_goc_id)",
            "UNIQUE(organization_id, goi_thau_id, lot_scope, nha_thau_goc_id)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (nha_thau_goc_id) REFERENCES nha_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (nha_thau_phien_ban_id) REFERENCES nha_thau(id) ON DELETE RESTRICT"
        ]
    },
    "contractor_violation_checks": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "package_id": "TEXT NOT NULL",
            "lot_id": "TEXT",
            "bid_opening_record_id": "TEXT NOT NULL",
            "contractor_id": "TEXT",
            "joint_venture_member_id": "TEXT",
            "contractor_identifier": "TEXT NOT NULL CHECK(trim(contractor_identifier) != '')",
            "tax_code": "TEXT",
            "bid_closing_at": "TEXT",
            "checked_at": "TEXT NOT NULL",
            "status": "TEXT NOT NULL CHECK(status IN ('VIOLATION_CONFIRMED', 'NO_ACTIVE_VIOLATION', 'REVIEW_REQUIRED', 'LOOKUP_FAILED', 'NOT_CHECKED', 'IDENTITY_CONFLICT'))",
            "matched_identity_type": "TEXT NOT NULL CHECK(matched_identity_type IN ('CONTRACTOR_IDENTIFIER', 'TAX_CODE', 'NONE'))",
            "rule_version": "TEXT NOT NULL CHECK(trim(rule_version) != '')",
            "source_provider": "TEXT NOT NULL CHECK(trim(source_provider) != '')",
            "source_payload_hash": "TEXT NOT NULL DEFAULT '' CHECK(length(source_payload_hash) IN (0, 64))",
            "source_records_json": "TEXT NOT NULL DEFAULT '[]'",
            "is_stale": "INTEGER NOT NULL DEFAULT 0 CHECK(is_stale IN (0,1))",
            "created_by": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (package_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (lot_id) REFERENCES goi_thau_phan_lo(id) ON DELETE CASCADE",
            "FOREIGN KEY (bid_opening_record_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (contractor_id) REFERENCES nha_thau(id) ON DELETE SET NULL",
            "FOREIGN KEY (joint_venture_member_id) REFERENCES thong_tin_mo_thau_lien_danh_thanh_vien(id) ON DELETE CASCADE",
            "FOREIGN KEY (created_by) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "to_chuc": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "ten_to_chuc": "TEXT NOT NULL",
            "ma_so_thue": "TEXT",
            "ten_viet_tat": "TEXT",
            "owner_user_id": "TEXT",
            "trang_thai": "TEXT NOT NULL DEFAULT 'active' CHECK(trang_thai IN ('active', 'suspended'))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (owner_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "thanh_vien_to_chuc": {
        "columns": {
            "user_id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL",
            "vai_tro_trong_to_chuc": "TEXT NOT NULL DEFAULT 'employee' CHECK(vai_tro_trong_to_chuc IN ('manager', 'employee'))",
            "ten_nhan_su": "TEXT",
            "so_dien_thoai": "TEXT",
            "trang_thai_thanh_vien": "TEXT NOT NULL DEFAULT 'active' CHECK(trang_thai_thanh_vien IN ('active', 'left'))",
            "left_at": "TEXT",
            "left_by": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "primary_keys": ["user_id", "organization_id"],
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE",
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE CASCADE"
        ]
    },
    "goi_thau_chuyen_gia": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "chuyen_gia_id": "TEXT NOT NULL",
            "loai": "TEXT NOT NULL DEFAULT 'chuyen_gia'",
            "chuc_vu": "TEXT",
            "cong_viec": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "primary_keys": ["organization_id", "goi_thau_id", "chuyen_gia_id", "loai"],
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (chuyen_gia_id) REFERENCES chuyen_gia(id) ON DELETE RESTRICT"
        ]
    },
    "deleted_records": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "table_name": "TEXT NOT NULL",
            "record_id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "delete_version": "INTEGER DEFAULT 0",
            "deleted_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "record_snapshot_json": "TEXT",
            "delete_actor_user_id": "TEXT",
            "delete_mutation_id": "TEXT"
        }
    },
    "cau_hinh_bien_word": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "ten_bien": "TEXT NOT NULL",
            "source_table": "TEXT NOT NULL",
            "source_column": "TEXT NOT NULL",
            "mo_ta": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, ten_bien)",
            "UNIQUE(organization_id, source_table, source_column)"
        ]
    },

    "word_mapping_overrides": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL CHECK(owner_type IN ('organization', 'personal'))",
            "mapping_key": "TEXT NOT NULL CHECK(mapping_key != '')",
            "ten_bien_override": "TEXT",
            "source_table_override": "TEXT",
            "source_column_override": "TEXT",
            "mo_ta_override": "TEXT",
            "disabled": "INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1))",
            "base_version": "INTEGER NOT NULL CHECK(base_version > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["organization_id", "mapping_key"]
    },



    "ma_tran_phan_quyen": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "emp_id": "TEXT NOT NULL",
            "kehoach": "TEXT NOT NULL DEFAULT '' CHECK(kehoach IN ('', 'view', 'edit'))",
            "goithau": "TEXT NOT NULL DEFAULT '' CHECK(goithau IN ('', 'view', 'edit'))",
            "chudautu": "TEXT NOT NULL DEFAULT '' CHECK(chudautu IN ('', 'view', 'edit'))",
            "nhathau": "TEXT NOT NULL DEFAULT '' CHECK(nhathau IN ('', 'view', 'edit'))",
            "chuyengia": "TEXT NOT NULL DEFAULT '' CHECK(chuyengia IN ('', 'view', 'edit'))",
            "hopdong": "TEXT NOT NULL DEFAULT '' CHECK(hopdong IN ('', 'view', 'edit'))",
            "thongtinmothau": "TEXT NOT NULL DEFAULT '' CHECK(thongtinmothau IN ('', 'view', 'edit'))",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, emp_id)"
        ]
    },
    "sync_metadata": {
        "columns": {
            "organization_id": "TEXT PRIMARY KEY CHECK(organization_id != '')",
            "current_version": "INTEGER NOT NULL DEFAULT 0",
            "min_available_version": "INTEGER NOT NULL DEFAULT 0 CHECK(min_available_version >= 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "unique_constraints": [
            "CONSTRAINT sync_metadata_current_version_nonnegative_check CHECK(current_version >= 0)",
            "CONSTRAINT sync_metadata_available_version_order_check CHECK(min_available_version <= current_version)"
        ]
    },
    "organization_subscriptions": {
        "columns": {
            "organization_id": "TEXT PRIMARY KEY",
            "package_id": "TEXT NOT NULL",
            "plan_version_id": "TEXT",
            "source": "TEXT NOT NULL DEFAULT 'legacy' CHECK(source IN ('legacy', 'admin', 'order'))",
            "source_order_id": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'suspended', 'expired', 'cancelled'))",
            "starts_at": "INTEGER NOT NULL CHECK(starts_at > 0)",
            "expires_at": "INTEGER CHECK(expires_at IS NULL OR expires_at > starts_at)",
            "member_quota": "INTEGER NOT NULL CHECK(member_quota > 0)",
            "revision": "INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE CASCADE",
            "FOREIGN KEY (package_id) REFERENCES goi_dich_vu(id) ON DELETE RESTRICT",
            "FOREIGN KEY (plan_version_id) REFERENCES billing_plan_versions(id) ON DELETE RESTRICT",
            "FOREIGN KEY (source_order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT"
        ]
    },
    "account_subscriptions": {
        "columns": {
            "user_id": "TEXT PRIMARY KEY",
            "package_id": "TEXT NOT NULL",
            "plan_version_id": "TEXT",
            "source": "TEXT NOT NULL DEFAULT 'legacy' CHECK(source IN ('legacy', 'admin', 'order'))",
            "source_order_id": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'suspended', 'expired', 'cancelled'))",
            "starts_at": "INTEGER NOT NULL CHECK(starts_at > 0)",
            "expires_at": "INTEGER CHECK(expires_at IS NULL OR expires_at > starts_at)",
            "revision": "INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE",
            "FOREIGN KEY (package_id) REFERENCES goi_dich_vu(id) ON DELETE RESTRICT",
            "FOREIGN KEY (plan_version_id) REFERENCES billing_plan_versions(id) ON DELETE RESTRICT",
            "FOREIGN KEY (source_order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_drafts": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "schema_version": "INTEGER NOT NULL DEFAULT 1 CHECK(schema_version > 0)",
            "base_release_id": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'validated', 'archived'))",
            "revision": "INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)",
            "document_json": "TEXT NOT NULL CHECK(length(document_json) BETWEEN 2 AND 262144)",
            "checksum": "TEXT NOT NULL CHECK(length(checksum) = 64)",
            "validation_digest": "TEXT CHECK(validation_digest IS NULL OR length(validation_digest) = 64)",
            "validation_revision": "INTEGER CHECK(validation_revision IS NULL OR validation_revision > 0)",
            "validation_json": "TEXT CHECK(validation_json IS NULL OR length(validation_json) <= 262144)",
            "readiness_expires_at": "INTEGER",
            "created_by": "TEXT NOT NULL",
            "updated_by": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (base_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (updated_by) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_releases": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "version_label": "TEXT NOT NULL UNIQUE CHECK(trim(version_label) != '')",
            "schema_version": "INTEGER NOT NULL DEFAULT 1 CHECK(schema_version > 0)",
            "checksum": "TEXT NOT NULL CHECK(length(checksum) = 64)",
            "snapshot_json": "TEXT NOT NULL CHECK(length(snapshot_json) BETWEEN 2 AND 262144)",
            "mode": "TEXT NOT NULL CHECK(mode IN ('legacy', 'shadow', 'pilot', 'production'))",
            "scope_key": "TEXT NOT NULL DEFAULT 'global' CHECK(trim(scope_key) != '')",
            "effective_from": "INTEGER NOT NULL CHECK(effective_from > 0)",
            "non_sellable": "INTEGER NOT NULL DEFAULT 0 CHECK(non_sellable IN (0,1))",
            "base_release_id": "TEXT",
            "published_by": "TEXT",
            "reason": "TEXT NOT NULL CHECK(length(trim(reason)) BETWEEN 3 AND 2000)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (base_release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (published_by) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_release_timeline": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "release_id": "TEXT NOT NULL",
            "event_type": "TEXT NOT NULL CHECK(event_type IN ('published', 'scheduled', 'stop_sales'))",
            "scope_key": "TEXT NOT NULL DEFAULT 'global' CHECK(trim(scope_key) != '')",
            "effective_at": "INTEGER NOT NULL CHECK(effective_at > 0)",
            "scope_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(scope_json) <= 32768)",
            "reason": "TEXT NOT NULL CHECK(length(trim(reason)) BETWEEN 3 AND 2000)",
            "actor_user_id": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_policy_versions": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "release_id": "TEXT NOT NULL",
            "policy_kind": "TEXT NOT NULL CHECK(trim(policy_kind) != '')",
            "selector": "TEXT NOT NULL DEFAULT 'default' CHECK(trim(selector) != '')",
            "schema_version": "INTEGER NOT NULL DEFAULT 1 CHECK(schema_version > 0)",
            "payload_json": "TEXT NOT NULL CHECK(length(payload_json) BETWEEN 2 AND 65536)",
            "checksum": "TEXT NOT NULL CHECK(length(checksum) = 64)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(release_id, policy_kind, selector)"],
        "foreign_keys": [
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "billing_plan_versions": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "release_id": "TEXT NOT NULL",
            "logical_package_code": "TEXT NOT NULL CHECK(trim(logical_package_code) != '')",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "tier": "TEXT NOT NULL CHECK(tier IN ('personal', 'silver', 'gold', 'diamond'))",
            "variant": "TEXT NOT NULL CHECK(variant IN ('internal', 'connected'))",
            "legacy_package_id": "TEXT",
            "member_quota": "INTEGER NOT NULL CHECK(member_quota > 0)",
            "included_procurement_quota": "INTEGER NOT NULL DEFAULT 0 CHECK(included_procurement_quota >= 0)",
            "document_export_word": "INTEGER NOT NULL CHECK(document_export_word IN (0,1))",
            "document_export_excel": "INTEGER NOT NULL CHECK(document_export_excel IN (0,1))",
            "document_export_award_result_excel": "INTEGER NOT NULL CHECK(document_export_award_result_excel IN (0,1))",
            "violation_check_enabled": "INTEGER NOT NULL DEFAULT 0 CHECK(violation_check_enabled IN (0,1))",
            "sales_state": "TEXT NOT NULL DEFAULT 'non_sellable' CHECK(sales_state IN ('sellable', 'stopped', 'non_sellable'))",
            "display_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(display_json) <= 32768)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(release_id, logical_package_code)"],
        "foreign_keys": [
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (legacy_package_id) REFERENCES goi_dich_vu(id) ON DELETE RESTRICT"
        ]
    },
    "billing_skus": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "release_id": "TEXT NOT NULL",
            "sku_code": "TEXT NOT NULL CHECK(trim(sku_code) != '')",
            "item_type": "TEXT NOT NULL CHECK(item_type IN ('base_plan', 'procurement_credit_pack'))",
            "plan_version_id": "TEXT",
            "quantity": "INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0)",
            "repeatable": "INTEGER NOT NULL DEFAULT 0 CHECK(repeatable IN (0,1))",
            "sales_state": "TEXT NOT NULL DEFAULT 'non_sellable' CHECK(sales_state IN ('sellable', 'stopped', 'non_sellable'))",
            "display_order": "INTEGER NOT NULL DEFAULT 0 CHECK(display_order >= 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(release_id, sku_code)"],
        "foreign_keys": [
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (plan_version_id) REFERENCES billing_plan_versions(id) ON DELETE RESTRICT"
        ]
    },
    "billing_prices": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "release_id": "TEXT NOT NULL",
            "sku_id": "TEXT NOT NULL",
            "period": "TEXT NOT NULL CHECK(period IN ('monthly', 'yearly', 'one_time'))",
            "currency": "TEXT NOT NULL DEFAULT 'VND' CHECK(currency = 'VND')",
            "subtotal_amount": "INTEGER NOT NULL CHECK(subtotal_amount >= 0)",
            "tax_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(tax_amount >= 0)",
            "total_amount": "INTEGER NOT NULL CHECK(total_amount = subtotal_amount + tax_amount)",
            "tax_profile_ref": "TEXT",
            "effective_at": "INTEGER NOT NULL CHECK(effective_at > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(release_id, sku_id, period)"],
        "foreign_keys": [
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (sku_id) REFERENCES billing_skus(id) ON DELETE RESTRICT"
        ]
    },
    "payment_provider_profiles": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "version": "INTEGER NOT NULL CHECK(version > 0)",
            "provider": "TEXT NOT NULL CHECK(provider IN ('fake', 'payos'))",
            "environment": "TEXT NOT NULL CHECK(environment IN ('test', 'staging', 'production'))",
            "public_alias": "TEXT NOT NULL CHECK(trim(public_alias) != '')",
            "merchant_reference": "TEXT",
            "credential_reference": "TEXT",
            "capabilities_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(capabilities_json) <= 8192)",
            "min_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(min_amount >= 0)",
            "max_amount": "INTEGER NOT NULL CHECK(max_amount >= min_amount)",
            "checkout_ttl_seconds": "INTEGER NOT NULL CHECK(checkout_ttl_seconds BETWEEN 60 AND 86400)",
            "timeout_ms": "INTEGER NOT NULL CHECK(timeout_ms BETWEEN 100 AND 30000)",
            "max_attempts": "INTEGER NOT NULL CHECK(max_attempts BETWEEN 1 AND 10)",
            "routing_priority": "INTEGER NOT NULL DEFAULT 100 CHECK(routing_priority >= 0)",
            "mode": "TEXT NOT NULL CHECK(mode IN ('shadow', 'live', 'paused'))",
            "readiness_status": "TEXT NOT NULL CHECK(readiness_status IN ('unknown', 'ready', 'blocked_external', 'unhealthy'))",
            "last_health_checked_at": "INTEGER",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(provider, environment, version)"]
    },
    "billing_quotes": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "public_id": "TEXT NOT NULL UNIQUE CHECK(length(public_id) BETWEEN 20 AND 128)",
            "actor_user_id": "TEXT NOT NULL",
            "account_user_id": "TEXT",
            "organization_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "operation": "TEXT NOT NULL CHECK(operation IN ('purchase', 'renew', 'upgrade', 'downgrade', 'credit_pack'))",
            "request_hash": "TEXT NOT NULL CHECK(length(request_hash) = 64)",
            "release_id": "TEXT NOT NULL",
            "release_checksum": "TEXT NOT NULL CHECK(length(release_checksum) = 64)",
            "decision_json": "TEXT NOT NULL CHECK(length(decision_json) BETWEEN 2 AND 65536)",
            "subtotal_amount": "INTEGER NOT NULL CHECK(subtotal_amount >= 0)",
            "tax_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(tax_amount >= 0)",
            "total_amount": "INTEGER NOT NULL CHECK(total_amount = subtotal_amount + tax_amount)",
            "currency": "TEXT NOT NULL DEFAULT 'VND' CHECK(currency = 'VND')",
            "expected_subscription_revision": "INTEGER",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "CHECK((owner_kind = 'account' AND account_user_id IS NOT NULL AND organization_id IS NULL) OR (owner_kind = 'organization' AND account_user_id IS NULL AND organization_id IS NOT NULL))",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (account_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE RESTRICT",
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "billing_orders": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "public_id": "TEXT NOT NULL UNIQUE CHECK(length(public_id) BETWEEN 20 AND 128)",
            "quote_id": "TEXT NOT NULL UNIQUE",
            "actor_user_id": "TEXT NOT NULL",
            "account_user_id": "TEXT",
            "organization_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "operation": "TEXT NOT NULL CHECK(operation IN ('purchase', 'renew', 'upgrade', 'downgrade', 'credit_pack'))",
            "idempotency_key": "TEXT NOT NULL CHECK(length(idempotency_key) BETWEEN 8 AND 128)",
            "request_hash": "TEXT NOT NULL CHECK(length(request_hash) = 64)",
            "release_id": "TEXT NOT NULL",
            "provider_profile_id": "TEXT NOT NULL",
            "provider_order_code": "INTEGER NOT NULL CHECK(provider_order_code > 0)",
            "provider_reference": "TEXT NOT NULL CHECK(trim(provider_reference) != '')",
            "decision_json": "TEXT NOT NULL CHECK(length(decision_json) BETWEEN 2 AND 65536)",
            "subtotal_amount": "INTEGER NOT NULL CHECK(subtotal_amount >= 0)",
            "tax_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(tax_amount >= 0)",
            "total_amount": "INTEGER NOT NULL CHECK(total_amount = subtotal_amount + tax_amount)",
            "currency": "TEXT NOT NULL DEFAULT 'VND' CHECK(currency = 'VND')",
            "checkout_state": "TEXT NOT NULL DEFAULT 'creating' CHECK(checkout_state IN ('creating', 'open', 'create_failed', 'cancelled', 'expired'))",
            "payment_state": "TEXT NOT NULL DEFAULT 'unverified' CHECK(payment_state IN ('unverified', 'verified_paid', 'refund_pending', 'partially_refunded', 'refunded', 'refund_failed'))",
            "activation_state": "TEXT NOT NULL DEFAULT 'not_ready' CHECK(activation_state IN ('not_ready', 'pending', 'applied', 'retry', 'review_required', 'reversed'))",
            "checkout_url": "TEXT",
            "checkout_payment_json": "TEXT CHECK(length(checkout_payment_json) BETWEEN 2 AND 8192)",
            "checkout_expires_at": "INTEGER",
            "expected_subscription_revision": "INTEGER",
            "revision": "INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "UNIQUE(actor_user_id, owner_kind, account_user_id, organization_id, operation, idempotency_key)",
            "UNIQUE(provider_profile_id, provider_order_code)"
        ],
        "foreign_keys": [
            "CHECK((owner_kind = 'account' AND account_user_id IS NOT NULL AND organization_id IS NULL) OR (owner_kind = 'organization' AND account_user_id IS NULL AND organization_id IS NOT NULL))",
            "FOREIGN KEY (quote_id) REFERENCES billing_quotes(id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (account_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE RESTRICT",
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT",
            "FOREIGN KEY (provider_profile_id) REFERENCES payment_provider_profiles(id) ON DELETE RESTRICT"
        ]
    },
    "billing_order_items": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL",
            "sku_id": "TEXT NOT NULL",
            "plan_version_id": "TEXT",
            "price_id": "TEXT NOT NULL",
            "quantity": "INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0)",
            "snapshot_json": "TEXT NOT NULL CHECK(length(snapshot_json) BETWEEN 2 AND 65536)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT",
            "FOREIGN KEY (sku_id) REFERENCES billing_skus(id) ON DELETE RESTRICT",
            "FOREIGN KEY (plan_version_id) REFERENCES billing_plan_versions(id) ON DELETE RESTRICT",
            "FOREIGN KEY (price_id) REFERENCES billing_prices(id) ON DELETE RESTRICT"
        ]
    },
    "billing_provider_commands": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL",
            "command_type": "TEXT NOT NULL CHECK(command_type IN ('create_checkout', 'cancel_checkout', 'query_order'))",
            "provider_reference": "TEXT NOT NULL",
            "request_json": "TEXT NOT NULL CHECK(length(request_json) BETWEEN 2 AND 32768)",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'retry', 'completed', 'dead'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL CHECK(available_at > 0)",
            "lease_expires_at": "INTEGER",
            "locked_by": "TEXT",
            "last_error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(order_id, command_type)"],
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT"
        ]
    },
    "payment_transactions": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL",
            "provider_profile_id": "TEXT NOT NULL",
            "provider_transaction_id": "TEXT NOT NULL",
            "transaction_type": "TEXT NOT NULL CHECK(transaction_type IN ('payment', 'refund'))",
            "status": "TEXT NOT NULL CHECK(status IN ('verified', 'settled', 'failed'))",
            "verified_paid_amount": "INTEGER NOT NULL CHECK(verified_paid_amount >= 0)",
            "fee_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(fee_amount >= 0)",
            "net_settled_amount": "INTEGER NOT NULL DEFAULT 0 CHECK(net_settled_amount >= 0)",
            "currency": "TEXT NOT NULL DEFAULT 'VND' CHECK(currency = 'VND')",
            "payment_timing": "TEXT CHECK(payment_timing IN ('on_time', 'late_after_cancel', 'late_after_expiry'))",
            "provider_occurred_at": "INTEGER",
            "evidence_json": "TEXT NOT NULL CHECK(length(evidence_json) BETWEEN 2 AND 32768)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(provider_profile_id, provider_transaction_id, transaction_type)"],
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT",
            "FOREIGN KEY (provider_profile_id) REFERENCES payment_provider_profiles(id) ON DELETE RESTRICT"
        ]
    },
    "payment_webhook_events": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "provider_profile_id": "TEXT NOT NULL",
            "dedupe_key": "TEXT NOT NULL CHECK(trim(dedupe_key) != '')",
            "payload_hash": "TEXT NOT NULL CHECK(length(payload_hash) = 64)",
            "signed_fields_json": "TEXT NOT NULL CHECK(length(signed_fields_json) BETWEEN 2 AND 32768)",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'retry', 'processed', 'dead', 'ignored', 'review'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL CHECK(available_at > 0)",
            "lease_expires_at": "INTEGER",
            "locked_by": "TEXT",
            "last_error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "processed_at": "INTEGER"
        },
        "unique_constraints": ["UNIQUE(provider_profile_id, dedupe_key, payload_hash)"],
        "foreign_keys": [
            "FOREIGN KEY (provider_profile_id) REFERENCES payment_provider_profiles(id) ON DELETE RESTRICT"
        ]
    },
    "billing_subscription_activations": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL UNIQUE",
            "state": "TEXT NOT NULL CHECK(state IN ('pending', 'applied', 'retry', 'review_required', 'reversed'))",
            "before_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(before_json) <= 32768)",
            "after_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(after_json) <= 32768)",
            "expected_revision": "INTEGER",
            "applied_revision": "INTEGER",
            "reason_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT"
        ]
    },
    "billing_refund_intents": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL",
            "idempotency_key": "TEXT NOT NULL CHECK(length(idempotency_key) BETWEEN 8 AND 128)",
            "amount": "INTEGER NOT NULL CHECK(amount > 0)",
            "reason": "TEXT NOT NULL CHECK(length(trim(reason)) BETWEEN 3 AND 2000)",
            "actor_user_id": "TEXT NOT NULL",
            "method": "TEXT NOT NULL CHECK(method IN ('manual_off_platform', 'provider'))",
            "state": "TEXT NOT NULL CHECK(state IN ('pending', 'succeeded', 'failed', 'cancelled'))",
            "activation_revision": "INTEGER NOT NULL CHECK(activation_revision > 0)",
            "provider_reference": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(order_id, idempotency_key)"],
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ]
    },
    "usage_credit_grants": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "account_user_id": "TEXT",
            "organization_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "feature": "TEXT NOT NULL CHECK(feature = 'procurement.source_fetch')",
            "total": "INTEGER NOT NULL CHECK(total > 0)",
            "remaining": "INTEGER NOT NULL CHECK(remaining >= 0 AND remaining <= total)",
            "reserved": "INTEGER NOT NULL DEFAULT 0 CHECK(reserved >= 0 AND reserved <= remaining)",
            "source": "TEXT NOT NULL CHECK(source IN ('plan', 'purchase', 'admin'))",
            "order_item_id": "TEXT",
            "release_id": "TEXT NOT NULL",
            "policy_checksum": "TEXT NOT NULL CHECK(length(policy_checksum) = 64)",
            "issued_at": "INTEGER NOT NULL CHECK(issued_at > 0)",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > issued_at)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "CHECK((owner_kind = 'account' AND account_user_id IS NOT NULL AND organization_id IS NULL) OR (owner_kind = 'organization' AND account_user_id IS NULL AND organization_id IS NOT NULL))",
            "FOREIGN KEY (account_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE RESTRICT",
            "FOREIGN KEY (order_item_id) REFERENCES billing_order_items(id) ON DELETE RESTRICT",
            "FOREIGN KEY (release_id) REFERENCES commercial_releases(id) ON DELETE RESTRICT"
        ]
    },
    "usage_reservations": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "account_user_id": "TEXT",
            "organization_id": "TEXT",
            "owner_kind": "TEXT NOT NULL CHECK(owner_kind IN ('account', 'organization'))",
            "feature": "TEXT NOT NULL CHECK(feature = 'procurement.source_fetch')",
            "provider": "TEXT NOT NULL CHECK(trim(provider) != '')",
            "entity_kind": "TEXT NOT NULL CHECK(trim(entity_kind) != '')",
            "source_code": "TEXT NOT NULL CHECK(trim(source_code) != '')",
            "source_revision": "TEXT NOT NULL CHECK(trim(source_revision) != '')",
            "job_key": "TEXT NOT NULL CHECK(trim(job_key) != '')",
            "grant_id": "TEXT NOT NULL",
            "state": "TEXT NOT NULL DEFAULT 'reserved' CHECK(state IN ('reserved', 'consumed', 'released'))",
            "lease_expires_at": "INTEGER NOT NULL CHECK(lease_expires_at > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": ["UNIQUE(owner_kind, account_user_id, organization_id, feature, provider, entity_kind, source_code, source_revision)"],
        "foreign_keys": [
            "CHECK((owner_kind = 'account' AND account_user_id IS NOT NULL AND organization_id IS NULL) OR (owner_kind = 'organization' AND account_user_id IS NULL AND organization_id IS NOT NULL))",
            "FOREIGN KEY (account_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE RESTRICT",
            "FOREIGN KEY (grant_id) REFERENCES usage_credit_grants(id) ON DELETE RESTRICT"
        ]
    },
    "usage_ledger": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "grant_id": "TEXT NOT NULL",
            "reservation_id": "TEXT",
            "entry_type": "TEXT NOT NULL CHECK(entry_type IN ('grant', 'reserve', 'consume', 'release', 'expire', 'adjust'))",
            "quantity": "INTEGER NOT NULL CHECK(quantity != 0)",
            "balance_after": "INTEGER NOT NULL CHECK(balance_after >= 0)",
            "metadata_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(metadata_json) <= 32768)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (grant_id) REFERENCES usage_credit_grants(id) ON DELETE RESTRICT",
            "FOREIGN KEY (reservation_id) REFERENCES usage_reservations(id) ON DELETE RESTRICT"
        ]
    },
    "billing_invoice_requests": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "order_id": "TEXT NOT NULL UNIQUE",
            "payment_transaction_id": "TEXT NOT NULL",
            "tax_snapshot_json": "TEXT NOT NULL CHECK(length(tax_snapshot_json) BETWEEN 2 AND 32768)",
            "buyer_profile_json": "TEXT NOT NULL CHECK(length(buyer_profile_json) BETWEEN 2 AND 32768)",
            "status": "TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested', 'issued', 'failed'))",
            "idempotency_key": "TEXT NOT NULL UNIQUE",
            "provider_reference": "TEXT",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (order_id) REFERENCES billing_orders(id) ON DELETE RESTRICT",
            "FOREIGN KEY (payment_transaction_id) REFERENCES payment_transactions(id) ON DELETE RESTRICT"
        ]
    },
    "commercial_outbox": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "event_type": "TEXT NOT NULL CHECK(trim(event_type) != '')",
            "aggregate_type": "TEXT NOT NULL CHECK(trim(aggregate_type) != '')",
            "aggregate_id": "TEXT NOT NULL CHECK(trim(aggregate_id) != '')",
            "payload_json": "TEXT NOT NULL CHECK(length(payload_json) BETWEEN 2 AND 32768)",
            "status": "TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'processing', 'retry', 'dispatched', 'dead'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL CHECK(available_at > 0)",
            "lease_expires_at": "INTEGER",
            "locked_by": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
    },
    "vong_danh_gia": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "loai_vong": "TEXT NOT NULL CHECK(loai_vong IN ('single', 'technical', 'financial'))",
            "thu_tu": "INTEGER NOT NULL DEFAULT 0 CHECK(thu_tu >= 0)",
            "trang_thai": "TEXT NOT NULL DEFAULT 'draft' CHECK(trang_thai IN ('draft', 'completed', 'approved'))",
            "so_bao_cao": "TEXT",
            "ngay_bao_cao": "TEXT",
            "da_luu_danh_sach_dat": "INTEGER NOT NULL DEFAULT 0 CHECK(da_luu_danh_sach_dat IN (0,1))",
            "hoan_thanh_luc": "TEXT",
            "extension_json": "TEXT NOT NULL DEFAULT '{\"schemaVersion\":1}' CHECK(json_valid(extension_json) AND length(CAST(extension_json AS BLOB)) <= 65536)",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE"
        ],
        "unique_constraints": ["UNIQUE(organization_id, goi_thau_id, loai_vong)"]
    },
    "tieu_chi_danh_gia": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "vong_danh_gia_id": "TEXT NOT NULL",
            "ma_tieu_chi": "TEXT NOT NULL",
            "ten_tieu_chi": "TEXT NOT NULL",
            "diem_toi_da": "REAL CHECK(diem_toi_da IS NULL OR (diem_toi_da >= 0 AND diem_toi_da = round(diem_toi_da, 4)))",
            "trong_so": "REAL CHECK(trong_so IS NULL OR (trong_so >= 0 AND trong_so <= 100 AND trong_so = round(trong_so, 4)))",
            "nhom_danh_gia": "TEXT NOT NULL DEFAULT 'technical' CHECK(nhom_danh_gia IN ('validity', 'capacity', 'technical', 'financial'))",
            "loai_ket_qua": "TEXT NOT NULL DEFAULT 'pass_fail' CHECK(loai_ket_qua IN ('pass_fail', 'score', 'text', 'number'))",
            "bat_buoc": "INTEGER NOT NULL DEFAULT 1 CHECK(bat_buoc IN (0,1))",
            "tieu_chi_cha_id": "TEXT",
            "thu_tu": "INTEGER NOT NULL DEFAULT 0 CHECK(thu_tu >= 0)",
            "extension_json": "TEXT NOT NULL DEFAULT '{\"schemaVersion\":1}' CHECK(json_valid(extension_json) AND length(CAST(extension_json AS BLOB)) <= 65536)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (vong_danh_gia_id) REFERENCES vong_danh_gia(id) ON DELETE CASCADE",
            "FOREIGN KEY (tieu_chi_cha_id) REFERENCES tieu_chi_danh_gia(id) ON DELETE SET NULL",
        ],
        "unique_constraints": ["UNIQUE(organization_id, vong_danh_gia_id, ma_tieu_chi)"]
    },
    "bao_cao_danh_gia_nha_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "vong_danh_gia_id": "TEXT NOT NULL",
            "thong_tin_mo_thau_id": "TEXT NOT NULL",
            "trang_thai": "TEXT NOT NULL DEFAULT 'draft' CHECK(trang_thai IN ('draft', 'completed'))",
            "ket_luan": "TEXT",
            "hoan_thanh_luc": "TEXT",
            "extension_json": "TEXT NOT NULL DEFAULT '{\"schemaVersion\":1}' CHECK(json_valid(extension_json) AND length(CAST(extension_json AS BLOB)) <= 65536)",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
        },
        "foreign_keys": [
            "FOREIGN KEY (vong_danh_gia_id) REFERENCES vong_danh_gia(id) ON DELETE CASCADE",
            "FOREIGN KEY (thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, vong_danh_gia_id, thong_tin_mo_thau_id)"
        ],
    },
    "chi_tiet_danh_gia_nha_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "bao_cao_danh_gia_nha_thau_id": "TEXT NOT NULL",
            "tieu_chi_danh_gia_id": "TEXT NOT NULL",
            "ket_qua": "TEXT NOT NULL DEFAULT 'pending' CHECK(ket_qua IN ('pending', 'pass', 'fail', 'not_applicable'))",
            "diem": "REAL CHECK(diem IS NULL OR (diem >= 0 AND diem = round(diem, 4)))",
            "noi_dung_hsdt": "TEXT",
            "nhan_xet": "TEXT",
            "ly_do_khong_dat": "TEXT",
            "yeu_cau_lam_ro": "TEXT",
            "ket_qua_lam_ro": "TEXT",
            "tai_lieu_tham_chieu": "TEXT",
            "extension_json": "TEXT NOT NULL DEFAULT '{\"schemaVersion\":1}' CHECK(json_valid(extension_json) AND length(CAST(extension_json AS BLOB)) <= 65536)",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
        },
        "foreign_keys": [
            "FOREIGN KEY (bao_cao_danh_gia_nha_thau_id) REFERENCES bao_cao_danh_gia_nha_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (tieu_chi_danh_gia_id) REFERENCES tieu_chi_danh_gia(id) ON DELETE CASCADE",
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, bao_cao_danh_gia_nha_thau_id, tieu_chi_danh_gia_id)"
        ],
    },
    "ket_qua_danh_gia_nha_thau": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL",
            "thong_tin_mo_thau_id": "TEXT NOT NULL",
            "danh_gia_hop_le": "TEXT",
            "danh_gia_nang_luc": "TEXT",
            "danh_gia_ky_thuat": "TEXT",
            "danh_gia_tai_chinh": "TEXT",
            "gia_xep_hang": "INTEGER CHECK(gia_xep_hang IS NULL OR (typeof(gia_xep_hang) = 'integer' AND gia_xep_hang >= 0))",
            "gia_de_nghi_trung_thau": "INTEGER CHECK(gia_de_nghi_trung_thau IS NULL OR (typeof(gia_de_nghi_trung_thau) = 'integer' AND gia_de_nghi_trung_thau >= 0))",
            "chap_thuan_gia_de_nghi_trung_thau_duoi_50": "INTEGER CHECK(chap_thuan_gia_de_nghi_trung_thau_duoi_50 IS NULL OR (typeof(chap_thuan_gia_de_nghi_trung_thau_duoi_50) = 'integer' AND chap_thuan_gia_de_nghi_trung_thau_duoi_50 IN (0, 1)))",
            "danh_gia_ket_luan": "TEXT",
            "diem": "REAL CHECK(diem IS NULL OR (diem >= 0 AND diem = round(diem, 4)))",
            "ly_do_loai": "TEXT",
            "lam_ro_hop_le": "TEXT",
            "lam_ro_nang_luc": "TEXT",
            "lam_ro_ky_thuat": "TEXT",
            "lam_ro_tai_chinh": "TEXT",
            "nguyen_nhan_khong_dat_hop_le": "TEXT",
            "nguyen_nhan_khong_dat_nang_luc": "TEXT",
            "nguyen_nhan_khong_dat_ky_thuat": "TEXT",
            "danh_gia_luc": "TEXT",
            "sync_version": "INTEGER DEFAULT 0",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (goi_thau_id) REFERENCES goi_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(id) ON DELETE CASCADE",
            "FOREIGN KEY (organization_id, goi_thau_id, thong_tin_mo_thau_id) REFERENCES thong_tin_mo_thau(organization_id, goi_thau_id, id) ON DELETE CASCADE"
        ],
        "unique_constraints": ["UNIQUE(organization_id, thong_tin_mo_thau_id)"]
    },
    "api_idempotency": {
        "columns": {
            "actor_user_id": "TEXT NOT NULL",
            "operation": "TEXT NOT NULL",
            "idempotency_key": "TEXT NOT NULL",
            "response_json": "TEXT NOT NULL",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)"
        },
        "primary_keys": ["actor_user_id", "operation", "idempotency_key"],
        "foreign_keys": [
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "word_default_seeds": {
        "columns": {
            "organization_id": "TEXT PRIMARY KEY CHECK(organization_id != '')",
            "mappings_version": "INTEGER NOT NULL CHECK(mappings_version > 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        }
    },
    "sync_mutations": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "actor_user_id": "TEXT NOT NULL",
            "client_mutation_id": "TEXT NOT NULL",
            "request_hash": "TEXT",
            "response_json": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))"
        },
        "primary_keys": ["organization_id", "actor_user_id", "client_mutation_id"],
        "foreign_keys": [
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "record_edit_ownership": {
        "columns": {
            "organization_id": "TEXT NOT NULL",
            "table_name": (
                "TEXT NOT NULL CHECK(table_name IN ("
                "'chu_dau_tu', 'ke_hoach_lcnt', 'goi_thau', "
                "'thong_tin_mo_thau', 'hop_dong', 'nha_thau', 'chuyen_gia'))"
            ),
            "record_id": "TEXT NOT NULL",
            "user_id": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["organization_id", "table_name", "record_id"],
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ]
    },
    "goi_thau_moc_tien_do": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL CHECK(trim(goi_thau_id) != '')",
            "milestone_key": "TEXT NOT NULL CHECK(length(trim(milestone_key)) BETWEEN 1 AND 120)",
            "instance_key": "TEXT NOT NULL DEFAULT '' CHECK(length(instance_key) <= 160)",
            "source_entity_id": "TEXT NOT NULL DEFAULT '' CHECK(length(source_entity_id) <= 160)",
            "ma_nhom": "TEXT NOT NULL CHECK(ma_nhom IN ('I', 'II', 'III', 'IV', 'V'))",
            "ten_nhom": "TEXT NOT NULL CHECK(length(trim(ten_nhom)) BETWEEN 1 AND 160)",
            "ma_moc": "TEXT NOT NULL CHECK(length(trim(ma_moc)) BETWEEN 3 AND 10)",
            "cong_viec": "TEXT NOT NULL CHECK(length(trim(cong_viec)) BETWEEN 1 AND 300)",
            "don_vi_ban_hanh": "TEXT NOT NULL DEFAULT '' CHECK(length(don_vi_ban_hanh) <= 300)",
            "so_van_ban": "TEXT NOT NULL DEFAULT '' CHECK(length(so_van_ban) <= 300)",
            "ngay_du_kien": "TEXT CHECK(ngay_du_kien IS NULL OR (length(ngay_du_kien) = 10 AND date(ngay_du_kien) IS NOT NULL))",
            "ngay_thuc_te": "TEXT CHECK(ngay_thuc_te IS NULL OR (length(ngay_thuc_te) = 10 AND date(ngay_thuc_te) IS NOT NULL))",
            "ghi_chu": "TEXT NOT NULL DEFAULT '' CHECK(length(ghi_chu) <= 2000)",
            "source_key": "TEXT NOT NULL DEFAULT '' CHECK(length(source_key) <= 160)",
            "source_mode": "TEXT NOT NULL DEFAULT 'MANUAL' CHECK(source_mode IN ('AUTO', 'MANUAL'))",
            "is_optional": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(is_optional) = 'integer' AND is_optional IN (0, 1))",
            "trang_thai": "TEXT NOT NULL DEFAULT 'PENDING' CHECK(trang_thai IN ('PENDING', 'IN_PROGRESS', 'DONE', 'NOT_APPLICABLE'))",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(sort_order) = 'integer' AND sort_order BETWEEN 0 AND 9999)",
            "template_version": "INTEGER NOT NULL DEFAULT 2 CHECK(typeof(template_version) = 'integer' AND template_version >= 1)",
            "sync_version": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(sync_version) = 'integer' AND sync_version >= 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, goi_thau_id, milestone_key, instance_key)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (organization_id, goi_thau_id) REFERENCES goi_thau(organization_id, id) ON DELETE CASCADE"
        ]
    },
    "goi_thau_dieu_chinh_hsmt": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "goi_thau_id": "TEXT NOT NULL CHECK(trim(goi_thau_id) != '')",
            "sequence": "INTEGER NOT NULL CHECK(typeof(sequence) = 'integer' AND sequence > 0)",
            "reason": "TEXT NOT NULL DEFAULT '' CHECK(length(reason) <= 2000)",
            "submission_number": "TEXT NOT NULL DEFAULT '' CHECK(length(submission_number) <= 300)",
            "submission_date": "TEXT CHECK(submission_date IS NULL OR date(submission_date) IS NOT NULL)",
            "appraisal_report_number": "TEXT NOT NULL DEFAULT '' CHECK(length(appraisal_report_number) <= 300)",
            "appraisal_report_date": "TEXT CHECK(appraisal_report_date IS NULL OR date(appraisal_report_date) IS NOT NULL)",
            "approval_decision_number": "TEXT NOT NULL DEFAULT '' CHECK(length(approval_decision_number) <= 300)",
            "approval_decision_date": "TEXT CHECK(approval_decision_date IS NULL OR date(approval_decision_date) IS NOT NULL)",
            "published_at": "TEXT",
            "archived_at": "TEXT",
            "created_by_id": "TEXT",
            "updated_by_id": "TEXT",
            "sync_version": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(sync_version) = 'integer' AND sync_version >= 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, goi_thau_id, sequence)",
            "UNIQUE(organization_id, goi_thau_id, id)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (organization_id, goi_thau_id) REFERENCES goi_thau(organization_id, id) ON DELETE CASCADE",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL",
            "FOREIGN KEY (updated_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ]
    },
    "pending_email_changes": {
        "columns": {
            "user_id": "TEXT PRIMARY KEY",
            "current_email_norm": "TEXT NOT NULL CHECK(current_email_norm != '')",
            "pending_email": "TEXT NOT NULL CHECK(pending_email != '')",
            "pending_email_norm": "TEXT NOT NULL UNIQUE CHECK(pending_email_norm != '')",
            "otp_hash": "TEXT NOT NULL CHECK(otp_hash != '')",
            "requested_at": "INTEGER NOT NULL CHECK(requested_at > 0)",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > requested_at)",
            "verified_at": "INTEGER",
            "requested_ip": "TEXT"
        },
        "foreign_keys": [
            "FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "CHECK(pending_email_norm != current_email_norm)",
            "CHECK(verified_at IS NULL OR (verified_at >= requested_at AND verified_at <= expires_at))"
        ]
    },
    "document_export_capabilities": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "user_id": "TEXT NOT NULL CHECK(user_id != '')",
            "financial": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(financial) = 'integer' AND financial IN (0, 1))",
            "identity": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(identity) = 'integer' AND identity IN (0, 1))",
            "signature": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(signature) = 'integer' AND signature IN (0, 1))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["organization_id", "user_id"],
        "foreign_keys": [
            "FOREIGN KEY (user_id, organization_id) REFERENCES thanh_vien_to_chuc(user_id, organization_id) ON DELETE CASCADE"
        ]
    },
    "nhat_ky_thuc_hien": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL DEFAULT 'organization' CHECK(owner_type IN ('organization', 'personal'))",
            "target_type": "TEXT NOT NULL CHECK(target_type IN ('goithau', 'hopdong'))",
            "target_id": "TEXT NOT NULL CHECK(target_id != '')",
            "target_root_id": "TEXT NOT NULL CHECK(target_root_id != '')",
            "action": "TEXT NOT NULL CHECK(action IN ('goithau.created', 'goithau.updated', 'hopdong.created', 'hopdong.updated', 'package_document.uploaded', 'package_document.replaced', 'package_document.deleted', 'assignment.added', 'assignment.removed'))",
            "actor_user_id": "TEXT",
            "actor_name_snapshot": "TEXT NOT NULL DEFAULT 'Không xác định'",
            "occurred_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "related_document_id": "TEXT",
            "related_assignment_id": "TEXT",
            "client_mutation_id": "TEXT",
            "request_id": "TEXT",
            "metadata_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(metadata_json) <= 32768)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "phan_cong_nhan_su_lich_su": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "organization_id": "TEXT NOT NULL",
            "assignment_id": "TEXT NOT NULL",
            "id_nhan_vien": "TEXT NOT NULL",
            "id_muc_tieu": "TEXT NOT NULL",
            "loai_doi_tuong": "TEXT NOT NULL CHECK(loai_doi_tuong IN ('kehoach', 'goithau', 'hopdong'))",
            "assigned_at": "TEXT",
            "ended_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "ended_by": "TEXT",
            "successor_user_id": "TEXT",
            "reason": "TEXT NOT NULL DEFAULT 'member_left'"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, assignment_id, ended_at)"
        ]
    },
    "audit_chain_heads": {
        "columns": {
            "chain_id": "TEXT PRIMARY KEY CHECK(chain_id != '')",
            "last_sequence": "INTEGER NOT NULL DEFAULT 0 CHECK(last_sequence >= 0)",
            "last_log_id": "INTEGER",
            "last_hash": "TEXT NOT NULL CHECK(length(last_hash) = 64)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        }
    },
    "audit_log": {
        "columns": {
            "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
            "chain_id": "TEXT NOT NULL CHECK(chain_id != '')",
            "sequence": "INTEGER NOT NULL CHECK(sequence > 0)",
            "actor_user_id": "TEXT",
            "organization_id": "TEXT",
            "action": "TEXT NOT NULL",
            "target_type": "TEXT",
            "target_id": "TEXT",
            "ip_address": "TEXT",
            "metadata_json": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime(\'now\'))",
            "previous_hash": "TEXT NOT NULL CHECK(length(previous_hash) = 64)",
            "entry_hash": "TEXT NOT NULL CHECK(length(entry_hash) = 64)"
        },
        "unique_constraints": [
            "UNIQUE(chain_id, sequence)",
            "UNIQUE(chain_id, previous_hash)",
            "UNIQUE(chain_id, entry_hash)"
        ],
        "foreign_keys": [
            "FOREIGN KEY (chain_id) REFERENCES audit_chain_heads(chain_id) ON DELETE RESTRICT"
        ]
    },
    "sensitive_record_read_capabilities": {
        "columns": {
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "user_id": "TEXT NOT NULL CHECK(user_id != '')",
            "financial": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(financial) = 'integer' AND financial IN (0, 1))",
            "identity": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(identity) = 'integer' AND identity IN (0, 1))",
            "signature": "INTEGER NOT NULL DEFAULT 0 CHECK(typeof(signature) = 'integer' AND signature IN (0, 1))",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": ["organization_id", "user_id"],
        "foreign_keys": [
            "FOREIGN KEY (user_id, organization_id) REFERENCES thanh_vien_to_chuc(user_id, organization_id) ON DELETE CASCADE"
        ]
    },
    "procurement_source_revision": {
        "columns": {
            "id": "TEXT NOT NULL CHECK(trim(id) != '')",
            "organization_id": "TEXT NOT NULL CHECK(trim(organization_id) != '')",
            "provider": "TEXT NOT NULL CHECK(provider IN ('VNEPS', 'VNEPS_FIXTURE', 'MUASAMCONG'))",
            "entity_kind": "TEXT NOT NULL CHECK(entity_kind IN ('PLAN', 'PACKAGE', 'NOTICE'))",
            "family_key": "TEXT NOT NULL CHECK(trim(family_key) != '')",
            "revision_uuid": "TEXT NOT NULL CHECK(trim(revision_uuid) != '')",
            "revision_no": "TEXT",
            "parent_plan_revision_uuid": "TEXT",
            "id_detail": "TEXT",
            "aliases_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(aliases_json) <= 32768)",
            "canonical_snapshot_json": "TEXT NOT NULL CHECK(length(canonical_snapshot_json) BETWEEN 2 AND 16777216)",
            "digest": "TEXT NOT NULL CHECK(length(digest) = 71 AND digest LIKE 'sha256:%')",
            "schema_version": "TEXT NOT NULL CHECK(trim(schema_version) != '')",
            "disposition": "TEXT NOT NULL CHECK(disposition IN ('APPLIED', 'OBSERVED_NOT_APPLIED', 'NOOP'))",
            "fetched_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "applied_at": "TEXT",
            "public_url": "TEXT",
            "local_entity_type": "TEXT",
            "local_root_id": "TEXT",
            "local_snapshot_id": "TEXT",
            "match_method": "TEXT",
            "match_confidence": "TEXT",
            "confirmed_by": "TEXT",
            "operation_id": "TEXT",
            "idempotency_key": "TEXT NOT NULL CHECK(trim(idempotency_key) != '')",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "CONSTRAINT procurement_source_revision_observation_unique "
            "UNIQUE(organization_id, provider, entity_kind, revision_uuid, digest)",
            "CONSTRAINT procurement_source_revision_idempotent_observation_unique "
            "UNIQUE(organization_id, provider, idempotency_key, revision_uuid, digest)"
        ]
    },
    "procurement_source_binding": {
        "columns": {
            "id": "TEXT NOT NULL CHECK(trim(id) != '')",
            "organization_id": "TEXT NOT NULL CHECK(trim(organization_id) != '')",
            "provider": "TEXT NOT NULL CHECK(provider IN ('VNEPS', 'VNEPS_FIXTURE', 'MUASAMCONG'))",
            "family_key": "TEXT NOT NULL CHECK(trim(family_key) != '')",
            "plan_revision_uuid": "TEXT NOT NULL CHECK(trim(plan_revision_uuid) != '')",
            "id_detail": "TEXT NOT NULL CHECK(trim(id_detail) != '')",
            "stable_external_id": "TEXT",
            "symbol": "TEXT",
            "notify_no": "TEXT",
            "local_entity_type": "TEXT NOT NULL CHECK(local_entity_type IN ('goithau', 'kehoach'))",
            "local_root_id": "TEXT NOT NULL CHECK(trim(local_root_id) != '')",
            "local_snapshot_id": "TEXT NOT NULL CHECK(trim(local_snapshot_id) != '')",
            "match_method": "TEXT NOT NULL CHECK(trim(match_method) != '')",
            "match_confidence": "TEXT NOT NULL DEFAULT 'EXACT' CHECK(match_confidence IN ('EXACT', 'USER_CONFIRMED'))",
            "confirmed_by": "TEXT",
            "canonical_fields_json": "TEXT NOT NULL DEFAULT '{}' CHECK(length(canonical_fields_json) <= 131072)",
            "digest": "TEXT NOT NULL CHECK(length(digest) = 71 AND digest LIKE 'sha256:%')",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "CONSTRAINT procurement_source_binding_snapshot_unique "
            "UNIQUE(organization_id, provider, plan_revision_uuid, id_detail, local_snapshot_id)"
        ]
    },
    "procurement_import_operation": {
        "columns": {
            "id": "TEXT NOT NULL CHECK(trim(id) != '')",
            "organization_id": "TEXT NOT NULL CHECK(trim(organization_id) != '')",
            "provider": "TEXT NOT NULL CHECK(provider IN ('VNEPS', 'VNEPS_FIXTURE', 'MUASAMCONG'))",
            "family_key": "TEXT NOT NULL CHECK(trim(family_key) != '')",
            "mode": "TEXT NOT NULL CHECK(mode IN ('LATEST', 'SELECTED', 'ALL'))",
            "status": "TEXT NOT NULL CHECK(status IN ('PENDING', 'RUNNING', 'PARTIAL', 'COMPLETED', 'FAILED'))",
            "next_revision_index": "INTEGER NOT NULL DEFAULT 0 CHECK(next_revision_index >= 0)",
            "total_revisions": "INTEGER NOT NULL CHECK(total_revisions > 0)",
            "bundle_digest": "TEXT NOT NULL CHECK(length(bundle_digest) = 71 AND bundle_digest LIKE 'sha256:%')",
            "revision_results_json": "TEXT NOT NULL DEFAULT '[]' CHECK(length(revision_results_json) <= 262144)",
            "idempotency_key": "TEXT NOT NULL CHECK(trim(idempotency_key) != '')",
            "request_hash": "TEXT NOT NULL CHECK(length(request_hash) = 64)",
            "actor_user_id": "TEXT NOT NULL CHECK(trim(actor_user_id) != '')",
            "error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "unique_constraints": [
            "CONSTRAINT procurement_import_operation_family_idempotency_unique "
            "UNIQUE(organization_id, provider, family_key, idempotency_key)"
        ]
    },
    "procurement_import_session": {
        "columns": {
            "id": "TEXT NOT NULL CHECK(trim(id) != '')",
            "organization_id": "TEXT NOT NULL CHECK(trim(organization_id) != '')",
            "user_id": "TEXT NOT NULL CHECK(trim(user_id) != '')",
            "workspace_lease": "TEXT NOT NULL CHECK(trim(workspace_lease) != '')",
            "provider": "TEXT NOT NULL CHECK(provider IN ('VNEPS', 'VNEPS_FIXTURE', 'MUASAMCONG'))",
            "entity_kind": "TEXT NOT NULL CHECK(entity_kind IN ('PLAN', 'PACKAGE'))",
            "family_key": "TEXT NOT NULL CHECK(trim(family_key) != '')",
            "bundle_digest": "TEXT NOT NULL CHECK(length(bundle_digest) = 71 AND bundle_digest LIKE 'sha256:%')",
            "revisions_json": "TEXT NOT NULL CHECK(length(revisions_json) BETWEEN 2 AND 262144)",
            "canonical_bundle_json": "TEXT NOT NULL CHECK(length(canonical_bundle_json) BETWEEN 2 AND 16777216)",
            "preview_id": "TEXT",
            "preview_bundle_json": "TEXT CHECK(length(preview_bundle_json) BETWEEN 2 AND 16777216)",
            "preview_bundle_digest": "TEXT CHECK(length(preview_bundle_digest) = 71 AND preview_bundle_digest LIKE 'sha256:%')",
            "preview_expires_at": "TIMESTAMPTZ",
            "current_revision_index": "INTEGER NOT NULL DEFAULT 0 CHECK(current_revision_index >= 0)",
            "status": "TEXT NOT NULL CHECK(status IN ('READY', 'EDITING_REVISION', 'WAITING_NEXT_CONFIRMATION', 'COMPLETED', 'CANCELLED', 'FAILED'))",
            "expires_at": "TIMESTAMPTZ NOT NULL",
            "created_at": "TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP",
            "updated_at": "TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP"
        },
        "primary_keys": [
            "PRIMARY KEY (organization_id, id)"
        ]
    },
    "procurement_raw_snapshot": {
        "columns": {
            "id": "TEXT NOT NULL CHECK(trim(id) != '')",
            "organization_id": "TEXT NOT NULL CHECK(trim(organization_id) != '')",
            "provider": "TEXT NOT NULL CHECK(provider = 'MUASAMCONG')",
            "bundle_schema_version": "TEXT NOT NULL CHECK(trim(bundle_schema_version) != '')",
            "entity_kind": "TEXT NOT NULL CHECK(entity_kind IN ('PLAN', 'NOTICE', 'OPENING', 'RESULT', 'CONTRACT', 'PROJECT'))",
            "canonical_code": "TEXT NOT NULL CHECK(trim(canonical_code) != '')",
            "revision_id": "TEXT",
            "revision_number": "TEXT",
            "child_entity_kind": "TEXT CHECK(child_entity_kind IN ('PACKAGE', 'LOT'))",
            "child_entity_id": "TEXT",
            "operation": "TEXT NOT NULL CHECK(trim(operation) != '')",
            "endpoint": "TEXT NOT NULL CHECK(trim(endpoint) != '')",
            "request_json": "TEXT NOT NULL CHECK(length(request_json) <= 262144)",
            "response_json": "TEXT NOT NULL CHECK(length(response_json) <= 8388608)",
            "error_json": "TEXT CHECK(length(error_json) <= 32768)",
            "content_hash": "TEXT NOT NULL CHECK(length(content_hash) = 64)",
            "dedup_key": "TEXT NOT NULL CHECK(length(dedup_key) = 64)",
            "schema_fingerprint": "TEXT NOT NULL CHECK(trim(schema_fingerprint) != '')",
            "success": "INTEGER NOT NULL CHECK(success IN (0, 1))",
            "retrieved_at": "TEXT NOT NULL",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "primary_keys": [
            "PRIMARY KEY (organization_id, id)"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, provider, dedup_key)"
        ]
    },
    "conflict_resolution_drafts": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "actor_user_id": "TEXT NOT NULL CHECK(actor_user_id != '')",
            "workspace_fingerprint": "TEXT NOT NULL CHECK(length(workspace_fingerprint) BETWEEN 1 AND 200)",
            "batch_id": "TEXT NOT NULL CHECK(length(batch_id) BETWEEN 1 AND 200)",
            "mutation_id": "TEXT NOT NULL CHECK(length(mutation_id) BETWEEN 1 AND 200)",
            "entity_type": "TEXT NOT NULL CHECK(entity_type IN ('kehoach', 'goithau'))",
            "table_name": "TEXT NOT NULL CHECK(table_name IN ('ke_hoach_lcnt', 'goi_thau'))",
            "record_id": "TEXT NOT NULL CHECK(record_id != '')",
            "expected_row_version": "INTEGER NOT NULL CHECK(expected_row_version > 0)",
            "server_row_version": "INTEGER NOT NULL CHECK(server_row_version > 0)",
            "payload_ciphertext": "TEXT",
            "payload_sha256": "TEXT NOT NULL CHECK(length(payload_sha256) = 64)",
            "status": "TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE', 'RESOLVED'))",
            "resolution_mutation_id": "TEXT",
            "created_at": "INTEGER NOT NULL CHECK(created_at > 0)",
            "updated_at": "INTEGER NOT NULL CHECK(updated_at > 0)",
            "expires_at": "INTEGER NOT NULL CHECK(expires_at > created_at)"
        },
        "foreign_keys": [
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, actor_user_id, workspace_fingerprint, batch_id, mutation_id, table_name, record_id)",
            "CHECK((status = 'ACTIVE' AND payload_ciphertext IS NOT NULL) OR (status = 'RESOLVED' AND payload_ciphertext IS NULL))"
        ]
    },
    "word_template": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL CHECK(owner_type IN ('organization', 'personal'))",
            "stable_code": "TEXT NOT NULL CHECK(length(stable_code) BETWEEN 1 AND 160)",
            "display_name": "TEXT NOT NULL CHECK(length(display_name) BETWEEN 1 AND 255)",
            "legacy_alias": "TEXT NOT NULL CHECK(length(legacy_alias) BETWEEN 1 AND 255)",
            "draft_version_id": "TEXT",
            "published_version_id": "TEXT",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "retired_at": "TEXT"
        },
        "foreign_keys": [
            "FOREIGN KEY (draft_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (published_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, stable_code)",
            "UNIQUE(organization_id, legacy_alias)"
        ]
    },
    "word_template_version": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "template_id": "TEXT NOT NULL",
            "version_no": "INTEGER NOT NULL CHECK(version_no > 0)",
            "storage_key": "TEXT NOT NULL CHECK(length(storage_key) BETWEEN 1 AND 512)",
            "sha256": "TEXT NOT NULL CHECK(length(sha256) = 64)",
            "byte_size": "INTEGER NOT NULL CHECK(byte_size > 0)",
            "original_filename": "TEXT NOT NULL CHECK(length(original_filename) BETWEEN 1 AND 255)",
            "creation_manifest_json": "TEXT NOT NULL CHECK(length(creation_manifest_json) BETWEEN 2 AND 262144)",
            "manifest_hash": "TEXT NOT NULL CHECK(length(manifest_hash) = 64)",
            "sanitizer_version": "TEXT NOT NULL CHECK(sanitizer_version != '')",
            "source_version_id": "TEXT",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_id) REFERENCES word_template(id) ON DELETE RESTRICT",
            "FOREIGN KEY (source_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, template_id, version_no)"
        ]
    },
    "word_template_preflight_run": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "template_version_id": "TEXT NOT NULL",
            "template_sha256": "TEXT NOT NULL CHECK(length(template_sha256) = 64)",
            "parser_version": "TEXT NOT NULL CHECK(parser_version != '')",
            "mapping_base_version": "TEXT NOT NULL CHECK(mapping_base_version != '')",
            "mapping_snapshot_hash": "TEXT NOT NULL CHECK(length(mapping_snapshot_hash) = 64)",
            "required_registry_version": "TEXT NOT NULL CHECK(required_registry_version != '')",
            "context_policy_version": "TEXT NOT NULL CHECK(context_policy_version != '')",
            "report_json": "TEXT NOT NULL CHECK(length(report_json) BETWEEN 2 AND 1048576)",
            "report_hash": "TEXT NOT NULL CHECK(length(report_hash) = 64)",
            "result": "TEXT NOT NULL CHECK(result IN ('PASS', 'BLOCKED'))",
            "run_by_id": "TEXT",
            "run_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (run_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ]
    },
    "word_template_publication_event": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "template_id": "TEXT NOT NULL",
            "from_version_id": "TEXT",
            "to_version_id": "TEXT",
            "action": "TEXT NOT NULL CHECK(action IN ('PUBLISH', 'RESTORE', 'RETIRE'))",
            "accepted_preflight_run_id": "TEXT",
            "actor_user_id": "TEXT",
            "reason": "TEXT",
            "config_revision": "INTEGER",
            "audit_reference": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_id) REFERENCES word_template(id) ON DELETE RESTRICT",
            "FOREIGN KEY (from_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (to_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (accepted_preflight_run_id) REFERENCES word_template_preflight_run(id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ]
    },
    "word_template_projection_outbox": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "template_id": "TEXT",
            "template_version_id": "TEXT",
            "event_type": "TEXT NOT NULL CHECK(event_type IN ('PUBLICATION', 'RETIREMENT', 'ASSIGNMENT'))",
            "desired_alias": "TEXT NOT NULL CHECK(desired_alias != '')",
            "desired_checksum": "TEXT",
            "payload_json": "TEXT NOT NULL CHECK(length(payload_json) BETWEEN 2 AND 262144)",
            "status": "TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'RETRY', 'FAILED'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "locked_at": "TEXT",
            "last_error_code": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_id) REFERENCES word_template(id) ON DELETE CASCADE",
            "FOREIGN KEY (template_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, template_id, event_type, desired_checksum)"
        ]
    },
    "word_publication_assignment_v2": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL CHECK(owner_type IN ('organization', 'personal'))",
            "document_type": "TEXT NOT NULL CHECK(document_type != '')",
            "context_key": "TEXT NOT NULL DEFAULT 'default' CHECK(context_key != '')",
            "template_id": "TEXT NOT NULL",
            "resolution_mode": "TEXT NOT NULL DEFAULT 'FOLLOW_PUBLISHED' CHECK(resolution_mode IN ('FOLLOW_PUBLISHED', 'PIN_VERSION'))",
            "pinned_version_id": "TEXT",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(sort_order >= 0)",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_id) REFERENCES word_template(id) ON DELETE RESTRICT",
            "FOREIGN KEY (pinned_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "CONSTRAINT word_assignment_target_unique UNIQUE(organization_id, document_type, context_key, template_id)",
            "CONSTRAINT word_assignment_order_unique UNIQUE(organization_id, document_type, context_key, sort_order)",
            "CHECK((resolution_mode = 'FOLLOW_PUBLISHED' AND pinned_version_id IS NULL) OR (resolution_mode = 'PIN_VERSION' AND pinned_version_id IS NOT NULL))"
        ]
    },
    "word_template_assignment_config": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "owner_type": "TEXT NOT NULL CHECK(owner_type IN ('organization', 'personal'))",
            "revision": "INTEGER NOT NULL DEFAULT 0 CHECK(revision >= 0)",
            "updated_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (updated_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id)"
        ]
    },
    "legal_instrument": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "stable_code": "TEXT NOT NULL CHECK(stable_code != '')",
            "title": "TEXT NOT NULL CHECK(title != '')",
            "document_type": "TEXT NOT NULL CHECK(document_type != '')",
            "document_number": "TEXT NOT NULL CHECK(document_number != '')",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(stable_code)"]
    },
    "legal_instrument_draft": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "instrument_id": "TEXT NOT NULL",
            "draft_revision": "INTEGER NOT NULL DEFAULT 1 CHECK(draft_revision > 0)",
            "source_uri": "TEXT NOT NULL CHECK(source_uri != '')",
            "source_content": "TEXT NOT NULL CHECK(source_content != '')",
            "issued_date": "TEXT NOT NULL CHECK(date(issued_date) IS NOT NULL)",
            "effective_from": "TEXT NOT NULL CHECK(date(effective_from) IS NOT NULL)",
            "effective_to": "TEXT",
            "relation_manifest_json": "TEXT NOT NULL DEFAULT '{}'",
            "updated_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (instrument_id) REFERENCES legal_instrument(id) ON DELETE CASCADE",
            "FOREIGN KEY (updated_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "CHECK(effective_to IS NULL OR effective_to >= effective_from)"
        ]
    },
    "legal_instrument_version": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "instrument_id": "TEXT NOT NULL",
            "version_no": "INTEGER NOT NULL CHECK(version_no > 0)",
            "source_uri": "TEXT NOT NULL CHECK(source_uri != '')",
            "source_content": "TEXT NOT NULL CHECK(source_content != '')",
            "content_sha256": "TEXT NOT NULL CHECK(length(content_sha256) = 64)",
            "issued_date": "TEXT NOT NULL CHECK(date(issued_date) IS NOT NULL)",
            "effective_from": "TEXT NOT NULL CHECK(date(effective_from) IS NOT NULL)",
            "effective_to": "TEXT",
            "relation_manifest_json": "TEXT NOT NULL",
            "relation_manifest_hash": "TEXT NOT NULL CHECK(length(relation_manifest_hash) = 64)",
            "published_by_id": "TEXT",
            "published_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (instrument_id) REFERENCES legal_instrument(id) ON DELETE RESTRICT",
            "FOREIGN KEY (published_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(instrument_id, version_no)",
            "CHECK(effective_to IS NULL OR effective_to >= effective_from)"
        ]
    },
    "legal_source_profile": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "stable_code": "TEXT NOT NULL CHECK(stable_code != '')",
            "display_name": "TEXT NOT NULL CHECK(display_name != '')",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(stable_code)"]
    },
    "legal_source_profile_draft": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "profile_id": "TEXT NOT NULL",
            "draft_revision": "INTEGER NOT NULL DEFAULT 1 CHECK(draft_revision > 0)",
            "effective_from": "TEXT NOT NULL CHECK(date(effective_from) IS NOT NULL)",
            "effective_to": "TEXT",
            "priority": "INTEGER NOT NULL DEFAULT 0",
            "manual_review_required": "INTEGER NOT NULL DEFAULT 0 CHECK(manual_review_required IN (0,1))",
            "instrument_version_ids_json": "TEXT NOT NULL DEFAULT '[]'",
            "updated_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (profile_id) REFERENCES legal_source_profile(id) ON DELETE CASCADE",
            "FOREIGN KEY (updated_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "CHECK(effective_to IS NULL OR effective_to >= effective_from)"
        ]
    },
    "legal_source_profile_version": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "profile_id": "TEXT NOT NULL",
            "version_no": "INTEGER NOT NULL CHECK(version_no > 0)",
            "effective_from": "TEXT NOT NULL CHECK(date(effective_from) IS NOT NULL)",
            "effective_to": "TEXT",
            "priority": "INTEGER NOT NULL DEFAULT 0",
            "manual_review_required": "INTEGER NOT NULL DEFAULT 0 CHECK(manual_review_required IN (0,1))",
            "manifest_hash": "TEXT NOT NULL CHECK(length(manifest_hash) = 64)",
            "published_by_id": "TEXT",
            "published_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (profile_id) REFERENCES legal_source_profile(id) ON DELETE RESTRICT",
            "FOREIGN KEY (published_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(profile_id, version_no)",
            "CHECK(effective_to IS NULL OR effective_to >= effective_from)"
        ]
    },
    "legal_source_profile_member": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "profile_version_id": "TEXT NOT NULL",
            "instrument_version_id": "TEXT NOT NULL",
            "sort_order": "INTEGER NOT NULL DEFAULT 0 CHECK(sort_order >= 0)"
        },
        "foreign_keys": [
            "FOREIGN KEY (profile_version_id) REFERENCES legal_source_profile_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (instrument_version_id) REFERENCES legal_instrument_version(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": [
            "UNIQUE(profile_version_id, instrument_version_id)",
            "UNIQUE(profile_version_id, sort_order)"
        ]
    },
    "legal_applicability_policy_version": {
        "columns": {
            "id": "TEXT PRIMARY KEY",
            "policy_code": "TEXT NOT NULL CHECK(policy_code != '')",
            "version": "TEXT NOT NULL CHECK(version != '')",
            "config_json": "TEXT NOT NULL CHECK(config_json != '')",
            "config_hash": "TEXT NOT NULL CHECK(length(config_hash) = 64)",
            "published_by_id": "TEXT",
            "published_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (published_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(policy_code, version)"]
    },
    "plan_legal_binding": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "plan_id": "TEXT NOT NULL",
            "binding_revision": "INTEGER NOT NULL CHECK(binding_revision > 0)",
            "target_row_version": "INTEGER NOT NULL CHECK(target_row_version > 0)",
            "policy_version_id": "TEXT NOT NULL",
            "profile_version_id": "TEXT",
            "status": "TEXT NOT NULL CHECK(status IN ('RESOLVED','AMBIGUOUS','UNRESOLVED','MANUAL_REVIEW_REQUIRED'))",
            "reason": "TEXT NOT NULL CHECK(reason != '')",
            "anchor_date": "TEXT",
            "anchor_source": "TEXT NOT NULL",
            "evidence_json": "TEXT NOT NULL",
            "evidence_hash": "TEXT NOT NULL CHECK(length(evidence_hash) = 64)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (plan_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT",
            "FOREIGN KEY (policy_version_id) REFERENCES legal_applicability_policy_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (profile_version_id) REFERENCES legal_source_profile_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, plan_id, binding_revision)"]
    },
    "package_legal_binding": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "package_id": "TEXT NOT NULL",
            "binding_revision": "INTEGER NOT NULL CHECK(binding_revision > 0)",
            "target_row_version": "INTEGER NOT NULL CHECK(target_row_version > 0)",
            "policy_version_id": "TEXT NOT NULL",
            "profile_version_id": "TEXT",
            "status": "TEXT NOT NULL CHECK(status IN ('RESOLVED','AMBIGUOUS','UNRESOLVED','MANUAL_REVIEW_REQUIRED'))",
            "reason": "TEXT NOT NULL CHECK(reason != '')",
            "anchor_date": "TEXT",
            "anchor_source": "TEXT NOT NULL",
            "evidence_json": "TEXT NOT NULL",
            "evidence_hash": "TEXT NOT NULL CHECK(length(evidence_hash) = 64)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (package_id) REFERENCES goi_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (policy_version_id) REFERENCES legal_applicability_policy_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (profile_version_id) REFERENCES legal_source_profile_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, package_id, binding_revision)"]
    },
    "plan_legal_binding_head": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "plan_id": "TEXT NOT NULL",
            "current_binding_id": "TEXT NOT NULL",
            "binding_revision": "INTEGER NOT NULL CHECK(binding_revision > 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (plan_id) REFERENCES ke_hoach_lcnt(id) ON DELETE RESTRICT",
            "FOREIGN KEY (current_binding_id) REFERENCES plan_legal_binding(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, plan_id)"]
    },
    "package_legal_binding_head": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "package_id": "TEXT NOT NULL",
            "current_binding_id": "TEXT NOT NULL",
            "binding_revision": "INTEGER NOT NULL CHECK(binding_revision > 0)",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (package_id) REFERENCES goi_thau(id) ON DELETE RESTRICT",
            "FOREIGN KEY (current_binding_id) REFERENCES package_legal_binding(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, package_id)"]
    },
    "generated_document_provenance": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "artifact_id": "TEXT NOT NULL CHECK(artifact_id != '')",
            "template_version_id": "TEXT NOT NULL",
            "template_sha256": "TEXT NOT NULL CHECK(length(template_sha256) = 64)",
            "record_type": "TEXT",
            "record_id": "TEXT",
            "record_row_version": "INTEGER",
            "artifact_sha256": "TEXT NOT NULL CHECK(length(artifact_sha256) = 64)",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (template_version_id) REFERENCES word_template_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": [
            "UNIQUE(organization_id, artifact_id)"
        ]
    },
    "procurement_case": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "case_no": "TEXT NOT NULL CHECK(case_no != '')",
            "case_type": "TEXT NOT NULL CHECK(case_type IN ('CLARIFICATION', 'PETITION'))",
            "direction": "TEXT CHECK(direction IN ('INBOUND', 'OUTBOUND'))",
            "category": "TEXT CHECK(category IN ('E_HSMT', 'CONTRACTOR_SELECTION_RESULT', 'OTHER'))",
            "other_description": "TEXT",
            "subject": "TEXT NOT NULL CHECK(subject != '')",
            "state": "TEXT NOT NULL",
            "policy_version": "TEXT NOT NULL",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "due_at": "TEXT",
            "due_provenance": "TEXT CHECK(due_provenance IN ('MANUAL', 'POLICY'))",
            "deadline_status": "TEXT NOT NULL DEFAULT 'NOT_EVALUATED' CHECK(deadline_status IN ('ACTIVE', 'DUE_SOON', 'OVERDUE', 'NOT_EVALUATED'))",
            "created_by_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id) REFERENCES to_chuc(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, id)", "UNIQUE(organization_id, case_no)"]
    },
    "procurement_case_package_target": {
        "columns": {
            "id": "TEXT NOT NULL",
            "organization_id": "TEXT NOT NULL CHECK(organization_id != '')",
            "case_id": "TEXT NOT NULL",
            "package_lineage_root_id": "TEXT NOT NULL",
            "current_package_version_id": "TEXT NOT NULL",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, package_lineage_root_id) REFERENCES goi_thau(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, current_package_version_id) REFERENCES goi_thau(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, case_id)"]
    },
    "procurement_case_party": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "party_role": "TEXT NOT NULL",
            "display_name": "TEXT NOT NULL", "contact_json": "TEXT NOT NULL DEFAULT '{}'",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": ["FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT"]
    },
    "procurement_case_responsibility": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "responsible_user_id": "TEXT",
            "responsible_unit": "TEXT", "assigned_by_id": "TEXT",
            "assigned_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (responsible_user_id) REFERENCES tai_khoan(id) ON DELETE SET NULL",
            "FOREIGN KEY (assigned_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ]
    },
    "procurement_case_response_revision": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "revision_no": "INTEGER NOT NULL CHECK(revision_no > 0)",
            "package_version_id": "TEXT NOT NULL", "content": "TEXT NOT NULL",
            "content_sha256": "TEXT NOT NULL CHECK(length(content_sha256) = 64)",
            "created_by_id": "TEXT", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, package_version_id) REFERENCES goi_thau(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, case_id, revision_no)"]
    },
    "procurement_case_transition": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "sequence_no": "INTEGER NOT NULL CHECK(sequence_no > 0)",
            "from_state": "TEXT", "to_state": "TEXT NOT NULL", "action": "TEXT NOT NULL",
            "package_version_id": "TEXT NOT NULL", "response_revision_id": "TEXT",
            "reason": "TEXT", "actor_user_id": "TEXT",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, package_version_id) REFERENCES goi_thau(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (response_revision_id) REFERENCES procurement_case_response_revision(id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, case_id, sequence_no)"]
    },
    "procurement_case_attachment": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "response_revision_id": "TEXT",
            "filename": "TEXT NOT NULL", "storage_key": "TEXT NOT NULL",
            "media_type": "TEXT NOT NULL", "byte_size": "INTEGER NOT NULL CHECK(byte_size >= 0)",
            "sha256": "TEXT NOT NULL CHECK(length(sha256) = 64)",
            "created_by_id": "TEXT", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (response_revision_id) REFERENCES procurement_case_response_revision(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ],
        "unique_constraints": ["UNIQUE(organization_id, storage_key)"]
    },
    "procurement_case_legal_basis": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT NOT NULL", "response_revision_id": "TEXT",
            "profile_version_id": "TEXT", "instrument_version_id": "TEXT",
            "note": "TEXT", "verification_status": "TEXT NOT NULL DEFAULT 'VERIFIED' CHECK(verification_status IN ('VERIFIED', 'UNVERIFIED_NOTE'))",
            "created_by_id": "TEXT", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (response_revision_id) REFERENCES procurement_case_response_revision(id) ON DELETE RESTRICT",
            "FOREIGN KEY (profile_version_id) REFERENCES legal_source_profile_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (instrument_version_id) REFERENCES legal_instrument_version(id) ON DELETE RESTRICT",
            "FOREIGN KEY (created_by_id) REFERENCES tai_khoan(id) ON DELETE SET NULL"
        ]
    },
    "procurement_case_source_observation": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_type": "TEXT NOT NULL CHECK(case_type IN ('CLARIFICATION', 'PETITION'))",
            "provider": "TEXT NOT NULL", "upstream_identity": "TEXT NOT NULL",
            "upstream_revision": "TEXT NOT NULL", "source_sha256": "TEXT NOT NULL CHECK(length(source_sha256) = 64)",
            "canonical_json": "TEXT NOT NULL", "linked_case_id": "TEXT",
            "observed_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": ["FOREIGN KEY (organization_id, linked_case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT"],
        "unique_constraints": ["UNIQUE(organization_id, provider, upstream_identity, upstream_revision)"]
    },
    "procurement_case_command": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "case_id": "TEXT", "actor_user_id": "TEXT NOT NULL",
            "idempotency_key": "TEXT NOT NULL", "command_name": "TEXT NOT NULL",
            "request_hash": "TEXT NOT NULL CHECK(length(request_hash) = 64)",
            "result_json": "TEXT NOT NULL", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, case_id) REFERENCES procurement_case(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, actor_user_id, idempotency_key)"]
    },
    "calendar_event_head": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "event_key": "TEXT NOT NULL", "uid": "TEXT NOT NULL",
            "source_type": "TEXT", "source_id": "TEXT",
            "significant_payload_hash": "TEXT NOT NULL CHECK(length(significant_payload_hash) = 64)",
            "sequence": "INTEGER NOT NULL DEFAULT 0 CHECK(sequence >= 0)",
            "canonical_revision_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "source_fingerprint": "TEXT NOT NULL", "policy_version": "TEXT NOT NULL",
            "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)"
        },
        "unique_constraints": [
            "UNIQUE(organization_id, id)", "UNIQUE(organization_id, event_key)",
            "UNIQUE(uid)"
        ]
    },
    "calendar_event_revision": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "event_head_id": "TEXT NOT NULL", "sequence": "INTEGER NOT NULL CHECK(sequence >= 0)",
            "significant_payload_hash": "TEXT NOT NULL CHECK(length(significant_payload_hash) = 64)",
            "canonical_revision_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "source_fingerprint": "TEXT NOT NULL", "policy_version": "TEXT NOT NULL"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, event_head_id) REFERENCES calendar_event_head(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, event_head_id, sequence)"]
    },
    "bulk_operation": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "actor_user_id": "TEXT NOT NULL", "action_key": "TEXT NOT NULL",
            "contract_version": "TEXT NOT NULL", "target_type": "TEXT NOT NULL CHECK(target_type IN ('kehoach', 'goithau'))",
            "selection_mode": "TEXT NOT NULL CHECK(selection_mode = 'EXPLICIT_IDS')",
            "selection_json": "TEXT NOT NULL", "selection_hash": "TEXT NOT NULL CHECK(length(selection_hash) = 64)",
            "dependency_json": "TEXT NOT NULL", "preview_json": "TEXT NOT NULL",
            "status": "TEXT NOT NULL CHECK(status IN ('PREVIEW_READY', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED', 'STALE'))",
            "idempotency_key": "TEXT", "request_hash": "TEXT",
            "result_json": "TEXT", "expires_at": "TEXT NOT NULL",
            "confirmed_at": "TEXT", "completed_at": "TEXT", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": ["FOREIGN KEY (actor_user_id) REFERENCES tai_khoan(id) ON DELETE RESTRICT"],
        "unique_constraints": ["UNIQUE(organization_id, id)", "UNIQUE(organization_id, actor_user_id, idempotency_key)"]
    },
    "bulk_operation_item": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "operation_id": "TEXT NOT NULL", "target_id": "TEXT NOT NULL",
            "expected_row_version": "INTEGER NOT NULL CHECK(expected_row_version > 0)",
            "display_code": "TEXT NOT NULL", "display_title": "TEXT NOT NULL"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, operation_id) REFERENCES bulk_operation(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, operation_id, target_id)"]
    },
    "bulk_operation_artifact": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "operation_id": "TEXT NOT NULL", "storage_key": "TEXT NOT NULL",
            "filename": "TEXT NOT NULL", "media_type": "TEXT NOT NULL",
            "byte_size": "INTEGER NOT NULL CHECK(byte_size >= 0)",
            "sha256": "TEXT NOT NULL CHECK(length(sha256) = 64)",
            "expires_at": "TEXT NOT NULL", "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, operation_id) REFERENCES bulk_operation(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, operation_id)", "UNIQUE(organization_id, storage_key)"]
    },
    "calendar_oauth_state": {
        "columns": {
            "state_hash": "TEXT PRIMARY KEY CHECK(length(state_hash) = 64)",
            "organization_id": "TEXT NOT NULL", "user_id": "TEXT NOT NULL",
            "provider": "TEXT NOT NULL CHECK(provider IN ('GOOGLE', 'MICROSOFT'))",
            "code_verifier_ciphertext": "TEXT NOT NULL", "redirect_uri": "TEXT NOT NULL",
            "calendar_id": "TEXT NOT NULL", "active_role": "TEXT",
            "expires_at": "INTEGER NOT NULL", "used_at": "INTEGER",
            "created_at": "INTEGER NOT NULL"
        },
        "foreign_keys": ["FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"]
    },
    "calendar_connection": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "user_id": "TEXT NOT NULL", "provider": "TEXT NOT NULL CHECK(provider IN ('GOOGLE', 'MICROSOFT'))",
            "calendar_id": "TEXT NOT NULL", "account_label": "TEXT NOT NULL DEFAULT ''",
            "active_role": "TEXT", "token_ciphertext": "TEXT NOT NULL",
            "scopes_json": "TEXT NOT NULL", "outbound_profile_version": "TEXT NOT NULL",
            "status": "TEXT NOT NULL CHECK(status IN ('ACTIVE', 'REAUTH_REQUIRED', 'REVOKED'))",
            "token_expires_at": "INTEGER", "row_version": "INTEGER NOT NULL DEFAULT 1 CHECK(row_version > 0)",
            "consented_at": "INTEGER NOT NULL", "revoked_at": "INTEGER",
            "created_at": "TEXT NOT NULL DEFAULT (datetime('now'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": ["FOREIGN KEY (user_id) REFERENCES tai_khoan(id) ON DELETE CASCADE"],
        "unique_constraints": ["UNIQUE(organization_id, id)", "UNIQUE(organization_id, user_id, provider, calendar_id)"]
    },
    "calendar_event_binding": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "connection_id": "TEXT NOT NULL", "event_head_id": "TEXT NOT NULL",
            "remote_event_id": "TEXT NOT NULL", "remote_etag": "TEXT",
            "last_delivered_sequence": "INTEGER NOT NULL CHECK(last_delivered_sequence >= 0)",
            "last_delivered_hash": "TEXT NOT NULL CHECK(length(last_delivered_hash) = 64)",
            "status": "TEXT NOT NULL CHECK(status IN ('ACTIVE', 'CANCELLED'))",
            "updated_at": "TEXT NOT NULL DEFAULT (datetime('now'))"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, connection_id) REFERENCES calendar_connection(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, event_head_id) REFERENCES calendar_event_head(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, id)", "UNIQUE(organization_id, connection_id, event_head_id)"]
    },
    "calendar_delivery_outbox": {
        "columns": {
            "id": "TEXT NOT NULL", "organization_id": "TEXT NOT NULL",
            "connection_id": "TEXT NOT NULL", "event_head_id": "TEXT NOT NULL",
            "action": "TEXT NOT NULL CHECK(action IN ('UPSERT', 'CANCEL'))",
            "event_sequence": "INTEGER NOT NULL CHECK(event_sequence >= 0)",
            "payload_hash": "TEXT NOT NULL CHECK(length(payload_hash) = 64)",
            "payload_json": "TEXT NOT NULL", "status": "TEXT NOT NULL CHECK(status IN ('PENDING', 'PROCESSING', 'RETRY', 'DELIVERED', 'FAILED'))",
            "attempt_count": "INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count >= 0)",
            "available_at": "INTEGER NOT NULL", "locked_at": "INTEGER",
            "last_error_code": "TEXT", "created_at": "INTEGER NOT NULL",
            "updated_at": "INTEGER NOT NULL"
        },
        "foreign_keys": [
            "FOREIGN KEY (organization_id, connection_id) REFERENCES calendar_connection(organization_id, id) ON DELETE RESTRICT",
            "FOREIGN KEY (organization_id, event_head_id) REFERENCES calendar_event_head(organization_id, id) ON DELETE RESTRICT"
        ],
        "unique_constraints": ["UNIQUE(organization_id, id)", "UNIQUE(organization_id, connection_id, event_head_id, action, event_sequence, payload_hash)"]
    }
}

# The procurement center, calendar connectors, and bulk export were retired in
# schema v77. Keep their historical DDL above readable for old upgrade steps,
# but exclude them from the canonical schema used by fresh installations.
RETIRED_PROCUREMENT_CENTER_TABLES = frozenset({
    "procurement_case", "procurement_case_package_target",
    "procurement_case_party", "procurement_case_responsibility",
    "procurement_case_response_revision", "procurement_case_transition",
    "procurement_case_attachment", "procurement_case_legal_basis",
    "procurement_case_source_observation", "procurement_case_command",
    "calendar_event_head", "calendar_event_revision", "calendar_oauth_state",
    "calendar_connection", "calendar_event_binding", "calendar_delivery_outbox",
    "bulk_operation", "bulk_operation_item", "bulk_operation_artifact",
})
RETIRED_OPTIONAL_FEATURE_TABLES = frozenset({
    "conflict_resolution_drafts",
    "legal_instrument", "legal_instrument_draft", "legal_instrument_version",
    "legal_source_profile", "legal_source_profile_draft",
    "legal_source_profile_version", "legal_source_profile_member",
    "legal_applicability_policy_version",
    "plan_legal_binding", "package_legal_binding",
    "plan_legal_binding_head", "package_legal_binding_head",
})
HISTORICAL_SCHEMA_DINH_NGHIA = dict(SCHEMA_DINH_NGHIA)
for _retired_table in RETIRED_PROCUREMENT_CENTER_TABLES:
    SCHEMA_DINH_NGHIA.pop(_retired_table, None)


_SIMPLE_ID_FK = re.compile(
    r"^FOREIGN KEY \((?P<column>[a-zA-Z0-9_]+)\) "
    r"REFERENCES (?P<table>[a-zA-Z0-9_]+)\(id\)(?P<suffix>.*)$"
)

ROW_VERSION_TABLES = frozenset({
    "chu_dau_tu", "ke_hoach_lcnt", "goi_thau", "chuyen_gia", "nha_thau",
    "hop_dong", "phan_cong_nhan_su", "danh_muc_trang_thai_hop_dong",
    "thong_tin_mo_thau", "ma_tran_phan_quyen", "goi_thau_phan_lo",
    "goi_thau_hang_hoa",
    "hang_hoa_du_thau_nha_thau",
    "dot_xu_ly_phan_lo", "dot_xu_ly_phan_lo_chi_tiet",
    "nhom_phu_thuoc_phan_lo", "ho_so_nghiep_vu_lcnt",
    "goi_thau_dieu_chinh_hsmt",
})


def _apply_row_versions(schema):
    for table_name in ROW_VERSION_TABLES:
        columns = schema[table_name]["columns"]
        if "row_version" not in columns:
            columns["row_version"] = (
                "INTEGER NOT NULL DEFAULT 1 "
                "CHECK(typeof(row_version) = 'integer' AND row_version > 0)"
            )


def _apply_numeric_versions(schema):
    """Use numeric ordering for entity and synchronization versions."""
    for table_spec in schema.values():
        columns = table_spec.get("columns", {})
        if "phien_ban" in columns:
            columns["phien_ban"] = (
                "INTEGER NOT NULL DEFAULT 0 "
                "CHECK(typeof(phien_ban) = 'integer' AND phien_ban >= 0)"
            )
        if "sync_version" in columns:
            columns["sync_version"] = (
                "INTEGER NOT NULL DEFAULT 0 "
                "CHECK(typeof(sync_version) = 'integer' AND sync_version >= 0)"
            )


def _apply_tenant_constraints(schema):
    """Materialize tenant isolation in every clean-schema table.

    A globally unique ``id`` is not sufficient: child and parent must also carry
    the same organization key so PostgreSQL itself rejects cross-tenant links.
    """
    tenant_tables = {
        table_name
        for table_name, table_spec in schema.items()
        if "organization_id" in table_spec.get("columns", {})
    }

    for table_name in tenant_tables:
        table_spec = schema[table_name]
        columns = table_spec.get("columns", {})
        foreign_keys = list(table_spec.get("foreign_keys", []))
        upgraded_foreign_keys = []

        for foreign_key in foreign_keys:
            match = _SIMPLE_ID_FK.match(foreign_key)
            if (
                match
                and match.group("column") != "organization_id"
                and match.group("table") in tenant_tables
            ):
                upgraded_foreign_keys.append(
                    "FOREIGN KEY (organization_id, {column}) "
                    "REFERENCES {table}(organization_id, id){suffix}".format(
                        column=match.group("column"),
                        table=match.group("table"),
                        suffix=match.group("suffix"),
                    )
                )
            else:
                upgraded_foreign_keys.append(foreign_key)

        if "owner_type" in columns:
            upgraded_foreign_keys.append(
                "CHECK((owner_type = 'personal' AND organization_id LIKE 'personal:%') "
                "OR (owner_type = 'organization' AND organization_id NOT LIKE 'personal:%'))"
            )

        table_spec["foreign_keys"] = list(dict.fromkeys(upgraded_foreign_keys))

        composite_tenant_id = (
            str(columns.get("id", "")).startswith("TEXT")
            and "NOT NULL" in str(columns.get("organization_id", "")).upper()
        )
        if composite_tenant_id:
            table_spec["primary_keys"] = ["organization_id", "id"]
            unique_constraints = [
                constraint
                for constraint in table_spec.get("unique_constraints", [])
                if constraint.replace(" ", "").upper()
                != "UNIQUE(ORGANIZATION_ID,ID)"
            ]
            table_spec["unique_constraints"] = unique_constraints
        elif "id" in columns:
            tenant_unique = "UNIQUE(organization_id, id)"
            unique_constraints = list(table_spec.get("unique_constraints", []))
            if tenant_unique not in unique_constraints:
                unique_constraints.append(tenant_unique)
            table_spec["unique_constraints"] = unique_constraints


_apply_numeric_versions(SCHEMA_DINH_NGHIA)
_apply_row_versions(SCHEMA_DINH_NGHIA)
_apply_tenant_constraints(SCHEMA_DINH_NGHIA)

# Preserve the released v64/v70 DDL, including the tenant transformations
# above, for historical replay. Fresh installs omit the retired features.
for _retired_table in RETIRED_OPTIONAL_FEATURE_TABLES:
    SCHEMA_DINH_NGHIA.pop(_retired_table, None)
