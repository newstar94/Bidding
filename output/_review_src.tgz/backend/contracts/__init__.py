"""Contract domain helpers."""
