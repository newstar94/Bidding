import os
import hashlib
import threading
import time
import urllib.request
import urllib.error
import json
import re
import random
import unicodedata
import uuid
from backend.db.db_helper import database
from backend.partners.address_parser import compose_external_address, parse_vietnam_address_to_internal
from backend.partners.position_normalization import derive_investor_head_position
from backend.shared.text_utils import normalize_person_name
from backend.partners.name_case import normalize_procurement_partner_name
from backend.shared.logging_utils import log_error, log_structured_event
from backend.shared.idle_backoff import idle_poll_backoff_from_env
from backend.observability.recording import record_partner_upstream
from backend.shared.muasamcong_tls import MUASAMCONG_SSL_CONTEXT
from backend.procurement_lookup.config import MUASAMCONG_HOST, MUASAMCONG_ORIGIN
from backend.shared.safe_http import open_allowlisted_https


_partner_worker_started = False
_partner_worker_thread = None
_partner_worker_lock = threading.Lock()
_partner_work_event = threading.Event()
_partner_stop_event = threading.Event()
_lookup_locks = tuple(threading.Lock() for _ in range(64))
PARTNER_LOOKUP_CACHE_VERSION = "4"


class PartnerLookupBusyError(RuntimeError):
    """The bounded outbound lookup capacity is exhausted."""


class PartnerUpstreamError(RuntimeError):
    """An upstream failed before returning a valid not-found/success response."""


def _bounded_env_int(name, default, minimum, maximum):
    try:
        value = int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return min(maximum, max(minimum, value))


def _bounded_env_float(name, default, minimum, maximum):
    try:
        value = float(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return min(maximum, max(minimum, value))


_outbound_slots = threading.BoundedSemaphore(
    _bounded_env_int("PARTNER_LOOKUP_MAX_CONCURRENCY", 4, 1, 16)
)


def _lookup_cache_key(tax_code, org_code, role_name):
    material = (
        f"{PARTNER_LOOKUP_CACHE_VERSION}\0{tax_code or ''}\0"
        f"{org_code or ''}\0{role_name or ''}"
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def _cache_get(cache_key):
    now = int(time.time())
    conn = database.get_connection()
    try:
        row = conn.execute(
            """SELECT found, result_json FROM partner_lookup_cache
               WHERE cache_key = ? AND expires_at > ?""",
            (cache_key, now),
        ).fetchone()
        if row is None:
            return False, None
        if not row["found"]:
            return True, None
        try:
            value = json.loads(row["result_json"] or "")
        except (TypeError, json.JSONDecodeError):
            return False, None
        return (True, value) if isinstance(value, dict) else (False, None)
    finally:
        conn.close()


def _cache_put(cache_key, result):
    now = int(time.time())
    found = isinstance(result, dict)
    ttl = _bounded_env_int(
        "PARTNER_LOOKUP_POSITIVE_CACHE_SECONDS" if found else "PARTNER_LOOKUP_NEGATIVE_CACHE_SECONDS",
        6 * 3600 if found else 300,
        30,
        7 * 86400,
    )
    result_json = json.dumps(result, ensure_ascii=False, separators=(",", ":")) if found else None
    if result_json and len(result_json.encode("utf-8")) > 512 * 1024:
        compact = {key: value for key, value in result.items() if key not in {"procurement_data", "businesses"}}
        result_json = json.dumps(compact, ensure_ascii=False, separators=(",", ":"))
        result = compact
    if result_json and len(result_json.encode("utf-8")) > 512 * 1024:
        # The provider response remains usable for this request, but oversized
        # material is never persisted in the shared cache.
        return result
    conn = database.get_connection()
    try:
        conn.execute(
            """INSERT INTO partner_lookup_cache
               (cache_key, result_json, found, expires_at, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT (cache_key) DO UPDATE SET
                   result_json = excluded.result_json,
                   found = excluded.found,
                   expires_at = excluded.expires_at,
                   updated_at = excluded.updated_at""",
            (cache_key, result_json, 1 if found else 0, now + ttl, now),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return result


def _circuit_allows(upstream):
    now = int(time.time())
    conn = database.get_connection()
    try:
        conn.execute("BEGIN")
        conn.execute(
            """INSERT INTO partner_upstream_health
               (upstream, failure_count, opened_until, probe_locked_until, updated_at)
               VALUES (?, 0, 0, 0, ?) ON CONFLICT (upstream) DO NOTHING""",
            (upstream, now),
        )
        row = conn.execute(
            """SELECT failure_count, opened_until, probe_locked_until
               FROM partner_upstream_health WHERE upstream = ? FOR UPDATE""",
            (upstream,),
        ).fetchone()
        allowed = True
        if int(row["opened_until"]) > now:
            allowed = False
        elif int(row["failure_count"]) >= 3:
            if int(row["probe_locked_until"]) > now:
                allowed = False
            else:
                conn.execute(
                    "UPDATE partner_upstream_health SET probe_locked_until = ?, updated_at = ? WHERE upstream = ?",
                    (now + 15, now, upstream),
                )
        conn.commit()
        return allowed
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _circuit_success(upstream):
    now = int(time.time())
    conn = database.get_connection()
    try:
        conn.execute(
            """UPDATE partner_upstream_health
               SET failure_count = 0, opened_until = 0, probe_locked_until = 0, updated_at = ?
               WHERE upstream = ?""",
            (now, upstream),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _circuit_failure(upstream):
    now = int(time.time())
    conn = database.get_connection()
    try:
        conn.execute("BEGIN")
        row = conn.execute(
            "SELECT failure_count FROM partner_upstream_health WHERE upstream = ? FOR UPDATE",
            (upstream,),
        ).fetchone()
        failures = int(row["failure_count"] if row else 0) + 1
        open_seconds = min(600, 30 * (2 ** max(0, failures - 3))) if failures >= 3 else 0
        conn.execute(
            """INSERT INTO partner_upstream_health
               (upstream, failure_count, opened_until, probe_locked_until, updated_at)
               VALUES (?, ?, ?, 0, ?)
               ON CONFLICT (upstream) DO UPDATE SET
                   failure_count = excluded.failure_count,
                   opened_until = excluded.opened_until,
                   probe_locked_until = 0,
                   updated_at = excluded.updated_at""",
            (upstream, failures, now + open_seconds, now),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _call_upstream(upstream, function, *args, **kwargs):
    if not _circuit_allows(upstream):
        log_structured_event("partner.upstream_circuit_open", level="WARN", fields={"upstream": upstream})
        record_partner_upstream(upstream, "circuit_open")
        return False, None
    attempts = _bounded_env_int("PARTNER_UPSTREAM_MAX_ATTEMPTS", 2, 1, 3)
    for attempt in range(attempts):
        try:
            result = function(*args, **kwargs)
            _circuit_success(upstream)
            record_partner_upstream(upstream, "found" if result else "not_found")
            log_structured_event("partner.upstream_completed", fields={"upstream": upstream, "found": bool(result)})
            return True, result
        except PartnerUpstreamError as exc:
            if attempt + 1 < attempts:
                time.sleep(min(2.0, 0.2 * (2 ** attempt) + random.uniform(0.0, 0.25)))
                continue
            _circuit_failure(upstream)
            root_error = exc.__cause__ or exc
            outcome = "timeout" if isinstance(root_error, (TimeoutError,)) else "error"
            record_partner_upstream(upstream, outcome)
            log_structured_event(
                "partner.upstream_failed",
                level="WARN",
                fields={"upstream": upstream, "errorType": type(root_error).__name__},
            )
            return False, None

PLACEHOLDER_CONTRACTOR_NAMES = {
    "Nhà thầu (Chưa cập nhật thông tin)",
    "Nhà thầu (Mã số thuế không hợp lệ)",
}


def _is_placeholder_contractor_name(value):
    return not str(value or "").strip() or str(value).strip() in PLACEHOLDER_CONTRACTOR_NAMES


def _worker_debug(message):
    if os.environ.get("APP_DEBUG", "False").lower() == "true":
        print(message, flush=True)

def extract_clean_tax_code(val):
    if not val:
        return None

    val = str(val).strip()

    if val.lower().startswith("vn"):
        val = val[2:]

    cleaned = re.sub(r'[^0-9\-]', '', val)

    digits_only = re.sub(r'[^0-9]', '', cleaned)
    if 9 <= len(digits_only) <= 14:
        return cleaned
    return None


MUASAMCONG_CONTRACTOR_SERVICE_BASE = (
    f"{MUASAMCONG_ORIGIN}/o/egp-portal-contractors-approved/services"
)
MUASAMCONG_INVESTOR_SERVICE_BASE = (
    f"{MUASAMCONG_ORIGIN}/o/egp-portal-investor-approved-v2/services"
)


def normalize_procurement_org_code(value):
    raw_value = re.sub(r"[\s._-]+", "", str(value or "").strip().lower())
    match = re.fullmatch(r"(vnp|vnz|vn)(\d{9,14})", raw_value)
    return f"{match.group(1)}{match.group(2)}" if match else None


def _post_muasamcong_json(
    endpoint,
    payload,
    timeout=None,
    service_base=MUASAMCONG_CONTRACTOR_SERVICE_BASE,
):
    if timeout is None:
        timeout = _bounded_env_float(
            "PARTNER_MUASAMCONG_TIMEOUT_SECONDS", 6.0, 1.0, 15.0
        )
    request = urllib.request.Request(
        f"{service_base}/{endpoint}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "Origin": MUASAMCONG_ORIGIN,
            "Referer": f"{MUASAMCONG_ORIGIN}/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/150 Safari/537.36",
        },
        method="POST",
    )
    try:
        with open_allowlisted_https(
            request,
            allowed_hosts={MUASAMCONG_HOST},
            timeout=timeout,
            context=MUASAMCONG_SSL_CONTEXT,
        ) as response:
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > 1024 * 1024:
                raise PartnerUpstreamError("MuaSamCong response is too large")
            raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise PartnerUpstreamError("MuaSamCong response is too large")
            value = json.loads(raw.decode("utf-8-sig"))
            if not isinstance(value, (dict, list)):
                raise PartnerUpstreamError("MuaSamCong response schema is invalid")
            return value
    except PartnerUpstreamError:
        raise
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
        raise PartnerUpstreamError("MuaSamCong request failed") from exc


def _fetch_muasamcong_area_name(code, service_base=MUASAMCONG_CONTRACTOR_SERVICE_BASE):
    if not code:
        return ""
    try:
        result = _post_muasamcong_json(
            "get-area-by-code",
            {"queryParams": {"code": {"equals": code}}},
            timeout=_bounded_env_float(
                "PARTNER_MUASAMCONG_AREA_TIMEOUT_SECONDS", 2.0, 0.5, 5.0
            ),
            service_base=service_base,
        )
        if isinstance(result, list):
            values = result
        elif isinstance(result, dict):
            values = result.get("value", [])
        else:
            values = []
        return values[0].get("name", "") if values else ""
    except Exception:
        return ""


def _normalize_muasamcong_text(value):
    text = unicodedata.normalize("NFKC", str(value or ""))
    return re.sub(r"\s+", " ", text).strip()


def _normalize_muasamcong_phone(value):
    text = _normalize_muasamcong_text(value)
    if not text:
        return ""
    digits = re.sub(r"\D", "", text)
    if not digits:
        return ""
    has_international_prefix = re.match(r"^[\s(]*\+", str(value or "")) is not None
    return f"+{digits}" if has_international_prefix else digits


def _normalize_muasamcong_partner_info(info):
    """Normalize mapped MSC fields while preserving the raw audit payload."""

    normalized = dict(info or {})
    for field in (
        "address",
        "short_name",
        "english_name",
        "representative_position",
        "business_type",
    ):
        normalized[field] = _normalize_muasamcong_text(normalized.get(field))
    normalized["name"] = normalize_procurement_partner_name(
        _normalize_muasamcong_text(normalized.get("name"))
    )
    normalized["representative_name"] = normalize_person_name(
        _normalize_muasamcong_text(normalized.get("representative_name"))
    )
    normalized["org_code"] = normalize_procurement_org_code(
        normalized.get("org_code")
    ) or ""
    normalized["tax_code"] = extract_clean_tax_code(
        normalized.get("tax_code")
    ) or ""
    normalized["phone"] = _normalize_muasamcong_phone(normalized.get("phone"))
    normalized["head_position"] = derive_investor_head_position(
        normalized.get("representative_position")
    )
    return normalized


def _build_muasamcong_partner_info(data, org_code, area_names=None):
    if not isinstance(data, dict) or not data.get("orgFullName"):
        return None

    def clean_text(value):
        return str(value or "").strip()

    area_names = area_names or {}
    administrative_names = [
        area_names.get(data.get("officeWar")),
        area_names.get(data.get("officeDis")),
        area_names.get(data.get("officePro")),
    ]
    address = compose_external_address(data.get("officeAdd"), *administrative_names)

    representative_position = clean_text(data.get("repPosition"))
    return _normalize_muasamcong_partner_info({
        "name": normalize_procurement_partner_name(data.get("orgFullName")),
        "address": address,
        "short_name": clean_text(data.get("orgShortName")),
        "source": "MuaSamCong",
        "org_code": clean_text(data.get("orgCode") or org_code),
        "tax_code": clean_text(data.get("taxCode")),
        "english_name": clean_text(data.get("orgEnName")),
        "representative_name": normalize_person_name(data.get("repName")),
        "representative_position": representative_position,
        "head_position": derive_investor_head_position(representative_position),
        "phone": clean_text(data.get("officePhone")),
        "business_type": clean_text(data.get("businessType")),
        "businesses": data.get("businesses") or [],
        "procurement_data": data,
    })


def _muasamcong_status_key(value):
    decomposed = unicodedata.normalize("NFKD", str(value or ""))
    without_marks = "".join(
        character
        for character in decomposed
        if unicodedata.category(character) != "Mn"
    )
    return " ".join(without_marks.casefold().split())


def _latest_muasamcong_contractor_status(data):
    history = data.get("roleContractorHis") if isinstance(data, dict) else None
    status_events = [
        event
        for event in (history or [])
        if isinstance(event, dict)
        and str(event.get("type") or "").strip().upper() == "CHANGE_ROLE_STATUS"
        and str(event.get("value") or "").strip()
    ]
    if not status_events:
        return ""
    latest = max(
        enumerate(status_events),
        key=lambda entry: (str(entry[1].get("createdDate") or ""), -entry[0]),
    )[1]
    return _muasamcong_status_key(latest.get("value"))


def _is_muasamcong_contractor_terminated(data):
    return _latest_muasamcong_contractor_status(data) in {
        "cham dut",
        "terminated",
    }


def fetch_muasamcong_info(tax_code="", org_code="", role_name="NT"):
    normalized_org_code = normalize_procurement_org_code(org_code)
    if not normalized_org_code:
        return None

    normalized_role = str(role_name or "NT").strip().upper()
    if normalized_role not in {"NT", "CDT"}:
        normalized_role = "NT"

    try:
        if normalized_role == "CDT":
            service_base = MUASAMCONG_INVESTOR_SERVICE_BASE
            response_data = _post_muasamcong_json(
                "um/org/get-detail-info",
                {"orgCode": normalized_org_code},
                service_base=service_base,
            )
            data = response_data.get("orgInfo") if isinstance(response_data, dict) else None
            returned_org_code = normalize_procurement_org_code(data.get("orgCode")) if isinstance(data, dict) else None
            if returned_org_code != normalized_org_code:
                return None
        else:
            service_base = MUASAMCONG_CONTRACTOR_SERVICE_BASE
            data = _post_muasamcong_json(
                "get-detail-approve-bidder",
                {"orgCode": normalized_org_code, "roleName": normalized_role},
                service_base=service_base,
            )

        returned_org_code = (
            normalize_procurement_org_code(data.get("orgCode"))
            if isinstance(data, dict)
            else None
        )
        if returned_org_code != normalized_org_code:
            return None
        if normalized_role == "NT" and _is_muasamcong_contractor_terminated(data):
            return None

        area_codes = list(dict.fromkeys(
            code for code in (data.get("officePro"), data.get("officeDis"), data.get("officeWar"))
            if code
        ))
        # These auxiliary calls remain inside the single bounded lookup slot.
        # Avoid spawning an unbounded/nested thread pool per incoming request.
        area_names = {
            code: _fetch_muasamcong_area_name(code, service_base)
            for code in area_codes
        }
        return _build_muasamcong_partner_info(
            data,
            normalized_org_code,
            area_names,
        )
    except PartnerUpstreamError:
        raise
    except Exception as error:
        raise PartnerUpstreamError("MuaSamCong response processing failed") from error

def fetch_vietqr_info(tax_code):
    url = f"https://api.vietqr.io/v2/business/{tax_code}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with open_allowlisted_https(
            req,
            allowed_hosts={"api.vietqr.io"},
            timeout=_bounded_env_float(
                "PARTNER_VIETQR_TIMEOUT_SECONDS", 4.0, 1.0, 10.0
            ),
        ) as response:
            if response.status == 200:
                raw = response.read(512 * 1024 + 1)
                if len(raw) > 512 * 1024:
                    raise PartnerUpstreamError("VietQR response is too large")
                res_data = json.loads(raw.decode('utf-8'))
                if not isinstance(res_data, dict):
                    raise PartnerUpstreamError("VietQR response schema is invalid")
                if res_data.get("code") == "00" and "data" in res_data:
                    data = res_data["data"]
                    if not isinstance(data, dict):
                        raise PartnerUpstreamError("VietQR response schema is invalid")
                    return {
                        "name": data.get("name"),
                        "address": data.get("address"),
                        "short_name": data.get("shortName"),
                        "source": "VietQR"
                    }
    except urllib.error.HTTPError as exc:
        if exc.code in {400, 404}:
            return None
        raise PartnerUpstreamError("VietQR request failed") from exc
    except PartnerUpstreamError:
        raise
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
        raise PartnerUpstreamError("VietQR request failed") from exc
    return None

def fetch_escodata_info(tax_code):

    digits_only = re.sub(r'[^0-9]', '', tax_code)
    url = f"https://escodata.net/api-mst/{digits_only}.htm"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with open_allowlisted_https(
            req,
            allowed_hosts={"escodata.net"},
            timeout=_bounded_env_float(
                "PARTNER_ESCODATA_TIMEOUT_SECONDS", 4.0, 1.0, 10.0
            ),
        ) as response:
            if response.status == 200:
                raw = response.read(512 * 1024 + 1)
                if len(raw) > 512 * 1024:
                    raise PartnerUpstreamError("Escodata response is too large")
                content = raw.decode('utf-8')
                res_data = json.loads(content)
                if not isinstance(res_data, dict):
                    raise PartnerUpstreamError("Escodata response schema is invalid")
                name = res_data.get("name") or res_data.get("ten_cong_ty") or res_data.get("title")
                address = res_data.get("address") or res_data.get("dia_chi")
                if name:
                    return {
                        "name": name,
                        "address": address,
                        "short_name": res_data.get("short_name") or res_data.get("ten_viet_tat"),
                        "source": "Escodata"
                    }
    except urllib.error.HTTPError as exc:
        if exc.code in {400, 404}:
            return None
        raise PartnerUpstreamError("Escodata request failed") from exc
    except PartnerUpstreamError:
        raise
    except (urllib.error.URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
        raise PartnerUpstreamError("Escodata request failed") from exc
    return None

def lookup_partner_info(tax_code="", org_code=None, role_name="NT"):
    cleaned_tax_code = extract_clean_tax_code(tax_code)
    procurement_org_code = normalize_procurement_org_code(org_code)
    has_explicit_procurement_org_code = bool(procurement_org_code)
    normalized_role = str(role_name or "NT").strip().upper()
    if normalized_role not in {"NT", "CDT"}:
        normalized_role = "NT"
    if not procurement_org_code:
        digits_only = re.sub(r"[^0-9]", "", str(cleaned_tax_code or ""))
        procurement_org_code = f"vn{digits_only}" if digits_only else None

    cache_key = _lookup_cache_key(
        cleaned_tax_code or "", procurement_org_code or "", normalized_role
    )
    cached, cached_value = _cache_get(cache_key)
    if cached:
        return cached_value

    lookup_lock = _lookup_locks[int(cache_key[:8], 16) % len(_lookup_locks)]
    lock_timeout = _bounded_env_float(
        "PARTNER_LOOKUP_LOCK_TIMEOUT_SECONDS", 1.0, 0.05, 5.0
    )
    if not lookup_lock.acquire(timeout=lock_timeout):
        raise PartnerLookupBusyError("A lookup for this identifier is already running")
    try:
        # Collapse a cache miss stampede for the same identifier.
        cached, cached_value = _cache_get(cache_key)
        if cached:
            return cached_value

        slot_timeout = _bounded_env_float(
            "PARTNER_LOOKUP_SLOT_TIMEOUT_SECONDS", 0.25, 0.05, 3.0
        )
        if not _outbound_slots.acquire(timeout=slot_timeout):
            raise PartnerLookupBusyError("Outbound lookup capacity is exhausted")
        try:
            msc_available, info = _call_upstream(
                "muasamcong",
                fetch_muasamcong_info,
                cleaned_tax_code or "",
                procurement_org_code,
                role_name=normalized_role,
            )
            if info:
                return _cache_put(cache_key, info)

            if not cleaned_tax_code:
                if not msc_available:
                    raise PartnerUpstreamError("MuaSamCong is unavailable")
                _cache_put(cache_key, None)
                return None

            vietqr_available, info = _call_upstream(
                "vietqr", fetch_vietqr_info, cleaned_tax_code
            )
            if info:
                info["tax_code"] = cleaned_tax_code
                if has_explicit_procurement_org_code:
                    info["org_code"] = procurement_org_code
                return _cache_put(cache_key, info)

            escodata_available, info = _call_upstream(
                "escodata", fetch_escodata_info, cleaned_tax_code
            )
            if info:
                info["tax_code"] = cleaned_tax_code
                if has_explicit_procurement_org_code:
                    info["org_code"] = procurement_org_code
                return _cache_put(cache_key, info)

            # Once a valid tax code is available, the tax-code providers are
            # sufficient fallback sources. MuaSamCong may be unavailable (for
            # example because its TLS endpoint is temporarily incompatible)
            # without turning a completed tax-code lookup into a 502.
            # A negative result is still cached only when both fallback
            # providers completed successfully.
            if not (vietqr_available and escodata_available):
                raise PartnerUpstreamError("One or more partner upstreams are unavailable")
            _cache_put(cache_key, None)
            return None
        finally:
            _outbound_slots.release()
    finally:
        lookup_lock.release()

_PARTNER_WORKER_ID = f"{os.getpid()}-{uuid.uuid4().hex[:12]}"


def _enqueue_partner_enrichment_jobs(organization_id, contractor_ids):
    normalized_ids = sorted({
        str(contractor_id or "").strip()
        for contractor_id in contractor_ids or ()
        if str(contractor_id or "").strip()
    })
    if not organization_id or not normalized_ids:
        return 0
    now = int(time.time())
    connection = database.get_connection()
    try:
        connection.execute("BEGIN")
        queued = 0
        for contractor_id in normalized_ids:
            job_id = "partner-job-" + hashlib.sha256(
                f"{organization_id}\0{contractor_id}".encode("utf-8")
            ).hexdigest()
            cursor = connection.execute(
                """
                INSERT INTO partner_enrichment_jobs (
                    id, organization_id, contractor_id, status,
                    attempt_count, available_at, locked_at, locked_by,
                    last_error_code, created_at, updated_at
                ) VALUES (?, ?, ?, 'pending', 0, ?, NULL, NULL, NULL, ?, ?)
                ON CONFLICT (organization_id, contractor_id) DO UPDATE SET
                    status = 'pending',
                    attempt_count = 0,
                    available_at = excluded.available_at,
                    locked_at = NULL,
                    locked_by = NULL,
                    last_error_code = NULL,
                    updated_at = excluded.updated_at
                WHERE partner_enrichment_jobs.status <> 'processing'
                """,
                (
                    job_id,
                    organization_id,
                    contractor_id,
                    now,
                    now,
                    now,
                ),
            )
            if cursor.rowcount:
                queued += 1
        connection.commit()
        return queued
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _claim_partner_enrichment_job():
    now = int(time.time())
    stale_before = now - _bounded_env_int(
        "PARTNER_JOB_STALE_SECONDS",
        300,
        60,
        3_600,
    )
    connection = database.get_connection()
    try:
        connection.execute("BEGIN")
        row = connection.execute(
            """
            SELECT id, organization_id, contractor_id, attempt_count
            FROM partner_enrichment_jobs
            WHERE (
                    status IN ('pending', 'retry')
                    AND available_at <= ?
                  )
               OR (
                    status = 'processing'
                    AND locked_at <= ?
                  )
            ORDER BY available_at, created_at, id
            FOR UPDATE SKIP LOCKED
            LIMIT 1
            """,
            (now, stale_before),
        ).fetchone()
        if not row:
            connection.commit()
            return None
        attempt_count = int(row["attempt_count"] or 0) + 1
        connection.execute(
            """
            UPDATE partner_enrichment_jobs
            SET status = 'processing', attempt_count = ?,
                locked_at = ?, locked_by = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                attempt_count,
                now,
                _PARTNER_WORKER_ID,
                now,
                row["id"],
            ),
        )
        connection.commit()
        job = dict(row)
        job["attempt_count"] = attempt_count
        return job
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _finish_partner_enrichment_job(job, *, error=None):
    now = int(time.time())
    max_attempts = _bounded_env_int(
        "PARTNER_ENRICHMENT_MAX_ATTEMPTS",
        5,
        1,
        20,
    )
    attempts = int(job.get("attempt_count") or 1)
    if error is None:
        status = "completed"
        available_at = now
        error_code = None
    elif attempts >= max_attempts:
        status = "failed"
        available_at = now
        error_code = error.__class__.__name__[:96]
    else:
        status = "retry"
        available_at = now + min(3_600, 30 * (2 ** (attempts - 1)))
        error_code = error.__class__.__name__[:96]
    connection = database.get_connection()
    try:
        connection.execute(
            """
            UPDATE partner_enrichment_jobs
            SET status = ?, available_at = ?, locked_at = NULL,
                locked_by = NULL, last_error_code = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                status,
                available_at,
                error_code,
                now,
                job["id"],
            ),
        )
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _load_partner_job_contractor(job):
    connection = database.get_connection()
    try:
        row = connection.execute(
            """
            SELECT id, organization_id, ma_nha_thau, ma_so_thue,
                   ten_nha_thau, dia_chi, dia_chi_goc, ten_viet_tat,
                   nguoi_dai_dien, chuc_vu_dai_dien
            FROM nha_thau
            WHERE organization_id = ? AND id = ?
            LIMIT 1
            """,
            (job["organization_id"], job["contractor_id"]),
        ).fetchone()
        return dict(row) if row else None
    finally:
        connection.close()


def _apply_partner_enrichment(job, contractor, info):
    organization_id = str(job["organization_id"])
    contractor_id = str(job["contractor_id"])
    connection = database.get_connection()
    try:
        connection.execute("BEGIN")
        current = connection.execute(
            """
            SELECT ten_nha_thau
            FROM nha_thau
            WHERE organization_id = ? AND id = ?
            FOR UPDATE
            """,
            (organization_id, contractor_id),
        ).fetchone()
        if not current:
            connection.rollback()
            return
        if info and info.get("name"):
            new_name = str(info["name"]).strip()
            new_address_raw = str(info.get("address") or "").strip()
            new_address = (
                parse_vietnam_address_to_internal(new_address_raw)
                if new_address_raw
                else ""
            )
            new_short_name = str(info.get("short_name") or "").strip()
            new_representative_name = str(
                info.get("representative_name") or ""
            ).strip()
            new_representative_position = str(
                info.get("representative_position") or ""
            ).strip()
            returned_tax_code = str(info.get("tax_code") or "").strip()
            connection.execute(
                """
                INSERT INTO sync_metadata (organization_id, current_version)
                VALUES (?, 0) ON CONFLICT (organization_id) DO NOTHING
                """,
                (organization_id,),
            )
            new_sync_version = connection.execute(
                """
                UPDATE sync_metadata
                SET current_version = current_version + 1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE organization_id = ?
                RETURNING current_version
                """,
                (organization_id,),
            ).fetchone()[0]
            connection.execute(
                """
                UPDATE nha_thau
                SET ten_nha_thau = ?,
                    dia_chi = CASE
                        WHEN dia_chi IS NULL OR dia_chi = '' THEN ?
                        ELSE dia_chi END,
                    dia_chi_goc = CASE
                        WHEN dia_chi_goc IS NULL OR dia_chi_goc = '' THEN ?
                        ELSE dia_chi_goc END,
                    ten_viet_tat = CASE
                        WHEN ten_viet_tat IS NULL OR ten_viet_tat = '' THEN ?
                        ELSE ten_viet_tat END,
                    nguoi_dai_dien = CASE
                        WHEN nguoi_dai_dien IS NULL OR nguoi_dai_dien = '' THEN ?
                        ELSE nguoi_dai_dien END,
                    chuc_vu_dai_dien = CASE
                        WHEN chuc_vu_dai_dien IS NULL OR chuc_vu_dai_dien = '' THEN ?
                        ELSE chuc_vu_dai_dien END,
                    ma_so_thue = CASE WHEN ? <> '' THEN ? ELSE ma_so_thue END,
                    sync_version = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE organization_id = ? AND id = ?
                """,
                (
                    new_name,
                    new_address,
                    new_address_raw,
                    new_short_name,
                    new_representative_name,
                    new_representative_position,
                    returned_tax_code,
                    returned_tax_code,
                    new_sync_version,
                    organization_id,
                    contractor_id,
                ),
            )
            connection.execute(
                """
                UPDATE thong_tin_mo_thau
                SET ten_nha_thau = ?, sync_version = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE organization_id = ? AND nha_thau_id = ?
                  AND (
                    ten_nha_thau IS NULL OR ten_nha_thau = ''
                    OR ten_nha_thau = 'Nhà thầu (Chưa cập nhật thông tin)'
                    OR ten_nha_thau = 'Nhà thầu (Mã số thuế không hợp lệ)'
                  )
                """,
                (
                    new_name,
                    new_sync_version,
                    organization_id,
                    contractor_id,
                ),
            )
            from backend.sync.websocket import enqueue_websocket_event

            enqueue_websocket_event(
                connection,
                "broadcast",
                organization_id=organization_id,
                payload={
                    "type": "sync_update",
                    "table": "nhathau",
                    "id": contractor_id,
                    "syncVersion": new_sync_version,
                },
            )
        elif _is_placeholder_contractor_name(current["ten_nha_thau"]):
            connection.execute(
                """
                UPDATE nha_thau
                SET ten_nha_thau = 'Nhà thầu (Chưa cập nhật thông tin)'
                WHERE organization_id = ? AND id = ?
                """,
                (organization_id, contractor_id),
            )
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _needs_partner_enrichment(contractor):
    return (
        _is_placeholder_contractor_name(contractor.get("ten_nha_thau"))
        or not str(contractor.get("dia_chi") or "").strip()
        or str(contractor.get("ma_so_thue") or "").lower().startswith("vn")
        or not str(contractor.get("nguoi_dai_dien") or "").strip()
        or not str(contractor.get("chuc_vu_dai_dien") or "").strip()
    )

def _process_partner_enrichment_job(job):
    contractor = _load_partner_job_contractor(job)
    if contractor is None:
        _finish_partner_enrichment_job(job)
        return
    tax_code = extract_clean_tax_code(contractor.get("ma_so_thue"))
    org_code = normalize_procurement_org_code(contractor.get("ma_nha_thau"))
    needs_enrichment = _needs_partner_enrichment(contractor)
    if not needs_enrichment:
        _finish_partner_enrichment_job(job)
        return
    try:
        info = (
            lookup_partner_info(
                tax_code or "",
                org_code=org_code,
                role_name="NT",
            )
            if tax_code or org_code
            else None
        )
        _apply_partner_enrichment(job, contractor, info)
        _finish_partner_enrichment_job(job)
    except Exception as error:
        _finish_partner_enrichment_job(job, error=error)
        raise


def _drain_partner_enrichment_jobs() -> int:
    processed = 0
    while not _partner_stop_event.is_set():
        job = _claim_partner_enrichment_job()
        if job is None:
            return processed
        processed += 1
        try:
            _process_partner_enrichment_job(job)
        except Exception as error:
            log_error(error, "PartnerLookup.DurableWorker")
    return processed


def run_partner_lookup_worker():
    """Claim durable jobs with SKIP LOCKED; never hold DB state over network I/O."""

    _worker_debug("[Partner Worker] Durable enrichment worker started.")
    backoff = idle_poll_backoff_from_env(
        "PARTNER_LOOKUP_POLL_SECONDS",
        "PARTNER_LOOKUP_MAX_POLL_SECONDS",
        default_initial=1.0,
    )
    global _partner_worker_started, _partner_worker_thread
    try:
        while not _partner_stop_event.is_set():
            signaled = _partner_work_event.wait(timeout=backoff.next_delay())
            _partner_work_event.clear()
            if _partner_stop_event.is_set():
                return
            if signaled:
                backoff.reset()
            try:
                processed = _drain_partner_enrichment_jobs()
            except Exception as error:
                log_error(error, "PartnerLookup.DurableWorker")
                processed = 0
            if processed:
                backoff.reset()
    finally:
        with _partner_worker_lock:
            if _partner_worker_thread is threading.current_thread():
                _partner_worker_thread = None
                _partner_worker_started = False


def start_partner_background_service():
    global _partner_worker_started, _partner_worker_thread
    with _partner_worker_lock:
        if _partner_worker_started:
            return _partner_worker_thread
        _partner_stop_event.clear()
        _partner_worker_started = True
        worker = threading.Thread(
            target=run_partner_lookup_worker, daemon=True, name="partner-enrichment-worker",
        )
        _partner_worker_thread = worker
        try:
            worker.start()
        except BaseException:
            _partner_worker_thread = None
            _partner_worker_started = False
            raise
        return worker


def request_partner_background_service_stop():
    """Signal stop immediately; the lifecycle owner must join the returned worker."""
    with _partner_worker_lock:
        _partner_stop_event.set()
        _partner_work_event.set()
        return _partner_worker_thread


def stop_partner_background_service(*, timeout=30.0):
    """Stop and join within the deadline; report whether in-flight work finished."""
    worker = request_partner_background_service_stop()
    if worker is None:
        return True
    worker.join(timeout=max(0.0, float(timeout)))
    return not worker.is_alive()


def request_partner_enrichment(organization_id=None, contractor_ids=None):
    """Persist work before waking a process-local poller."""

    if organization_id and contractor_ids:
        _enqueue_partner_enrichment_jobs(organization_id, contractor_ids)
    start_partner_background_service()
    _partner_work_event.set()
