"""Casing-only normalization of all-uppercase procurement partner names."""
import re

ACRONYMS = set("TNHH CTCP CP MTV UBND HDN HĐND BQL BQLDA HTX JSC LLC FPT VNPT EVN BIDV PCCC TM DV XNK".split())
PHRASES = (
    "Công ty", "Cổ phần", "Trách nhiệm hữu hạn", "Một thành viên", "Hai thành viên",
    "Thương mại", "Dịch vụ", "Dược phẩm", "Xây dựng", "Đầu tư", "Phát triển",
    "Trung tâm", "Y tế", "Bệnh viện", "Ban quản lý", "Dự án", "Ủy ban nhân dân",
    "Liên danh", "Chi nhánh", "Khu vực", "Thành phố", "Thị xã", "Thị trấn",
)
LOWERCASE_CONNECTORS = ("và",)
VIETNAMESE_VOWELS = set("aeiouyàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵ")


def _is_short_initialism(word):
    letters = "".join(char for char in word.casefold() if char.isalpha())
    return 1 < len(letters) <= 4 and not any(char in VIETNAMESE_VOWELS for char in letters)


def normalize_procurement_partner_name(value):
    text = str(value or "")
    if not text.isupper():
        return re.sub(
            r"[^\W\d_][^\W_]*",
            lambda match: match.group().upper() if _is_short_initialism(match.group()) else match.group(),
            text,
        )

    def word_case(match):
        word = match.group()
        if word in ACRONYMS or _is_short_initialism(word) or any(char.isdigit() for char in word):
            return word
        return word[:1] + word[1:].lower()

    result = re.sub(r"[^\W\d_][^\W_]*", word_case, text)
    for phrase in PHRASES:
        result = re.sub(r"(?<!\w)" + re.escape(phrase) + r"(?!\w)", phrase, result, flags=re.I)
    for connector in LOWERCASE_CONNECTORS:
        result = re.sub(r"(?<!\w)" + re.escape(connector) + r"(?!\w)", connector, result, flags=re.I)
    return result
