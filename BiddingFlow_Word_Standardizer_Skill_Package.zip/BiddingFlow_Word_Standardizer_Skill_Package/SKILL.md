---
name: biddingflow-word-standardizer
description: >
  Skill dành cho BiddingFlow để tự động đọc file DOCX mẫu, nhận diện các trường/ngữ nghĩa
  của văn bản hành chính, kiểm tra thể thức - kỹ thuật trình bày theo Nghị định 30/2020/NĐ-CP
  và Phụ lục I, II, III; sau đó đề xuất hoặc áp dụng sửa định dạng an toàn mà không làm hỏng
  placeholder/template logic.
version: 1.0.0
language: vi
source_basis:
  - Nghị định 30/2020/NĐ-CP ngày 05/03/2020
  - Phụ lục I - Thể thức, kỹ thuật trình bày văn bản hành chính và bản sao văn bản
  - Phụ lục II - Viết hoa trong văn bản hành chính
  - Phụ lục III - Bảng chữ viết tắt tên loại và mẫu trình bày văn bản hành chính, bản sao văn bản
---

# BIDDINGFLOW WORD STANDARDIZER

## 1. Mục tiêu

Skill này giúp ứng dụng thực hiện chuỗi công việc:

```text
DOCX mẫu
→ đọc cấu trúc OOXML
→ nhận diện loại văn bản
→ nhận diện các trường/placeholder
→ ánh xạ trường sang thành phần thể thức
→ kiểm tra quy chuẩn
→ chấm mức độ tin cậy
→ đề xuất sửa / tự sửa an toàn
→ render kiểm tra trực quan
→ xuất DOCX chuẩn hóa + báo cáo thay đổi
```

Mục tiêu là **chuẩn hóa thể thức và kỹ thuật trình bày**, không thay người dùng quyết định nội dung pháp lý.

---

# 2. Phạm vi áp dụng và nguyên tắc pháp lý

## 2.1. Không áp dụng Nghị định 30 một cách mù quáng cho mọi file Word

Nghị định 30/2020/NĐ-CP áp dụng trực tiếp đối với cơ quan, tổ chức nhà nước và doanh nghiệp nhà nước.

Văn bản chuyên ngành là văn bản hình thành trong hoạt động chuyên môn, nghiệp vụ của một ngành/lĩnh vực; người đứng đầu cơ quan quản lý ngành/lĩnh vực có thể quy định phù hợp trên cơ sở Nghị định.

Vì vậy skill phải hỗ trợ ba profile:

### `n30_strict`

Áp dụng đầy đủ Nghị định 30 và Phụ lục I-II-III.

Dùng khi:
- cơ quan nhà nước;
- tổ chức thuộc phạm vi áp dụng;
- doanh nghiệp nhà nước;
- hoặc tổ chức chủ động chọn Nghị định 30 làm quy chuẩn nội bộ.

### `sector_template`

Văn bản chuyên ngành / biểu mẫu đấu thầu có mẫu chuyên ngành riêng.

Nguyên tắc:

```text
Quy tắc chuyên ngành
       thắng
Quy tắc NĐ30 nền
```

Chỉ sửa phần NĐ30 nếu không xung đột với mẫu chuyên ngành.

### `reference_only`

Dùng Nghị định 30 như chuẩn tham khảo cho doanh nghiệp/tổ chức không bắt buộc áp dụng.

Skill chỉ:
- audit;
- đề xuất;
- không tự sửa các phần có rủi ro.

---

# 3. Ba chế độ chạy

## `audit`

Chỉ nhận diện + báo lỗi.

Không sửa DOCX.

## `preview_fix`

Tạo:
- danh sách thay đổi dự kiến;
- bản preview;
- mức độ tin cậy;
- lý do/căn cứ.

Chưa ghi đè file gốc.

## `apply_fix`

Chỉ áp dụng thay đổi đã được xác định là an toàn.

Luôn tạo file mới.

Không ghi đè bản mẫu gốc.

---

# 4. Kiến trúc bắt buộc

Không chỉ dùng thư viện đọc paragraph cấp cao.

DOCX phải được đọc ở cả hai tầng:

## Tầng 1 — OOXML structural analysis

Đọc tối thiểu:

```text
word/document.xml
word/styles.xml
word/numbering.xml
word/settings.xml
word/header*.xml
word/footer*.xml
word/_rels/*
word/media/*
```

Phải nhận diện:

- paragraph;
- run;
- table;
- table cell;
- section;
- header/footer;
- page setup;
- bookmark;
- field code;
- content control (`w:sdt`);
- text box / drawing text;
- hyperlink;
- image;
- merged cells;
- page-number field;
- paragraph border;
- tabs;
- indents;
- style inheritance.

## Tầng 2 — Render verification

DOCX là định dạng flow-based; OOXML không luôn cho biết chính xác tọa độ cuối cùng sau khi Word/LibreOffice paginate.

Sau khi sửa phải:

```text
DOCX
→ render PDF
→ kiểm tra page count
→ kiểm tra bounding boxes / vùng hiển thị
→ tạo preview ảnh hoặc PDF
```

Không coi “XML hợp lệ” là “giao diện đúng”.

---

# 5. Không được làm hỏng template

Đây là invariant bắt buộc.

Skill phải bảo vệ các dạng placeholder:

```text
{{ field }}
{{object.field}}
{% for x in items %}
{% if condition %}
[[FIELD]]
${field}
<<field>>
MERGEFIELD
DOCVARIABLE
DOC PROPERTY
Content Control / SDT
Bookmark
```

## Không được

- tự đổi tên placeholder;
- thêm khoảng trắng vào bên trong key;
- tách một placeholder thành nhiều run nếu engine template không hỗ trợ;
- merge các run làm mất field code;
- xóa content control;
- xóa bookmark;
- xóa loop/condition;
- format bằng cách phá cấu trúc XML của template.

Placeholder phải được coi là **atomic token**.

---

# 6. Quy trình nhận diện loại văn bản

Skill phải xác định `document_type` trước khi sửa sâu.

Dùng nhiều tín hiệu đồng thời.

## 6.1. Tín hiệu

- tên loại ở vùng giữa đầu trang;
- số/ký hiệu;
- chữ viết tắt trong số văn bản;
- `V/v`;
- `Kính gửi`;
- các marker đặc thù;
- cấu trúc chữ ký;
- các nhãn như `Điều`, `QUYẾT ĐỊNH:`, `QUYẾT NGHỊ:`;
- vị trí tương đối trong tài liệu;
- mẫu top-left / top-right;
- tên file chỉ là tín hiệu phụ, không phải source of truth.

## 6.2. Loại văn bản cần nhận diện

### Loại riêng

- `nghi_quyet_ca_biet`
- `quyet_dinh_truc_tiep`
- `quyet_dinh_gian_tiep`
- `cong_van`
- `cong_dien`
- `giay_moi`
- `giay_gioi_thieu`
- `bien_ban`
- `giay_nghi_phep`
- `phu_luc`
- `ban_sao`

### Nhóm văn bản có tên loại theo Mẫu 1.4

- chỉ thị;
- quy chế;
- quy định;
- thông cáo;
- thông báo;
- hướng dẫn;
- chương trình;
- kế hoạch;
- phương án;
- đề án;
- dự án;
- báo cáo;
- tờ trình;
- giấy ủy quyền;
- phiếu gửi;
- phiếu chuyển;
- phiếu báo.

### Loại cần thận trọng

`hop_dong`

Nghị định liệt kê Hợp đồng là văn bản hành chính, nhưng mẫu Phụ lục III không đưa Hợp đồng vào Mẫu 1.4.

Do đó:
- nhận diện được `HỢP ĐỒNG`;
- áp dụng quy tắc kỹ thuật chung khi phù hợp;
- không tự tái cấu trúc phần nội dung/chữ ký hợp đồng nếu chưa có profile chuyên ngành.

---

# 7. Từ điển chữ viết tắt để nhận diện số/ký hiệu

Dùng làm tín hiệu nhận diện, không tự sửa nếu chưa chắc chắn.

| Loại | Viết tắt |
|---|---|
| Nghị quyết (cá biệt) | NQ |
| Quyết định (cá biệt) | QĐ |
| Chỉ thị | CT |
| Quy chế | QC |
| Quy định | QyĐ |
| Thông cáo | TC |
| Thông báo | TB |
| Hướng dẫn | HD |
| Chương trình | CTr |
| Kế hoạch | KH |
| Phương án | PA |
| Đề án | ĐA |
| Dự án | DA |
| Báo cáo | BC |
| Biên bản | BB |
| Tờ trình | TTr |
| Hợp đồng | HĐ |
| Công điện | CĐ |
| Bản ghi nhớ | BGN |
| Bản thỏa thuận | BTT |
| Giấy ủy quyền | GUQ |
| Giấy mời | GM |
| Giấy giới thiệu | GGT |
| Giấy nghỉ phép | GNP |
| Phiếu gửi | PG |
| Phiếu chuyển | PC |
| Phiếu báo | PB |
| Bản sao y | SY |
| Bản trích sao | TrS |
| Bản sao lục | SL |

---

# 8. Canonical semantic fields

Skill không phụ thuộc vào tên biến thật của template.

Mọi placeholder phát hiện được phải được map sang một semantic field.

## 8.1. Header

```text
document.parent_organization
document.issuing_organization
document.number
document.symbol
document.location
document.issue_date
document.national_header
document.motto
```

## 8.2. Tên loại / trích yếu

```text
document.type
document.subject
document.office_letter_subject
```

## 8.3. Nội dung

```text
document.legal_bases[]
document.proposal_basis
document.body
document.sections[]
document.articles[]
document.clauses[]
document.points[]
```

## 8.4. Người nhận

```text
document.primary_addressees[]
document.recipients[]
document.archive_recipient
```

## 8.5. Ký ban hành

```text
document.signing_authority
document.signer_title
document.signer_name
document.signer_signature
document.organization_seal
```

## 8.6. Thông tin bổ sung

```text
document.confidentiality
document.urgency
document.circulation_instruction
document.drafter_code
document.copy_count
document.contact.address
document.contact.email
document.contact.website
document.contact.phone
document.contact.fax
document.page_number
```

## 8.7. Phụ lục

```text
appendix.index
appendix.title
appendix.parent_document_number
appendix.parent_document_date
appendix.parent_organization
appendix.body
```

---

# 9. Nhận diện placeholder

## 9.1. Candidate extraction

Thu thập candidate từ:

- text token;
- text quanh dấu `...`, `_`, `[]`;
- Jinja/Handlebars-style token;
- merge field;
- SDT tag/alias;
- bookmark name;
- form field;
- cell label + cell value;
- paragraph label + run bên cạnh.

## 9.2. Feature cho mỗi candidate

```json
{
  "raw_key": "{{plan.soVanBan}}",
  "normalized_key": "plan.soVanBan",
  "text_before": "Số:",
  "text_after": "/QĐ-...",
  "container": "table_cell",
  "section_index": 0,
  "order_index": 12,
  "style": {},
  "neighbors": [],
  "candidate_semantics": []
}
```

## 9.3. Scoring

Gợi ý trọng số:

```text
lexical / key-name signal            35%
nhãn lân cận                          25%
vị trí logical zone                   15%
định dạng hiện tại                    10%
document-type context                 10%
quan hệ với candidate khác             5%
```

## 9.4. Confidence

### `>= 0.90`

Có thể auto-map và auto-format.

### `0.70 - 0.89`

Map tạm thời nhưng chỉ `preview_fix`.

### `< 0.70`

Không tự sửa.

Yêu cầu review/mapping thủ công.

---

# 10. Nhận diện vùng bố cục

Không dựa vào tọa độ tuyệt đối từ OOXML.

Dùng logical zones.

## `header_left`

Thường chứa:

- cơ quan chủ quản;
- cơ quan ban hành;
- số/ký hiệu;
- `V/v` đối với công văn.

## `header_right`

Thường chứa:

- Quốc hiệu;
- Tiêu ngữ;
- địa danh + ngày tháng.

## `center_title`

- tên loại;
- trích yếu.

## `primary_addressee`

- `Kính gửi`.

## `main_body`

- căn cứ;
- lời mở đầu;
- phần/chương/mục;
- điều/khoản/điểm;
- nội dung.

## `footer_left`

- `Nơi nhận`;
- nơi lưu;
- mã người soạn thảo.

## `signature_right`

- quyền hạn;
- chức vụ;
- vùng chữ ký;
- họ tên;
- dấu.

## `contact_footer`

- địa chỉ;
- email;
- website;
- điện thoại;
- fax.

---

# 11. Pattern cấu trúc phải hỗ trợ

Skill phải xử lý được cả:

## Layout bằng paragraph/tab

và:

## Layout bằng borderless table

Đặc biệt top header và signature/recipient block thường có thể được dựng bằng bảng 2 cột không viền.

Không được coi bảng 2 cột là “bảng dữ liệu” rồi tự thêm border.

---

# 12. Quy tắc kỹ thuật chung

Nguồn: Phụ lục I.

## 12.1. Khổ giấy

A4:

```text
210 mm x 297 mm
```

## 12.2. Hướng trang

Mặc định: portrait.

Landscape có thể chấp nhận khi nội dung có bảng/biểu và không tách thành phụ lục riêng.

**Không tự xoay section nếu không đủ tự tin.**

## 12.3. Lề

```text
Trên: 20 - 25 mm
Dưới: 20 - 25 mm
Trái: 30 - 35 mm
Phải: 15 - 20 mm
```

Nếu đang trong khoảng hợp lệ:

**không thay đổi chỉ để “đồng bộ”.**

Nếu ngoài khoảng:

- chọn giá trị hợp lệ gần nhất để giảm layout shift;
- hoặc dùng profile preferred:
  - top 20 mm;
  - bottom 20 mm;
  - left 30 mm;
  - right 20 mm.

## 12.4. Font

```text
Times New Roman
Unicode
màu đen
```

Không áp font lên:
- ảnh;
- chữ ký scan;
- logo;
- object nhúng không phải text.

## 12.5. Số trang

- chữ số Ả Rập;
- cỡ 13-14;
- đứng;
- canh giữa theo chiều ngang ở lề trên;
- không hiển thị số trang thứ nhất.

---

# 13. Size profile thống nhất

Phụ lục yêu cầu việc tăng/giảm cỡ chữ trong cùng một văn bản phải thống nhất.

Skill phải xác định dominant profile trước.

## Profile `body_13`

```text
body            13
quốc hiệu       12
tiêu ngữ        13
địa danh/date   13
title           13
subject         13
signature       13
```

## Profile `body_14`

```text
body            14
quốc hiệu       13
tiêu ngữ        14
địa danh/date   14
title           14
subject         14
signature       14
```

Nếu tài liệu hiện tại đã nhất quán trong các khoảng pháp luật cho phép:

**không ép sang profile khác.**

---

# 14. Rule matrix các thành phần chính

## 14.1. Quốc hiệu

Text chuẩn:

```text
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
```

- in hoa;
- 12-13;
- đứng;
- đậm;
- vùng `header_right`;
- canh giữa.

## 14.2. Tiêu ngữ

Text chuẩn:

```text
Độc lập - Tự do - Hạnh phúc
```

- in thường theo cách viết chuẩn;
- 13-14;
- đứng;
- đậm;
- canh giữa;
- dưới Quốc hiệu;
- có dòng kẻ ngang bên dưới.

## 14.3. Tên cơ quan chủ quản

- in hoa;
- 12-13;
- đứng;
- canh giữa;
- không bắt buộc đậm.

## 14.4. Tên cơ quan ban hành

- in hoa;
- 12-13;
- đứng;
- đậm;
- canh giữa;
- dưới cơ quan chủ quản;
- có đường kẻ ngang dài khoảng 1/3 đến 1/2 dòng chữ.

## 14.5. Số, ký hiệu

- cỡ 13;
- đứng;
- canh giữa dưới tên cơ quan;
- dạng bắt đầu bằng `Số:`;
- số nhỏ hơn 10 phải có `0` phía trước khi applicable;
- dấu `/` giữa số và ký hiệu;
- dấu `-` giữa các nhóm viết tắt;
- không chèn khoảng trắng quanh `/` và `-`.

## 14.6. Địa danh và thời gian

- 13-14;
- nghiêng;
- cùng hàng logic với số/ký hiệu;
- vùng `header_right`;
- canh giữa dưới Quốc hiệu/Tiêu ngữ;
- sau địa danh có dấu phẩy.

## 14.7. Tên loại văn bản

Đối với văn bản có tên loại:

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## 14.8. Trích yếu

### Văn bản có tên loại

- in thường;
- 13-14;
- đứng;
- đậm;
- canh giữa;
- có dòng kẻ bên dưới.

### Công văn

- bắt đầu bằng `V/v`;
- in thường;
- 12-13;
- đứng;
- không bắt buộc đậm;
- đặt dưới số/ký hiệu phía trái.

---

# 15. Nội dung văn bản

## 15.1. Body

- in thường;
- 13-14;
- đứng;
- canh đều hai lề;
- first-line indent: 1 cm hoặc 1,27 cm;
- paragraph spacing: tối thiểu 6 pt;
- line spacing: từ single đến 1.5 lines.

Nếu current value nằm trong khoảng hợp lệ:

**preserve**.

## 15.2. Căn cứ

- in thường;
- nghiêng;
- 13-14;
- mỗi căn cứ xuống dòng;
- cuối mỗi căn cứ `;`;
- căn cứ cuối kết thúc `.`.

Không tự sửa nội dung/căn cứ nếu chỉ dựa vào NLP.

Chỉ sửa:
- font;
- style;
- spacing;
- punctuation khi pattern xác định chắc chắn và người dùng bật content-normalization.

---

# 16. Heading / numbering

## Phần / Chương

Dòng:

```text
Phần I
Chương I
```

- in thường;
- 13-14;
- đứng;
- đậm;
- canh giữa;
- số La Mã.

Tiêu đề:

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## Mục / Tiểu mục

Dòng `Mục 1`, `Tiểu mục 1`:

- in thường;
- 13-14;
- đứng;
- đậm;
- canh giữa.

Tiêu đề:

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## Điều

- in thường;
- 13-14;
- đứng;
- đậm;
- first-line indent 1 hoặc 1,27 cm.

## Khoản

- số Ả Rập + `.`;
- 13-14;
- đứng;
- nếu có tiêu đề: tiêu đề đậm;
- nếu không có tiêu đề: không đậm.

## Điểm

- chữ cái tiếng Việt + `)`;
- 13-14;
- đứng.

---

# 17. Người ký

## Quyền hạn

Ví dụ:

```text
TM.
Q.
KT.
TL.
TUQ.
```

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## Chức vụ

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## Họ tên

- kiểu chữ bình thường theo tên riêng;
- 13-14;
- đứng;
- đậm;
- canh giữa.

## Chữ ký / dấu

Skill:

- được nhận diện vùng;
- được căn chỉnh nếu asset đã tồn tại;
- được kiểm tra kích thước/position.

Skill **không được tự sinh chữ ký hoặc con dấu**.

Nếu không có asset:

- giữ placeholder;
- báo `missing_signature_asset` / `missing_seal_asset`.

---

# 18. Người nhận

## Kính gửi

- 13-14;
- đứng.

Một nơi:

```text
Kính gửi: Bộ Nội vụ
```

Nhiều nơi:

```text
Kính gửi:
- ...
- ...
- ...
```

## Nơi nhận

Label:

```text
Nơi nhận:
```

- cỡ 12;
- nghiêng;
- đậm.

Danh sách:

- cỡ 11;
- đứng;
- mỗi nơi một dòng;
- đầu dòng `-`;
- dòng giữa kết thúc `;`;
- dòng cuối thường là `Lưu: ...` và kết thúc `.`.

---

# 19. Phụ lục

## Tiêu đề đầu phụ lục

`Phụ lục I`:

- in thường;
- cỡ 14;
- đứng;
- đậm;
- canh giữa.

Tên phụ lục:

- in hoa;
- 13-14;
- đứng;
- đậm;
- canh giữa.

Thông tin kèm theo:

```text
(Kèm theo Văn bản số... ngày... tháng... năm... của...)
```

- in thường;
- 13-14;
- nghiêng;
- canh giữa.

Số trang phụ lục:

- đánh riêng theo từng phụ lục.

---

# 20. Thành phần bổ sung

## Độ khẩn

- `HỎA TỐC`;
- `THƯỢNG KHẨN`;
- `KHẨN`.

Format:

- in hoa;
- 13-14;
- đứng;
- đậm.

Không tự thêm độ khẩn nếu template/data không khai báo.

## Phạm vi lưu hành

Ví dụ:

```text
XEM XONG TRẢ LẠI
LƯU HÀNH NỘI BỘ
```

- in hoa;
- 13-14;
- đứng;
- đậm.

## Ký hiệu người soạn thảo / số lượng bản

- cỡ 11;
- đứng.

## Contact footer

- cỡ 11-12;
- đứng;
- dưới đường kẻ ngang kéo hết vùng trình bày.

---

# 21. Viết hoa

Nguồn: Phụ lục II.

## Tự sửa an toàn

Có thể auto-fix với confidence cao:

- chữ cái đầu câu;
- tên loại văn bản đã nhận diện chắc chắn;
- tên loại/section marker cố định;
- Quốc hiệu;
- các marker cố định `Điều`, `Chương`, `Mục`,...

## Chỉ cảnh báo, không tự đổi nếu chưa chắc chắn

- tên người;
- địa danh;
- tên cơ quan;
- tên chức vụ;
- danh hiệu;
- sự kiện lịch sử;
- tên nước ngoài;
- tên tác phẩm;
- danh từ riêng hóa.

Lý do:

Auto-capitalization sai có thể làm thay đổi tên pháp lý.

---

# 22. Nhận diện các mẫu đặc thù

## `nghi_quyet_ca_biet`

Tín hiệu:

- `NGHỊ QUYẾT`;
- ký hiệu `NQ`;
- `QUYẾT NGHỊ:`.

Field thêm:

```text
resolution.authority
resolution.legal_bases[]
resolution.body
```

## `quyet_dinh_truc_tiep`

Tín hiệu:

- `QUYẾT ĐỊNH`;
- ký hiệu `QĐ`;
- `QUYẾT ĐỊNH:`;
- `Điều 1...`.

Field:

```text
decision.subject
decision.authority
decision.legal_bases[]
decision.proposal
decision.articles[]
```

## `quyet_dinh_gian_tiep`

Tín hiệu:

- `QUYẾT ĐỊNH`;
- `Ban hành` hoặc `Phê duyệt`;
- nội dung Điều 1 dẫn tới tài liệu kèm theo.

Field thêm:

```text
decision.attached_document
```

## `cong_van`

Tín hiệu:

- không có tên loại lớn ở giữa;
- có `V/v`;
- có `Kính gửi`.

## `cong_dien`

Tín hiệu:

- `CÔNG ĐIỆN`;
- ký hiệu `CĐ`;
- marker `điện:`.

## `giay_moi`

Tín hiệu:

- `GIẤY MỜI`;
- `trân trọng kính mời`;
- `Chủ trì`;
- `Thời gian`;
- `Địa điểm`.

Field:

```text
invitation.invitee
invitation.event
invitation.chair
invitation.time
invitation.location
invitation.notes
```

## `giay_gioi_thieu`

Tín hiệu:

- `GIẤY GIỚI THIỆU`;
- `trân trọng giới thiệu`;
- `Ông (bà)`;
- `Được cử đến`;
- `Về việc`.

## `bien_ban`

Tín hiệu:

- `BIÊN BẢN`;
- `Thời gian bắt đầu`;
- `Địa điểm`;
- `Thành phần tham dự`;
- `Chủ trì`;
- `Thư ký`.

Field:

```text
minutes.start_time
minutes.location
minutes.participants
minutes.chair
minutes.secretary
minutes.body
minutes.end_time
```

## `giay_nghi_phep`

Tín hiệu:

- `GIẤY NGHỈ PHÉP`;
- `Được nghỉ phép`;
- `Số ngày nghỉ phép`.

---

# 23. Safe-fix policy

Mỗi issue phải được gắn:

```text
SAFE_AUTO_FIX
PREVIEW_ONLY
MANUAL_REVIEW
PROHIBITED
```

## SAFE_AUTO_FIX

Khi semantic confidence >= 0.90:

- Times New Roman;
- màu text đen;
- font size ngoài range;
- bold/italic sai rõ ràng;
- alignment;
- paragraph spacing;
- line spacing;
- first-line indent;
- page margins ngoài range;
- page-number style;
- hidden border của borderless layout bị bật nhầm;
- preserve placeholder while applying run/paragraph style.

## PREVIEW_ONLY

- di chuyển block sang cột trái/phải;
- tái cấu trúc table;
- thêm/dời `Kính gửi`;
- thêm dòng kẻ;
- đổi orientation;
- đổi page break/section break;
- sửa chữ hoa tên riêng;
- sửa số/ký hiệu;
- sửa punctuation nội dung.

## MANUAL_REVIEW

- không xác định được loại văn bản;
- xung đột mẫu chuyên ngành;
- field confidence < 0.90;
- nhiều candidate cho một semantic field;
- missing legal component;
- template có macro/object phức tạp.

## PROHIBITED

- sinh chữ ký giả;
- sinh con dấu giả;
- thay người ký;
- thay nội dung pháp lý;
- xóa căn cứ;
- sửa số tiền;
- sửa ngày tháng nghiệp vụ;
- thay tên đơn vị;
- thay kết quả đấu thầu;
- thay quyền/phân công;
- sửa dữ liệu domain để “làm cho văn bản hợp lệ”.

---

# 24. Dòng kẻ

Skill phải phân biệt:

- border thật;
- shape line;
- underline;
- hàng table giả.

## Tiêu ngữ

Dòng kẻ:
- nét liền;
- độ dài xấp xỉ dòng Tiêu ngữ;
- canh giữa.

## Tên cơ quan ban hành

Dòng kẻ:
- nét liền;
- dài khoảng 1/3 đến 1/2 độ dài dòng tên;
- canh giữa.

Không dùng chuỗi underscore `______` nếu có thể tạo line object/border chính xác hơn.

---

# 25. Số và ngày tháng

## Số văn bản

Không tự cấp số.

Chỉ validate format.

## Ngày ban hành

Khi dữ liệu được render từ field:

```text
<Địa danh>, ngày DD tháng M/MM năm YYYY
```

Phải tuân theo format của profile pháp lý.

Không tự thay ngày nghiệp vụ trong template.

---

# 26. Output chuẩn của detector

```json
{
  "document_type": {
    "value": "cong_van",
    "confidence": 0.97
  },
  "profile": "n30_strict",
  "fields": [
    {
      "semantic": "document.issuing_organization",
      "source": "{{organization.name}}",
      "confidence": 0.98,
      "location": {
        "part": "document.xml",
        "container": "table_cell",
        "section": 0
      }
    }
  ],
  "violations": [
    {
      "rule_id": "N30-P1-FONT",
      "severity": "error",
      "target": "document.body",
      "current": "Arial 11",
      "expected": "Times New Roman 13-14",
      "fix_policy": "SAFE_AUTO_FIX"
    }
  ]
}
```

---

# 27. Output chuẩn sau khi sửa

Skill trả:

1. `corrected.docx`
2. `recognition.json`
3. `validation-report.json`
4. `changes.json`
5. preview PDF/ảnh nếu hệ thống hỗ trợ
6. summary cho UI

Ví dụ UI:

```text
Đã nhận diện: Công văn
Độ tin cậy: 97%

22 thành phần đã kiểm tra
14 đúng quy chuẩn
6 đã tự sửa
2 cần kiểm tra thủ công
```

---

# 28. Change log

Mỗi thay đổi phải có:

```json
{
  "rule_id": "N30-P1-BODY-FONT",
  "target": "{{report.content}}",
  "before": {
    "font": "Arial",
    "size": 11
  },
  "after": {
    "font": "Times New Roman",
    "size": 13
  },
  "reason": "Phụ lục I - quy định phông chữ và cỡ chữ nội dung",
  "confidence": 0.99
}
```

---

# 29. Bảo toàn dữ liệu và rollback

Không sửa in-place.

Phải có:

```text
original template
↓
template version
↓
normalized candidate
↓
preview
↓
publish
```

Nếu BiddingFlow đã có Template Version History thì skill phải dùng version hiện có, không tạo version system thứ hai.

Mọi lần normalize phải:
- có checksum;
- actor;
- timestamp;
- source template version;
- rule-set version;
- change log.

---

# 30. Rule-set versioning

Quy tắc phải được tách khỏi code.

Ví dụ:

```text
rules/n30_2020_rules.json
```

Mỗi rule có:

```json
{
  "id": "N30-P1-NATIONAL-HEADER",
  "source": "Phụ lục I, Phần I",
  "effective_from": "2020-03-05",
  "profile": "n30_2020",
  "enabled": true
}
```

Sau này nếu có chuẩn mới:

```text
n30_2020
nxx_20xx
enterprise_internal_v1
sector_procurement_v1
```

Không ghi đè rule cũ vì template/document cũ có thể cần validate theo rule set lịch sử.

---

# 31. Không được tự suy diễn mẫu chuyên ngành đấu thầu

Nếu template là:

- HSMT;
- E-HSMT;
- Báo cáo đánh giá;
- Báo cáo thẩm định;
- biểu mẫu theo Thông tư/ngành;

thì skill phải:

1. nhận diện đây là template chuyên ngành;
2. giữ cấu trúc nội dung chuyên ngành;
3. áp NĐ30 cho administrative shell/format nếu tương thích;
4. không đổi các bảng, heading, trường bắt buộc chuyên ngành nếu chưa có rule profile chuyên ngành.

---

# 32. QA bắt buộc

Sau khi sửa:

## Structural QA

- DOCX mở được;
- XML hợp lệ;
- không mất placeholder;
- số placeholder trước/sau bằng nhau;
- field code còn nguyên;
- SDT/bookmark còn nguyên;
- không mất image;
- không mất table;
- không mất section;
- không mất header/footer.

## Template QA

- render thử với dữ liệu mẫu;
- loop không hỏng;
- condition không hỏng;
- placeholder không lộ ra ngoài;
- field có font/size đúng sau render.

## Visual QA

Kiểm tra từng trang:

- không overlap;
- không clipping;
- không vỡ table;
- header trái/phải không chồng nhau;
- chữ ký/nơi nhận không va nhau;
- page number đúng;
- margin nhìn đúng;
- không xuất hiện border table layout.

---

# 33. Acceptance criteria

Skill chỉ được coi là đạt khi:

- [ ] Nhận diện đúng loại văn bản với confidence.
- [ ] Nhận diện được common administrative fields.
- [ ] Nhận diện được placeholder trong paragraph/table/SDT/field.
- [ ] Không phá placeholder.
- [ ] Có rule profile.
- [ ] Có version cho rule set.
- [ ] Kiểm tra đúng A4/margin/font/page number.
- [ ] Kiểm tra đúng Quốc hiệu/Tiêu ngữ.
- [ ] Kiểm tra đúng cơ quan/số-ký hiệu/địa danh-ngày.
- [ ] Kiểm tra đúng tên loại/trích yếu.
- [ ] Kiểm tra đúng body/heading/indent/spacing.
- [ ] Kiểm tra đúng signature block.
- [ ] Kiểm tra đúng Kính gửi/Nơi nhận.
- [ ] Hỗ trợ phụ lục.
- [ ] Hỗ trợ mẫu dùng borderless table.
- [ ] Không sinh chữ ký/dấu giả.
- [ ] Có `audit`, `preview_fix`, `apply_fix`.
- [ ] Mọi auto-fix có change log.
- [ ] Render QA sau sửa.
- [ ] Có rollback/version.
- [ ] Không áp NĐ30 mù quáng lên template chuyên ngành.

---

# 34. Thứ tự triển khai khuyến nghị cho BiddingFlow

## Phase 1 — Detector

Chỉ:
- parse DOCX;
- nhận diện type;
- nhận diện placeholder;
- semantic mapping;
- audit format.

Chưa auto-fix.

## Phase 2 — Safe Auto Fix

Thêm:
- font;
- size;
- bold/italic;
- alignment;
- spacing;
- margin;
- page number.

## Phase 3 — Layout Fix

Thêm:
- header two-column;
- signature/recipient block;
- line rules;
- visual render QA.

## Phase 4 — Specialized Profiles

Thêm:
- template đấu thầu;
- báo cáo đánh giá;
- báo cáo thẩm định;
- quyết định KQLCNT;
- hợp đồng;
- các profile nội bộ.

---

# 35. Quy tắc cuối cùng

1. **Nội dung nghiệp vụ là dữ liệu, không phải thứ để formatter tự sửa.**
2. **Thể thức có thể tự sửa khi rule deterministic và confidence cao.**
3. **Tên riêng và nội dung pháp lý chỉ cảnh báo nếu không đủ chắc chắn.**
4. **Không phá template placeholders để đổi formatting.**
5. **Không tạo một template engine thứ hai.**
6. **Không tạo version engine thứ hai.**
7. **Không coi render thành công là đủ; phải visual QA.**
8. **Không coi mọi Word trong đấu thầu đều là văn bản hành chính thuần túy.**
9. **Mọi sửa đổi phải truy vết được.**
10. **Bản gốc luôn được bảo toàn.**
