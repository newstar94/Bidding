# BiddingFlow Word Standardizer Skill

Gói skill này được xây dựng từ hai tài liệu nguồn người dùng cung cấp:

1. **Nghị định 30/2020/NĐ-CP về công tác văn thư**
2. **Phụ lục kèm Nghị định 30/2020/NĐ-CP**, gồm:
   - Phụ lục I: thể thức và kỹ thuật trình bày;
   - Phụ lục II: viết hoa;
   - Phụ lục III: chữ viết tắt và các mẫu trình bày.

## Nội dung

- `SKILL.md`: hướng dẫn đầy đủ để agent/application thực hiện nhận diện + chuẩn hóa.
- `rules/n30_2020_rules.json`: rule set dạng máy đọc được.
- `schemas/semantic_fields.json`: từ điển semantic field chuẩn.
- `examples/detection-output.example.json`: ví dụ output detector.

## Khuyến nghị triển khai

Bắt đầu bằng **audit-only**, sau đó mới bật safe auto-fix.

Không cho engine tự sửa nội dung nghiệp vụ/pháp lý.
